@echo OFF

set "USER_PROFILE=%USERPROFILE%"
set "TEMP_FILE=%TEMP%\temp_version.txt"

rem Execute mvn help:evaluate and store output in the temporary file
call mvn help:evaluate -Dexpression=library.engine.version -q -DforceStdout > "%TEMP_FILE%"

rem Wait for the file to be created (optional, if needed)
timeout /t 2 /nobreak > nul

rem Read the content of the temporary file to set the VERSION variable

set /p VERSION=<"%TEMP_FILE%"

rem Delete the temp file
del "%TEMP_FILE%"

rem Run the JAR file
java -cp %USER_PROFILE%\.m2\repository\com\acn\ntc\library-zephyr\%VERSION%\library-zephyr-%VERSION%.jar automation.library.zephyr.DeleteFolder


setlocal enableDelayedExpansion
CALL :GetCertArg
CALL :GetPathToEnvironmentConfig
CALL :GetPathToEnvironmentConfigTarget
CALL :GetPathToTestSuites
CALL :GetPathToTestRunners
CALL :GetListOfFilesAsChoiceList %envDirectory% .properties securetext
CALL :GetPathToTechStacks
CALL :GetListOfFilesAsChoiceList %techStackDir% .json
CALL :EnvChoose
EXIT /B 0
:Validation
set /a Valid=0
for /L %%G IN (1,1,%4) DO (
                if [%1]==[%%G] (SET /a Valid=1)
)
if [%Valid%]==[1] (CALL :%2) ELSE (CALL :%3)
EXIT /B 0
:ValidPath
::echo ValidPath
set /a Valid=0
for /L %%G IN (1,1,%4) DO (
    if [%1]==[C:!ListOfPossiblePath[%%G]!!ListOfPossibleFile[%%G]!] (SET /a Valid=1)
)
::echo COMPARE  --- %1 == C:!ListOfPossiblePath[%%G]!!ListOfPossibleFile[%%G]!
cls
if [%Valid%]==[1] (set argDriverPath=-Dcukes.driverPath="%1")
if [%Valid%]==[1] (CALL :%2) ELSE (CALL :%3) ELSE (CALL :%4)
EXIT /B 0
:ListIsEmpty
ECHO There isn't any options in list to choose from, at %~1 %~2...
PAUSE
EXIT

:RecomendationPath
::echo RecomendationPath
echo.
echo Here is some possible executive pathways:
for /L %%G IN (1,1,%IndexListPath%) DO (
                echo C:!ListOfPossiblePath[%%G]!!ListOfPossibleFile[%%G]!
)
echo.
CALL :UserDeterminedPath
EXIT /B 0

:EnvChoose
cls
for /l %%n in (1,1,%IDDoGetListOfFilesExclude%) do (
                set /A count=%%n+1
                echo [%%n] - !filenameExclude[%%n]!
)
if [%IDDoGetListOfFilesExclude%]==[0] (CALL :ListIsEmpty Environment Selection)
set /p UserInputEnv=Choose environment:
Call :Validation %UserInputEnv% BroswerLoc EnvChoose %IDDoGetListOfFilesExclude%
EXIT /B 0

:BroswerLoc
cls
for /l %%n in (1,1,%IDDoGetListOfFiles%) do (
                echo [%%n] - !filename[%%n]!
)
if [%IDDoGetListOfFiles%]==[0] (CALL :ListIsEmpty Browser Location)
set /p UserInputLoc=Choose run location and browser:
::if [!filename[%UserInputLoc%]!]==[LOCAL_CH] (CALL :SetArgumentLOCALCH)
::if [!filename[%UserInputLoc%]!]==[LOCAL_IE] (CALL :SetArgumentLOCALIE)
::if [!filename[%UserInputLoc%]!]==[LOCAL_MSEDGE] (CALL :SetArgumentLOCALMSEDGE)
set techstack=!filename[%UserInputLoc%]!
Call :Validation %UserInputLoc% OptionsSpecifiedPath BroswerLoc %IDDoGetListOfFiles%
EXIT /B 0
:SetArgumentLOCALCH
CALL :GetPathForLocalCH
set argDriverPath=-Dcukes.driverPath=%PathLocalCH%
EXIT /B 0
:SetArgumentLOCALIE
CALL :GetPathForLocalIE
set argDriverPath=-Dcukes.driverPath=%PathLocalIE%
EXIT /B 0
:SetArgumentLOCALMSEDGE
CALL :GetPathForLocalMSEDGE
set argDriverPath=-Dcukes.driverPath=%PathLocalMSEDGE%
EXIT /B 0
:OptionsSpecifiedPath:
set runListFramework[1]=Select the driver from Citi default path
set runListFramework[2]=Select from Driver Framework
set runListFramework[3]=Specified the path by User
set runListFramework[4]=Select the edge driver
cls
for /l %%n in (1,1,4) do (
                echo [%%n] - !runListFramework[%%n]!
)
set /p OptionsAfterTestRunnerInput=Specify a path to the driver executable base on the selection:
cls
Call :Validation %OptionsAfterTestRunnerInput% AfterOptionsSpecifiedPath OptionsAfterTestRunner 4
EXIT /B 0

:AfterOptionsSpecifiedPath:
if [%OptionsAfterTestRunnerInput%]==[1] (CALL :DefaultCitiDriverPath)
if [%OptionsAfterTestRunnerInput%]==[2] (CALL :TestType)
if [%OptionsAfterTestRunnerInput%]==[3] (CALL :UserDeterminedPath)
if [%OptionsAfterTestRunnerInput%]==[4] (CALL :DefaultCitiedgeDriverPath)
CALL :OptionsSpecifiedPath
EXIT /B 0

:DefaultCitiDriverPath
CALL :GetPathDefaultCitiPath
CALL :GetListDefaultPath
for /l %%n in (1,1,%IndexListPathDefault%) do (
                echo [%%n] - !ListOfPossibleFileDefault[%%n]!
)
if [%IndexListPathDefault%]==[0] (CALL :ListIsEmpty Framework Selection)
set /p FrameworkDefaultInput=Select the Citi Default Framework Driver:
set argDriverPath=-Dcukes.driverPath="C:!ListOfPossiblePathDefault[%FrameworkDefaultInput%]!!ListOfPossibleFileDefault[%FrameworkDefaultInput%]!"
Call :Validation %FrameworkDefaultInput% TestType DefaultCitiDriverPath %IndexListPathDefault%
EXIT /B 0

:DefaultCitiedgeDriverPath
CALL :GetPathDefaultCitiedgePath
CALL :GetListDefaultPathnew
for /l %%n in (1,1,%IndexListPathDefault%) do (
                echo [%%n] - !ListOfPossibleFileDefault[%%n]!
)
if [%IndexListPathDefault%]==[0] (CALL :ListIsEmpty Framework Selection)
set /p FrameworkDefaultInput=Select the Citi Default Framework Driver:
set argDriverPath=-Dcukes.driverPath="C:!ListOfPossiblePathDefault[%FrameworkDefaultInput%]!!ListOfPossibleFileDefault[%FrameworkDefaultInput%]!"
Call :Validation %FrameworkDefaultInput% TestType DefaultCitiDriverPath %IndexListPathDefault%
EXIT /B 0

:GetListDefaultPath:
SET UserPath=C:\Program Files (x86)\Selenium Client\Selenium drives\
SET /a IndexListPathDefault=1
for /R "%UserPath%" %%G in (*.exe) do (
    set ListOfPossiblePathDefault[!IndexListPathDefault!]=%%~pG
    set ListOfPossibleFileDefault[!IndexListPathDefault!]=%%~nxG
    set /a IndexListPathDefault+=1
)
set /a IndexListPathDefault-=1
EXIT /B 0

:GetListDefaultPathnew:
SET UserPath=C:\Program Files (x86)\Selenium Client\edge drivers
SET /a IndexListPathDefault=1
for /R "%UserPath%" %%G in (*.exe) do (
    set ListOfPossiblePathDefault[!IndexListPathDefault!]=%%~pG
    set ListOfPossibleFileDefault[!IndexListPathDefault!]=%%~nxG
    set /a IndexListPathDefault+=1
)
set /a IndexListPathDefault-=1
EXIT /B 0

::FrameworkListSelection
::call :DoGetListOfFramework
::cls
::for /l %%n in (1,1,%indexFramework%) do (
::                echo [%%n] - !filenameFramework[%%n]!
::)
::if [%indexFramework%]==[0] (CALL :ListIsEmpty Drivers Selection)
::set /p FrameworkInput=Select the Framework Driver:
::set argDriverPath=!filePathFramework[%FrameworkInput%]!
::Call :Validation %FrameworkInput% TestType FrameworkListSelection %indexFramework%
::EXIT /B 0

:::DoGetListOfFramework
::call :GetPathForFramework
::set /a indexFramework=1
::for /f "tokens=*" %%G in ('DIR -PATH %PathLocalFramework% /s /b /a-d 2^>nul') do (
::                set filenameFramework[!indexFramework!]=%%~nG
::                set filePathFramework[!indexFramework!]=%%G
::                set /a indexFramework+=1
::)
::set /a indexFramework-=1
::EXIT /B 0

:UserDeterminedPath
echo.
echo (eg.: %CD% )
echo.
Set /p UserDriverPath=Input the path way where the Driver is:
FOR %%i in (%UserDriverPath%) do (
	set filedrive=%%~di
	set filepath=%%~pi
	set filename=%%~ni
	set fileextension=%%~xi
)
CALL :GetListOfPath %filedrive%%filepath%
::echo ValidPath %filedrive%%filepath%%filename%%fileextension% TestType RecomendationPath %IndexListPath%
::pause
CALL :ValidPath %filedrive%%filepath%%filename%%fileextension% TestType RecomendationPath %IndexListPath%
EXIT /B 0

:GetListOfPath
SET UserPath=%1
SET /a IndexListPath=1
for /R "%UserPath%" %%G in (*.exe) do (
    set ListOfPossiblePath[!IndexListPath!]=%%~pG
    set ListOfPossibleFile[!IndexListPath!]=%%~nxG
    set /a IndexListPath+=1
)
set /a IndexListPath-=1
if [%indexFolder%]==[0] (CALL :ListIsEmptyPath %UserPath%)
EXIT /B 0

:ListIsEmptyPath
CLS
ECHO There isn't any options in list from the choosen path ( %~1 ), exiting...
PAUSE
EXIT

:TestType
set runList[1]=Test Suite
set runList[2]=Test Runner
cls
for /l %%n in (1,1,2) do (
                echo [%%n] - !runList[%%n]!
)
set /p UserInputRun=What would you like to run?
cls
Call :Validation %UserInputRun% DecisionTest TestType 2
EXIT /B 0

:DecisionTest
if [%UserInputRun%]==[1] (CALL :TestSuite)
if [%UserInputRun%]==[2] (CALL :TestRunner)
EXIT /B 0

:TestSuite
call :GetListOfFilesAsChoiceList %testSuiteDir% .xml
cls
for /l %%n in (1,1,%IDDoGetListOfFiles%) do (
                echo [%%n] - !filename[%%n]!
)
if [%IDDoGetListOfFiles%]==[0] (CALL :ListIsEmpty Test Suite)
set /p TestSuiteSelection=Test Suites:
set cmdTestOption=-Dcukes.testsuite=!filename[%TestSuiteSelection%]!
Call :Validation %TestSuiteSelection% FinalStep TestSuite %IDDoGetListOfFiles%
EXIT /B 0

:TestRunner
call :GetListOfFilesAsChoiceList %testRunnerDir% .java
cls
for /l %%n in (1,1,%IDDoGetListOfFiles%) do (
                echo [%%n] - !filename[%%n]!
)
if [%IDDoGetListOfFiles%]==[0] (CALL :ListIsEmpty Test Runner)
set /p TestRunnerSelection=Test Runners:
set cmdTestOption=-Dtest=!filename[%TestRunnerSelection%]!
Call :Validation %TestRunnerSelection% FinalStep TestRunner %IDDoGetListOfFiles%
EXIT /B 0

:FinalStep
set finalRunCmd=mvn test -q %cmdTestOption% -Dcukes.env=!filenameExclude[%UserInputEnv%]! -Dcukes.techstack=%techstack% -Dcukes.mobiletechstack=%techstack% -Dorg.apache.logging.log4j.level=ERROR -Dorg.slf4j.simpleLogger.log.org.codehaus.mojo=error -Dorg.slf4j.simpleLogger.log.org.apache.maven.plugins=error -Dcukes.leanft.defaultFindRetries=1 -Dcukes.selenium.defaultFindRetries=1 %argDriverPath% %CertArg%
cls
echo %finalRunCmd%
CALL %finalRunCmd%


set "USER_PROFILE=%USERPROFILE%"
set "TEMP_FILE=%TEMP%\temp_version.txt"

rem Execute mvn help:evaluate and store output in the temporary file
call mvn help:evaluate -Dexpression=library.engine.version -q -DforceStdout > "%TEMP_FILE%"

rem Wait for the file to be created (optional, if needed)
timeout /t 2 /nobreak > nul

rem Read the content of the temporary file to set the VERSION variable

set /p VERSION=<"%TEMP_FILE%"

rem Delete the temp file
del "%TEMP_FILE%"
rem Run the JAR file
java -cp %USER_PROFILE%\.m2\repository\com\acn\ntc\library-zephyr\%VERSION%\library-zephyr-%VERSION%.jar automation.library.zephyr.Update_XML

CALL :RunAllureReport
PAUSE
EXIT
:RunAllureReport
echo Generating the Allure Report...
CALL mvn allure:serve %CertArg%
EXIT /B 0
:InValidPath
cls
echo The path that has been provided doesn't contain any driver
call :UserDeterminedPath
PAUSE
EXIT /B 0

:GetListOfFilesAsChoiceList
SET workingDir=%CD%
SET pathToFiles=%workingDir%\%1*%2
if NOT [%3]==[] (CALL :DoGetListOfFilesExclude %pathToFiles% %~3) ELSE (CALL :DoGetListOfFiles %pathToFiles%)
EXIT /B 0

:DoGetListOfFilesExclude
SET excludeVal=%~2
SET pathToFiles=%~1
set /a IDDoGetListOfFilesExclude=1
for /f "tokens=*" %%G in ('DIR -Path %pathToFiles%  /b /a-d 2^>nul ^| find /i /v "securetext" 2^>nul ^| find /i /v "ALM" 2^>nul ^| find /i /v "ZEPHYR" 2^>nul') do (
	set filenameExclude[!IDDoGetListOfFilesExclude!]=%%~nG
	set /a IDDoGetListOfFilesExclude+=1
)
set /a IDDoGetListOfFilesExclude-=1
EXIT /B 0


:DoGetListOfFiles
set /a IDDoGetListOfFiles=1
SET pathToFiles=%~1
for /f "tokens=*" %%G in ('DIR -Path %pathToFiles% /b /a-d 2^>nul') do (
    set filename[!IDDoGetListOfFiles!]=%%~nG
    set /a IDDoGetListOfFiles+=1
)
set /a IDDoGetListOfFiles-=1
EXIT /B 0

:GetPathToEnvironmentConfig
set fileSeparator=\
set envDirectory=src%fileSeparator%test%fileSeparator%resources%fileSeparator%config%fileSeparator%environments%fileSeparator%
EXIT /B 0

:GetPathToEnvironmentConfigTarget
set fileSeparator=\
set envDirectoryTarget=target%fileSeparator%
EXIT /B 0

:GetPathToTechStacks
set fileSeparator=\
set techStackDir=src%fileSeparator%test%fileSeparator%resources%fileSeparator%config%fileSeparator%selenium%fileSeparator%stacks%fileSeparator%
EXIT /B 0

:GetPathToTestSuites
set fileSeparator=\
set testSuiteDir=src%fileSeparator%test%fileSeparator%resources%fileSeparator%testsuites%fileSeparator%
EXIT /B 0

:GetPathToTestRunners
set fileSeparator=\
set testRunnerDir=src%fileSeparator%test%fileSeparator%java%fileSeparator%runners%fileSeparator%
EXIT /B 0

:GetPathForLocalCH
set fileSeparator=\
SET workingDir=%CD%
set PathLocalCH=%workingDir%%fileSeparator%lib%fileSeparator%drivers%fileSeparator%windows%fileSeparator%chromeDriver.exe
EXIT /B 0

:GetPathForLocalMSEDGE
set fileSeparator=\
SET workingDir=%CD%
set PathLocalMSEDGE=C:\Program Files (x86)\Selenium Client\edge drivers\msedgedriver.exe
EXIT /B 0

:GetPathForLocalIE
set fileSeparator=\
SET workingDir=%CD%
set PathLocalIE=%workingDir%%fileSeparator%lib%fileSeparator%drivers%fileSeparator%windows%fileSeparator%IEDriver.exe
EXIT /B 0

:GetPathForFramework
set fileSeparator=\
SET workingDir=%CD%
set PathLocalFramework=%workingDir%%fileSeparator%lib%fileSeparator%drivers%fileSeparator%
EXIT /B 0

:GetPathDefaultCitiedgePath
set fileSeparator=\
set PathLocalFrameworkDefauktCiti=C:%fileSeparator%Program Files (x86)%fileSeparator%Selenium Client%edge drivers
EXIT /B 0

:GetPathDefaultCitiPath
set fileSeparator=\
set PathLocalFrameworkDefauktCiti=C:%fileSeparator%Program Files (x86)%fileSeparator%Selenium Client%fileSeparator%Selenium drives
EXIT /B 0

:GetCertArg
set CertArg=-Djavax.net.ssl.trustStore=c:/certs/cacerts.jks -Djavax.net.ssl.trustStorePassword=changeit
EXIT /B 0

endlocal
