@ECHO OFF
setlocal
set "USER_PROFILE=%USERPROFILE%"

set META_FILE=%USERPROFILE%\.m2\repository\com\acn\ntc\library-engine\maven-metadata-central.xml

for /f "tokens=3 delims=<>" %%a in ('findstr /i "<release>" "%META_FILE%"') do ( set VERSION=%%a)

echo RELEASE_VERSION: %VERSION%

java -cp %USER_PROFILE%\.m2\repository\com\acn\ntc\library-zephyr\%VERSION%\library-zephyr-%VERSION%.jar automation.library.zephyr.ZephyrTest
endlocal