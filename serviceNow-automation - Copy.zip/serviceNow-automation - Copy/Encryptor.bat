@ECHO OFF
title Run Encryptor
java -jar %CD%\lib\runner\Encryptor.jar
PAUSE