package pageobjects;

import automation.library.selenium.core.Element;
import automation.library.selenium.exec.BasePO;
import org.openqa.selenium.By;

import java.io.IOException;

public class TILoginPage extends BasePO {
    private By userName = By.xpath("//input[@formcontrolname = 'username']");
    private By password = By.xpath("//input[@formcontrolname='password']");
    private By submit = By.xpath("//input[@type='submit']");
    private By region = By.xpath("//select[@name = 'country']");
    private By ATMSearch = By.xpath("//label[@class='btn btn-outline-blue btn-xl active-search']");
    private By logOut = By.xpath("//span[text() = 'Log Out']");
    private By menu = By.xpath("//mat-icon[text() = 'menu']");



    public Element userName() throws IOException, InterruptedException {
        return $(userName);
    }

    public Element password() throws IOException, InterruptedException {
        return $(password);
    }
    public Element region() throws IOException, InterruptedException {
        return $(region);
    }

    public Element submit() throws IOException, InterruptedException {
        return $(submit);
    }
    public Element ATMSearch() throws IOException, InterruptedException {
        return $(ATMSearch);
    }
    public Element logOut() throws IOException, InterruptedException {
        return $(logOut);
    }
    public Element menu() throws IOException, InterruptedException {
        return $(menu);
    }
    private By advanceButton = By.xpath("//button[@id='details-button']");
    public Element advanceButton() throws IOException,InterruptedException{
        return $ (advanceButton);
    }
    private By proceedButton = By.xpath("//a[@id='proceed-link']");
    public Element proceedButton() throws IOException,InterruptedException{
        return $ (proceedButton);
    }






}
