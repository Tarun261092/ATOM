package pageobjects.TIPageObject;


import automation.library.selenium.core.Element;
import automation.library.selenium.exec.BasePO;
import org.openqa.selenium.By;

import java.io.IOException;

public class TIHomePage extends BasePO {


    private By terminalIdTI = By.xpath("//input[@name='terminalIds']");
    private By postDateFrom = By.xpath("//input[@id='postDateFrom']");
    private By postDateTo = By.xpath("//input[@id='postDateTo']");
    private By transaction = By.xpath("//input[@id = 'transactions-filter']");
    private By searchButton = By.xpath("//button[@id='search-button']");
    private By cardAndAccountSearch = By.xpath("//label[text() = ' Card and Account Search ']");
    private By result = By.xpath("//tr[@class = 'ng-star-inserted'][2]");
    private By footer = By.xpath("//div[@class = 'footer-container']");
    private By ATMSearch = By.xpath("//label[@class='btn btn-outline-blue btn-xl active-search']");
    private By selectLanguage = By.xpath("//select[@id = 'languageSelect']");
    private By transactionType = By.xpath("//select[@id = 'transactionTypePayment']");
    private By reversalRadioButton = By.xpath("//div[@class = 'form-check form-check-inline radio']");
    private By accountNumber = By.xpath("//input[@id = 'accountNumber']");
    private By cardNumber = By.xpath("//input[@id = 'cardNumber']");
    private By resultBranchNumber = By.xpath("//tbody/tr[@class = 'ng-star-inserted']/td[10]");
    private By resultAccountNumber = By.xpath("//tbody/tr[@class = 'ng-star-inserted']/td[4]");
    private By reversalYes = By.xpath("//input[@id = 'reversalsYes']");
    private By reversalNo = By.xpath("//input[@id = 'reversalsNo']");
    private By settlementsButton = By.xpath("//input[@id = 'settlements-filter']");
    private By settlementTypeBox = By.xpath("//mat-select[@id = 'settlementType']");
    private By getSettlementsDisplayProof = By.xpath("//span[text() = 'Display Proof']");
    private By getSettlementsReleaseInBalance = By.xpath("//span[text() = 'Release In Balance']");
    private By getSettlementsReleaseOutOfBalance = By.xpath("//span[text() = 'Release Out of Balance']");
    private By getSettlementsAddSubCash = By.xpath("//span[text() = 'Add/Subtract Cash']");
    private By forwardPaginationButton = By.xpath("//button[@class = 'page-button'][2]");
    private By backwardPaginationButton = By.xpath("//button[@class = 'page-button'][1]");
    private By resultTerminalID = By.xpath("//tr[@class = 'ng-star-inserted']/td[2]");
    private By resultTransactionType = By.xpath("//tr[@class = 'ng-star-inserted']/td[5]");
    private By resultCardNumber = By.xpath("//tr[@class = 'ng-star-inserted']/td[3]");
    private By errorMessage = By.xpath("//li[text() = 'No matching search results. Please try again']");
//private By errorMessage = By.xpath("//h3[text()='Search failed']");

    private By errorMessageOutRange = By.xpath("//p[@class = 'error-tag date-error ng-star-inserted']");
    private By resultCard = By.xpath("//tr[1][@class = 'ng-star-inserted']");
    private By SGDTransactionAmountCurrency = By.xpath("//div[contains(text(), 'SGD')]");
    private By USDTransactionAmountCurrency = By.xpath("//div[contains(text(), 'USD')]");
    private By HKDTransactionAmountCurrency = By.xpath("//div[contains(text(), 'HKD')]");
private By ExportButton = By.xpath("//button[text()='Export']");
public Element ExportButton() throws IOException, InterruptedException {
        return $(ExportButton);
    }
    public Element HKDTransactionAmountCurrency() throws IOException, InterruptedException {
        return $(HKDTransactionAmountCurrency);
    }
    public Element USDTransactionAmountCurrency() throws IOException, InterruptedException {
        return $(USDTransactionAmountCurrency);
    }
    public Element SGDTransactionAmountCurrency() throws IOException, InterruptedException {
        return $(SGDTransactionAmountCurrency);
    }
    public Element resultCard() throws IOException, InterruptedException {
        return $(resultCard);
    }
    public Element errorMessageOutRange() throws IOException, InterruptedException {
        return $(errorMessageOutRange);
    }
    public Element errorMessage() throws IOException, InterruptedException {
        return $(errorMessage);
    }
    public Element resultCardNumber() throws IOException, InterruptedException {
        return $(resultCardNumber);
    }
    public Element resultTerminalID() throws IOException, InterruptedException {
        return $(resultTerminalID);
    }
    public Element resultTransactionType() throws IOException, InterruptedException {
        return $(resultTransactionType);
    }

    public Element forwardPaginationButton() throws IOException, InterruptedException {
        return $(forwardPaginationButton);
    }
    public Element backwardPaginationButton() throws IOException, InterruptedException {
        return $(backwardPaginationButton);
    }
    public Element getSettlementsDisplayProof() throws IOException, InterruptedException {
        return $(getSettlementsDisplayProof);
    }
    public Element getSettlementsReleaseInBalance() throws IOException, InterruptedException {
        return $(getSettlementsReleaseInBalance);
    }

    public Element getSettlementsReleaseOutOfBalance() throws IOException, InterruptedException {
        return $(getSettlementsReleaseOutOfBalance);
    }
    public Element getSettlementsAddSubCash() throws IOException, InterruptedException {
        return $(getSettlementsAddSubCash);
    }
    public Element settlementTypeBox() throws IOException, InterruptedException {
        return $(settlementTypeBox);
    }
    public Element settlementsButton() throws IOException, InterruptedException {
        return $(settlementsButton);
    }

    public Element reversalYes() throws IOException, InterruptedException {
        return $(reversalYes);
    }
    public Element reversalNo() throws IOException, InterruptedException {
        return $(reversalNo);
    }

    public Element resultAccountNumber() throws IOException, InterruptedException {
        return $(resultAccountNumber);
    }
    public Element resultBranchNumber() throws IOException, InterruptedException {
        return $(resultBranchNumber);
    }

    public Element cardNumber() throws IOException, InterruptedException {
        return $(cardNumber);
    }
    public Element accountNumber() throws IOException, InterruptedException {
        return $(accountNumber);
    }
    public Element reversalRadioButton() throws IOException, InterruptedException {
        return $(reversalRadioButton);
    }
    public Element transactionType() throws IOException, InterruptedException {
        return $(transactionType);
    }
    public Element selectLanguage() throws IOException, InterruptedException {
        return $(selectLanguage);
    }
    public Element ATMSearch() throws IOException, InterruptedException {
        return $(ATMSearch);
    }
    public Element footer() throws IOException, InterruptedException {
        return $(footer);
    }
    public Element terminalIdTI() throws IOException, InterruptedException {
        return $(terminalIdTI);
    }
    public Element result() throws IOException, InterruptedException {
        return $(result);
    }
    public Element postDateFrom() throws IOException, InterruptedException {
        return $(postDateFrom);
    }
    public Element postDateTo() throws IOException, InterruptedException {
        return $(postDateTo);
    }
    public Element transaction() throws IOException, InterruptedException {
        return $(transaction);
    }
    public Element cardAndAccountSearch() throws IOException, InterruptedException {
        return $(cardAndAccountSearch);
    }
    public Element searchButton() throws IOException, InterruptedException {
        return $(searchButton);
    }


}
