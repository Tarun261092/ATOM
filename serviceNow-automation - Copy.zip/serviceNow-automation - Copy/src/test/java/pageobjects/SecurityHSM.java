package pageobjects;

import java.io.IOException;

import org.openqa.selenium.By;
import automation.library.common.TestContext;
import automation.library.selenium.core.Element;
import automation.library.selenium.exec.BasePO;
import java.awt.*;

public class SecurityHSM extends BasePO{
	
	
	//private String customerStateCellName= "//tr[@data-rk='1300001032']/td[text()=' Open consumer with indication']";
	
	/*public  Element customerStateCellName() {
		String cStateName = String.format("%s",TestContext.getInstance().testdataGet("WSID"));
		return $(By.xpath(customerStateCellName.replace("1300001032",cStateName)));
	}*/
	
	private By securityLink= By.xpath("//a/span[text()='Security']");
	
	public Element securityLink() throws IOException, InterruptedException {
		return $(securityLink);}
private By securityLink1= By.xpath("//a/span[text()='Security']");
public Element securityLink1() throws IOException, InterruptedException {
		Thread.sleep(10000);
		return $(securityLink1);}

	private By AdministrationLink= By.xpath("//a/span[text()='Administration']");
	
	public Element AdministrationLink() throws IOException, InterruptedException {
		return $(AdministrationLink);
	}
	
	private By TaskScheduler = By.xpath("//a/span[text()='Task scheduler']");
	public Element TaskScheduler() throws IOException, InterruptedException {
		return $(TaskScheduler);
		}
	
	private By ScheduledTasks = By.xpath("//a/span[text()='Scheduled tasks']");
	public Element ScheduledTasks() throws IOException, InterruptedException {
		return $(ScheduledTasks);
		}
	
	private By TaskFilter= By.xpath("//input[starts-with(@id,'taskPanel:tasksListForm:tasksList:j_id_')]");
	public Element TaskFilter() throws IOException, InterruptedException {
		return $(TaskFilter);
		}

	private By TaskFilter1= By.xpath("//input[@id='taskPanel:tasksListForm:tasksList:j_id_4w:filter']");
	public Element TaskFilter1() throws IOException, InterruptedException {
		return $(TaskFilter1);
		}
	
	private By zoneKeyCleanUpTask= By.xpath("//div[@id='taskPanel:tasksListForm:tasksList_ZoneKeyCleanupTask_checkbox']");
	public Element zoneKeyCleanUpTask() throws IOException, InterruptedException {
		return $(zoneKeyCleanUpTask);
		}

	private By zoneKeyTask= By.xpath("//div[@id='taskPanel:tasksListForm:tasksList_CitiZoneKeyTask_checkbox']");
	public Element zoneKeyTask() throws IOException, InterruptedException {
		return $(zoneKeyTask);
		}

	private By Execute = By.xpath("//button[@id='taskPanel:tasksListForm:tasksList:execute']");
	public Element Execute() throws IOException, InterruptedException {
		return $(Execute);
		}

	private By Yes = By.xpath("//button[@id='confirmDialogForm:confirmYes']");
	public Element Yes() throws IOException, InterruptedException {
		Thread.sleep(2000);
		return $(Yes);
		}

	private By hsmLink = By.xpath("//a/span[text()='HSM']");
	public Element hsmLink() throws IOException, InterruptedException {
		return $(hsmLink);
		}
	private By hsmConfigurationsLabel = By.xpath("//div[text()='HSM Configurations']");
	public Element hsmConfigurationsLabel() throws IOException, InterruptedException {
		return $(hsmConfigurationsLabel);
		}
	private By citi1GreenLight = By.xpath("//tr[@data-ri='0']//i[@class='icon-circle state-green']");
	public Element citi1GreenLight() throws IOException, InterruptedException {
		return $(citi1GreenLight);
		}

	private By citi2GreenLight = By.xpath("//tr[@data-ri='1']//i[@class='icon-circle state-green']");
	public Element citi2GreenLight() throws IOException, InterruptedException {
		return $(citi2GreenLight);
		}
	
	}