package pageobjects;

import java.io.IOException;

import org.openqa.selenium.By;
import automation.library.common.TestContext;
import automation.library.selenium.core.Element;
import automation.library.selenium.exec.BasePO;

public class ZoneKeys extends BasePO{
	
	
	//private String customerStateCellName= "//tr[@data-rk='1300001032']/td[text()=' Open consumer with indication']";
	
	/*public  Element customerStateCellName() {
		String cStateName = String.format("%s",TestContext.getInstance().testdataGet("WSID"));
		return $(By.xpath(customerStateCellName.replace("1300001032",cStateName)));
	}*/
	
	private By securityLink= By.xpath("//a/span[text()='Security']");
	
	public Element securityLink() throws IOException, InterruptedException {
		return $(securityLink);}

	private By ZoneKeys = By.xpath("//a/span[text()='Zone keys']");
	public Element ZoneKeys() throws IOException, InterruptedException {
		return $(ZoneKeys);
		}
	private By Zone_USA = By.xpath("//tr/td[text()='ZONE_USA']");
	public Element Zone_USA() throws IOException, InterruptedException {
		return $(Zone_USA);
		}

	private By Zone_HK = By.xpath("//tr/td[text()='ZONE_HKG']");
	public Element Zone_HK() throws IOException, InterruptedException {
		return $(Zone_HK);
		}

	private By Zone_HKG = By.xpath("//li[text()='ZONE_HKG']");
	public Element Zone_HKG() throws IOException, InterruptedException {
		return $(Zone_HKG);
		}

	private By Create_Zone = By.xpath("//label[text()='-- Create a new Zone --']");
	public Element Create_Zone() throws IOException, InterruptedException {
		return $(Create_Zone);
		}
	
	private By Zone_SG = By.xpath("//tr/td[text()='ZONE_SG']");
	public Element Zone_SG() throws IOException, InterruptedException {
		return $(Zone_SG);
		}

	private By Zone_ARE = By.xpath("//tr/td[text()='ZONE_ARE']");
	public Element Zone_ARE() throws IOException, InterruptedException {
		return $(Zone_ARE);
		}
	private By ZoneKeyOverview = By.xpath("//div[text()='Zone key overview']");
	public Element ZoneKeyOverview() throws IOException, InterruptedException {
		return $(ZoneKeyOverview);
		}

	private By ZPK1 = By.xpath("//tr/td[text()='ZPK1']");
	public Element ZPK1() throws IOException, InterruptedException {
		return $(ZPK1);
		}

	private By ZPK2 = By.xpath("//tr/td[text()='ZPK2']");
	public Element ZPK2() throws IOException, InterruptedException {
		return $(ZPK2);
		}

	private By ZPK3 = By.xpath("//tr/td[text()='ZPK3']");
	public Element ZPK3() throws IOException, InterruptedException {
		return $(ZPK3);
		}

	private By Invalidate = By.xpath("//span[text()='Invalidate']");
	public Element Invalidate() throws IOException, InterruptedException {
		return $(Invalidate);
		}
	private By hsmConfigurationsLabel = By.xpath("//div[text()='HSM Configurations']");
	public Element hsmConfigurationsLabel() throws IOException, InterruptedException {
		return $(hsmConfigurationsLabel);
		}
	private By citi1GreenLight = By.xpath("//tr[@data-ri='0']//i[@class='icon-circle state-green']");
	public Element citi1GreenLight() throws IOException, InterruptedException {
		return $(citi1GreenLight);
		}

	private By citi2GreenLight = By.xpath("//tr[@data-ri='1']//i[@class='icon-circle state-green']");
	public Element citi2GreenLight() throws IOException, InterruptedException {
		return $(citi2GreenLight);
		}
	
	}