package pageobjects.GPMP;

import automation.library.common.TestContext;
import automation.library.selenium.core.Element;
import automation.library.selenium.exec.BasePO;
import org.openqa.selenium.By;

import java.io.IOException;

public class GPMPRiskPage extends BasePO{


    private String customerStateCellName= "//tr[@data-rk='1400001047']/td[text()=' Open consumer with indication']";

    public  Element customerStateCellName() {
        String cStateName = String.format("%s",TestContext.getInstance().testdataGet("WSID"));
        return $(By.xpath(customerStateCellName.replace("1400001047",cStateName)));
    }

    private By circularRisk= By.xpath("// i[@class='lmnicon lmnicon-add-circle-o']/ parent::button// span[contains(text(),'Risk')]");

    public Element circularRisk() throws IOException, InterruptedException {
        return $(circularRisk);}

    private By searchRisk= By.xpath("// section[contains(@class,'treeWrapper')]// input[@placeholder='Search']");

    public Element searchRisk() throws IOException, InterruptedException {
        return $(searchRisk);}

    private By selectRisk= By.xpath("// div[contains(@class,'treeWrapper__body')]// label// child::span[@class='search-highlight']");

    public Element selectRisk() throws IOException, InterruptedException {
        return $(selectRisk);}

    private By addReferenceControl= By.xpath("// button[text()=' Next: Add Reference Control ']");

    public Element addReferenceControl() throws IOException, InterruptedException {
        return $(addReferenceControl);}

    private By reviewRole= By.xpath("// span[@class='lmn-checkbox lmn-mr-0']");

    public Element reviewRole() throws IOException, InterruptedException {
        return $(reviewRole);}

    private By nextReview= By.xpath("// button[text()=' Next: Review ']");

    public Element nextReview() throws IOException, InterruptedException {
        return $(nextReview);}

    private By Save= By.xpath("// button[normalize-space(text())='Save']");

    public Element Save() throws IOException, InterruptedException {
        return $(Save);}

    private By riskAdded= By.xpath("//*[text()=' Risk and Control(s) added successfully. ']");

    public Element riskAdded() throws IOException, InterruptedException {
        return $(riskAdded);}

    private By filterRiskTaxonomy= By.xpath("// button[contains(@class,'lmn-tag lmn-text')]// span[text()='Risk Taxonomy'] | //*[@class='mt-tag-item']/ descendant::span[text()='Risk Taxonomy']");

    public Element filterRiskTaxonomy() throws IOException, InterruptedException {
        return $(filterRiskTaxonomy);}

    private By riskTaxonomyInput= By.xpath("// div[@class='lmn-overlay-container']// input[contains(@class,'lmn-input')]");

    public Element riskTaxonomyInput() throws IOException, InterruptedException {
        return $(riskTaxonomyInput);}

    private By selectAll= By.xpath("// div[contains(@class,'lmn-virtual-scroll-content')]// span[@class='lmn-checkbox']");

    public Element selectAll() throws IOException, InterruptedException {
        return $(selectAll);}

    private By Apply= By.xpath("// div[@class='lmn-overlay-container']// button[text()=' Apply ']");

    public Element Apply() throws IOException, InterruptedException {
        return $(Apply);}

    private By filterStatus= By.xpath("// button[@appendto='body' and @placement='top' and contains(@class, 'lmn-tag-deselected') and span[text()='Status']]");

    public Element filterStatus() throws IOException, InterruptedException {
        return $(filterStatus);}

    private By draftStatus= By.xpath("// label[@class='lmn-selection-control lmn-d-flex' and .// span[@class='lmn-text-truncate' and text()='Draft']]");

    public Element draftStatus() throws IOException, InterruptedException {
        return $(draftStatus);}

    private By activeStatus= By.xpath("// label[@class='lmn-selection-control lmn-d-flex' and .// span[@class='lmn-text-truncate' and text()='Active']]");

    public Element activeStatus() throws IOException, InterruptedException {
        return $(activeStatus);}


    private By reviewAndSubmitRC= By.xpath("//footer[contains(@class,'view-rcm__footer')]//button[text()=' Review & Submit RC ']");

    public Element reviewAndSubmitRC() throws IOException, InterruptedException {
        return $(reviewAndSubmitRC);}

    private By SubmitRC= By.xpath("//footer[contains(@class,'details-wrapper__footer')]//button[text()='Submit RC']");

    public Element SubmitRC() throws IOException, InterruptedException {
        return $(SubmitRC);}

    private By edit= By.xpath("//button[text()=' Edit ']");

    public Element edit() throws IOException, InterruptedException {
        return $(edit);}

    private By deactivateRisk= By.xpath("//button[text()=' Deactivate Risk ']");

    public Element deactivateRisk() throws IOException, InterruptedException {
        return $(deactivateRisk);}

    private By reactivateRationale= By.xpath("//textarea[@placeholder='This is rationale for reactivating the Risk']");

    public Element reactivateRationale() throws IOException, InterruptedException {
        return $(reactivateRationale);}

    private By deactivateRationale= By.xpath("//textarea[@placeholder='This is rationale for deactivating the Risk']");

    public Element deactivateRationale() throws IOException, InterruptedException {
        return $(deactivateRationale);}

    private By confirm= By.xpath("//button[text()=' Confirm ']");

    public Element confirm() throws IOException, InterruptedException {
        return $(confirm);}

    private By logOutDropdown= By.xpath("//a[@audit-event-details='Username Dropdown']");

    public Element logOutDropdown() throws IOException, InterruptedException {
        return $(logOutDropdown);}

    private By logOut= By.xpath("//span[@class='logout-icon']");

    public Element logOut() throws IOException, InterruptedException {
        return $(logOut);}

    private By Tasks= By.xpath("//span[text()='Tasks']");

    public Element Tasks() throws IOException, InterruptedException {
        return $(Tasks);}

    private By Approve= By.xpath("//footer[contains(@class,'review-rcm__footer')]//button[text()=' Approve ']");

    public Element Approve() throws IOException, InterruptedException {
        return $(Approve);}

    private By ReActivate= By.xpath("//button[text()=' Reactivate ']");

    public Element ReActivate() throws IOException, InterruptedException {
        return $(ReActivate);}

    private By GotIt= By.xpath("//button[text()=' OK, got it ']");

    public Element GotIt() throws IOException, InterruptedException {
        return $(GotIt);}

    private By deActivationSuccessfulMessage= By.xpath("//span[text()=' The RC deactivation submitted for approval successfully. ']");

    public Element deActivationSuccessfulMessage() throws IOException, InterruptedException {
        return $(deActivationSuccessfulMessage);}

    private By noResultFound= By.xpath("//div[@class='ag-center-cols-viewport']");

    public Element noResultFound() throws IOException, InterruptedException {
        return $(noResultFound);}

    private By reviewAndApproveDeactivation= By.xpath("//a[text()='Review & Approve RC Deactivation']");

    public Element reviewAndApproveDeactivation() throws IOException, InterruptedException {
        return $(reviewAndApproveDeactivation);}

    private By approve= By.xpath("//button[text()=' Approve ']");

    public Element approve() throws IOException, InterruptedException {
        return $(approve);}

    private By deActivationApprovedMessage= By.xpath("//span[text()=' RC deactivation approved successfully. ']");

    public Element deActivationApprovedMessage() throws IOException, InterruptedException {
        return $(deActivationApprovedMessage);}

    private By viewDetails= By.xpath("//mca-gpmp-prcm-wrapper[2]//button[contains(text(), ' View Details ')]");

    public Element viewDetails() throws IOException, InterruptedException {
        return $(viewDetails);}

    private By RC_submittedForApproval= By.xpath("//span[text()=' RC Submitted for approval successfully. ']");

    public Element RC_submittedForApproval() throws IOException, InterruptedException {
        return $(RC_submittedForApproval);}

    private By reviewAndApproveReactivation= By.xpath("//a[text()='Review & Approve RC Reactivation']");

    public Element reviewAndApproveReactivation() throws IOException, InterruptedException {
        return $(reviewAndApproveReactivation);}

    private By RC_ReactivationApproved= By.xpath("//span[text()=' RC reactivation approved successfully. ']");

    public Element RC_ReactivationApproved() throws IOException, InterruptedException {
        return $(RC_ReactivationApproved);}


































}
