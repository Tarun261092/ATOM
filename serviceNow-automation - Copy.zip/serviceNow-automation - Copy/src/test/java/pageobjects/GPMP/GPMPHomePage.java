package pageobjects.GPMP;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.By;
import automation.library.common.TestContext;
import automation.library.selenium.core.Element;
import automation.library.selenium.exec.BasePO;

public class GPMPHomePage extends BasePO{


    private String customerStateCellName= "//tr[@data-rk='1400001047']/td[text()=' Open consumer with indication']";

    public  Element customerStateCellName() {
        String cStateName = String.format("%s",TestContext.getInstance().testdataGet("WSID"));
        return $(By.xpath(customerStateCellName.replace("1400001047",cStateName)));
    }

    private By advanced = By.xpath("//button[contains(text(),'Advanced')]");
    private By proceedTo = By.xpath("//a[contains(text(),'Proceed to')]");
    public Element advanced() throws IOException, InterruptedException {
        return $(advanced);
    }
    public Element proceedTo() throws IOException, InterruptedException {
        return $(proceedTo);
    }
    private By username= By.xpath("//input[@id='pf.username']");

    public Element username() throws IOException, InterruptedException {
        return $(username);}

    private By password= By.xpath("//input[@id='pf.pass']");

    public Element password() throws IOException, InterruptedException {
        return $(password);}

    private By signOn= By.xpath("//button[@title='Sign On']");

    public Element signOn() throws IOException, InterruptedException {
        return $(signOn);}

    private By MCA= By.xpath("//h6[text()='MCA']");

    public Element MCA() throws IOException, InterruptedException {
        return $(MCA);}

    private By MCA_TS2= By.xpath("//h6[text()='MCA TS2']");

    public Element MCA_TS2() throws IOException, InterruptedException {
        return $(MCA_TS2);}

    private By GPMP_SIT2= By.xpath("//h3[@title='Global Process MCA Profile (GPMP) - SIT2']");

    public Element GPMP_SIT2() throws IOException, InterruptedException {
        return $(GPMP_SIT2);}

    private By GPMP_SIT= By.xpath("//h3[@title='Global Process MCA Profile (GPMP) - SIT']");

    public Element GPMP_SIT() throws IOException, InterruptedException {
        return $(GPMP_SIT);}

    private By searchIcon= By.xpath("//mt-typeahead[contains(@class, 'globalsearch')]");

    public Element searchIcon() throws IOException, InterruptedException {
        return $(searchIcon);}

    private By searchInput= By.xpath("// mt-typeahead[contains(@class, 'globalsearch')]// input");

    public Element searchInput() throws IOException, InterruptedException {
        return $(searchInput);}

    private By firstAvailableRecord= By.xpath("// div[@col-id='gpmpName']// div[@class='cell-value-div tool-tip']// span[1]");

    public Element firstAvailableRecord() throws IOException, InterruptedException {
        return $(firstAvailableRecord);}

    private By manageRC= By.xpath("// button[@mtbutton='ghost' and contains(@class, 'lmn-btn-ghost') and span[text()='Manage RC']]");

    public Element manageRC() throws IOException, InterruptedException {
        return $(manageRC);}


    public void waitForFrame() throws Exception {
        Thread.sleep(20000);
        driver.manage().timeouts().implicitlyWait(Duration.ofMinutes(2));
    }







}
