package pageobjects;

import java.io.IOException;

import org.openqa.selenium.By;
import automation.library.common.TestContext;
import automation.library.selenium.core.Element;
import automation.library.selenium.exec.BasePO;

public class OCMHomePage extends BasePO{
	
	
	private String customerStateCellName= "//tr[@data-rk='1400001047']/td[text()=' Open consumer with indication']";
	
	public  Element customerStateCellName() {
		String cStateName = String.format("%s",TestContext.getInstance().testdataGet("WSID"));
		return $(By.xpath(customerStateCellName.replace("1400001047",cStateName)));
	}
	
	private By periodsSection= By.xpath("//span[text()='Periods']");
	
	public Element periodsSection() throws IOException, InterruptedException {
		return $(periodsSection);}

	}
