package pageobjects;

import java.io.IOException;
import org.openqa.selenium.By;

import automation.library.selenium.core.Element;
import automation.library.selenium.exec.BasePO;

public class OCMLoginPage extends BasePO  {

	private By userName = By.xpath("//input[@id='loginForm:UserName']");
	//private By userName = By.cssSelector("input[type='text']");
	//private By password = By.xpath("//input[@id='loginForm:Password' and type='password']");
	private By password = By.cssSelector("input[type='password']");
	private By signOn = By.xpath("//span[@class='ui-button-text ui-c' and text()='Login']");
		private By advanced = By.xpath("//button[contains(text(),'Advanced')]");
private By proceedTo = By.xpath("//a[contains(text(),'Proceed to')]");

	
	public Element userName() throws IOException, InterruptedException {
		return $(userName);
		}
	
	public Element password() throws IOException, InterruptedException {
		return $(password);
		}
	
	public Element signOn() throws IOException, InterruptedException {
		return $(signOn);
		}
	public Element advanced() throws IOException, InterruptedException {
		return $(advanced);
		}
	public Element proceedTo() throws IOException, InterruptedException {
		return $(proceedTo);
		}

}