package pageobjects.ServiceNowPageObject;


import automation.library.selenium.core.Element;
import automation.library.selenium.exec.BasePO;
import org.openqa.selenium.By;
import org.openqa.selenium.SearchContext;
import org.openqa.selenium.WebElement;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.util.List;

public class BranchLocator extends BasePO {

	private By BranchNumber = By.xpath("//input[@name='FCNum']");
	public Element BranchNumber() throws IOException, InterruptedException {
		return $(BranchNumber);
	}

	private By KnownLocations = By.xpath("//table[@id='KnownBranchesTable']");
	public Element KnownLocations() throws IOException, InterruptedException {
		return $(KnownLocations);
	}

	private By BranchLink = By.xpath("//*[@id=\"KnownBranchesTable\"]/tbody/tr/td[2]/a");
	public Element BranchLink() throws IOException, InterruptedException {
		return $(BranchLink);
	}

	private By SOEID = By.xpath("//*[@id=\"BranchStuff\"]/table[5]/tbody/tr[1]/td[4]/b");
	public Element SOEID() throws IOException, InterruptedException {
		return $(SOEID);
	}

	private By SOEID1 = By.xpath("//*[@id=\"BranchStuff\"]/table[5]/tbody/tr[3]/td[4]/a");
	public Element SOEID1() throws IOException, InterruptedException {
		return $(SOEID1);
	}



	private By StaffList = By.xpath("//*[@id=\"BranchStuff\"]/table[5]");
	public Element StaffList() throws IOException, InterruptedException {
		return $(StaffList);
	}

	private By DLSearchBar = By.xpath("//input[@placeholder='Search for DL by Name']");
	public Element DLSearchBar() throws IOException, InterruptedException {
		return $(DLSearchBar);
	}

	private By DL_URL = By.xpath("//a[@class='Anc-ModifyDL']");
	public Element DL_URL() throws IOException, InterruptedException {
		return $(DL_URL);
	}


	private By DL_Members = By.xpath("//a[contains(text(),'View/Modify DL Members')]");
	public Element DL_Members() throws IOException, InterruptedException {
		return $(DL_Members);
	}

	private By Remove_All = By.xpath("//input[@name='cbRemoveAll']");
	public Element Remove_All() throws IOException, InterruptedException {
		return $(Remove_All);
	}

	private By Submit = By.xpath("//button[text()='Submit']");
	public Element Submit() throws IOException, InterruptedException {
		return $(Submit);
	}

	private By Close = By.xpath("//button[text()='Close']");
	public Element Close() throws IOException, InterruptedException {
		return $(Close);
	}

	private By AddEmail = By.xpath("//input[@name='DLMembers']");
	public Element AddEmail() throws IOException, InterruptedException {
		return $(AddEmail);
	}

	/*private By all = By.className("sn-polaris-tab can-animate polaris-enabled");
	public Element all() throws IOException, InterruptedException
	{
		return $(all);
	}*/
	
	/*public void all() throws Exception
	{
			final JavascriptExecutor js = (JavascriptExecutor) getDriver();
			String all= "document.querySelector(\"body > macroponent-f51912f4c700201072b211d4d8c26010\").shadowRoot.querySelector(\"div > sn-canvas-appshell-root > sn-canvas-appshell-layout > sn-polaris-layout\").shadowRoot.querySelector(\"div.sn-polaris-layout.polaris-enabled > div.layout-main > div.header-bar > sn-polaris-header\").shadowRoot.querySelector(\"#d6e462a5c3533010cbd77096e940dd8c\").click()";
			Thread.sleep(10000);
			Object ob= js.executeScript(all);
		Thread.sleep(10000);
			if(ob!=null)
				throw new Exception("unable to execute process");
		
	}
*/
	public void extracting() throws Exception
	{
		WebElement table = driver.findElement(By.xpath("//*[@id=\"BranchStuff\"]/table[5]"));
		List<WebElement> rows = table.findElements(By.tagName("a"));
		for(int i=0;i<rows.size();i++)
		{
			System.out.println("Data in row "+ rows.get(i).getText());
		}
		driver.get("https://emaildirectorycenter.citigroup.net/VoyagerDLPortal/Home/Index#");
		Thread.sleep(5000);
		driver.findElement(By.xpath("//input[@placeholder='Search for DL by Name']")).sendKeys("*PBWM US ATM-Branch-Test");
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		Thread.sleep(1000);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(3000);
		driver.findElement(By.xpath("//a[@class='Anc-ModifyDL']")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//a[text()='View/Modify DL Members (1) ']")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@name='cbRemoveAll']")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//button[text()='Submit']")).click();
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(3000);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(5000);
		driver.findElement(By.xpath("//a[text()='View/Modify DL Members (1) ']\"")).click();
		Thread.sleep(3000);

		driver.findElement(By.xpath("//input[@name='DLMembers']\"")).sendKeys("TS13842");
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		Thread.sleep(3000);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(3000);
		driver.findElement(By.xpath("//button[text()='Submit']")).click();

	}

	public void SubmitForPopUp() throws Exception
	{
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
	}

	public void EmailEntry() throws Exception
	{
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		Thread.sleep(3000);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
	}



	}

