package pageobjects.ServiceNowPageObject;

import automation.library.selenium.core.Element;
import automation.library.selenium.exec.BasePO;
import org.openqa.selenium.By;

import java.io.IOException;

public class SNOWIntOnboardingRequest extends BasePO {

    /**#########################################################################################################################
     *Elements those are available under "Site Association" inside the Create Asset page are
     * available below
     * ##############################################################################################################
     */

    
    private By currentlyImplementedInFUJI = By.xpath("//span[text()= '-- None --']");
    public Element currentlyImplementedInFUJI() throws IOException, InterruptedException {
        return $(currentlyImplementedInFUJI);
    }

    private By currentlyImplementedInFUJIDropDown = By.xpath("//select[@name = 'country']");
    public Element currentlyImplementedInFUJIDropDown() throws IOException, InterruptedException {
        return $(currentlyImplementedInFUJIDropDown);
    }
    private By businessOwnerOfTheIntegrationField = By.xpath("//input[@aria-label='Who is the business owner of the integration?']");
    public Element businessOwnerOfTheIntegrationField() throws IOException, InterruptedException {
        return $(businessOwnerOfTheIntegrationField);
    }
    private By businessOwnerOfTheIntegrationTextBox = By.xpath("//div[@id='s2id_sp_formfield_business_owner']");
    public Element businessOwnerOfTheIntegrationTextBox() throws IOException, InterruptedException {
        return $(businessOwnerOfTheIntegrationTextBox);
    }
    
  
  private By businessOwnerOfTheIntegration = By.xpath("//input[@class='select2-input select2-active']");
    public Element businessOwnerOfTheIntegration() throws IOException, InterruptedException {
        return $(businessOwnerOfTheIntegration);
    }
    private By businessOwnerOfTheIntegrationName = By.xpath("//div[@class='select2-result-cell']");
    public Element businessOwnerOfTheIntegrationName() throws IOException, InterruptedException {
        return $(businessOwnerOfTheIntegrationName);
    }
  
    private By technicalOwnerOfTheIntegrationField = By.xpath("//input[@aria-label='Who is the technical owner of the integration?']");
    public Element technicalOwnerOfTheIntegrationField() throws IOException, InterruptedException {
        return $(technicalOwnerOfTheIntegrationField);
    }    
    
    private By technicalOwnerOfTheIntegration = By.xpath("//input[@class='select2-input select2-active']");
    public Element technicalOwnerOfTheIntegration() throws IOException, InterruptedException {
        return $(technicalOwnerOfTheIntegration);
    }  
        private By technicalOwnerOfTheIntegrationTextBox = By.xpath("//div[@id='s2id_sp_formfield_technical_owner']");
        public Element technicalOwnerOfTheIntegrationTextBox() throws IOException, InterruptedException {
            return $(technicalOwnerOfTheIntegrationTextBox);
        
    }
        
        private By technicalOwnerOfTheIntegrationName = By.xpath("//div[@class='select2-result-cell']");
        public Element technicalOwnerOfTheIntegrationName() throws IOException, InterruptedException {
            return $(technicalOwnerOfTheIntegrationName);
        }
    private By groupDL = By.xpath("//input[@name='group_dl']");
    public Element groupDL() throws IOException, InterruptedException {
        return $(groupDL);
    }
    private By description = By.xpath("//textarea[@name='please_describe_in_detail_the_integration']");
    public Element description() throws IOException, InterruptedException {
        return $(description);
    }
    private By benefitsOutline = By.xpath("//textarea[@name='outline_benefits']");
    public Element benefitsOutline() throws IOException, InterruptedException {
        return $(benefitsOutline);
    }
    private By applicationModules = By.xpath("//input[@name='modules']");
    public Element applicationModules() throws IOException, InterruptedException {
        return $(applicationModules);
    }

    private By estimatedTime_CostSavings = By.xpath("//textarea[@name='estimated_savings']");
    public Element estimatedTime_CostSavings() throws IOException, InterruptedException {
        return $(estimatedTime_CostSavings);
    }
    private By buinessJustification = By.xpath("//textarea[@name='justification']");
    public Element buinessJustification() throws IOException, InterruptedException {
        return $(buinessJustification);
    }

    private By additionalDetails = By.xpath("//textarea[@name='additional_details']");
    public Element additionalDetails() throws IOException, InterruptedException {
        return $(additionalDetails);
    }
    
    private By addToWishList = By.xpath("//button[@name='add_to_wishlist']");
    public Element addToWishList() throws IOException, InterruptedException {
        return $(addToWishList);
    }
    private By processorManufacturerIntel = By.xpath("//span[text() = 'INTEL']");
    public Element processorManufacturerIntel() throws IOException, InterruptedException {
        return $(processorManufacturerIntel);
    }
    
    private By addedToWishListLabel = By.xpath("//span[text()='Your item has been added to your Wish List.']");
    public Element addedToWishListLabel() throws IOException, InterruptedException {
        return $(addedToWishListLabel);
    }


    private By SearchOpenRequest = By.xpath("//input[@placeholder='Search open requests']");
    public Element SearchOpenRequest() throws IOException, InterruptedException {
        return $(SearchOpenRequest);
    }
    private By Search = By.xpath("//button[@title='Search']");
    public Element Search() throws IOException, InterruptedException {
        return $(Search);
    }
    private By INC = By.xpath("//a[text()=' Test Integration ']");
    public Element INC() throws IOException, InterruptedException {
        return $(INC);
    }

    private By REQ = By.xpath("//a[@title='ServiceNow Integration Onboarding Request']");
    public Element REQ() throws IOException, InterruptedException {
        return $(REQ);
    }

    private By TempAdminREQ = By.xpath("//a[text()=' Temporary Admin Access Request ']");
    public Element TempAdminREQ() throws IOException, InterruptedException {
        return $(TempAdminREQ);
    }
    private By TempAdminREQ1 = By.xpath("//a[text()='Temporary Admin Access Request']");
    public Element TempAdminREQ1() throws IOException, InterruptedException {
        return $(TempAdminREQ1);
    }
    private By REQUEST = By.xpath("//a[text()=' ServiceNow Integration Onboarding Request ']");
    public Element REQUEST() throws IOException, InterruptedException {
        return $(REQUEST);
    }
    private By Contact = By.xpath("//dt[contains(text(),'Contact')]");
    public Element Contact() throws IOException, InterruptedException {
        return $(Contact);
    }

    private By Requested_For = By.xpath("//b[text()=\"Requested For\"]");
    public Element Requested_For() throws IOException, InterruptedException {
        return $(Requested_For);
    }

    private By Business_Justification = By.xpath("//b[text()=\"Business Justification for Access\"]");
    public Element Business_Justification() throws IOException, InterruptedException {
        return $(Business_Justification);
    }
    private By Short_Description = By.xpath("//dt[contains(text(),'Short description')]");
    public Element Short_Description() throws IOException, InterruptedException {
        return $(Short_Description);
    }
    private By Description = By.xpath("//dt[contains(text(),'Description')]");
    public Element Description() throws IOException, InterruptedException {
        return $(Description);
    }
    private By Assignment_Group = By.xpath("//dt[contains(text(),'Assignment group')]");
    public Element Assignment_Group() throws IOException, InterruptedException {
        return $(Assignment_Group);
    }
    private By State = By.xpath("//dt[contains(text(),'State')]");
    public Element State() throws IOException, InterruptedException {
        return $(State);
    }

    private By Created = By.xpath("//dt[contains(text(),'Created')]");
    public Element Created() throws IOException, InterruptedException {
        return $(Created);
    }
    private By Quantity = By.xpath("//dt[contains(text(),'Quantity')]");
    public Element Quantity() throws IOException, InterruptedException {
        return $(Quantity);
    }
    private By Priority = By.xpath("//dt[contains(text(),'Priority')]");
    public Element Priority() throws IOException, InterruptedException {
        return $(Priority);
    }
    private By Updated = By.xpath("//dt[contains(text(),'Updated')]");
    public Element Updated() throws IOException, InterruptedException {
        return $(Updated);
    }
    private By Number = By.xpath("//dt[contains(text(),'Number')]");
    public Element Number() throws IOException, InterruptedException {
        return $(Number);
    }








}
