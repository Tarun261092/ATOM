package pageobjects.ServiceNowPageObject;

import automation.library.selenium.core.Element;
import automation.library.selenium.exec.BasePO;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.SearchContext;

import java.io.IOException;

public class SNOWMainPage extends BasePO {

    /**
     * #########################################################################################################################
     * Elements those are available
     * ##############################################################################################################
     */

    private By RequestSomething = By.xpath("//h2[text()= 'Request Something']");

    public Element RequestSomething() throws IOException, InterruptedException {
        return $(RequestSomething);
    }

    private By Services = By.xpath("//div[text()='Services']");

    public Element Services() throws IOException, InterruptedException {
        return $(Services);
    }

    private By changeDashboard = By.xpath("//button[@data-original-title='Change dashboard']");

    public Element changeDashboard() throws IOException, InterruptedException {
        return $(changeDashboard);
    }

    private By frame1 = By.xpath("//iframe[@class='shimmer']");

    public Element frame1() throws IOException, InterruptedException {
        return $(frame1);
    }

    private By frame2 = By.xpath("//iframe[@title='Main Content']");

    public Element frame2() throws IOException, InterruptedException {
        return $(frame2);
    }


    private By AssignmentGroup = By.xpath("//div[text()='Assignment Group']");

    public Element AssignmentGroup() throws IOException, InterruptedException {
        return $(AssignmentGroup);
    }

    private By prodSupport = By.xpath("//span[text()='Production Support Dashboard']");

    public Element prodSupport() throws IOException, InterruptedException {
        return $(prodSupport);
    }


    private By History = By.xpath("//div[text()='History']");

    public Element History() throws IOException, InterruptedException {
        return $(History);
    }


    private By ServiceNow_Integration_Onboarding_Request = By.xpath("//h3[text()= 'ServiceNow Integration Onboarding Request']");

    public Element ServiceNow_Integration_Onboarding_Request() throws IOException, InterruptedException {
        return $(ServiceNow_Integration_Onboarding_Request);
    }

    private By editAndCancelButton = By.xpath("//button[contains(@id, 'edit-atm-form-button')]");

    public Element editAndCancelButton() throws IOException, InterruptedException {
        return $(editAndCancelButton);
    }


    private By username = By.xpath("document.getElementById('user_name')");

    public Element username() throws IOException, InterruptedException {
        return $(username);
    }

    private By password = By.xpath("//input[@name= 'user_password']");

    public Element password() throws IOException, InterruptedException {
        return $(password);
    }

    private By login = By.xpath("//button[text()= 'Log in']");

    public Element login() throws IOException, InterruptedException {
        return $(login);
    }

    private By MyItems = By.xpath("//*[@id='xd150fd31cb10020000f8d856634c9ce6']/li[3]/a");

    public Element MyItems() throws IOException, InterruptedException {
        return $(MyItems);
    }

    private By KnowledgeBase = By.xpath("//h2[text()= 'Knowledge Base']");

    public Element KnowledgeBase() throws IOException, InterruptedException {
        return $(KnowledgeBase);
    }

    private By How_to_add_file = By.xpath("//a[contains(text(), 'How to')]");

    public Element How_to_add_file() throws IOException, InterruptedException {
        return $(How_to_add_file);
    }

    private By Subscribe = By.xpath("//button[text()= ' Subscribe ']");

    public Element Subscribe() throws IOException, InterruptedException {
        return $(Subscribe);
    }

    private By Actions = By.xpath("//button[text()=  ' Actions ']");

    public Element Actions() throws IOException, InterruptedException {
        return $(Actions);
    }

    private By You_are_now_subscribed = By.xpath("//span[contains(text(), 'You are now subscribed')]");

    public Element You_are_now_subscribed() throws IOException, InterruptedException {
        return $(You_are_now_subscribed);
    }

    private By OpenDropDown = By.xpath("//div[@id='s2id_view']");

    public Element OpenDropDown() throws IOException, InterruptedException {
        return $(OpenDropDown);
    }

    private By username1 = By.xpath("//input[@title='Username']");

    public Element username1() throws IOException, InterruptedException {
        return $(username1);
    }

    private By pwd = By.xpath("//input[@id='password']");

    public Element pwd() throws IOException, InterruptedException {
        return $(pwd);
    }

    private By lgn = By.xpath("//button[@type='submit']");

    public Element lgn() throws IOException, InterruptedException {
        return $(lgn);
    }


    private By view = By.xpath("//select[@id='view']");

    public Element view() throws IOException, InterruptedException {
        return $(view);
    }

    private By helpful = By.xpath("//span[text()='helpful']");

    public Element helpful() throws IOException, InterruptedException {
        return $(helpful);
    }

    private By Helpful = By.xpath("//span[text()='Helpful?']");

    public Element Helpful() throws IOException, InterruptedException {
        return $(Helpful);
    }

    private By RateThisArticle = By.xpath("//span[text()='Rate this article']");

    public Element RateThisArticle() throws IOException, InterruptedException {
        return $(RateThisArticle);
    }
    //SearchContext shdw1 = driver.findElement(By.xpath("//macroponent-f51912f4c700201072b211d4d8c26010")).getShadowRoot();
    //SearchContext d1 = shdw1.findElement(By.cssSelector("div > sn-canvas-appshell-root > sn-canvas-appshell-layout > sn-polaris-layout")).getShadowRoot();
    //SearchContext d2 = d1.findElement(By.cssSelector("div.sn-polaris-layout.polaris-enabled > div.layout-main > div.header-bar > sn-polaris-header")).getShadowRoot();
    //SearchContext d3 = d2.findElement(By.cssSelector("nav > div > sn-polaris-menu:nth-child(1)")).getShadowRoot();


    /*private By Alll = By.xpath("//span[@id='SEISMIC_ARIA_LIVE_REGION_ASSERTIVE']");

    public Element Alll() throws IOException, InterruptedException {
Thread.sleep(5000);
        SearchContext shdw1 = driver.findElement(By.xpath("//macroponent-f51912f4c700201072b211d4d8c26010")).getShadowRoot();
        SearchContext d1 = shdw1.findElement(By.cssSelector("div > sn-canvas-appshell-root > sn-canvas-appshell-layout > sn-polaris-layout")).getShadowRoot();
        SearchContext d2 = d1.findElement(By.cssSelector("div.sn-polaris-layout.polaris-enabled > div.layout-main > div.header-bar > sn-polaris-header")).getShadowRoot();
        d2.findElement(By.cssSelector("#d6e462a5c3533010cbd77096e940dd8c")).click();

       // WebElement All = (WebElement) js.executeScript("return document.querySelector(\"body > macroponent-f51912f4c700201072b211d4d8c26010\").shadowRoot.querySelector(\"div > sn-canvas-appshell-root > sn-canvas-appshell-layout > sn-polaris-layout\").shadowRoot.querySelector(\"div.sn-polaris-layout.polaris-enabled > div.layout-main > div.header-bar > sn-polaris-header\").shadowRoot.querySelector(\"#d6e462a5c3533010cbd77096e940dd8c\")");
       // All.click();
    return $(Alll);
}

    private By Filter = By.xpath("//span[@id='SEISMIC_ARIA_LIVE_REGION_ASSERTIVE']");

    public Element Filter() throws IOException, InterruptedException {
        SearchContext shdw1 = driver.findElement(By.xpath("//macroponent-f51912f4c700201072b211d4d8c26010")).getShadowRoot();
        SearchContext d1 = shdw1.findElement(By.cssSelector("div > sn-canvas-appshell-root > sn-canvas-appshell-layout > sn-polaris-layout")).getShadowRoot();
        SearchContext d2 = d1.findElement(By.cssSelector("div.sn-polaris-layout.polaris-enabled > div.layout-main > div.header-bar > sn-polaris-header")).getShadowRoot();
        SearchContext d3 = d2.findElement(By.cssSelector("nav > div > sn-polaris-menu:nth-child(1)")).getShadowRoot();
        d3.findElement(By.cssSelector("#filter")).sendKeys("Knowledge");
        //d2.findElement(By.cssSelector("#d6e462a5c3533010cbd77096e940dd8c")).click();

        // WebElement All = (WebElement) js.executeScript("return document.querySelector(\"body > macroponent-f51912f4c700201072b211d4d8c26010\").shadowRoot.querySelector(\"div > sn-canvas-appshell-root > sn-canvas-appshell-layout > sn-polaris-layout\").shadowRoot.querySelector(\"div.sn-polaris-layout.polaris-enabled > div.layout-main > div.header-bar > sn-polaris-header\").shadowRoot.querySelector(\"#d6e462a5c3533010cbd77096e940dd8c\")");
        // All.click();
        return $(Filter);
    }*/

    /*private By All = By.xpath("//macroponent-f51912f4c700201072b211d4d8c26010").;
    public Element All() throws IOException, InterruptedException {
        SearchContext shdw1 = driver.findElement(By.xpath("//macroponent-f51912f4c700201072b211d4d8c26010")).getShadowRoot();
        SearchContext d1 = shdw1.findElement(By.cssSelector("div > sn-canvas-appshell-root > sn-canvas-appshell-layout > sn-polaris-layout")).getShadowRoot();
        SearchContext d2 = d1.findElement(By.cssSelector("div.sn-polaris-layout.polaris-enabled > div.layout-main > div.header-bar > sn-polaris-header")).getShadowRoot();
        WebElement All1= d2.findElement(By.cssSelector("#d6e462a5c3533010cbd77096e940dd8c"));
        All1.click();
        return $(All);
    }*/

    /*SearchContext shdw1 = driver.findElement(By.xpath("//macroponent-f51912f4c700201072b211d4d8c26010")).getShadowRoot();
    SearchContext d1 = shdw1.findElement(By.cssSelector("div > sn-canvas-appshell-root > sn-canvas-appshell-layout > sn-polaris-layout")).getShadowRoot();
    SearchContext d2 = d1.findElement(By.cssSelector("div.sn-polaris-layout.polaris-enabled > div.layout-main > div.header-bar > sn-polaris-header")).getShadowRoot();
    //private By All=d2.findElement(By.cssSelector("#d6e462a5c3533010cbd77096e940dd8c"));
    private By All = By.cssSelector("#d6e462a5c3533010cbd77096e940dd8c");
    //private WebElement All=d2.findElement(By.cssSelector("#d6e462a5c3533010cbd77096e940dd8c"));
    //private By All = (By) d2.findElement(By.cssSelector("#d6e462a5c3533010cbd77096e940dd8c"));
    //private By All = ("return document.querySelector(\"body > macroponent-f51912f4c700201072b211d4d8c26010\").shadowRoot.querySelector(\"div > sn-canvas-appshell-root > sn-canvas-appshell-layout > sn-polaris-layout\").shadowRoot.querySelector(\"div.sn-polaris-layout.polaris-enabled > div.layout-main > div.header-bar > sn-polaris-header\").shadowRoot.querySelector(\"#d6e462a5c3533010cbd77096e940dd8c\")");
    public Element All() throws IOException, InterruptedException {
       // d2.findElement(By.cssSelector("#d6e462a5c3533010cbd77096e940dd8c")).click();
        // Thread.sleep(6000);
       // WebElement All = (WebElement) js.executeScript("return document.querySelector(\"body > macroponent-f51912f4c700201072b211d4d8c26010\").shadowRoot.querySelector(\"div > sn-canvas-appshell-root > sn-canvas-appshell-layout > sn-polaris-layout\").shadowRoot.querySelector(\"div.sn-polaris-layout.polaris-enabled > div.layout-main > div.header-bar > sn-polaris-header\").shadowRoot.querySelector(\"#d6e462a5c3533010cbd77096e940dd8c\")");
       // All.click();
        return $(All);
    }*/

    /*private By Profile = (By) js.executeScript(
            "return document.querySelector(\"body > macroponent-f51912f4c700201072b211d4d8c26010\").shadowRoot.querySelector(\"div > sn-canvas-appshell-root > sn-canvas-appshell-layout > sn-polaris-layout\").shadowRoot.querySelector(\"div.sn-polaris-layout.polaris-enabled > div.layout-main > div.header-bar > sn-polaris-header\").shadowRoot.querySelector(\"nav > div > div.ending-header-zone > div.polaris-header-controls > div.utility-menu.can-animate > div > now-avatar\").shadowRoot.querySelector(\"span > span > span > span > span\")");
    public Element Profile() throws InterruptedException {
        return $(Profile);
    }*/
    /*private By All = (WebElement) js.executeScript(
            "return document.querySelector(\"body > macroponent-f51912f4c700201072b211d4d8c26010\").shadowRoot.querySelector(\"div > sn-canvas-appshell-root > sn-canvas-appshell-layout > sn-polaris-layout\").shadowRoot.querySelector(\"div.sn-polaris-layout.polaris-enabled > div.layout-main > div.header-bar > sn-polaris-header\").shadowRoot.querySelector(\"nav > div > div.ending-header-zone > div.polaris-header-controls > div.utility-menu.can-animate > div > now-avatar\").shadowRoot.querySelector(\"span > span > span > span > span\")");
    public Element All() throws IOException, InterruptedException {
        Thread.sleep(8000);
        return $(All);
    }*/




}
