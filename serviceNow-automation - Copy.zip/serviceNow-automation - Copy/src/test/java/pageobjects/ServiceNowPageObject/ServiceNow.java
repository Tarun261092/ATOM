package pageobjects.ServiceNowPageObject;


import automation.library.selenium.core.Element;
import automation.library.selenium.exec.BasePO;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.SearchContext;

import java.io.IOException;

public class ServiceNow extends BasePO {



	/*private By all = By.className("sn-polaris-tab can-animate polaris-enabled");
	public Element all() throws IOException, InterruptedException
	{
		return $(all);
	}*/
	
	/*public void all() throws Exception
	{
			final JavascriptExecutor js = (JavascriptExecutor) getDriver();
			String all= "document.querySelector(\"body > macroponent-f51912f4c700201072b211d4d8c26010\").shadowRoot.querySelector(\"div > sn-canvas-appshell-root > sn-canvas-appshell-layout > sn-polaris-layout\").shadowRoot.querySelector(\"div.sn-polaris-layout.polaris-enabled > div.layout-main > div.header-bar > sn-polaris-header\").shadowRoot.querySelector(\"#d6e462a5c3533010cbd77096e940dd8c\").click()";
			Thread.sleep(10000);
			Object ob= js.executeScript(all);
		Thread.sleep(10000);
			if(ob!=null)
				throw new Exception("unable to execute process");
		
	}
*/
	public void alll() throws Exception
	{
		Thread.sleep(10000);
		SearchContext shdw1 = driver.findElement(By.xpath("//macroponent-f51912f4c700201072b211d4d8c26010")).getShadowRoot();
		SearchContext d1 = shdw1.findElement(By.cssSelector("div > sn-canvas-appshell-root > sn-canvas-appshell-layout > sn-polaris-layout")).getShadowRoot();
		SearchContext d2 = d1.findElement(By.cssSelector("div.sn-polaris-layout.polaris-enabled > div.layout-main > div.header-bar > sn-polaris-header")).getShadowRoot();
		d2.findElement(By.cssSelector("#d6e462a5c3533010cbd77096e940dd8c")).click();
		Thread.sleep(10000);


	}

}