package pageobjects.CMSPageObject;

import automation.library.selenium.core.Element;
import automation.library.selenium.exec.BasePO;
import org.openqa.selenium.By;

import java.io.IOException;

public class CMSDeviceRegistration extends BasePO {
    private By AssetType = By.xpath("//*[@id=\"assetType\"]");
    public Element AssetType() throws IOException, InterruptedException {
        return $(AssetType);
    }
    private By AssetTypeATM = By.xpath("//*[text()=\"ATM\"]");
    public Element AssetTypeATM() throws IOException, InterruptedException {
        return $(AssetTypeATM);
    }
    private By AssetTypeDevice= By.xpath("//*[text()=\"Device\"]");
    public Element AssetTypeDevice() throws IOException, InterruptedException {
        return $(AssetTypeDevice);
    }
    private By Search= By.xpath("//*[text()=\" Search \"]");
    public Element Search() throws IOException, InterruptedException {
        return $(Search);
    }
    private By DeviceRegistration= By.xpath("//*[text()=\" Device Registration \"]");
    public Element DeviceRegistration() throws IOException, InterruptedException {
        return $(DeviceRegistration);
    }

    private By DeviceRegistrationHeader= By.xpath("//*[text()=\"Device Registration\"]");
    public Element DeviceRegistrationHeader() throws IOException, InterruptedException {
        return $(DeviceRegistrationHeader);
    }

    private By FIMP= By.xpath("//*[@id=\"fimp\"]");
    public Element FIMP() throws IOException, InterruptedException {
        return $(FIMP);
    }

    private By FIMPError1= By.xpath("//*[text()=\"Numbers only, Must be 2 characters long\"]");
    public Element FIMPError1() throws IOException, InterruptedException {
        return $(FIMPError1);
    }
    private By FIMPError2= By.xpath("//*[text()=\"Must be 2 characters long\"]");
    public Element FIMPError2() throws IOException, InterruptedException {
        return $(FIMPError2);
    }

    private By BranchCode= By.xpath("//*[@id=\"branchCode\"]");
    public Element BranchCode() throws IOException, InterruptedException {
        return $(BranchCode);
    }

    private By Required= By.xpath("//*[text()=\"Required field\"]");
    public Element Required() throws IOException, InterruptedException {
        return $(Required);
    }
    private By BranchCodeError1= By.xpath("//*[text()=\"Numbers only, Must be 3 characters long\"]");
    public Element BranchCodeError1() throws IOException, InterruptedException {
        return $(BranchCodeError1);
    }
    private By BranchCodeError2= By.xpath("//*[text()=\"Must be 3 characters long\"]");
    public Element BranchCodeError2() throws IOException, InterruptedException {
        return $(BranchCodeError2);
    }
    private By DeviceNumber= By.xpath("//*[@id=\"deviceNumber\"]");
    public Element DeviceNumber() throws IOException, InterruptedException {
        return $(DeviceNumber);
    }
    private By DeviceID= By.xpath("//*[@id=\"deviceId\"]");
    public Element DeviceID() throws IOException, InterruptedException {
        return $(DeviceID);
    }
    private By DeviceNumberError1= By.xpath("//*[text()=\"Numbers only, Must be 3 characters long\"]");
    public Element DeviceNumberError1() throws IOException, InterruptedException {
        return $(DeviceNumberError1);
    }
    private By DeviceNumberError2= By.xpath("//*[text()=\"Must be 3 characters long\"]");
    public Element DeviceNumberError2() throws IOException, InterruptedException {
        return $(DeviceNumberError2);
    }

    private By DeviceType= By.xpath("//*[@id=\"deviceType\"]");
    public Element DeviceType() throws IOException, InterruptedException {
        return $(DeviceType);
    }

    private By NGT= By.xpath("//*[text()=\"NGT\"]");
    public Element NGT() throws IOException, InterruptedException {
        return $(NGT);
    }

    private By NBS= By.xpath("//*[text()=\"NBS\"]");
    public Element NBS() throws IOException, InterruptedException {
        return $(NBS);
    }

    private By SignOnState= By.xpath("//*[@id=\"signOnState\"]");
    public Element SignOnState() throws IOException, InterruptedException {
        return $(SignOnState);
    }

    private By SignOnState_option1= By.xpath("//*[@id=\"signOnState\"]");
    public Element SignOnState_option1() throws IOException, InterruptedException {
        return $(SignOnState_option1);
    }

    private By SignOnState_option2= By.xpath("//*[@id=\"signOnState\"]");
    public Element SignOnState_option2() throws IOException, InterruptedException {
        return $(SignOnState_option1);
    }

    private By TrainingFlagValue= By.xpath("//*[text()=\"Non training Terminal\"]");
    public Element TrainingFlagValue() throws IOException, InterruptedException {
        return $(TrainingFlagValue);
    }


    private By TrainingFlag= By.xpath("//*[@id=\"trainingFlag\"]");
    public Element TrainingFlag() throws IOException, InterruptedException {
        return $(TrainingFlag);
    }

    private By OwningBranch= By.xpath("//*[text()=\"Owning Branch\"]");
    public Element OwningBranch() throws IOException, InterruptedException {
        return $(OwningBranch);
    }
    private By DeviceSearch= By.xpath("//*[text()=\"Device Search\"]");
    public Element DeviceSearch() throws IOException, InterruptedException {
        return $(DeviceSearch);
    }

    private By DeviceIDSearch= By.xpath("//*[@id=\"deviceId\"]");
    public Element DeviceIDSearch() throws IOException, InterruptedException {
        return $(DeviceIDSearch);
    }

    private By FIMPSearch= By.xpath("//*[@id=\"fimp\"]");
    public Element FIMPSearch() throws IOException, InterruptedException {
        return $(FIMPSearch);
    }

    private By BranchCodeSearch= By.xpath("//*[@id=\"branchCode\"]");
    public Element BranchCodeSearch() throws IOException, InterruptedException {
        return $(BranchCodeSearch);
    }

    private By DeviceNumberSearch= By.xpath("//*[@id=\"deviceNumber\"]");
    public Element DeviceNumberSearch() throws IOException, InterruptedException {
        return $(DeviceNumberSearch);
    }

    private By DeviceStatus= By.xpath("//*[@id=\"deviceStatus\"]");
    public Element DeviceStatus() throws IOException, InterruptedException {
        return $(DeviceStatus);
    }

    private By DeviceIDSearchError1= By.xpath("//*[text()=\" Can't contain symbols or spaces\"]");
    public Element DeviceIDSearchError1() throws IOException, InterruptedException {
        return $(DeviceIDSearchError1);
    }

    private By DeviceIDSearchError2= By.xpath("//*[text()=\" Can't be larger than 14 digits\"]");
    public Element DeviceIDSearchError2() throws IOException, InterruptedException {
        return $(DeviceIDSearchError2);
    }

    private By SearchButton= By.xpath("//*[text()=\"Search\"]/parent::button");
    public Element SearchButton() throws IOException, InterruptedException {
        return $(SearchButton);
    }

    private By DeviceIDValue= By.xpath("//*[text()=\"B9955500000300\"]");
    public Element DeviceIDValue() throws IOException, InterruptedException {
        return $(DeviceIDValue);
    }

    private By FIMPSearchError1= By.xpath("//*[text()=\" Numbers only\"]");
    public Element FIMPSearchError1() throws IOException, InterruptedException {
        return $(FIMPSearchError1);
    }

    private By FIMPSearchError2= By.xpath("//*[text()=\" Can't be larger than 2 digits\"]");
    public Element FIMPSearchError2() throws IOException, InterruptedException {
        return $(FIMPSearchError2);
    }

    private By FIMPValue= By.xpath("(//*[text()=\"11\"])[1]");
    public Element FIMPValue() throws IOException, InterruptedException {
        return $(FIMPValue);
    }
    private By BranchCodeSearchError1= By.xpath("//*[text()=\" Numbers only\"]");
    public Element BranchCodeSearchError1() throws IOException, InterruptedException {
        return $(BranchCodeSearchError1);
    }

    private By BranchCodeSearchError2= By.xpath("//*[text()=\" Numbers only, Can't be larger than 3 digits\"]");
    public Element BranchCodeSearchError2() throws IOException, InterruptedException {
        return $(BranchCodeSearchError2);
    }

    private By NoMatch= By.xpath("//*[text()=\"No matching search results\"]");
    public Element NoMatch() throws IOException, InterruptedException {
        return $(NoMatch);
    }

    private By BranchCodeValidMatch= By.xpath("(//*[text()=\"123\"])[1]");
    public Element BranchCodeValidMatch() throws IOException, InterruptedException {
        return $(BranchCodeValidMatch);
    }
    private By DeviceNumberSearchError1= By.xpath("//*[text()=\" Numbers only\"]");
    public Element DeviceNumberSearchError1() throws IOException, InterruptedException {
        return $(DeviceNumberSearchError1);
    }
    private By DeviceNumberSearchError2= By.xpath("//*[text()=\" Numbers only, Can't be larger than 3 digits\"]");
    public Element DeviceNumberSearchError2() throws IOException, InterruptedException {
        return $(DeviceNumberSearchError2);
    }

    private By DeviceNumberValidMatch= By.xpath("(//*[text()=\"300\"])[1]");
    public Element DeviceNumberValidMatch() throws IOException, InterruptedException {
        return $(DeviceNumberValidMatch);
    }

    private By DeviceStatusActive= By.xpath("//*[text()=\"ACTIVE\"]");
    public Element DeviceStatusActive() throws IOException, InterruptedException {
        return $(DeviceStatusActive);
    }

    private By DeviceStatusInActive= By.xpath("(//*[text()=\"300\"])[1]");
    public Element DeviceStatusInActive() throws IOException, InterruptedException {
        return $(DeviceStatusInActive);
    }

    private By DeviceStatusDeleted= By.xpath("(//*[text()=\"300\"])[1]");
    public Element DeviceStatusDeleted() throws IOException, InterruptedException {
        return $(DeviceStatusDeleted);
    }


}
