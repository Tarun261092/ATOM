package pageobjects.CMSPageObject;

import automation.library.selenium.core.Element;
import automation.library.selenium.exec.BasePO;
import org.openqa.selenium.By;

import java.io.IOException;

public class CMSSearch extends BasePO {
    private By AssetSearch = By.xpath("(//*[text()=\"Asset Search\"])[1]");
    public Element AssetSearch() throws IOException, InterruptedException {
        return $(AssetSearch);
    }
    private By LocationSearch = By.xpath("(//*[text()=\"Location Search\"])[1]");
    public Element LocationSearch() throws IOException, InterruptedException {
        return $(LocationSearch);
    }

    private By SiteSearch = By.xpath("(//*[text()=\"Site Search\"])[1]");
    public Element SiteSearch() throws IOException, InterruptedException {
        return $(SiteSearch);
    }

    private By AssetID = By.xpath("//*[@id=\"assetId\"]");
    public Element AssetID() throws IOException, InterruptedException {
        return $(AssetID);
    }

    private By ATMNum = By.xpath("//*[@id=\"atmNodeId\"]");
    public Element ATMNum() throws IOException, InterruptedException {
        return $(ATMNum);
    }

    private By TerminalID = By.xpath("//*[@id=\"terminalId\"]");
    public Element TerminalID() throws IOException, InterruptedException {
        return $(TerminalID);
    }

    private By Status = By.xpath("//*[@id=\"status\"]");
    public Element Status() throws IOException, InterruptedException {
        return $(Status);
    }

    private By Model = By.xpath("//*[@id=\"model\"]");
    public Element Model() throws IOException, InterruptedException {
        return $(Model);
    }

    private By SerialNumber = By.xpath("//*[@id=\"serialNumber\"]");
    public Element SerialNumber() throws IOException, InterruptedException {
        return $(SerialNumber);
    }

    private By MacAddress = By.xpath("//*[@id=\"macAddress\"]");
    public Element MacAddress() throws IOException, InterruptedException {
        return $(MacAddress);
    }

    private By LocationID = By.xpath("//*[@id=\"locationId\"]");
    public Element LocationID() throws IOException, InterruptedException {
        return $(LocationID);
    }

    private By LocationDescription = By.xpath("//*[@id=\"locationDescription\"]");
    public Element LocationDescription() throws IOException, InterruptedException {
        return $(LocationDescription);
    }

    private By LocationStatus = By.xpath("//*[@formcontrolname=\"locationStatus\"]");
    public Element LocationStatus() throws IOException, InterruptedException {
        return $(LocationStatus);
    }

    private By SiteNumber = By.xpath("//*[@formcontrolname=\"siteNumber\"]");
    public Element SiteNumber() throws IOException, InterruptedException {
        return $(SiteNumber);
    }

    private By SiteDescription = By.xpath("//*[@formcontrolname=\"siteDescription\"]");
    public Element SiteDescription() throws IOException, InterruptedException {
        return $(SiteDescription);
    }

    private By SiteStatus = By.xpath("//*[@formcontrolname=\"siteStatus\"]");
    public Element SiteStatus() throws IOException, InterruptedException {
        return $(SiteStatus);
    }

    private By CommonFC = By.xpath("//*[@formcontrolname=\"commonFC\"]");
    public Element CommonFC() throws IOException, InterruptedException {
        return $(CommonFC);
    }

    private By Search = By.xpath("//*[text()=\"Search\"]");
    public Element Search() throws IOException, InterruptedException {
        return $(Search);
    }

    private By AssetSearchPopup = By.xpath("//*[@role=\"dialog\"]");
    public Element AssetSearchPopup() throws IOException, InterruptedException {
        return $(AssetSearchPopup);
    }
    private By AssetIDSearchResult = By.xpath("//*[contains(text(),'DN200')]");
    public Element AssetIDSearchResult() throws IOException, InterruptedException {
        return $(AssetIDSearchResult);
    }

private By AssetIDSearchResultSG = By.xpath("//*[contains(text(),'BSG01')]");
public Element AssetIDSearchResultSG() throws IOException, InterruptedException {
    return $(AssetIDSearchResultSG);
}

    private By AssetIDErrorMessage = By.xpath("//*[text()=\" Numbers only\"]");
    public Element AssetIDErrorMessage() throws IOException, InterruptedException {
        return $(AssetIDErrorMessage);
    }

    private By AssetIDErrorPopup = By.xpath("//*[text()=\"Invalid Search\"]");
    public Element AssetIDErrorPopup() throws IOException, InterruptedException {
        return $(AssetIDErrorPopup);
    }
    private By SearchResultSerialNumber = By.xpath("(//*[text()=' 2312345667 '])[1]");
    public Element SearchResultSerialNumber() throws IOException, InterruptedException {
        return $(SearchResultSerialNumber);
    }
    private By SearchResultMACaddress = By.xpath("(//*[text()=\" aa-aa-aa-aa-aa-aa \"])[1]");
    public Element SearchResultMACaddress() throws IOException, InterruptedException {
        return $(SearchResultMACaddress);
    }
    private By MACAddressErrorMessage = By.xpath("//*[text()=\" Please enter a valid MAC Address\"]");
    public Element MACAddressErrorMessage() throws IOException, InterruptedException {
        return $(MACAddressErrorMessage);
    }

    private By LocationIDResult = By.xpath("//*[text()=\" 102513 \"]");
    public Element LocationIDResult() throws IOException, InterruptedException {
        return $(LocationIDResult);
    }


    private By LocationIDResultSG = By.xpath("//*[text()=\" 100802 \"]");
    public Element LocationIDResultSG() throws IOException, InterruptedException {
        return $(LocationIDResultSG);
    }

    private By SearchDescriptionResult = By.xpath("//*[contains(text(),\" Test \")]");
    public Element SearchDescriptionResult() throws IOException, InterruptedException {
        return $(SearchDescriptionResult);
    }
    private By LocationActive = By.xpath("//*[text()=\"ACTIVE\"]");
    public Element LocationActive() throws IOException, InterruptedException {
        return $(LocationActive);
    }

    private By LocationInActive = By.xpath("//*[text()=\"INACTIVE\"]");
    public Element LocationInActive() throws IOException, InterruptedException {
        return $(LocationInActive);
    }

    private By LocationStatusResults = By.xpath("//*[@id=\"location-search-results-table\"]");
    public Element LocationStatusResults() throws IOException, InterruptedException {
        return $(LocationStatusResults);
    }

    private By LocationIDErrorMessage = By.xpath("//*[text()=\"Numbers only\"]");
    public Element LocationIDErrorMessage() throws IOException, InterruptedException {
        return $(LocationIDErrorMessage);
    }

    private By LocationIDErrorPopup = By.xpath("//*[text()=\"Location ID Invalid\"]");
    public Element LocationIDErrorPopup() throws IOException, InterruptedException {
        return $(LocationIDErrorPopup);
    }

    private By SiteNumberErrorMessage = By.xpath("//*[text()=\"Numbers only, Must be 3 digits\"]");
    public Element SiteNumberErrorMessage() throws IOException, InterruptedException {
        return $(SiteNumberErrorMessage);
    }

    private By SiteNumberErrorMessage2Digit = By.xpath("//*[text()='Site Number must be a 2 digit numeric value']");
    public Element SiteNumberErrorMessage2Digit() throws IOException, InterruptedException {
        return $(SiteNumberErrorMessage2Digit);
    }

    private By SiteNumberErrorPopup = By.xpath("//*[text()=\"Site Number Invalid\"]");
    public Element SiteNumberErrorPopup() throws IOException, InterruptedException {
        return $(SiteNumberErrorPopup);
    }
    private By SiteNumberResults = By.xpath("//*[text()=\" 087 \"]");
    public Element SiteNumberResults() throws IOException, InterruptedException {
        return $(SiteNumberResults);
    }

    private By SiteNumberResultsSG = By.xpath("//*[text()=\" 12 \"]");
    public Element SiteNumberResultsSG() throws IOException, InterruptedException {
        return $(SiteNumberResultsSG);
    }
    private By SiteReturnToSearchResults = By.xpath("//*[text()=\"Return to Search Results\"]");
    public Element SiteReturnToSearchResults() throws IOException, InterruptedException {
        return $(SiteReturnToSearchResults);
    }
    private By SiteEditButton = By.xpath("//*[text()=\"Edit\"]");
    public Element SiteEditButton() throws IOException, InterruptedException {
        return $(SiteEditButton);
    }
    private By SiteCancelButton = By.xpath("//*[text()=\"Cancel\"]");
    public Element SiteCancelButton() throws IOException, InterruptedException {
        return $(SiteCancelButton);
    }
    private By SaveSiteButton = By.xpath("//*[@id=\"submit-site-form-button\"]");
    public Element SaveSiteButton() throws IOException, InterruptedException {
        return $(SaveSiteButton);
    }

    private By ConfirmationOKButton = By.xpath("//*[text()=\" OK \"]");
    public Element ConfirmationOKButton() throws IOException, InterruptedException {
        return $(ConfirmationOKButton);
    }

    private By SummaryScreen = By.xpath("//*[text()=\"Your changes have been saved!\"]");
    public Element SummaryScreen() throws IOException, InterruptedException {
        return $(SummaryScreen);
    }

    private By ConfirmationCancelButton = By.xpath("//*[text()=\" Cancel \"]");
    public Element ConfirmationCancelButton() throws IOException, InterruptedException {
        return $(ConfirmationCancelButton);
    }

    private By NoMatchPopup = By.xpath("//*[text()=\"No matching search results\"]");
    public Element NoMatchPopup() throws IOException, InterruptedException {
        return $(NoMatchPopup);
    }
    private By SiteDescriptionError = By.xpath("//*[text()=\"Can't be larger than 50 characters\"]");
    public Element SiteDescriptionError() throws IOException, InterruptedException {
        return $(SiteDescriptionError);
    }

    private By SearchResultTable = By.xpath("//*[@id=\"atm-search-results-table\"]");
    public Element SearchResultTable() throws IOException, InterruptedException {
        return $(SearchResultTable);
    }
    private By SiteStatusActive = By.xpath("//*[text()=\"ACTIVE\"]");
    public Element SiteStatusActive() throws IOException, InterruptedException {
        return $(SiteStatusActive);
    }
    private By SiteStatusInActive = By.xpath("//*[text()=\"INACTIVE\"]");
    public Element SiteStatusInActive() throws IOException, InterruptedException {
        return $(SiteStatusInActive);
    }
    private By ActiveResults = By.xpath("(//*[text()=\" ACTIVE \"])[1]");
    public Element ActiveResults() throws IOException, InterruptedException {
        return $(ActiveResults);
    }
    private By InActiveResults = By.xpath("(//*[text()=\" INACTIVE \"])[1]");
    public Element InActiveResults() throws IOException, InterruptedException {
        return $(InActiveResults);
    }
    private By CommonFCResults = By.xpath("(//*[text()=\" 1 \"])[1]");
    public Element CommonFCResults() throws IOException, InterruptedException {
        return $(CommonFCResults);
    }

    private By SummaryScreenOKButton = By.xpath("//*[text()=\"OK\"]");
    public Element SummaryScreenOKButton() throws IOException, InterruptedException {
        return $(SummaryScreenOKButton);
    }

}
