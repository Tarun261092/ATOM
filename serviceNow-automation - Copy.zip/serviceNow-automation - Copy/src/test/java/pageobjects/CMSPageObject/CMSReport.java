package pageobjects.CMSPageObject;

import automation.library.selenium.core.Element;
import automation.library.selenium.exec.BasePO;
import org.openqa.selenium.By;

import java.io.IOException;

public class CMSReport extends BasePO {
    private By terminalMetadata = By.xpath("//*[text()=\"Terminal MetaData \"]");
    public Element terminalMetadata() throws IOException, InterruptedException {
        return $(terminalMetadata);
    }

    private By terminalRegistration = By.xpath("//*[text()=\"Terminal Registration \"]");
    public Element terminalRegistration() throws IOException, InterruptedException {
        return $(terminalRegistration);
    }
    private By terminalMetadataHeader = By.xpath("//*[text()=\"Terminal Metadata Report\"]");
    public Element terminalMetadataHeader() throws IOException, InterruptedException {
        return $(terminalMetadataHeader);
    }

    private By downloadReport = By.xpath("//*[text()=\" Download Report \"]");
    public Element downloadReport() throws IOException, InterruptedException {
        return $(downloadReport);
    }


    private By ATMNodeId = By.xpath("//input[@id=\"atmNodeId\"]");
    public Element ATMNodeId() throws IOException, InterruptedException {
        return $(ATMNodeId);
    }

    private By FromDate = By.xpath("//input[@id=\"postDateFrom\"]");
    public Element FromDate() throws IOException, InterruptedException {
        return $(FromDate);
    }

    private By ToDate = By.xpath("//input[@id=\"postDateTo\"]");
    public Element ToDate() throws IOException, InterruptedException {
        return $(ToDate);
    }
    private By Search = By.xpath("//*[text()=\"Search\"]");
    public Element Search() throws IOException, InterruptedException {
        return $(Search);
    }
    private By SearchResults = By.xpath("//tbody[@role=\"rowgroup\"]");
    public Element SearchResults() throws IOException, InterruptedException {
        return $(SearchResults);
    }
    private By FromDateRequired = By.xpath("(//*[text()=\"Required field\"])[1]");
    public Element FromDateRequired() throws IOException, InterruptedException {
        return $(FromDateRequired);
    }
    private By ToDateRequired = By.xpath("(//*[text()=\"Required field\"])[2]");
    public Element ToDateRequired() throws IOException, InterruptedException {
        return $(ToDateRequired);
    }
    private By FromDateasterisk = By.xpath("(//*[text()=\" *\"])[1]");
    public Element FromDateasterisk() throws IOException, InterruptedException {
        return $(FromDateasterisk);
    }
    private By ToDateasterisk = By.xpath("(//*[text()=\" *\"])[2]");
    public Element ToDateasterisk() throws IOException, InterruptedException {
        return $(ToDateasterisk);
    }


}
