package pageobjects.CMSPageObject;

import automation.library.selenium.core.Element;
import automation.library.selenium.exec.BasePO;
import org.openqa.selenium.By;

import java.io.IOException;

public class CMSBulkuploadPage extends BasePO {
    private By terminal = By.xpath("//*[text()=\" Terminal \"]");
    public Element terminal() throws IOException, InterruptedException {
        return $(terminal);
    }

    private By bulkuploadheader = By.xpath("//*[text()=\"Bulk Upload\"]");
    public Element bulkuploadheader() throws IOException, InterruptedException {
        return $(bulkuploadheader);
    }
    private By nextgen = By.xpath("//*[text()=\"NextGen Migration\"]");
    public Element nextgen() throws IOException, InterruptedException {
        return $(nextgen);
    }


    private By location = By.xpath("//*[text()=\" Location \"]");
    public Element location() throws IOException, InterruptedException {
        return $(location);
    }
    private By site = By.xpath("//*[text()=\" Site \"]");
    public Element site() throws IOException, InterruptedException {
        return $(site);
    }

    private By chooseFile = By.xpath("(//*[text()=\"Choose File \"])[1]");
    public Element chooseFile() throws IOException, InterruptedException {
        return $(chooseFile);
    }
    private By submit = By.xpath("(//*[text()=\"Submit \"])[1]");
    public Element submit() throws IOException, InterruptedException {
        return $(submit);
    }

    private By chooseFileNextgen = By.xpath("(//*[text()=\"Choose File \"])[2]");
    public Element chooseFileNextgen() throws IOException, InterruptedException {
        return $(chooseFileNextgen);
    }

    private By submitNextgen = By.xpath("//*[text()=\" Submit \"]");
    public Element submitNextgen() throws IOException, InterruptedException {
        return $(submitNextgen);
    }

}
