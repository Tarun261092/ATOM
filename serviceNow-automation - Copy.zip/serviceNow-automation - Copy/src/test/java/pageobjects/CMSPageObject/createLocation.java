package pageobjects.CMSPageObject;

import automation.library.selenium.core.Element;
import automation.library.selenium.exec.BasePO;
import org.openqa.selenium.By;

import java.io.IOException;

public class createLocation extends BasePO {
   
    private By locationName = By.xpath("//span[text() = 'BRANCH']");

    public Element locationName() throws IOException, InterruptedException {
        return $(locationName);
    }

    private By locationName2 = By.xpath("//input[@formcontrolname='locationName']");

    public Element locationName2() throws IOException, InterruptedException {
        return $(locationName2);
    }

    private By errorMessageCostCenter = By.xpath("(//mat-error[text()= 'Numbers only'])[1]");

    public Element errorMessageCostCenter() throws IOException, InterruptedException {
        return $(errorMessageCostCenter);
    }

    private By errorMessage = By.xpath("//mat-error[contains(@class, 'mat-error ng-tns-c91')]");

    public Element errorMessage() throws IOException, InterruptedException {
        return $(errorMessage);
    }

    private By errorMessageZIP = By.xpath("//mat-error[text()='Must be 5 digits']");

    public Element errorMessageZIP() throws IOException, InterruptedException {
        return $(errorMessageZIP);
    }

    private By errorMessageZIPSG = By.xpath("//mat-error[text()='Must be 6 digits']");

    public Element errorMessageZIPSG() throws IOException, InterruptedException {
        return $(errorMessageZIPSG);
    }

    private By errorMessageFIID = By.xpath("//mat-error[contains(text(), 'Must be')]");

    public Element errorMessageFIID() throws IOException, InterruptedException {
        return $(errorMessageFIID);
    }

    private By locationName1 = By.xpath("//mat-select[@formcontrolname = 'locationType']");

    public Element locationName1() throws IOException, InterruptedException {
        return $(locationName1);
    }


    private By description = By.xpath("//input[@id='mat-input-4']");
    public Element description() throws IOException, InterruptedException {
        return $(description);
    }

    private By locationStatus = By.xpath("//mat-select[@formcontrolname = 'locationStatus']");
    public Element locationStatus() throws IOException, InterruptedException {
        return $(locationStatus);

           }

    private By ActiveLocationStatus = By.xpath("//span[text() = 'ACTIVE']");
    public Element ActiveLocationStatus() throws IOException, InterruptedException {
        return $(ActiveLocationStatus);

    }
    private By costCenter = By.xpath("//input[@formcontrolname = 'costCenter']");
    public Element costCenter() throws IOException, InterruptedException {
        return $(costCenter);

    }
    private By FIID = By.xpath("//input[@formcontrolname = 'fiid']");
    public Element FIID() throws IOException, InterruptedException {
        return $(FIID);

    }
    private By streetAddress = By.xpath("//input[@formcontrolname='address']");
    public Element streetAddress() throws IOException, InterruptedException {
        return $(streetAddress);

    }
    private By city = By.xpath("//input[@formcontrolname='city']");
    public Element city() throws IOException, InterruptedException {
        return $(city);

    }
    private By stateBox = By.xpath("//mat-select[@formcontrolname= 'state']");
    public Element stateBox() throws IOException, InterruptedException {
        return $(stateBox);

    }
    private By state = By.xpath("//mat-select[@formcontrolname= 'state']");
    public Element state() throws IOException, InterruptedException {
        return $(state);

    }
    //span[text() = 'KY']
    private By stateKY = By.xpath("//span[text() = 'KY']");
    public Element stateKY() throws IOException, InterruptedException {
        return $(stateKY);

    }
    private By zipCode = By.xpath("//input[@formcontrolname= 'zip']");
    public Element zipCode() throws IOException, InterruptedException {
        return $(zipCode);

    }

    private By countryCode = By.xpath("//input[@formcontrolname= 'countryCode']");
    public Element countryCode() throws IOException, InterruptedException {
        return $(countryCode);

    }
    //countryCode  locationPhone
    private By phoneNumber = By.xpath("//input[@formcontrolname= 'locationPhone']");
    public Element phoneNumber() throws IOException, InterruptedException {
        return $(phoneNumber);

    }
    private By dayLightSavingBox = By.xpath("//mat-select[@formcontrolname= 'dst']");
    public Element dayLightSavingBox() throws IOException, InterruptedException {
        return $(dayLightSavingBox);

    }
    private By dayLightSaving = By.xpath("//span[text() = 'YES']");
    public Element dayLightSaving() throws IOException, InterruptedException {
        return $(dayLightSaving);

    }

    private By businessSegmentBox = By.xpath("//mat-select[@formcontrolname = 'businessSegmentCode']");
    public Element businessSegmentBox() throws IOException, InterruptedException {
        return $(businessSegmentBox);

    }
    private By businessSegmentCode = By.xpath("//div[@role = 'listbox']");
    public Element businessSegmentCode() throws IOException, InterruptedException {
        return $(businessSegmentCode);

    }
    private By saveLocationButton = By.xpath("//span[text() = 'Save Location']");
    public Element saveLocationButton() throws IOException, InterruptedException {
        return $(saveLocationButton);

    }
    ////mat-select[@formcontrolname= 'timeZone']

    private By timeZoneBox = By.xpath("//mat-select[@formcontrolname= 'timeZone']/div/div[2]");
    public Element timeZoneBox() throws IOException, InterruptedException {
        return $(timeZoneBox);

    }
    private By timeZoneList = By.xpath("//span[text() = 'UTC-05:00 (ET)']");
    public Element timeZoneList() throws IOException, InterruptedException {
        return $(timeZoneList);

    }
    private By timeZoneET = By.xpath("//span[text() = 'UTC-05:00 (ET)']");
    public Element timeZoneET() throws IOException, InterruptedException {
        return $(timeZoneET);

    }
    private By confirmOKButton = By.xpath("//span[text() = ' OK ']");
    public Element confirmOKButton() throws IOException, InterruptedException {
        return $(confirmOKButton);

    }
    private By confirmText = By.xpath("//span[text() = 'Your changes have been saved!']");
    public Element confirmText() throws IOException, InterruptedException {
        return $(confirmText);

    }
    private By errorText = By.xpath("//h3[contains(text(), 'The following ')]");
    public Element errorText() throws IOException, InterruptedException {
        return $(errorText);

    }
    private By locationStatusRequiredField = By.xpath("//div[@id=\"locationStatus\"]//*[text()=\"Required field\"]");
    public Element locationStatusRequiredField() throws IOException, InterruptedException {
        return $(locationStatusRequiredField);


    }


    private By FIIDRequiredField = By.xpath("//div[@id=\"fiid\"]//*[text()=\"Required field\"]");
    public Element FIIDRequiredField() throws IOException, InterruptedException {
        return $(FIIDRequiredField);


    }

    private By timeZoneRequiredField = By.xpath("//div[@id=\"timeZone\"]//*[text()=\"Required field\"]");
    public Element timeZoneRequiredField() throws IOException, InterruptedException {
        return $(timeZoneRequiredField);


    }
    private By daylightsavingRequiredField = By.xpath("//div[@id=\"dst\"]//*[text()=\"Required field\"]");
    public Element daylightsavingRequiredField() throws IOException, InterruptedException {
        return $(daylightsavingRequiredField);


    }
    private By DefaultBusinessSegmentCode = By.xpath("//*[text()=\"GCB\"]");
    public Element DefaultBusinessSegmentCode() throws IOException, InterruptedException {
        return $(DefaultBusinessSegmentCode);


    }
    private By latitude = By.xpath("//input[@formcontrolname = 'latitude']");
    public Element latitude() throws IOException, InterruptedException {
        return $(latitude);


    }
    private By longitude = By.xpath("//input[@formcontrolname = 'longitude']");
    public Element longitude() throws IOException, InterruptedException {
        return $(longitude);


    }

    private By latitudeerrormessage = By.xpath("//*[text()=\"Please enter a valid latitude\"]");
    public Element latitudeerrormessage() throws IOException, InterruptedException {
        return $(latitudeerrormessage);


    }

    private By longitudeerrormessage = By.xpath("//*[text()=\"Please enter a valid longitude\"]");
    public Element longitudeerrormessage() throws IOException, InterruptedException {
        return $(longitudeerrormessage);


    }

}
