package pageobjects.CMSPageObject;

import automation.library.selenium.core.Element;
import automation.library.selenium.exec.BasePO;
import org.openqa.selenium.By;

import java.io.IOException;

public class CMSHomePage extends BasePO {
    private By terminalID = By.xpath("//input[@id='terminalId']");
    private By searchButton = By.xpath("//span[text() = 'Search']");
    private By terminalIdResult = By.xpath("//tr[@class = 'mat-row cdk-row ng-star-inserted']/td[2]");

    public Element terminalIdResult() throws IOException, InterruptedException {
        return $(terminalIdResult);
    }
    public Element terminalID() throws IOException, InterruptedException {
        return $(terminalID);
    }
    public Element searchButton() throws IOException, InterruptedException {
        return $(searchButton);
    }
    private By createLocation = By.xpath("//div[text() = ' Create Location ']");
    public Element createLocation() throws IOException,InterruptedException{
        return $(createLocation);
    }
    private By createAsset = By.xpath("//div[text() = ' Create Asset ']");
    public Element createAsset() throws IOException,InterruptedException{
        return $(createAsset);
    }
    private By search = By.xpath("//div[text() = ' Search ']");
    public Element search() throws IOException,InterruptedException{
        return $(search);
    }
    private By createSite = By.xpath("//div[text() = ' Create Site ']");
    public Element createSite() throws IOException,InterruptedException{
        return $(createSite);
    }

    private By assetSearch = By.xpath("//h1[text()= 'Asset Search']");
    public Element assetSearch() throws IOException, InterruptedException {
        return $(assetSearch);
    }
    private By assetID = By.xpath("//input[@id='assetId']");
    public Element assetID() throws IOException, InterruptedException {
        return $(assetID);
    }
    //h2[text()= 'ATM Basics']


    private By noResultOrInvalidInput = By.xpath("//h3[text() = 'No matching search results']");
    public Element noResultOrInvalidInput() throws IOException, InterruptedException {
        return $(noResultOrInvalidInput);
    }

    private By mACAddress = By.xpath("//input[@id='macAddress']");
    public Element mACAddress() throws IOException, InterruptedException {
        return $(mACAddress);
    }

    private By mACAddressResult = By.xpath("//tr[@class = 'mat-row cdk-row ng-star-inserted']/td[6]");
    public Element mACAddressResult() throws IOException, InterruptedException {
        return $(mACAddressResult);
    }


//serialNumber
    private By serialNumber = By.xpath("//input[@id='serialNumber']");
    public Element serialNumber() throws IOException, InterruptedException {
        return $(serialNumber);
    }

    private By serialNumberResult = By.xpath("//tr[@class = 'mat-row cdk-row ng-star-inserted']/td[5]");
    public Element serialNumberResult() throws IOException, InterruptedException {
        return $(serialNumberResult);
    }
    //mat-select[@id = 'status']
    private By status = By.xpath("//mat-select[@id = 'status']");
    public Element status() throws IOException, InterruptedException {
        return $(status);
    }
    private By statusInUsed = By.xpath("//span[text() = 'IN USE']");
    public Element statusInUsed() throws IOException, InterruptedException {
        return $(statusInUsed);
    }
    //div[@class = 'cdk-overlay-pane']/div/div
    private By statusDropdown = By.xpath("//span[text() = 'IN USE']");
    public Element statusDropdown() throws IOException, InterruptedException {
        return $(statusDropdown);
    }
    //div[@class = 'search-results-container']

    private By model = By.xpath("//mat-select[@id = 'model']");
    public Element model() throws IOException, InterruptedException {
        return $(model);
    }
    //span[text() = 'DN450V']
    private By DN450VModel = By.xpath("//span[text() = 'DN450V']");
    public Element DN450VModel() throws IOException, InterruptedException {
        return $(DN450VModel);
    }
    private By DN200HModel = By.xpath("//span[text() = 'DN200H']");
    public Element DN200HModel() throws IOException, InterruptedException {
        return $(DN200HModel);
    }

    private By resultTable = By.xpath("//div[@class = 'search-results-container']");
    public Element resultTable() throws IOException, InterruptedException {
        return $(resultTable);
    }

    private By bulkUpload = By.xpath("//*[text()=\" Bulk Upload \"]");
    public Element bulkUpload() throws IOException, InterruptedException {
        return $(bulkUpload);
    }
    private By reportTab = By.xpath("//*[text()=\" Report \"]");
    public Element reportTab() throws IOException, InterruptedException {
        return $(reportTab);
    }


}
