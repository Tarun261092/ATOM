package pageobjects.CMSPageObject;

import automation.library.selenium.core.Element;
import automation.library.selenium.exec.BasePO;
import org.openqa.selenium.By;

import java.io.IOException;

public class CreateAsset extends BasePO {

    /**#########################################################################################################################
     *Elements those are available under "Site Association" inside the Create Asset page are
     * available below
     * ##############################################################################################################
     */

    private By siteAssociation = By.xpath("//span[text() = 'Site Association']");
    public Element siteAssociation() throws IOException, InterruptedException {
        return $(siteAssociation);
    }

    private By saveAsset = By.xpath("//button[@id= 'submit-atm-form-button']");
    public Element saveAsset() throws IOException, InterruptedException {
        return $(saveAsset);
    }
    private By editAndCancelButton = By.xpath("//button[contains(@id, 'edit-atm-form-button')]");
    public Element editAndCancelButton() throws IOException, InterruptedException {
        return $(editAndCancelButton);
    }

    private By confirmationPopUP = By.xpath("//div[text() = 'Confirmation Required']");
    public Element confirmationPopUP() throws IOException, InterruptedException {
        return $(confirmationPopUP);
    }
    private By confirmationPopUPOK = By.xpath("//span[text()= ' OK ']");
    public Element confirmationPopUPOK() throws IOException, InterruptedException {
        return $(confirmationPopUPOK);
    }
    private By confirmationPopUPCancel = By.xpath("//span[text()= ' Cancel ']");
    public Element confirmationPopUPCancel() throws IOException, InterruptedException {
        return $(confirmationPopUPCancel);
    }
    private By statusSiteAssociation = By.xpath("//mat-label[text()='Status']");
    public Element statusSiteAssociation() throws IOException, InterruptedException {
        return $(statusSiteAssociation);
    }
    private By activeField = By.xpath("//span[text()= 'ACTIVE']");
    public Element activeField() throws IOException, InterruptedException {
        return $(activeField);
    }
    private By searchSiteAssociation = By.xpath("//span[text()= 'Search']");
    public Element searchSiteAssociation() throws IOException, InterruptedException {
        return $(searchSiteAssociation);
    }

    private By selectSite = By.xpath("//tr[@role='row']/td[1]");
    public Element selectSite() throws IOException, InterruptedException {
        return $(selectSite);
    }
    private By ATMForm = By.xpath("//span[text()= 'ATM Form']");
    public Element ATMForm() throws IOException, InterruptedException {
        return $(ATMForm);
    }






    /**
     * ATM Basics and Below locators
     */
    private By AMTBasisHerder = By.xpath("//h2[text()= 'ATM Basics']");
    public Element AMTBasisHerder() throws IOException, InterruptedException {
        return $(AMTBasisHerder);
    }
    private By fimp = By.xpath("//input[@id = 'fimp']");
    public Element fimp() throws IOException, InterruptedException {
        return $(fimp);
    }
    private By fimpID = By.xpath("//span[text() = '07']");
    public Element fimpID() throws IOException, InterruptedException {
        return $(fimpID);
    }
    private By branch = By.xpath("//input[@id= 'branchCode']");
    public Element branch() throws IOException, InterruptedException {
        return $(branch);
    }
    private By branchCode = By.xpath("//span[text() = '733']");
    public Element branchCode() throws IOException, InterruptedException {
        return $(branchCode);
    }
    private By nodeInstance = By.xpath("//input[@formcontrolname = 'nodeInstance']");
    public Element nodeInstance() throws IOException, InterruptedException {
        return $(nodeInstance);
    }

    private By terminalType = By.xpath("//mat-select[@id = 'terminalType']");
    public Element terminalType() throws IOException, InterruptedException {
        return $(terminalType);
    }
    private By terminalTypeStandaloneF= By.xpath("//span[text() = 'STANDALONE - FRONT LOAD']");
    public Element terminalTypeStandaloneF() throws IOException, InterruptedException {
        return $(terminalTypeStandaloneF);
    }
    private By machineType = By.xpath("//mat-select[@id='machineType']");
    public Element machineType() throws IOException, InterruptedException {
        return $(machineType);
    }
    private By machineTypeATM = By.xpath("//span[text() = 'ATM']");
    public Element machineTypeATM() throws IOException, InterruptedException {
        return $(machineTypeATM);
    }

    private By terminalId = By.xpath("//input[@id = 'terminalId']");
    public Element terminalId() throws IOException, InterruptedException {
        return $(terminalId);
    }
    private By legacyKALTerminalYes = By.xpath("//mat-radio-group[@id= 'legacyKALTerminal']/mat-radio-button[1]");
    public Element legacyKALTerminalYes() throws IOException, InterruptedException {
        return $(legacyKALTerminalYes);
    }
    private By legacyKALTerminalNo = By.xpath("//mat-radio-group[@id= 'legacyKALTerminal']/mat-radio-button[2]");
    public Element legacyKALTerminalNo() throws IOException, InterruptedException {
        return $(legacyKALTerminalNo);
    }


    private By atmStatus = By.xpath("//mat-select[@id = 'atmStatus']");
    public Element atmStatus() throws IOException, InterruptedException {
        return $(atmStatus);
    }
    private By atmStatusDropDown = By.xpath("//div[@id='atmStatus-panel']");
    public Element atmStatusDropDown() throws IOException, InterruptedException {
        return $(atmStatusDropDown);
    }
    //span[text() = 'IN USE']
    private By atmStatusInUse = By.xpath("//span[text() = 'IN USE']");
    public Element atmStatusInUse() throws IOException, InterruptedException {
        return $(atmStatusInUse);
    }

    private By serialNumber = By.xpath("//input[@id='serialNumber']");
    public Element serialNumber() throws IOException, InterruptedException {
        return $(serialNumber);
    }
    private By manufacturer = By.xpath("//mat-select[@id='manufacturer']");
    public Element manufacturer() throws IOException, InterruptedException {
        return $(manufacturer);
    }
    private By manufacturerDN = By.xpath("//span[text() = 'DN']");
    public Element manufacturerDN() throws IOException, InterruptedException {
        return $(manufacturerDN);
    }
    private By manufacturerNCR = By.xpath("//span[text() = 'NCR']");
    public Element manufacturerNCR() throws IOException, InterruptedException {
        return $(manufacturerNCR);
    }
    private By model = By.xpath("//mat-select[@id='model']");
    public Element model() throws IOException, InterruptedException {
        return $(model);
    }
    private By modelDN450V = By.xpath("//span[text() = 'DN450V']");
    public Element modelDN450V() throws IOException, InterruptedException {
        return $(modelDN450V);
    }
    private By modelDN450H = By.xpath("//span[text() = 'DN450H']");
    public Element modelDN450H() throws IOException, InterruptedException {
        return $(modelDN450H);
    }
    private By modelDN200V = By.xpath("//span[text() = 'DN200V']");
    public Element modelDN200V() throws IOException, InterruptedException {
        return $(modelDN200V);
    }
    private By nickname = By.xpath("//input[@id='nickname']");
    public Element nickname() throws IOException, InterruptedException {
        return $(nickname);
    }
    private By owner = By.xpath("//mat-select[@id='owner']");
    public Element owner() throws IOException, InterruptedException {
        return $(owner);
    }
    private By ownerCitiBankNA = By.xpath("//span[text() = 'CITIBANK N.A(00002)']");
    public Element ownerCitiBankNA() throws IOException, InterruptedException {
        return $(ownerCitiBankNA);
    }




    private By installationDate = By.xpath("//input[@id = 'installationDate']");
    public Element installationDate() throws IOException, InterruptedException {
        return $(installationDate);
    }
    private By datePlacedInService = By.xpath("//input[@id = 'datePlacedInService']");
    public Element datePlacedInService() throws IOException, InterruptedException {
        return $(datePlacedInService);
    }

    private By REMSCode = By.xpath("//input[@id = 'remsCode']");
    public Element REMSCode() throws IOException, InterruptedException {
        return $(REMSCode);
    }
    private By REMSCodeError = By.xpath("//mat-error[text() = 'Must be 10 characters long']");
    public Element REMSCodeError() throws IOException, InterruptedException {
        return $(REMSCodeError);
    }



    private By surchargeYes = By.xpath("//mat-radio-group[@id = 'atmSurchargeFlag']/mat-radio-button[2]");
    public Element surchargeYes() throws IOException, InterruptedException {
        return $(surchargeYes);
    }
    private By surchargeNo = By.xpath("//mat-radio-group[@id = 'atmSurchargeFlag']/mat-radio-button[1]");
    public Element surchargeNo() throws IOException, InterruptedException {
        return $(surchargeNo);
    }
    private By surchargeFee = By.xpath("//input[@formcontrolname = 'surchargeFeeAmount']");
    public Element surchargeFee() throws IOException, InterruptedException {
        return $(surchargeFee);
    }
    private By surchargeErrorMSG = By.xpath("//mat-error[contains(text(), 'Value must contain a decimal')]");
    public Element surchargeErrorMSG() throws IOException, InterruptedException {
        return $(surchargeErrorMSG);
    }
    private By siteSchedule = By.xpath("//mat-radio-group[@id='scheduleDetails']/mat-radio-button[1]");
    public Element siteSchedule() throws IOException, InterruptedException {
        return $(siteSchedule);
    }
    private By siteSchedule24HR = By.xpath("//mat-radio-group[@id='scheduleDetails']/mat-radio-button[2]");
    public Element siteSchedule24HR() throws IOException, InterruptedException {
        return $(siteSchedule24HR);
    }



    /** #############################################################################################################################
     *                            ATM Network Details And Below locators
     * ###############################################################################################################################################
     */
    private By macAddress = By.xpath("//input[@id='macAddress']");
    public Element macAddress() throws IOException, InterruptedException {
        return $(macAddress);
    }
    private By macAddressErrorMessage = By.xpath("//mat-error[contains(text(), 'MAC Address')]");
    public Element macAddressErrorMessage() throws IOException, InterruptedException {
        return $(macAddressErrorMessage);
    }

    private By ipAddress = By.xpath("//input[@id='ipAddress']");
    public Element ipAddress() throws IOException, InterruptedException {
        return $(ipAddress);
    }
    private By ipAddressErrorMessage = By.xpath("//mat-error[contains(text(), 'IP Address')]");
    public Element ipAddressErrorMessage() throws IOException, InterruptedException {
        return $(ipAddressErrorMessage);
    }
    private By ipSubnetMask = By.xpath("//input[@id='ipSubnetMask']");
    public Element ipSubnetMask() throws IOException, InterruptedException {
        return $(ipSubnetMask);
    }
    private By primaryRouterIpAddress = By.xpath("//input[@id='primaryRouterIpAddress']");
    public Element primaryRouterIpAddress() throws IOException, InterruptedException {
        return $(primaryRouterIpAddress);
    }

    private By domainName = By.xpath("//input[@id='domainName']");
    public Element domainName() throws IOException, InterruptedException {
        return $(domainName);
    }

    private By organizationUnit = By.xpath("//input[@id='organizationUnit']");
    public Element organizationUnit() throws IOException, InterruptedException {
        return $(organizationUnit);
    }

    /** #############################################################################################################################
     *                            ATM Functions And Below locators
     * ###############################################################################################################################################
     */
    private By depositMediaProcessingMode = By.xpath("//mat-select[@id='depositMediaProcessingMode']");
    public Element depositMediaProcessingMode() throws IOException, InterruptedException {
        return $(depositMediaProcessingMode);}

    private By depositMediaCashAndCheck = By.xpath("//span[text() = 'CASH AND CHECK']");
    public Element depositMediaCashAndCheck() throws IOException, InterruptedException {
        return $(depositMediaCashAndCheck);
    }
    private By cashMode = By.xpath("//mat-select[@id='cashMode']");
    public Element cashMode() throws IOException, InterruptedException {
        return $(cashMode);}

    private By cashModeFullFunction = By.xpath("//span[text() = 'FULL FUNCTION']");
    public Element cashModeFullFunction() throws IOException, InterruptedException {
        return $(cashModeFullFunction);
    }

    private By cashRecyclerMode = By.xpath("//mat-select[@id='cashRecyclerMode']");
    public Element cashRecyclerMode() throws IOException, InterruptedException {
        return $(cashRecyclerMode);}

    private By cashRecyclerModeEnabled = By.xpath("//span[text() = 'ENABLED']");
    public Element cashRecyclerModeEnabled() throws IOException, InterruptedException {
        return $(cashRecyclerModeEnabled);}

    private By signOnStateYes = By.xpath("//mat-radio-group[@id='signOnState']/mat-radio-button[1]");
    public Element signOnStateYes() throws IOException, InterruptedException {
        return $(signOnStateYes);}
    private By signOnStateNo = By.xpath("//mat-radio-group[@id='signOnState']/mat-radio-button[2]");
    public Element signOnStateNo() throws IOException, InterruptedException {
        return $(signOnStateNo);}


        /** #############################################################################################################################
         *                           Terminal Capabilities And Below locators
         * ###############################################################################################################################################
         */

    private By marketingEnabled = By.xpath("//mat-select[@id= 'marketingEnabled']");
    public Element marketingEnabled() throws IOException, InterruptedException {
        return $(marketingEnabled);
    }
    private By marketingEnabledDynamic = By.xpath("//span[text() = 'DYNAMIC']");
    public Element marketingEnabledDynamic() throws IOException, InterruptedException {
        return $(marketingEnabledDynamic);
    }
    private By marketingEnabledStatic = By.xpath("//span[text() = 'STATIC']");
    public Element marketingEnabledStatic() throws IOException, InterruptedException {
        return $(marketingEnabledStatic);
    }

    private By language = By.xpath("//mat-select[@id='languages']");
    public Element language() throws IOException, InterruptedException {
        return $(language);
    }
    private By languageEnglish = By.xpath("//span[text() = 'ENGLISH (US)']");
    public Element languageEnglish() throws IOException, InterruptedException {
        return $(languageEnglish);
    }

    private By languageSpanish = By.xpath("//span[text() = 'SPANISH (US)']");
    public Element languageSpanish() throws IOException, InterruptedException {
        return $(languageSpanish);
    }

    private By voice = By.xpath("//mat-radio-group[@id = 'voice']");
    public Element voice() throws IOException, InterruptedException {
        return $(voice);
    }
    private By voiceEnabled = By.xpath("//mat-radio-group[@id= 'voice']/mat-radio-button[1]");
    public Element voiceEnabled() throws IOException, InterruptedException {
        return $(voiceEnabled);
    }
    private By voiceDisabled = By.xpath("//mat-radio-group[@id= 'voice']/mat-radio-button[2]");
    public Element voiceDisabled() throws IOException, InterruptedException {
        return $(voiceDisabled);
    }
    private By internalTransferDisabled = By.xpath("//mat-radio-group[@id= 'internalTransfer']/mat-radio-button[1]");
    public Element internalTransferDisabled() throws IOException, InterruptedException {
        return $(internalTransferDisabled);
    }
    private By internalTransferEnabled = By.xpath("//mat-radio-group[@id= 'internalTransfer']/mat-radio-button[2]");
    public Element internalTransferEnabled() throws IOException, InterruptedException {
        return $(internalTransferEnabled);
    }

    private By nfcModel = By.xpath("//mat-select[@id= 'nfcModel']");
    public Element nfcModel() throws IOException, InterruptedException {
        return $(nfcModel);
    }
    private By nfcModelSaturn = By.xpath("//span[contains(text(), 'SATURN')]");
    public Element nfcModelSaturn() throws IOException, InterruptedException {
        return $(nfcModelSaturn);
    }

    private By mobileAccessEnabled = By.xpath("//mat-radio-group[@id= 'mobileAccessEnabled']/mat-radio-button[1]");
    public Element mobileAccessEnabled() throws IOException, InterruptedException {
        return $(mobileAccessEnabled);
    }
    private By mobileAccessDisabled = By.xpath("//mat-radio-group[@id= 'mobileAccessEnabled']/mat-radio-button[2]");
    public Element mobileAccessDisabled() throws IOException, InterruptedException {
        return $(mobileAccessDisabled);
    }
    private By atmManagedFlagBranch = By.xpath("//mat-radio-group[@id= 'atmManagedFlag']/mat-radio-button[1]");
    public Element atmManagedFlagBranch() throws IOException, InterruptedException {
        return $(atmManagedFlagBranch);
    }
    private By atmManagedFlagVendor = By.xpath("//mat-radio-group[@id= 'atmManagedFlag']/mat-radio-button[2]");
    public Element atmManagedFlagVendor() throws IOException, InterruptedException {
        return $(atmManagedFlagVendor);
    }


    /** #############################################################################################################################
     *                           ATM Hardware And Below locators
     * ###############################################################################################################################################
     */
    private By depositPaymentCapability = By.xpath("//mat-select[@id= 'depositFriendly']");
    public Element depositPaymentCapability() throws IOException, InterruptedException {
        return $(depositPaymentCapability);
    }
    private By depositPaymentCapabilityCashAndCheck = By.xpath("(//span[text() = ' CASH AND CHECK'])[2]");
    public Element depositPaymentCapabilityCashAndCheck() throws IOException, InterruptedException {
        return $(depositPaymentCapabilityCashAndCheck);
    }
    private By cardReaderOrientation = By.xpath("//mat-select[@id= 'cardReaderOrientation']");
    public Element cardReaderOrientation() throws IOException, InterruptedException {
        return $(cardReaderOrientation);
    }
    private By cardReaderOrientationVertical = By.xpath("//span[text() = 'VERTICAL']");
    public Element cardReaderOrientationVertical() throws IOException, InterruptedException {
        return $(cardReaderOrientationVertical);
    }
    private By cardReaderOrientationHorizontal = By.xpath("//span[text() = 'HORIZONTAL']");
    public Element cardReaderOrientationHorizontal() throws IOException, InterruptedException {
        return $(cardReaderOrientationHorizontal);
    }
    private By cardReaderType = By.xpath("//mat-select[@id='cardReaderType']");
    public Element cardReaderType() throws IOException, InterruptedException {
        return $(cardReaderType);
    }
    private By cardReaderTypeDip = By.xpath("//span[text() = 'DIP']");
    public Element cardReaderTypeDip() throws IOException, InterruptedException {
        return $(cardReaderTypeDip);
    }
    private By cardReaderTypeTransport = By.xpath("//span[text() = 'TRANSPORT']");
    public Element cardReaderTypeTransport() throws IOException, InterruptedException {
        return $(cardReaderTypeTransport);
    }
    private By eppSerialNumber = By.xpath("//input[@id = 'eppSerialNumber']");
    public Element eppSerialNumber() throws IOException, InterruptedException {
        return $(eppSerialNumber);
    }
    private By eppProfile = By.xpath("//input[@id = 'eppProfile']");
    public Element eppProfile() throws IOException, InterruptedException {
        return $(eppProfile);
    }
    private By screenResolution = By.xpath("//mat-select[@id = 'screenResolution']");
    public Element screenResolution() throws IOException, InterruptedException {
        return $(screenResolution);
    }
    private By screenResolution1024 = By.xpath("//span[text() = '1024 X 768']");
    public Element screenResolution1024() throws IOException, InterruptedException {
        return $(screenResolution1024);
    }
    private By screenSize = By.xpath("//mat-select[@id = 'screenSize']");
    public Element screenSize() throws IOException, InterruptedException {
        return $(screenSize);
    }
    private By screenSize15 = By.xpath("//span[text() = '15 INCHES']");
    public Element screenSize15() throws IOException, InterruptedException {
        return $(screenSize15);
    }


    private By atmSoundVolume = By.xpath("//input[@id='atmSoundVolume']");
    public Element atmSoundVolume() throws IOException, InterruptedException {
        return $(atmSoundVolume);
    }

    private By processorManufacturer = By.xpath("//mat-select[@id='processorManufacturer']");
    public Element processorManufacturer() throws IOException, InterruptedException {
        return $(processorManufacturer);
    }
    private By processorManufacturerIntel = By.xpath("//span[text() = 'INTEL']");
    public Element processorManufacturerIntel() throws IOException, InterruptedException {
        return $(processorManufacturerIntel);
    }
    private By ATMErrorPopup = By.xpath("//*[text()=\"Please select a Site to associate before proceeding to ATM form.\"]");
    public Element ATMErrorPopup() throws IOException, InterruptedException {
        return $(ATMErrorPopup);
    }

    private By SerialNumberError = By.xpath("//mat-error[contains(text(), 'Must be 10')]");
    public Element SerialNumberError() throws IOException, InterruptedException {
        return $(SerialNumberError);
    }


    private By MachineTypePanel = By.xpath("//*[@id=\"machineType-panel\"]");
    public Element MachineTypePanel() throws IOException, InterruptedException {
        return $(MachineTypePanel);
    }


}
