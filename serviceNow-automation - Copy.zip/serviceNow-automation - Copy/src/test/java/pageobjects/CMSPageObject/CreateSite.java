package pageobjects.CMSPageObject;

import automation.library.selenium.core.Element;
import automation.library.selenium.exec.BasePO;
import org.openqa.selenium.By;

import java.io.IOException;

public class CreateSite extends BasePO {

    private By createSite = By.xpath("//div[text() = ' Create Site ']");

    public Element createSite() throws IOException, InterruptedException {
        return $(createSite);
    }
    private By siteNumber = By.xpath("//input[@formcontrolname= 'siteNumber']");

    public Element siteNumber() throws IOException, InterruptedException {
        return $(siteNumber);
    }
    private By siteDescription = By.xpath("//input[@formcontrolname= 'siteDescription']");

    public Element siteDescription() throws IOException, InterruptedException {
        return $(siteDescription);
    }
    private By siteIdVV = By.xpath("//input[@formcontrolname= 'siteIdVV']");

    public Element siteIdVV() throws IOException, InterruptedException {
        return $(siteIdVV);
    }
    private By accessType = By.xpath("//mat-select[@formcontrolname= 'accessType']");

    public Element accessType() throws IOException, InterruptedException {
        return $(accessType);
    }
    private By accessTypeBranch = By.xpath("//span[text() = 'BRANCH']");

    public Element accessTypeBranch() throws IOException, InterruptedException {
        return $(accessTypeBranch);
    }

    private By accessTypeDriveThru = By.xpath("//span[text() = 'DRIVE THRU']");

    public Element accessTypeDriveThru() throws IOException, InterruptedException {
        return $(accessTypeDriveThru);
    }
    private By accessTypeIsland = By.xpath("//span[text() = 'ISLAND']");

    public Element accessTypeIsland() throws IOException, InterruptedException {
        return $(accessTypeIsland);
    }


    private By status = By.xpath("//mat-select[@formcontrolname= 'status']");

    public Element status() throws IOException, InterruptedException {
        return $(status);
    }
    private By statusActive = By.xpath("//span[text() = 'ACTIVE']");

    public Element statusActive() throws IOException, InterruptedException {
        return $(statusActive);
    }


    private By onPremise = By.xpath("//mat-select[@formcontrolname= 'onPremise']");

    public Element onPremise() throws IOException, InterruptedException {
        return $(onPremise);
    }

    private By onPremiseYes = By.xpath("//span[text() = 'YES']");
    public Element onPremiseYes() throws IOException, InterruptedException {
        return $(onPremiseYes);
    }

    private By remoteSite = By.xpath("//mat-select[@formcontrolname= 'remoteSite']");
    public Element remoteSite() throws IOException, InterruptedException {
        return $(remoteSite);
    }
    private By remoteSiteYes = By.xpath("(//span[text() = 'YES'])[2]");
    public Element remoteSiteYes() throws IOException, InterruptedException {
        return $(remoteSiteYes);
    }

    private By publicAccess = By.xpath("//mat-select[@formcontrolname= 'publicAccess']");
    public Element publicAccess() throws IOException, InterruptedException {
        return $(publicAccess);
    }
    private By publicAccessYes = By.xpath("(//span[text() = 'YES'])[3]");
    public Element publicAccessYes() throws IOException, InterruptedException {
        return $(publicAccessYes);
    }

    private By vendor24HrAccess = By.xpath("//mat-select[@formcontrolname= 'vendor24HrAccess']");
    public Element vendor24HrAccess() throws IOException, InterruptedException {
        return $(vendor24HrAccess);
    }
    private By vendor24HrAccessYes = By.xpath("(//span[text() = 'YES'])[4]");
    public Element vendor24HrAccessYes() throws IOException, InterruptedException {
        return $(vendor24HrAccessYes);
    }

    private By customer24HrAccess = By.xpath("//mat-select[@formcontrolname= 'customer24HrAccess']");
    public Element customer24HrAccess() throws IOException, InterruptedException {
        return $(customer24HrAccess);
    }
    private By customer24HrAccessYes = By.xpath("(//span[text() = 'YES'])[5]");
    public Element customer24HrAccessYes() throws IOException, InterruptedException {
        return $(customer24HrAccessYes);
    }



    private By siteSchedule = By.xpath("//span[text() = 'Site Schedule']");
    public Element siteSchedule() throws IOException, InterruptedException {
        return $(siteSchedule);
    }
    private By locationAssociation = By.xpath("//span[text() = 'Location Association']");
    public Element locationAssociation() throws IOException, InterruptedException {
        return $(locationAssociation);
    }
    private By locationId = By.xpath("//input[@id = 'locationId']");
    public Element locationId() throws IOException, InterruptedException {
        return $(locationId);
    }
    private By locationSearchButton = By.xpath("//span[text() = 'Search']");
    public Element locationSearchButton() throws IOException, InterruptedException {
        return $(locationSearchButton);
    }
    private By locationSelect = By.xpath("//tbody[@role='rowgroup']/tr/td[1]");
    public Element locationSelect() throws IOException, InterruptedException {
        return $(locationSelect);
    }

    private By submitSiteButton = By.xpath("//span[text() = 'Save Site']");
    public Element submitSiteButton() throws IOException, InterruptedException {
        return $(submitSiteButton);
    }
    private By confirmationRequired = By.xpath("//h3[text() = 'Confirmation Required']");
    public Element confirmationRequired() throws IOException, InterruptedException {
        return $(confirmationRequired);
    }
    private By confirmationOk = By.xpath("//span[text() = ' OK ']");
    public Element confirmationOk() throws IOException, InterruptedException {
        return $(confirmationOk);
    }

    private By confirmationPage = By.xpath("//span[text() = 'Your changes have been saved!']");
    public Element confirmationPage() throws IOException, InterruptedException {
        return $(confirmationPage);
    }




    private By footerLogo = By.xpath("//img[@id= 'citi-footer-logo']");

    public Element footerLogo() throws IOException, InterruptedException {
        return $(footerLogo);
    }

    private By blankErrorMessage = By.xpath("//h3[@id='error-dialog-title']");

    public Element blankErrorMessage() throws IOException, InterruptedException {
        return $(blankErrorMessage);
    }




}
