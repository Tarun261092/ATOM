package runners;

import automation.library.engine.api.runner.AutoEngBaseTestAPI;
import automation.library.engine.core.runner.AutoEngBaseTest;
import io.cucumber.testng.CucumberOptions;
import org.testng.annotations.BeforeTest;

@CucumberOptions(tags = {"@CMS_HK1","not @ignore"},plugin =  {"junit:target/cucumber-reports/CMS.xml"})
public class CMS extends AutoEngBaseTest {
    @BeforeTest
    public void setup() {


        	System.setProperty("cukes.env","CMS");
        	System.setProperty("cukes.techstack", "GRID_MULTI");
        	System.setProperty("org.apache.logging.log4j.level", "DEBUG");
        	System.setProperty("javax.net.ssl.trustStorePassword", "changeit");
        // log.info("Value of Jenkins Build_Number --- " + Property.getVariable("label"));

    }

 
}