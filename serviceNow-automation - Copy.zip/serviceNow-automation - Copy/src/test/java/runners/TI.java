package runners;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;

import automation.library.common.Property;

import automation.library.engine.core.runner.AutoEngBaseTest;
import io.cucumber.testng.CucumberOptions;

//@CucumberOptions(tags = {"@TI_Env","not @ignore"})
@CucumberOptions(tags = {"@TI_NAM123","not @ignore"})

public class TI extends AutoEngBaseTest {
	
	@BeforeTest
	public void setup() {


	
		/*System.setProperty("cukes.techstack", "GRID_MULTI");
		System.setProperty("org.apache.logging.log4j.level", "DEBUG");
		System.setProperty("javax.net.ssl.trustStorePassword", "changeit");*/
		
	}
}