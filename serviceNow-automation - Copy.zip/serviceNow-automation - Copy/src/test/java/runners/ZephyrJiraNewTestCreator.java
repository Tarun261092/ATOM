package runners;

import org.testng.annotations.BeforeTest;

import automation.library.engine.core.runner.TlmUploadUtilityRunner;

public class ZephyrJiraNewTestCreator extends TlmUploadUtilityRunner {
	@BeforeTest
	public void setup() {


		System.setProperty("fw.folderName", "TM");
		System.setProperty("javax.net.ssl.trustStorePassword", "changeit");
		
	}
}
