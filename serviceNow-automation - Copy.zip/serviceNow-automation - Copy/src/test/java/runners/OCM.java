package runners;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeSuite;

import automation.library.engine.core.runner.AutoEngBaseTest;
import io.cucumber.testng.CucumberOptions;
import automation.library.engine.api.runner.AutoEngBaseTestAPI;

@CucumberOptions(tags = {"@Clarity","not @ignore"})

public class OCM extends AutoEngBaseTest {
	
 @BeforeSuite
 public void beforesuite() throws Throwable {
       theUserKillTheIEBrowsers();
       
 }
/*@CucumberOptions(tags = {"@TTS_Account_cfg","not @ignore"})
public class MicroServices extends AutoEngBaseTestAPI {

}*/

 @AfterMethod
 public void theUserKillTheIEBrowsers() throws Throwable {
       Runtime rt = Runtime.getRuntime(); 
       rt.exec("taskkill /F /IM chromedriver.exe /T");
       rt.exec("taskkill /F /IM iexplore.exe /T");
       rt.exec("taskkill /F /IM IEDriverServer.exe /T");
       rt.exec("taskkill /f /im ielowutil.exe");
       Thread.sleep(2000);	
 }
 
}