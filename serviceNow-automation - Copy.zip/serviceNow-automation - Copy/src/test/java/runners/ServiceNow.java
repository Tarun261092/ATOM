package runners;



import automation.library.engine.core.runner.AutoEngBaseTest;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(tags = {" @Test ","not @ignore"},plugin =  {"junit:target/cucumber-reports/ServiceNow.xml"})
//@CucumberOptions(tags = {" @Branch","not @ignore"})

public class ServiceNow extends AutoEngBaseTest {
	/*@BeforeTest
	public void setup() {


		//	System.setProperty("cukes.env","ServiceNow");
		//	System.setProperty("cukes.techstack", "GRID_MULTI");
		//	System.setProperty("org.apache.logging.log4j.level", "DEBUG");
		//	System.setProperty("javax.net.ssl.trustStorePassword", "changeit");
		// log.info("Value of Jenkins Build_Number --- " + Property.getVariable("label"));

	}*/
}