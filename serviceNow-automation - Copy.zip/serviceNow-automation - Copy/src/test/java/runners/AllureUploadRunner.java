package runners;

import automation.library.engine.core.runner.ReportUploadRunner;

public class AllureUploadRunner extends ReportUploadRunner {
}
