@AllTests @Basic @parallel=false
Feature: GetToken

  @getATMtoken

  Scenario: get token for authorization
    Given url ATM_URL_REST + POST_CREATE_KEY_BLUE
    And headers read('classpath:apiobjects/headers/global_header_generic.json')
  #   * configure ssl = { keyStore:'C:\\Tarun\\New\\naqe-automation-training\\src\\test\\resources\\apiobjects\\DevCerts\\CertAndKey.pfx', keyStorePassword: 'C1t1220000000022Bank', keyStoreType:'pkcs12'}
   And request read('createKey.json')
      When method post
  * def reportInfo = call read(CORE_GET_REPORT_INFO)