@AllTests @Basic @parallel=false
Feature: account list
  @cashDepositATM

  Scenario: retrieve account list
    Given url ATM_URL_REST + POST_BALANCE_INQUIRY_BLUE
 
    And headers read('classpath:apiobjects/headers/global_header_generic.json')
    #And header token
   # * configure ssl = { keyStore:'C:\\AMS\\CertAndKey.pfx', keyStorePassword: 'C1t1bank#', keyStoreType:'pkcs12'}
    And request read('classpath:apiobjects/services/ATM/DEV1/BalanceInquiry/BalanceInquiryATM.json')
      When method post
    * def reportInfo = call read(CORE_GET_REPORT_INFO)