@AllTests @Basic @parallel=false
Feature: GetToken

  @getATMtoken

  Scenario: get token for authorization
    Given url ATM_URL_REST + GET_TOKEN_SVC_NAME_BLUE
    #Given url ATM_URL_REST
    #And path GET_TOKEN_SVC_NAME_BLUE
    And headers read('classpath:apiobjects/headers/global_header.json')
  #   * configure ssl = { keyStore:'C:\\Tarun\\New\\naqe-automation-training\\src\\test\\resources\\apiobjects\\DevCerts\\CertAndKey.pfx', keyStorePassword: 'C1t1220000000022Bank', keyStoreType:'pkcs12'}
    When method get
  * def reportInfo = call read(CORE_GET_REPORT_INFO)