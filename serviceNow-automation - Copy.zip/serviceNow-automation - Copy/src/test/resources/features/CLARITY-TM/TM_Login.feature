Feature: UAT
  @EVM_HealthCheck @Clarity @Z_Auto @Test1 @Browser @PCD_MAR032025 @PED_AUG032024 @Sanity @LOB_AMS @CSIIDi-174657 @Test
  Scenario: AGR_8_NAM_Login

        Given the web application "OCM_NAM_UAT8_Omega" is launched in a "NewWindow"
        And the user clicks the "advanced" element at the "OCMLoginPage" page
        And the user clicks the "proceedTo" element at the "OCMLoginPage" page
        #And the user enters the user credential "#(ocmUserName)" into the "userName" textbox at the "OCMLoginPage" page
        And the user enters "QAUSER" into the "userName" textbox at the "OCMLoginPage" page
        And the user enters "admin1" into the "password" textbox at the "OCMLoginPage" page
        #And the user enters the encrypted value "#(ocmPassword)" into the "password" textbox at the "OCMLoginPage" page
        And the user clicks the "signOn" element at the "OCMLoginpage" page
	    And the user waits for the page to load
	    And the user validates the "securityLink" element is visible at the "SecurityHSM" page "Security Link is present" "HardStopOnFailure"
