Feature: UAT
  @EVM_HealthCheck @Clarity @Z_Auto @Test1 @Browser @PCD_MAR032025 @PED_AUG032024 @Sanity @LOB_AMS @CSIIDi-174657
  Scenario: AGR_8_NAM-TM-UAT_AMS-UAT3-Blue

        Given the web application "OCM_NAM_UAT8_Omega" is launched in a "NewWindow"
And the user clicks the "advanced" element at the "OCMLoginPage" page
And the user clicks the "proceedTo" element at the "OCMLoginPage" page
        #And the user enters the user credential "#(ocmUserName)" into the "userName" textbox at the "OCMLoginPage" page
And the user enters "QAUSER" into the "userName" textbox at the "OCMLoginPage" page
And the user enters "admin1" into the "password" textbox at the "OCMLoginPage" page
        #And the user enters the encrypted value "#(ocmPassword)" into the "password" textbox at the "OCMLoginPage" page
        And the user clicks the "signOn" element at the "OCMLoginpage" page
	And the user waits for the page to load
	And the user clicks the "securityLink" element at the "SecurityHSM" page
	And the user waits for the "ZoneKeys" element to be "VISIBLE" on the "ZoneKeys" page
	And the user clicks the "ZoneKeys" element at the "ZoneKeys" page
	And the user waits for the page to load
	And the user clicks the "Zone_NAM" element at the "ZoneKeys" page
	And the user clicks the "ZoneKeyOverview" element at the "ZoneKeys" page
	And the user waits for the "ZPK1" element to be "VISIBLE" on the "ZoneKeys" page
	And the user validates the "ZPK1" element is visible at the "ZoneKeys" page "ZPK1 is present" "HardStopOnFailure"
	And the user validates the "ZPK2" element is visible at the "ZoneKeys" page "ZPK2 is present" "HardStopOnFailure"
	And the user validates the "ZPK3" element is visible at the "ZoneKeys" page "ZPK3 is present" "HardStopOnFailure"
	
	And the user clicks the "ZPK1" element at the "ZoneKeys" page
	And the user rightclicks the "ZPK1" element at the "ZoneKeys" page
	And the user clicks the "Invalidate" element at the "ZoneKeys" page
	
	And the user clicks the "ZPK1" element at the "ZoneKeys" page
	And the user clicks the "ZPK2" element at the "ZoneKeys" page
	And the user rightclicks the "ZPK2" element at the "ZoneKeys" page
	And the user clicks the "Invalidate" element at the "ZoneKeys" page
	
	And the user clicks the "ZPK1" element at the "ZoneKeys" page
	And the user clicks the "ZPK3" element at the "ZoneKeys" page
	And the user rightclicks the "ZPK3" element at the "ZoneKeys" page
	And the user clicks the "Invalidate" element at the "ZoneKeys" page

	Then the user clicks the "AdministrationLink" element at the "SecurityHSM" page
	And the user clicks the "TaskScheduler" element at the "SecurityHSM" page
	And the user clicks the "ScheduledTasks" element at the "SecurityHSM" page
	And the user waits for the page to load

	Then the user clicks the "TaskFilter" element at the "SecurityHSM" page
	And the user enters "#(zoneKeyCleanUp)" into the "TaskFilter" textbox at the "SecurityHSM" page
	Then the user clicks the "zoneKeyCleanUpTask" element at the "SecurityHSM" page
	And the user waits for the page to load
	And the user clicks the "Execute" element at the "SecurityHSM" page
	And the user waits for the page to load
	And the user clicks the "Yes" element at the "SecurityHSM" page
	And the user waits for the "TaskFilter" element to be "VISIBLE" on the "SecurityHSM" page
	
	
	Then the user clears the value in the "TaskFilter" textbox at the "SecurityHSM" page
	Then the user clicks the "TaskFilter" element at the "SecurityHSM" page
	And the user enters "#(zoneKeyGenerate)" into the "TaskFilter" textbox at the "SecurityHSM" page
	Then the user clicks the "zoneKeyTask" element at the "SecurityHSM" page
	And the user waits for the page to load
	And the user clicks the "Execute" element at the "SecurityHSM" page
	And the user waits for the page to load
	And the user clicks the "Yes" element at the "SecurityHSM" page
	And the user waits for the "TaskFilter" element to be "VISIBLE" on the "SecurityHSM" page

	And the user clicks the "securityLink1" element at the "SecurityHSM" page
	And the user waits for the "ZoneKeys" element to be "VISIBLE" on the "ZoneKeys" page
	And the user clicks the "ZoneKeys" element at the "ZoneKeys" page
	And the user waits for the page to load
	
	And the user clicks the "Zone_NAM" element at the "ZoneKeys" page
	And the user clicks the "ZoneKeyOverview" element at the "ZoneKeys" page


	And the user waits for the "ZoneKeys" element to be "VISIBLE" on the "ZoneKeys" page
And the user waits for the page to load
	And the user clicks the "ZoneKeys" element at the "ZoneKeys" page
	And the user waits for the page to load
	And the user clicks the "Zone_NAM" element at the "ZoneKeys" page
	And the user clicks the "ZoneKeyOverview" element at the "ZoneKeys" page

	And the user waits for the "ZPK1" element to be "VISIBLE" on the "ZoneKeys" page
	And the user validates the "ZPK1" element is visible at the "ZoneKeys" page "ZPK1 is present" "HardStopOnFailure"
	And the user waits for the "ZPK2" element to be "VISIBLE" on the "ZoneKeys" page
	And the user validates the "ZPK2" element is visible at the "ZoneKeys" page "ZPK2 is present" "HardStopOnFailure"
	And the user waits for the "ZPK3" element to be "VISIBLE" on the "ZoneKeys" page
	And the user validates the "ZPK3" element is visible at the "ZoneKeys" page "ZPK3 is present" "HardStopOnFailure"
	
	
	
	