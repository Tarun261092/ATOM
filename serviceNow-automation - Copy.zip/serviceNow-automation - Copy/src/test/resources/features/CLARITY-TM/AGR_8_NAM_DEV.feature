Feature: TM-DEV1-NAM
 @EVM_HealthCheck @EnvDemo @ATM1234 @Z_Auto @Test1 @Browser @PCD_MAR032025 @PED_AUG032024 @Sanity @LOB_AMS @CSIIDi-173062
   Scenario: AGR_8_NAM-TM-DEV1_AMS-DEV1-Blue
         Given the web application "OCM_NAM_UAT8_Omega" is launched in a "NewWindow"
         And the user clicks the "advanced" element at the "OCMLoginPage" page
   And the user clicks on "<string>" element at the "<string>" page and validates the hyperlink if "<string>" element is present at the "<string>" page "<string>" "<string>"
         And the user clicks the "proceedTo" element at the "OCMLoginPage" page
   
         #And the user enters the user credential "#(ocmUserName)" into the "userName" textbox at the "OCMLoginPage" page
         And the user enters "QAUSER" into the "userName" textbox at the "OCMLoginPage" page
         And the user enters "admin1" into the "password" textbox at the "OCMLoginPage" page
         #And the user enters the encrypted value "#(ocmPassword)" into the "password" textbox at the "OCMLoginPage" page
         And the user clicks the "signOn" element at the "OCMLoginpage" page
        And the user waits for the page to load
        And the user clicks the "securityLink" element at the "SecurityHSM" page
        And the user waits for the "ZoneKeys" element to be "VISIBLE" on the "ZoneKeys" page
        And the user clicks the "ZoneKeys" element at the "ZoneKeys" page
        And the user waits for the page to load
        And the user clicks the "Zone_NAM" element at the "ZoneKeys" page
        And the user clicks the "ZoneKeyOverview" element at the "ZoneKeys" page
        And the user waits for the "ZPK1" element to be "VISIBLE" on the "ZoneKeys" page
        And the user validates the "ZPK1" element is visible at the "ZoneKeys" page "ZPK1 is present" "HardStopOnFailure"
        And the user validates the "ZPK2" element is visible at the "ZoneKeys" page "ZPK2 is present" "HardStopOnFailure"
        And the user validates the "ZPK3" element is visible at the "ZoneKeys" page "ZPK3 is present" "HardStopOnFailure"


