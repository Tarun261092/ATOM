package runners;

import automation.library.engine.api.runner.AutoEngBaseTestAPI;
import automation.library.engine.core.runner.AutoEngBaseTest;
import io.cucumber.testng.CucumberOptions;

/*@CucumberOptions(tags = {"@EnvDemo","not @ignore"},plugin =  {"junit:target/cucumber-reports/ATMDemo.xml"})

public class ATMDemo extends AutoEngBaseTest {
*/
@CucumberOptions(tags = {"@NoRecordsMessage","not @ignore"})
public class MCA extends AutoEngBaseTest {
	

 
}