Feature: Service Now
  @SNOW_Inc @ALM_4584
  Scenario: ServiceNow_Knowledge_Article
      Given the web application "SNOW" is launched in a "NewWindow"
      And the user enters the user credential "SOEID" into the "username1" textbox at the "SNOWMainPage" page
      And the user enters the user credential "Password" into the "pwd" textbox at the "SNOWMainPage" page
      And the user clicks the "lgn" element at the "SNOWMainPage" page
      And the user clicks the "KnowledgeBase" element at the "SNOWMainPage" page
      And the user clicks the "How_to_add_file" element at the "SNOWMainPage" page
      Then the user validates the "Subscribe" element is visible at the "SNOWMainPage" page "Subscribe" "HardStopOnFailure"
      Then the user validates the "Actions" element is visible at the "SNOWMainPage" page "Actions" "HardStopOnFailure"
      And the user clicks the "Subscribe" element at the "SNOWMainPage" page
      Then the user validates the "You_are_now_subscribed" element is visible at the "SNOWMainPage" page "You_are_now_subscribed" "HardStopOnFailure"
