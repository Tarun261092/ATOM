Feature: Service Now
  @SNOW_Incident @ALM_77647
  Scenario: ServiceNow_Incident_Creation
    Given the web application "SNOW" is launched in a "NewWindow"
    And the user clicks the "RequestSomething" element at the "SNOWMainPage" page
    Then the user clicks the "ServiceNow_Integration_Onboarding_Request" element at the "SNOWMainPage" page

    ###############BUSINESS OWNER###############
    Then the user validates the "businessOwnerOfTheIntegrationField" element is visible at the "SNOWIntOnboardingRequest" page "businessOwnerOfTheIntegrationField" "HardStopOnFailure"
    And the user clicks the "businessOwnerOfTheIntegrationTextBox" element at the "SNOWIntOnboardingRequest" page  
    And the user enters "#(businessOwner)" into the "businessOwnerOfTheIntegration" textbox at the "SNOWIntOnboardingRequest" page
    And the user clicks the "businessOwnerOfTheIntegrationName" element at the "SNOWIntOnboardingRequest" page

    ###############TECHNICAL OWNER###############
    Then the user validates the "technicalOwnerOfTheIntegrationField" element is visible at the "SNOWIntOnboardingRequest" page "technicalOwnerOfTheIntegrationField" "HardStopOnFailure"
    And the user clicks the "technicalOwnerOfTheIntegrationTextBox" element at the "SNOWIntOnboardingRequest" page  
    And the user enters "#(technicalOwner)" into the "technicalOwnerOfTheIntegration" textbox at the "SNOWIntOnboardingRequest" page
    And the user clicks the "technicalOwnerOfTheIntegrationName" element at the "SNOWIntOnboardingRequest" page
 
    Then the user validates the "groupDL" element is visible at the "SNOWIntOnboardingRequest" page "groupDL" "HardStopOnFailure"
    And the user enters "#(GroupDL)" into the "groupDL" textbox at the "SNOWIntOnboardingRequest" page
    And the user enters "#(Description)" into the "description" textbox at the "SNOWIntOnboardingRequest" page
    And the user enters "#(BenefitsOutline)" into the "benefitsOutline" textbox at the "SNOWIntOnboardingRequest" page
    And the user enters "#(Module)" into the "applicationModules" textbox at the "SNOWIntOnboardingRequest" page
    And the user enters "#(EstimatedSavings)" into the "estimatedTime_CostSavings" textbox at the "SNOWIntOnboardingRequest" page
    And the user enters "#(BusinessJustification)" into the "buinessJustification" textbox at the "SNOWIntOnboardingRequest" page
    And the user enters "#(additionalDetails)" into the "additionalDetails" textbox at the "SNOWIntOnboardingRequest" page
    Then the user validates the "addToWishList" element is visible at the "SNOWIntOnboardingRequest" page "addToWishList" "HardStopOnFailure"
    And the user clicks the "addToWishList" element at the "SNOWIntOnboardingRequest" page
    Then the user validates the "addedToWishListLabel" element is visible at the "SNOWIntOnboardingRequest" page "ItemAddedToWishList" "HardStopOnFailure"
   