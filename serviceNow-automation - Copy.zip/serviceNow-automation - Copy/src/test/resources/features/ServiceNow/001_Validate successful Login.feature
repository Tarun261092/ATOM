Feature: Channel Management System
  @CM @CMS_Demo123 @ALM_77662
  Scenario: Validate successful Login
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "USRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    Then the user validates that the partial text "assertSearch" element at the "CMSHomePage" page is "Equal To" "Asset Search" "Save" "HardStopOnFailure"
    Then the user validates the "assertSearch" element is visible at the "CMSHomePage" page "Asset Search" "HardStopOnFailure"
