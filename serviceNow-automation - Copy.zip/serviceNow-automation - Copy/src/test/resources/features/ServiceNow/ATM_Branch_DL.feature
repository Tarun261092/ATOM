Feature: ATM
    @SNOW_Inc @sanity @regression @ALM_4585 @Branch
  Scenario: ATM Branch DL
      Given the web application "Branch_Locator" is launched in a "NewWindow"
      And the user enters "0001" into the "BranchNumber" textbox at the "BranchLocator" page
      And the user clicks the "BranchLink" element at the "BranchLocator" page
      And the user waits for "5" seconds
      #And the user performs the "extracting" process at the "BranchLocator" page
      #And the user closes the current window in focus
      Then the web application "DLMC" is launched in a "NewWindow"
      And the user waits for "5" seconds
      #And  the user switches to window that contains "Distribution"
      And the user enters "*PBWM US ATM-Branch-Test" into the "DLSearchBar" textbox at the "BranchLocator" page
      And the user sends keys "KEY_DOWN" to the "DLSearchBar" element on the "BranchLocator" page
      And the user sends keys "KEY_ENTER" to the "DLSearchBar" element on the "BranchLocator" page
      And the user clicks the "DL_URL" element at the "BranchLocator" page
      And the user clicks the "DL_Members" element at the "BranchLocator" page
      And the user clicks the "Remove_All" element at the "BranchLocator" page
      And the user clicks the "Submit" element at the "BranchLocator" page
      And the user waits for "3" seconds
      And the user performs the "SubmitForPopUp" process at the "BranchLocator" page
      And the user waits for "3" seconds
      #Then the user validates the "Close" element is visible at the "BranchLocator" page "Close" "HardStopOnFailure"
      And the user clicks the "Close" element at the "BranchLocator" page
      And the user clicks the "DL_Members" element at the "BranchLocator" page
      #Then the user validates the "AddEmail" element is visible at the "BranchLocator" page "AddEmail" "HardStopOnFailure"
      And the user enters "TS13842" into the "AddEmail" textbox at the "BranchLocator" page

     #And the user sends keys "KEY_DOWN" to the "AddEmail" element on the "BranchLocator" page
      And the user waits for "3" seconds
      And the user performs the "EmailEntry" process at the "BranchLocator" page
      And the user clicks the "Submit" element at the "BranchLocator" page
      And the user waits for "3" seconds
      And the user performs the "SubmitForPopUp" process at the "BranchLocator" page
      And the user waits for "3" seconds
      #Then the user validates the "Close" element is visible at the "BranchLocator" page "Close" "HardStopOnFailure"
      And the user clicks the "Close" element at the "BranchLocator" page
