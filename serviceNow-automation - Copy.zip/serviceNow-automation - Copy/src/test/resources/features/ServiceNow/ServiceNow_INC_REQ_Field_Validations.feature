Feature: Service Now
    @SNOW_Inc @sanity @regression @ALM_4585
  Scenario: ServiceNow_INC_REQ_Field_Validations
      Given the web application "SNOW" is launched in a "NewWindow"
      #And the user enters the user credential "SOEID" into the "username1" textbox at the "SNOWMainPage" page
      #And the user enters the user credential "Password" into the "pwd" textbox at the "SNOWMainPage" page
      And the user clicks the "lgn" element at the "SNOWMainPage" page
      And the user clicks the "MyItems" element at the "SNOWMainPage" page
      And the user enters "#(INC)" into the "SearchOpenRequest" textbox at the "SNOWIntOnboardingRequest" page
      Then the user clicks the "Search" element at the "SNOWIntOnboardingRequest" page
      And the user clicks the "INC" element at the "SNOWIntOnboardingRequest" page
      Then the user validates the "Contact" element is visible at the "SNOWIntOnboardingRequest" page "Contact" "HardStopOnFailure"
      Then the user validates the "Short_Description" element is visible at the "SNOWIntOnboardingRequest" page "Short Description" "HardStopOnFailure"
      Then the user validates the "Assignment_Group" element is visible at the "SNOWIntOnboardingRequest" page "Assignment Group" "HardStopOnFailure"
      Then the user validates the "State" element is visible at the "SNOWIntOnboardingRequest" page "State" "HardStopOnFailure"
      Then the user validates the "Created" element is visible at the "SNOWIntOnboardingRequest" page "Created" "HardStopOnFailure"
      And the user clicks the "MyItems" element at the "SNOWMainPage" page
      And the user selects value "Closed" from the "view" combobox at the "SNOWMainPage" page
      And the user clicks the "TempAdminREQ" element at the "SNOWIntOnboardingRequest" page
      And the user clicks the "TempAdminREQ1" element at the "SNOWIntOnboardingRequest" page
      Then the user validates the "Number" element is visible at the "SNOWIntOnboardingRequest" page "Contact" "HardStopOnFailure"
      Then the user validates the "Quantity" element is visible at the "SNOWIntOnboardingRequest" page "Assignment Group" "HardStopOnFailure"
      Then the user validates the "State" element is visible at the "SNOWIntOnboardingRequest" page "State" "HardStopOnFailure"
      Then the user validates the "Created" element is visible at the "SNOWIntOnboardingRequest" page "Created" "HardStopOnFailure"