Feature: Service Now
  @SNOW_Inc @ALM_4610 @Article
  Scenario: ServiceNow_Knowledge_Article_Helpful_Element_Failure
     Given the web application "SNOW" is launched in a "NewWindow"
     And the user enters the user credential "SOEID" into the "username1" textbox at the "SNOWMainPage" page
     And the user enters the user credential "Password" into the "pwd" textbox at the "SNOWMainPage" page
     And the user clicks the "lgn" element at the "SNOWMainPage" page
     And the user clicks the "KnowledgeBase" element at the "SNOWMainPage" page
     And the user clicks the "How_to_add_file" element at the "SNOWMainPage" page
     Then the user validates the "Actions" element is visible at the "SNOWMainPage" page "Actions" "HardStopOnFailure"
     Then the user scroll to the page until the object "RateThisArticle" is visible at the page "SNOWMainPage"
     Then the user validates the "RateThisArticle" element is visible at the "SNOWMainPage" page "helpful" "HardStopOnFailure"
     Then the user validates the "helpful" element is visible at the "SNOWMainPage" page "helpful" "HardStopOnFailure"
