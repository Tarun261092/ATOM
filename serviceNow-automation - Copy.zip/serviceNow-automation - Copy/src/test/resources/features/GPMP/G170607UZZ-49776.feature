Feature: GPMP
  @GPMP @ALM_4584 @NoRecordsMessage
  Scenario: G170607UZZ-49776 - Verify whether user with View Only role is getting proper message when no match records are present as per the matching criteria
      Given the web application "Risk_Controls" is launched in a "NewWindow"
      And the user clicks the "advanced" element at the "GPMPHomePage" page
      And the user clicks the "proceedTo" element at the "GPMPHomePage" page
      And the user enters the user credential "ID" into the "username" textbox at the "GPMPHomePage" page
      And the user enters the user credential "password" into the "password" textbox at the "GPMPHomePage" page
      Then the user validates the "signOn" element is visible at the "GPMPHomePage" page "sign On" "HardStopOnFailure"
      And the user clicks the "signOn" element at the "GPMPHomePage" page
      And the user switches to frame with xPath "//iframe[@id='citi-insight-iframe0']"
      Then the user validates the "MCA_TS2" element is visible at the "GPMPHomePage" page "MCA_TS2" "HardStopOnFailure"
      And the user clicks the "MCA_TS2" element at the "GPMPHomePage" page
      And the user clicks the "GPMP_SIT2" element at the "GPMPHomePage" page
      And the user performs the "waitForFrame" process at the "GPMPHomePage" page
      And the user waits for the page to load
      And the user switches to the default window content
      And the user switches to frame with xPath "//iframe[@id='citi-insight-iframe1']"
      Then the user validates the "searchIcon" element is visible at the "GPMPHomePage" page "Search Icon" "HardStopOnFailure"
      And the user clicks the "searchIcon" element at the "GPMPHomePage" page
      And the user enters "1234" into the "searchInput" textbox at the "GPMPHomePage" page
      And the user sends keys "KEY_ENTER" to the "searchInput" element on the "GPMPHomePage" page
      And the user waits for the page to load
      Then the user validates the "noResultFound" element is visible at the "GPMPRiskPage" page "No Records Message" "HardStopOnFailure"