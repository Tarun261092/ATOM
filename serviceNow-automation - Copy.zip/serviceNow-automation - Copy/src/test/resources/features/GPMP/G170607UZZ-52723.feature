Feature: GPMP
  @GPMP @ALM_4584
  Scenario: G170607UZZ-52723:GPMP:Verify the RCM Creation as a Process owner Delegate
      Given the web application "Risk_Controls" is launched in a "NewWindow"
      And the user clicks the "advanced" element at the "GPMPHomePage" page
      And the user clicks the "proceedTo" element at the "GPMPHomePage" page
      And the user enters the user credential "ID" into the "username" textbox at the "GPMPHomePage" page
      And the user enters the user credential "password" into the "password" textbox at the "GPMPHomePage" page
      Then the user validates the "signOn" element is visible at the "GPMPHomePage" page "sign On" "HardStopOnFailure"
      And the user clicks the "signOn" element at the "GPMPHomePage" page
      And the user switches to frame with xPath "//iframe[@id='citi-insight-iframe0']"
      Then the user validates the "MCA_TS2" element is visible at the "GPMPHomePage" page "MCA_TS2" "HardStopOnFailure"
      And the user clicks the "MCA_TS2" element at the "GPMPHomePage" page
      And the user clicks the "GPMP_SIT2" element at the "GPMPHomePage" page
      And the user performs the "waitForFrame" process at the "GPMPHomePage" page
      And the user waits for the page to load
      And the user switches to the default window content
      And the user switches to frame with xPath "//iframe[@id='citi-insight-iframe1']"
      Then the user validates the "searchIcon" element is visible at the "GPMPHomePage" page "Search Icon" "HardStopOnFailure"
      And the user clicks the "searchIcon" element at the "GPMPHomePage" page
      And the user enters "3473" into the "searchInput" textbox at the "GPMPHomePage" page
      And the user sends keys "KEY_ENTER" to the "searchInput" element on the "GPMPHomePage" page
      And the user waits for the page to load
      And the user clicks the "firstAvailableRecord" element at the "GPMPHomePage" page
      Then the user validates the "manageRC" element is visible at the "GPMPHomePage" page "manage RC" "HardStopOnFailure"
      And the user clicks the "manageRC" element at the "GPMPHomePage" page
      And the user waits for the page to load
      And the user clicks the "circularRisk" element at the "GPMPRiskPage" page
      Then the user validates the "searchRisk" element is visible at the "GPMPRiskPage" page "manage RC" "HardStopOnFailure"
      And the user enters "Rogue Trading; Concealing Trades Risk" into the "searchRisk" textbox at the "GPMPRiskPage" page
      Then the user validates the "selectRisk" element is visible at the "GPMPRiskPage" page "selectRisk" "HardStopOnFailure"
      And the user clicks the "selectRisk" element at the "GPMPRiskPage" page
      Then the user validates the "addReferenceControl" element is visible at the "GPMPRiskPage" page "addReferenceControl" "HardStopOnFailure"
      And the user clicks the "addReferenceControl" element at the "GPMPRiskPage" page
      Then the user validates the "reviewRole" element is visible at the "GPMPRiskPage" page "reviewRole" "HardStopOnFailure"
      And the user clicks the "reviewRole" element at the "GPMPRiskPage" page
      Then the user validates the "nextReview" element is visible at the "GPMPRiskPage" page "nextReview" "HardStopOnFailure"
      And the user clicks the "nextReview" element at the "GPMPRiskPage" page
      Then the user validates the "Save" element is visible at the "GPMPRiskPage" page "Save" "HardStopOnFailure"
      And the user clicks the "Save" element at the "GPMPRiskPage" page
      Then the user validates the "riskAdded" element is visible at the "GPMPRiskPage" page "riskAdded" "HardStopOnFailure"
      Then the user validates the "filterRiskTaxonomy" element is visible at the "GPMPRiskPage" page "filterRiskTaxonomy" "HardStopOnFailure"
      And the user clicks the "filterRiskTaxonomy" element at the "GPMPRiskPage" page
      Then the user validates the "riskTaxonomyInput" element is visible at the "GPMPRiskPage" page "riskTaxonomyInput" "HardStopOnFailure"
      And the user enters "Rogue Trading; Concealing Trades Risk" into the "riskTaxonomyInput" textbox at the "GPMPRiskPage" page
      Then the user validates the "selectAll" element is visible at the "GPMPRiskPage" page "riskTaxonomyInput" "HardStopOnFailure"
      And the user clicks the "selectAll" element at the "GPMPRiskPage" page
      And the user clicks the "Apply" element at the "GPMPRiskPage" page
      Then the user validates the "filterStatus" element is visible at the "GPMPRiskPage" page "filterStatus" "HardStopOnFailure"
      And the user clicks the "filterStatus" element at the "GPMPRiskPage" page
      And the user clicks the "draftStatus" element at the "GPMPRiskPage" page
      Then the user validates the "Apply" element is visible at the "GPMPRiskPage" page "Apply" "HardStopOnFailure"
      And the user clicks the "Apply" element at the "GPMPRiskPage" page
        Then the user validates the "reviewAndSubmitRC" element is visible at the "GPMPRiskPage" page "viewDetails" "HardStopOnFailure"
    #And the user waits for the page to load





      #And the user clicks the "How_to_add_file" element at the "SNOWMainPage" page
      #Then the user validates the "Subscribe" element is visible at the "SNOWMainPage" page "Subscribe" "HardStopOnFailure"
      #Then the user validates the "Actions" element is visible at the "SNOWMainPage" page "Actions" "HardStopOnFailure"
