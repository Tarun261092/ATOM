Feature: GPMP

  @GPMP1 @ALM_4584
  Scenario: G170607UZZ-80058_GPMP_Verify RC deactivation by PO
    Given the web application "Risk_Controls" is launched in a "NewWindow"
    And the user clicks the "advanced" element at the "GPMPHomePage" page
    And the user clicks the "proceedTo" element at the "GPMPHomePage" page
    And the user enters the user credential "ID102" into the "username" textbox at the "GPMPHomePage" page
    And the user enters the user credential "password" into the "password" textbox at the "GPMPHomePage" page
    Then the user validates the "signOn" element is visible at the "GPMPHomePage" page "sign On" "HardStopOnFailure"
    And the user clicks the "signOn" element at the "GPMPHomePage" page
    And the user switches to frame with xPath "//iframe[@id='citi-insight-iframe0']"
    Then the user validates the "MCA" element is visible at the "GPMPHomePage" page "MCA" "HardStopOnFailure"
    And the user clicks the "MCA" element at the "GPMPHomePage" page
    And the user waits for the page to load
    And the user scroll to the page until the object "GPMP_SIT" is visible at the page "GPMPHomePage"
    Then the user validates the "GPMP_SIT" element is visible at the "GPMPHomePage" page "GPMP_SIT" "HardStopOnFailure"
    And the user clicks the "GPMP_SIT" element at the "GPMPHomePage" page
    And the user performs the "waitForFrame" process at the "GPMPHomePage" page
    And the user waits for the page to load
    And the user switches to the default window content
    And the user switches to frame with xPath "//iframe[@id='citi-insight-iframe1']"
    Then the user validates the "searchIcon" element is visible at the "GPMPHomePage" page "Search Icon" "HardStopOnFailure"
    And the user clicks the "searchIcon" element at the "GPMPHomePage" page
    And the user enters "6734" into the "searchInput" textbox at the "GPMPHomePage" page
    And the user sends keys "KEY_ENTER" to the "searchInput" element on the "GPMPHomePage" page
    And the user waits for the page to load
    And the user clicks the "firstAvailableRecord" element at the "GPMPHomePage" page
    Then the user validates the "manageRC" element is visible at the "GPMPHomePage" page "manage RC" "HardStopOnFailure"
    And the user clicks the "manageRC" element at the "GPMPHomePage" page
    And the user waits for the page to load
    Then the user validates the "filterRiskTaxonomy" element is visible at the "GPMPRiskPage" page "Filter Risk Taxonomy" "HardStopOnFailure"
    And the user clicks the "filterRiskTaxonomy" element at the "GPMPRiskPage" page
    And the user enters "Rogue Trading; Booking Fictitious Trades Risk" into the "riskTaxonomyInput" textbox at the "GPMPRiskPage" page
    And the user clicks the "selectAll" element at the "GPMPRiskPage" page
    Then the user validates the "Apply" element is visible at the "GPMPRiskPage" page "Apply" "HardStopOnFailure"
    And the user clicks the "Apply" element at the "GPMPRiskPage" page
    And the user clicks the "filterStatus" element at the "GPMPRiskPage" page
    And the user clicks the "activeStatus" element at the "GPMPRiskPage" page
    Then the user validates the "Apply" element is visible at the "GPMPRiskPage" page "Apply" "HardStopOnFailure"
    And the user clicks the "Apply" element at the "GPMPRiskPage" page
     #And the user clicks the "viewDetails" element at the "GPMPRiskPage" page
    Then the user validates the "edit" element is visible at the "GPMPRiskPage" page "edit" "HardStopOnFailure"
    And the user clicks the "edit" element at the "GPMPRiskPage" page
    Then the user validates the "deactivateRisk" element is visible at the "GPMPRiskPage" page "deactivateRisk" "HardStopOnFailure"
    And the user clicks the "deactivateRisk" element at the "GPMPRiskPage" page
    Then the user validates the "deactivateRationale" element is visible at the "GPMPRiskPage" page "deactivateRationale" "HardStopOnFailure"
    And the user enters "Design and Manage Mandatory Absence Framework for Sensitive Positions" into the "deactivateRationale" textbox at the "GPMPRiskPage" page
    And the user clicks the "confirm" element at the "GPMPRiskPage" page
    And the user switches to the default window content
    And the user clicks the "logOutDropdown" element at the "GPMPRiskPage" page
    And the user clicks the "logOut" element at the "GPMPRiskPage" page
    And the user waits for the page to load
    #And the user closes the current browser

#Approve the Deactivation Request
      #Given the web application "Risk_Controls" is launched in a "NewWindow"
      #And the user clicks the "advanced" element at the "GPMPHomePage" page
      #And the user clicks the "proceedTo" element at the "GPMPHomePage" page
    And the user enters the user credential "ID114" into the "username" textbox at the "GPMPHomePage" page
    And the user enters the user credential "password" into the "password" textbox at the "GPMPHomePage" page
    Then the user validates the "signOn" element is visible at the "GPMPHomePage" page "sign On" "HardStopOnFailure"
    And the user clicks the "signOn" element at the "GPMPHomePage" page
    And the user switches to frame with xPath "//iframe[@id='citi-insight-iframe0']"
    Then the user validates the "MCA" element is visible at the "GPMPHomePage" page "MCA" "HardStopOnFailure"
    And the user clicks the "MCA" element at the "GPMPHomePage" page
    And the user waits for the page to load
    And the user scroll to the page until the object "GPMP_SIT" is visible at the page "GPMPHomePage"
    Then the user validates the "GPMP_SIT" element is visible at the "GPMPHomePage" page "MCA" "HardStopOnFailure"
    And the user clicks the "GPMP_SIT" element at the "GPMPHomePage" page
    And the user waits for the page to load
    And the user switches to the default window content
    And the user switches to frame with xPath "//iframe[@id='citi-insight-iframe1']"
    Then the user validates the "Tasks" element is visible at the "GPMPRiskPage" page "Tasks" "HardStopOnFailure"
    And the user clicks the "Tasks" element at the "GPMPRiskPage" page
    Then the user validates the "searchIcon" element is visible at the "GPMPHomePage" page "Search Icon" "HardStopOnFailure"
    And the user clicks the "searchIcon" element at the "GPMPHomePage" page
    And the user enters "6734" into the "searchInput" textbox at the "GPMPHomePage" page
    And the user sends keys "KEY_ENTER" to the "searchInput" element on the "GPMPHomePage" page
    And the user waits for the page to load
    Then the user validates the "reviewAndApproveDeactivation" element is visible at the "GPMPRiskPage" page "Review and Approve Deactivation" "HardStopOnFailure"
    And the user clicks the "reviewAndApproveDeactivation" element at the "GPMPRiskPage" page
    And the user waits for the page to load
    Then the user validates the "Approve" element is visible at the "GPMPRiskPage" page "approve" "HardStopOnFailure"
    And the user clicks the "Approve" element at the "GPMPRiskPage" page
    Then the user validates the "deActivationApprovedMessage" element is visible at the "GPMPRiskPage" page "deactivation approved" "HardStopOnFailure"
   # And the user clicks the "logOutDropdown" element at the "GPMPRiskPage" page
   # Then the user validates the "logOut" element is visible at the "GPMPRiskPage" page "logOut" "HardStopOnFailure"
    And the user switches to the default window content
    And the user clicks the "logOutDropdown" element at the "GPMPRiskPage" page
    Then the user validates the "logOut" element is visible at the "GPMPRiskPage" page "logOut" "HardStopOnFailure"
    And the user clicks the "logOut" element at the "GPMPRiskPage" page
    And the user waits for the page to load
    #And the user closes the current browser

    #Re-Activate request from smeng102
   # Given the web application "Risk_Controls" is launched in a "NewWindow"
   # And the user clicks the "advanced" element at the "GPMPHomePage" page
   # And the user clicks the "proceedTo" element at the "GPMPHomePage" page
    And the user enters the user credential "ID102" into the "username" textbox at the "GPMPHomePage" page
    And the user waits for the page to load
    And the user enters the user credential "password" into the "password" textbox at the "GPMPHomePage" page
    Then the user validates the "signOn" element is visible at the "GPMPHomePage" page "sign On" "HardStopOnFailure"
    And the user clicks the "signOn" element at the "GPMPHomePage" page
    And the user waits for the page to load
    And the user switches to frame with xPath "//iframe[@id='citi-insight-iframe0']"
    Then the user validates the "MCA" element is visible at the "GPMPHomePage" page "MCA" "HardStopOnFailure"
    And the user clicks the "MCA" element at the "GPMPHomePage" page
    And the user waits for the page to load
    And the user scroll to the page until the object "GPMP_SIT" is visible at the page "GPMPHomePage"
    Then the user validates the "GPMP_SIT" element is visible at the "GPMPHomePage" page "GPMP_SIT" "HardStopOnFailure"
    And the user clicks the "GPMP_SIT" element at the "GPMPHomePage" page
    And the user waits for the page to load
    And the user switches to the default window content
    And the user switches to frame with xPath "//iframe[@id='citi-insight-iframe1']"
    Then the user validates the "searchIcon" element is visible at the "GPMPHomePage" page "Search Icon" "HardStopOnFailure"
    And the user clicks the "searchIcon" element at the "GPMPHomePage" page
    And the user enters "6734" into the "searchInput" textbox at the "GPMPHomePage" page
    And the user sends keys "KEY_ENTER" to the "searchInput" element on the "GPMPHomePage" page
    And the user waits for the page to load
    Then the user validates the "firstAvailableRecord" element is visible at the "GPMPHomePage" page "First Available Record" "HardStopOnFailure"
    And the user clicks the "firstAvailableRecord" element at the "GPMPHomePage" page
    Then the user validates the "manageRC" element is visible at the "GPMPHomePage" page "manage RC" "HardStopOnFailure"
    And the user clicks the "manageRC" element at the "GPMPHomePage" page
    And the user waits for the page to load
    #Then the user validates the "viewDetails" element is visible at the "GPMPRiskPage" page "View Details" "HardStopOnFailure"
    #And the user clicks the "viewDetails" element at the "GPMPHomePage" page
    Then the user validates the "ReActivate" element is visible at the "GPMPRiskPage" page "ReActivate" "HardStopOnFailure"
    And the user clicks the "ReActivate" element at the "GPMPRiskPage" page
    #And the user clicks the "GotIt" element at the "GPMPRiskPage" page
    Then the user validates the "reactivateRationale" element is visible at the "GPMPRiskPage" page "reactivateRationale" "HardStopOnFailure"
    And the user enters "Design and Manage Mandatory Absence Framework for Sensitive Positions" into the "reactivateRationale" textbox at the "GPMPRiskPage" page
    And the user clicks the "confirm" element at the "GPMPRiskPage" page
    And the user performs the "waitForFrame" process at the "GPMPHomePage" page
    #Then the user validates the "reviewAndSubmitRC" element is visible at the "GPMPRiskPage" page "reviewAndSubmitRC" "HardStopOnFailure"
    #And the user clicks the "reviewAndSubmitRC" element at the "GPMPRiskPage" page
    #Then the user validates the "SubmitRC" element is visible at the "GPMPRiskPage" page "SubmitRC" "HardStopOnFailure"
    #And the user clicks the "SubmitRC" element at the "GPMPRiskPage" page
   # Then the user validates the "RC_submittedForApproval" element is visible at the "GPMPRiskPage" page "Re-Activation request submitted successfully" "HardStopOnFailure"
    And the user switches to the default window content
    And the user clicks the "logOutDropdown" element at the "GPMPRiskPage" page
    Then the user validates the "logOut" element is visible at the "GPMPRiskPage" page "logOut" "HardStopOnFailure"
    And the user clicks the "logOut" element at the "GPMPRiskPage" page
    And the user waits for the page to load
    #And the user closes the current browser

    #Approve the Reactivation Request
   # Given the web application "Risk_Controls" is launched in a "NewWindow"
    #And the user clicks the "advanced" element at the "GPMPHomePage" page
    #And the user clicks the "proceedTo" element at the "GPMPHomePage" page
    And the user enters the user credential "ID114" into the "username" textbox at the "GPMPHomePage" page
    And the user enters the user credential "password" into the "password" textbox at the "GPMPHomePage" page
    Then the user validates the "signOn" element is visible at the "GPMPHomePage" page "sign On" "HardStopOnFailure"
    And the user clicks the "signOn" element at the "GPMPHomePage" page
    And the user waits for the page to load
    And the user switches to frame with xPath "//iframe[@id='citi-insight-iframe0']"
    Then the user validates the "MCA" element is visible at the "GPMPHomePage" page "MCA" "HardStopOnFailure"
    And the user clicks the "MCA" element at the "GPMPHomePage" page
    And the user waits for the page to load
    And the user scroll to the page until the object "GPMP_SIT" is visible at the page "GPMPHomePage"
    Then the user validates the "GPMP_SIT" element is visible at the "GPMPHomePage" page "GPMP_SIT" "HardStopOnFailure"
    And the user clicks the "GPMP_SIT" element at the "GPMPHomePage" page
    And the user waits for the page to load
    And the user switches to the default window content
    And the user switches to frame with xPath "//iframe[@id='citi-insight-iframe1']"
    Then the user validates the "Tasks" element is visible at the "GPMPRiskPage" page "Tasks" "HardStopOnFailure"
    And the user clicks the "Tasks" element at the "GPMPRiskPage" page
    Then the user validates the "searchIcon" element is visible at the "GPMPHomePage" page "Search Icon" "HardStopOnFailure"
    And the user clicks the "searchIcon" element at the "GPMPHomePage" page
    And the user enters "6734" into the "searchInput" textbox at the "GPMPHomePage" page
    And the user sends keys "KEY_ENTER" to the "searchInput" element on the "GPMPHomePage" page
    And the user waits for the page to load
    Then the user validates the "reviewAndApproveReactivation" element is visible at the "GPMPRiskPage" page "Review and Approve Reactivation" "HardStopOnFailure"
    And the user clicks the "reviewAndApproveReactivation" element at the "GPMPRiskPage" page
    And the user waits for the page to load
    Then the user validates the "Approve" element is visible at the "GPMPRiskPage" page "Approve" "HardStopOnFailure"
    And the user clicks the "Approve" element at the "GPMPRiskPage" page
    Then the user validates the "RC_ReactivationApproved" element is visible at the "GPMPRiskPage" page "Reactivation approved" "HardStopOnFailure"
    And the user switches to the default window content
    And the user clicks the "logOutDropdown" element at the "GPMPRiskPage" page
    Then the user validates the "logOut" element is visible at the "GPMPRiskPage" page "logOut" "HardStopOnFailure"
    And the user clicks the "logOut" element at the "GPMPRiskPage" page
    And the user closes the current browser
