Feature: TI-NAM
  @TI @TI_NAM @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: Validate TI ATM search with Transaction Type (Optional Field) NAM
    Given the web application "TI" is launched in a "NewWindow"
    And the user enters the user credential "TIUser" into the "userName" textbox at the "TILoginPage" page
    And the user enters the secure credential "#(DEV_SSO)" into the "password" textbox at the "TILoginPage" page
    And the user selects value "US" from the "region" combobox at the "TILoginPage" page
    Then the user validates the "submit" element is visible at the "TILoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "TILoginPage" page
    #Verify transaction type dropdown
    And the user enters the user credential "terminalID" into the "terminalIdTI" textbox at the "TIHomePage" page
    And the user enters the user credential "DateFromPrior" into the "postDateFrom" textbox at the "TIHomePage" page
    And the user enters the user credential "DateTo" into the "postDateTo" textbox at the "TIHomePage" page

    #And the user enters "terminalID" into the "terminalIdTI" textbox at the "TIHomePage" page
    #And the user enters "DateFrom" into the "postDateFrom" textbox at the "TIHomePage" page
    #And the user enters "DateTo" into the "postDateTo" textbox at the "TIHomePage" page
    #verify Login from DropDown
    And the user selects value "#(Login)" from the "transactionType" dropdown at the "TIHomePage" page
    Then the user validates the "transactionType" element is visible at the "TIHomePage" page "Login" "HardStopOnFailure"
    Then the user validates that the partial text "transactionType" element at the "TIHomePage" page is "Equal To" "#(Login)" "Validating Correct type selected" "HardStopOnFailure"
    #verify FastCash from DropDown
    And the user selects value "#(FastCash)" from the "transactionType" dropdown at the "TIHomePage" page
    Then the user validates the "transactionType" element is visible at the "TIHomePage" page "FastCash" "HardStopOnFailure"
    Then the user validates that the partial text "transactionType" element at the "TIHomePage" page is "Equal To" "#(FastCash)" "Validating Correct type selected" "HardStopOnFailure"

     #verify ReLogin from DropDown
    And the user selects value "#(ReLogin)" from the "transactionType" dropdown at the "TIHomePage" page
    Then the user validates the "transactionType" element is visible at the "TIHomePage" page "ReLogin" "HardStopOnFailure"
    Then the user validates that the partial text "transactionType" element at the "TIHomePage" page is "Equal To" "#(ReLogin)" "Validating Correct type selected" "HardStopOnFailure"

    #verify Withdrawal from DropDown
    And the user selects value "#(Withdrawal)" from the "transactionType" dropdown at the "TIHomePage" page
    Then the user validates the "transactionType" element is visible at the "TIHomePage" page "Withdrawal" "HardStopOnFailure"
    Then the user validates that the partial text "transactionType" element at the "TIHomePage" page is "Equal To" "#(Withdrawal)" "Validating Correct type selected" "HardStopOnFailure"

      #verify Balance Inquiry from DropDown
    And the user selects value "#(BalanceInquiry)" from the "transactionType" dropdown at the "TIHomePage" page
    Then the user validates the "transactionType" element is visible at the "TIHomePage" page "Balance Inquiry" "HardStopOnFailure"
    Then the user validates that the partial text "transactionType" element at the "TIHomePage" page is "Equal To" "#(BalanceInquiry)" "Validating Correct type selected" "HardStopOnFailure"

    #verify Account Overview from DropDown
    And the user selects value "#(AccountOverview)" from the "transactionType" dropdown at the "TIHomePage" page
    Then the user validates the "transactionType" element is visible at the "TIHomePage" page "Account overview" "HardStopOnFailure"
    Then the user validates that the partial text "transactionType" element at the "TIHomePage" page is "Equal To" "#(AccountOverview)" "Validating Correct type selected" "HardStopOnFailure"

        #verify PIN Change from DropDown
    And the user selects value "#(PINChange)" from the "transactionType" dropdown at the "TIHomePage" page
    Then the user validates the "transactionType" element is visible at the "TIHomePage" page "PIN Change" "HardStopOnFailure"
    Then the user validates that the partial text "transactionType" element at the "TIHomePage" page is "Equal To" "#(PINChange)" "Validating Correct type selected" "HardStopOnFailure"

    #verify Cash Deposit from DropDown
    And the user selects value "#(CashDeposit)" from the "transactionType" dropdown at the "TIHomePage" page
    Then the user validates the "transactionType" element is visible at the "TIHomePage" page "Cash Deposit" "HardStopOnFailure"
    Then the user validates that the partial text "transactionType" element at the "TIHomePage" page is "Equal To" "#(CashDeposit)" "Validating Correct type selected" "HardStopOnFailure"

     #verify Cash Payments from DropDown
    And the user selects value "#(CashPayment)" from the "transactionType" dropdown at the "TIHomePage" page
    Then the user validates the "transactionType" element is visible at the "TIHomePage" page "Cash Payments" "HardStopOnFailure"
    Then the user validates that the partial text "transactionType" element at the "TIHomePage" page is "Equal To" "#(CashPayment)" "Validating Correct type selected" "HardStopOnFailure"

     #verify PIN Less Cash Deposit from DropDown
    And the user selects value "#(PINLessCashDeposit)" from the "transactionType" dropdown at the "TIHomePage" page
    Then the user validates the "transactionType" element is visible at the "TIHomePage" page "PIN Less Cash Deposit" "HardStopOnFailure"
    Then the user validates that the partial text "transactionType" element at the "TIHomePage" page is "Equal To" "#(PINLessCashDeposit)" "Validating Correct type selected" "HardStopOnFailure"

     #verify Pin Less Check Deposit from DropDown
    And the user selects value "#(PINLessCheckDeposit)" from the "transactionType" dropdown at the "TIHomePage" page
    Then the user validates the "transactionType" element is visible at the "TIHomePage" page "PIN Less Check Deposit" "HardStopOnFailure"
    Then the user validates that the partial text "transactionType" element at the "TIHomePage" page is "Equal To" "#(PINLessCheckDeposit)" "Validating Correct type selected" "HardStopOnFailure"

     #verify Cash Payments from DropDown
    And the user selects value "#(PINLessCashPayment)" from the "transactionType" dropdown at the "TIHomePage" page
    Then the user validates the "transactionType" element is visible at the "TIHomePage" page "PIN Less Cash Payment" "HardStopOnFailure"
    Then the user validates that the partial text "transactionType" element at the "TIHomePage" page is "Equal To" "#(PINLessCashPayment)" "Validating Correct type selected" "HardStopOnFailure"

     #verify Pin Less Check Payment from DropDown
    And the user selects value "#(PINLessCheckPayment)" from the "transactionType" dropdown at the "TIHomePage" page
    Then the user validates the "transactionType" element is visible at the "TIHomePage" page "PIN Less Check Payment" "HardStopOnFailure"
    Then the user validates that the partial text "transactionType" element at the "TIHomePage" page is "Equal To" "#(PINLessCheckPayment)" "Validating Correct type selected" "HardStopOnFailure"

     #verify Check Deposit from DropDown
    And the user selects value "#(CheckDeposit)" from the "transactionType" dropdown at the "TIHomePage" page
    Then the user validates the "transactionType" element is visible at the "TIHomePage" page "Check Deposit" "HardStopOnFailure"
    Then the user validates that the partial text "transactionType" element at the "TIHomePage" page is "Equal To" "#(CheckDeposit)" "Validating Correct type selected" "HardStopOnFailure"

     #verify Cash Internal Transfer from DropDown
    And the user selects value "#(InternalTransfer)" from the "transactionType" dropdown at the "TIHomePage" page
    Then the user validates the "transactionType" element is visible at the "TIHomePage" page "Internal Transfer" "HardStopOnFailure"
    Then the user validates that the partial text "transactionType" element at the "TIHomePage" page is "Equal To" "#(InternalTransfer)" "Validating Correct type selected" "HardStopOnFailure"

      #verify Set PreferenceDeposit from DropDown
    And the user selects value "#(SetPreference)" from the "transactionType" dropdown at the "TIHomePage" page
    Then the user validates the "transactionType" element is visible at the "TIHomePage" page "Check Deposit" "HardStopOnFailure"
    Then the user validates that the partial text "transactionType" element at the "TIHomePage" page is "Equal To" "#(SetPreference)" "Validating Correct type selected" "HardStopOnFailure"

     #verify Get Preference Internal Transfer from DropDown
    And the user selects value "#(GetPreference)" from the "transactionType" dropdown at the "TIHomePage" page
    Then the user validates the "transactionType" element is visible at the "TIHomePage" page "Internal Transfer" "HardStopOnFailure"
    Then the user validates that the partial text "transactionType" element at the "TIHomePage" page is "Equal To" "#(GetPreference)" "Validating Correct type selected" "HardStopOnFailure"


