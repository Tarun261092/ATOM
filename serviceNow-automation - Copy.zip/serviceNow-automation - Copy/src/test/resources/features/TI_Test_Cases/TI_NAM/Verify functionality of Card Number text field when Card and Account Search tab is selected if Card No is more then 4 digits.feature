Feature: TI-NAM
  @TI @TI_NAM @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391

  Scenario: Verify functionality of Card Number text field when Card and Account Search tab is selected NAM
    Given the web application "TI" is launched in a "NewWindow"
    And the user enters the user credential "TIUser" into the "userName" textbox at the "TILoginPage" page
    And the user enters the secure credential "#(DEV_SSO)" into the "password" textbox at the "TILoginPage" page
    And the user selects value "US" from the "region" combobox at the "TILoginPage" page
    Then the user validates the "submit" element is visible at the "TILoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "TILoginPage" page
    #selecting Account and Card Search
    And the user clicks the "cardAndAccountSearch" element at the "TIHomePage" page
    And the user enters "#(CardNumber)" into the "cardNumber" textbox at the "TIHomePage" page
    Then the user validates the "cardNumber" element is visible at the "TIHomePage" page "Correct Card Number" "HardStopOnFailure"
    #Entering Alpha characters
    And the user clears the value in the "cardNumber" textbox at the "TIHomePage" page
    And the user enters "#(CardNumber1)" into the "cardNumber" textbox at the "TIHomePage" page
    Then the user validates the "cardNumber" element is visible at the "TIHomePage" page "Negative Test Data" "HardStopOnFailure"
    #Entering 5 digits card number
    And the user clears the value in the "cardNumber" textbox at the "TIHomePage" page
    And the user enters "#(CardNumber2)" into the "cardNumber" textbox at the "TIHomePage" page
    Then the user validates the "cardNumber" element is visible at the "TIHomePage" page "Value are larger then expected" "HardStopOnFailure"
    # Entering 3 digits card number
    And the user clears the value in the "cardNumber" textbox at the "TIHomePage" page
    And the user enters "#(CardNumber3)" into the "cardNumber" textbox at the "TIHomePage" page
    Then the user validates the "cardNumber" element is visible at the "TIHomePage" page "Value are small then expected" "HardStopOnFailure"