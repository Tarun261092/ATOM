Feature: TI-NAM
  @TI @TI_NAM @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391

  Scenario: Verify functionality of Transaction Type drop down when ATM search tab is selected or default NAM
    Given the web application "TI" is launched in a "NewWindow"
    And the user enters the user credential "TIUser" into the "userName" textbox at the "TILoginPage" page
    And the user enters the secure credential "#(DEV_SSO)" into the "password" textbox at the "TILoginPage" page
    And the user selects value "US" from the "region" combobox at the "TILoginPage" page
    Then the user validates the "submit" element is visible at the "TILoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "TILoginPage" page
    #Verify transaction type dropdown
    And the user clicks the "transactionType" element at the "TIHomePage" page
    Then the user validates the "transactionType" element is visible at the "TIHomePage" page "Transaction Type" "HardStopOnFailure"

