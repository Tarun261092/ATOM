Feature: TI-NAM
  @TI @TI_NAM @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: Verify page build of main TI search screen NAM
    #Login and verify login page
    Given the web application "TI" is launched in a "NewWindow"
    And the user enters the user credential "TIUser" into the "userName" textbox at the "TILoginPage" page
    And the user enters the secure credential "#(DEV_SSO)" into the "password" textbox at the "TILoginPage" page
    And the user selects value "US" from the "region" combobox at the "TILoginPage" page
    Then the user validates the "submit" element is visible at the "TILoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "TILoginPage" page
    #verify the home page
    Then the user validates the "selectLanguage" element is visible at the "TIHomePage" page "ATM Search" "HardStopOnFailure"
    Then the user validates the "ATMSearch" element is visible at the "TIHomePage" page "ATM Search" "HardStopOnFailure"
    And the user scroll to the page until the object "footer" is visible at the page "TIHomePage"
    And the user waits for the "footer" element to be "Visible" on the "TIHomePage" page
    Then the user validates the "terminalIdTI" element is visible at the "TIHomePage" page "footer" "HardStopOnFailure"
    Then the user validates the "footer" element is visible at the "TIHomePage" page "footer" "HardStopOnFailure"

