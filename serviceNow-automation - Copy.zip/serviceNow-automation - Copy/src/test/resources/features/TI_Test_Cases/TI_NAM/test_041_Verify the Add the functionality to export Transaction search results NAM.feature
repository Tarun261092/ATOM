Feature: TI-NAM
    @TI @TI_NAM @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
Scenario: Verify the Add the functionality to export Transaction search results NAM
    Given the web application "TI" is launched in a "NewWindow"
    When the user enters the user credential "TIUser" into the "userName" textbox at the "TILoginPage" page
And the user enters the secure credential "#(DEV_SSO)" into the "password" textbox at the "TILoginPage" page
    And the user selects value "USRegion" from the "region" combobox at the "TILoginPage" page
    Then the user validates the "submit" element is visible at the "TILoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "TILoginPage" page
    And the user enters the user credential "terminalID" into the "terminalIdTI" textbox at the "TIHomePage" page
    And the user enters the user credential "DateFrom" into the "postDateFrom" textbox at the "TIHomePage" page
    And the user enters the user credential "DateTo" into the "postDateTo" textbox at the "TIHomePage" page
    And the user exports the transaction search results