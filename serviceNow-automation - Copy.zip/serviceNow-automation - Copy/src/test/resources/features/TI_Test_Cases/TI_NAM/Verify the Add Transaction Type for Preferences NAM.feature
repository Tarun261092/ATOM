Feature: TI-NAM
  @TI @TI_NAM @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: Verify the Add Transaction Type for Preferences NAM
    Given the web application "TI" is launched in a "NewWindow"
    And the user enters the user credential "TIUser" into the "userName" textbox at the "TILoginPage" page
    And the user enters the secure credential "#(DEV_SSO)" into the "password" textbox at the "TILoginPage" page
    And the user selects value "US" from the "region" combobox at the "TILoginPage" page
    Then the user validates the "submit" element is visible at the "TILoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "TILoginPage" page
    # Preference option
    And the user waits for the "TerminalIdTI" element to be "Visible" on the "TIHomePage" page
    And the user enters the user credential "terminalID" into the "terminalIdTI" textbox at the "TIHomePage" page
    And the user enters the user credential "DateFrom" into the "postDateFrom" textbox at the "TIHomePage" page
    And the user enters the user credential "DateTo" into the "postDateTo" textbox at the "TIHomePage" page

    #And the user enters "terminalID" into the "terminalIdTI" textbox at the "TIHomePage" page
    #And the user enters "DateFrom" into the "postDateFrom" textbox at the "TIHomePage" page
    #And the user enters "DateTo" into the "postDateTo" textbox at the "TIHomePage" page
    #verify preference
    And the user selects value "#(GetPreference)" from the "transactionType" dropdown at the "TIHomePage" page
    Then the user validates the "transactionType" element is visible at the "TIHomePage" page "Get Preferences" "HardStopOnFailure"
    Then the user validates that the partial text "transactionType" element at the "TIHomePage" page is "Equal To" "#(GetPreference)" "Validating the selected option" "HardStopOnFailure"

    #verify FastCash from DropDown
    And the user selects value "#(SetPreference)" from the "transactionType" dropdown at the "TIHomePage" page
    Then the user validates the "transactionType" element is visible at the "TIHomePage" page "Set Preferences" "HardStopOnFailure"
    Then the user validates that the partial text "transactionType" element at the "TIHomePage" page is "Equal To" "#(SetPreference)" "Validating the selected option" "HardStopOnFailure"


