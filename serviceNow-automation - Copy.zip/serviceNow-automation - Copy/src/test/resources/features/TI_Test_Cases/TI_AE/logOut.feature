Feature: TI_AE
  #@TI_Test
  Scenario: Logout test for AE region with valid User ID and Password
    Given the web application "TI" is launched in a "NewWindow"
    And the user clicks the "advanceButton" element at the "TILoginPage" page
    And the user clicks the "proceedButton" element at the "TILoginPage" page
    And the user enters the user credential "TIUser" into the "userName" textbox at the "TILoginPage" page
    And the user enters the encrypted value "TIPassword" into the "password" textbox at the "TILoginPage" page
    And the user selects value "AERegion" from the "region" combobox at the "TILoginPage" page
    Then the user validates the "submit" element is visible at the "TILoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "TILoginPage" page
    Then the user validates the "ATMSearch" element is visible at the "TILoginPage" page "ATM Search" "HardStopOnFailure"
    And the user clicks the "menu" element at the "TILoginPage" page
    And the user clicks the "logOut" element at the "TILoginPage" page
    Then the user validates the "submit" element is visible at the "TILoginPage" page "Submit" "HardStopOnFailure"



