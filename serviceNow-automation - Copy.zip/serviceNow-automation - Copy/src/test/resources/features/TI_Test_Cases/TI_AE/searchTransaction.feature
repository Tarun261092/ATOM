Feature: TI_AE
  #@TI_Test
  Scenario: Transaction search with terminal Id
    Given the web application "TI" is launched in a "NewWindow"
    And the user clicks the "advanceButton" element at the "TILoginPage" page
    And the user clicks the "proceedButton" element at the "TILoginPage" page
    And the user enters the user credential "TIUser" into the "userName" textbox at the "TILoginPage" page
    And the user enters the encrypted value "TIPassword" into the "password" textbox at the "TILoginPage" page
    And the user selects value "AERegion" from the "region" combobox at the "TILoginPage" page
    Then the user validates the "submit" element is visible at the "TILoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "TILoginPage" page
    And the user waits for the page to load
    #Searching for Terminal details by node Id
    And the user enters "#(terminalID)" into the "terminalIdTI" textbox at the "TIHomePage" page
    And the user enters "#(TerminalTI)" into the "postDateFrom" textbox at the "TIHomePage" page
    And the user enters "#(DateFrom)" into the "postDateTo" textbox at the "TIHomePage" page
    And the user clicks the "searchButton" element at the "TIHomePage" page
    Then the user scroll to the page until the object "terminalIdResult" is visible at the page "TIHomePage"
    #Then the user scroll to the page until the object "terminalIdResult" is visible at the page "TIHomePage"
    Then the user validates the "terminalIdResult" element is visible at the "TIHomePage" page "B13000173" "HardStopOnFailure"
    And the user clicks the "menu" element at the "TILoginPage" page
    And the user clicks the "logOut" element at the "TILoginPage" page
    Then the user validates the "submit" element is visible at the "TILoginPage" page "Submit" "HardStopOnFailure"