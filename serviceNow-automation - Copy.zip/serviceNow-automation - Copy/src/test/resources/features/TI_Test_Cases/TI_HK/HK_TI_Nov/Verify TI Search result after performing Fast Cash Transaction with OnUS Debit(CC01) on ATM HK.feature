Feature: TI-HK
  @TI @TI_HK @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: Verify TI Search result after performing Fast Cash Transaction with OnUS Debit(CC01) on ATM HK
    Given the web application "TI" is launched in a "NewWindow"
    And the user enters the user credential "TIUser" into the "userName" textbox at the "TILoginPage" page
    And the user enters the secure credential "#(DEV_SSO)" into the "password" textbox at the "TILoginPage" page
    And the user selects value "HK" from the "region" combobox at the "TILoginPage" page
    Then the user validates the "submit" element is visible at the "TILoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "TILoginPage" page
  # Verify the transaction type and Terminal ID
    And the user enters the user credential "HKterminalID" into the "terminalIdTI" textbox at the "TIHomePage" page
    And the user enters the user credential "HKDateFrom" into the "postDateFrom" textbox at the "TIHomePage" page
    And the user enters the user credential "HKDateTo" into the "postDateTo" textbox at the "TIHomePage" page
    #And the user enters "#(terminalID)" into the "terminalIdTI" textbox at the "TIHomePage" page
    #And the user enters "#(DateFrom)" into the "postDateFrom" textbox at the "TIHomePage" page
    #And the user enters "#(DateTo)" into the "postDateTo" textbox at the "TIHomePage" page
    And the user selects value "#(FastCash)" from the "transactionType" dropdown at the "TIHomePage" page
    And the user clicks the "searchButton" element at the "TIHomePage" page
    #And the user waits for the page to load
    And the user waits for the "result" element to be "Visible" on the "TIHomePage" page
    Then the user validates the "result" element is visible at the "TIHomePage" page "Result" "HardStopOnFailure"
    And the user scroll to the page until the object "resultTerminalID" is visible at the page "TIHomePage"
    Then the user validates that the partial text "HKDTransactionAmountCurrency" element at the "TIHomePage" page is "Equal To" "HKD" "SGDTransactionAmountCurrency" "HardStopOnFailure"
    And the user waits for the "resultTerminalID" element to be "visible" on the "TIHomePage" page
    Then the user validates the "resultTerminalID" element is visible at the "TIHomePage" page "Fast Cash" "HardStopOnFailure"