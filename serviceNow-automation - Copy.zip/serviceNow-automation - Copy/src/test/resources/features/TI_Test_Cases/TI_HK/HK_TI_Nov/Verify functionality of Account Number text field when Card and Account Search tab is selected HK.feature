Feature: TI-HK
  @TI @TI_HK @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  
  Scenario: Verify functionality of Account Number text field when Card and Account Search tab is selected HK
    Given the web application "TI" is launched in a "NewWindow"
    And the user enters the user credential "TIUser" into the "userName" textbox at the "TILoginPage" page
    And the user enters the secure credential "#(DEV_SSO)" into the "password" textbox at the "TILoginPage" page
    And the user selects value "HK" from the "region" combobox at the "TILoginPage" page
    Then the user validates the "submit" element is visible at the "TILoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "TILoginPage" page
    #selecting Account and Card Search
  And the user clicks the "cardAndAccountSearch" element at the "TIHomePage" page
    And the user enters "#(AccountNumber)" into the "accountNumber" textbox at the "TIHomePage" page
    Then the user validates the "accountNumber" element is visible at the "TIHomePage" page "Valid Account Number" "HardStopOnFailure"
