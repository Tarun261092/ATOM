Feature: TI-SG
  @TI_AUG
  Scenario: Validate TI Card and Account search and display matching results SG
    Given the web application "TI" is launched in a "NewWindow"
    And the user enters the user credential "TIUser" into the "userName" textbox at the "TILoginPage" page
    And the user enters the encrypted value "TIPassword" into the "password" textbox at the "TILoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "TILoginPage" page
    Then the user validates the "submit" element is visible at the "TILoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "TILoginPage" page
    #selecting Account and Card Search
    And the user clicks the "cardAndAccountSearch" element at the "TIHomePage" page
    And the user enters "#(AccountNumber)" into the "accountNumber" textbox at the "TIHomePage" page
    And the user enters "#(CardNumber)" into the "cardNumber" textbox at the "TIHomePage" page
    And the user enters "#(DateFrom)" into the "postDateFrom" textbox at the "TIHomePage" page
    And the user enters "#(DateTo)" into the "postDateTo" textbox at the "TIHomePage" page
    And the user clicks the "searchButton" element at the "TIHomePage" page
    And the user scroll to the page until the object "result" is visible at the page "TIHomePage"
    Then the user validates the "result" element is visible at the "TIHomePage" page "Result" "HardStopOnFailure"
