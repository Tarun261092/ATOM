Feature: TI-SG
  @TI_AUG

  Scenario: Verify functionality of Card Number text field when Card and Account Search tab is selected SG
    Given the web application "TI" is launched in a "NewWindow"
    And the user enters the user credential "TIUser" into the "userName" textbox at the "TILoginPage" page
    And the user enters the encrypted value "TIPassword" into the "password" textbox at the "TILoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "TILoginPage" page
    Then the user validates the "submit" element is visible at the "TILoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "TILoginPage" page
    #selecting Account and Card Search
    And the user clicks the "cardAndAccountSearch" element at the "TIHomePage" page
    And the user enters "#(CardNumber)" into the "cardNumber" textbox at the "TIHomePage" page
    Then the user validates the "cardNumber" element is visible at the "TIHomePage" page "Correct Card Number" "HardStopOnFailure"
    #Entering Alpha characters
    And the user clears the value in the "cardNumber" textbox at the "TIHomePage" page
    And the user enters "#(CardNumber1)" into the "cardNumber" textbox at the "TIHomePage" page
    Then the user validates the "cardNumber" element is visible at the "TIHomePage" page "Negative Test Data" "HardStopOnFailure"
    #Entering 5 digits card number
    And the user clears the value in the "cardNumber" textbox at the "TIHomePage" page
    And the user enters "#(CardNumber2)" into the "cardNumber" textbox at the "TIHomePage" page
    Then the user validates the "cardNumber" element is visible at the "TIHomePage" page "Value are larger then expected" "HardStopOnFailure"
    # Entering 3 digits card number
    And the user clears the value in the "cardNumber" textbox at the "TIHomePage" page
    And the user enters "#(CardNumber3)" into the "cardNumber" textbox at the "TIHomePage" page
    Then the user validates the "cardNumber" element is visible at the "TIHomePage" page "Value are small then expected" "HardStopOnFailure"