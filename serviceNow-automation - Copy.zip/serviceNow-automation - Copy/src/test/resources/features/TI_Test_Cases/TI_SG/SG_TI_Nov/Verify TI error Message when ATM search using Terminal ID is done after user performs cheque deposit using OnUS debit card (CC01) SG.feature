Feature: TI-SG
  @TI_AUG
  Scenario: Verify TI error Message when ATM search using Terminal ID is done after user performs cheque deposit using OnUS debit card (CC01) SG
    Given the web application "TI" is launched in a "NewWindow"
    And the user enters the user credential "TIUser" into the "userName" textbox at the "TILoginPage" page
    And the user enters the encrypted value "TIPassword" into the "password" textbox at the "TILoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "TILoginPage" page
    Then the user validates the "submit" element is visible at the "TILoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "TILoginPage" page
  # Verify the transaction type and Terminal ID
    And the user enters "#(terminalID)" into the "terminalIdTI" textbox at the "TIHomePage" page
    And the user enters "#(DateFrom)" into the "postDateFrom" textbox at the "TIHomePage" page
    And the user enters "#(DateTo)" into the "postDateTo" textbox at the "TIHomePage" page
    And the user selects value "#(CheckDeposit)" from the "transactionType" dropdown at the "TIHomePage" page
    And the user clicks the "searchButton" element at the "TIHomePage" page
    And the user waits for the page to load
    And the user waits for the "errorMessage" element to be "Visible" on the "TIHomePage" page
    Then the user validates the "errorMessage" element is visible at the "TIHomePage" page "Error Message" "HardStopOnFailure"