Feature: TI-SG
  @TI_AUG
  Scenario: Validate TI ATM search Branch Number is displayed in the search result SG
    Given the web application "TI" is launched in a "NewWindow"
    And the user enters the user credential "TIUser" into the "userName" textbox at the "TILoginPage" page
    And the user enters the encrypted value "TIPassword" into the "password" textbox at the "TILoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "TILoginPage" page
    Then the user validates the "submit" element is visible at the "TILoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "TILoginPage" page
    #Verify transaction type dropdown
    And the user enters "#(terminalID)" into the "terminalIdTI" textbox at the "TIHomePage" page
    And the user enters "#(DateFrom)" into the "postDateFrom" textbox at the "TIHomePage" page
    And the user enters "#(DateTo)" into the "postDateTo" textbox at the "TIHomePage" page
    And the user clicks the "searchButton" element at the "TIHomePage" page
    And the user scroll to the page until the object "resultBranchNumber" is visible at the page "TIHomePage"
    And the user waits for the "resultBranchNumber" element to be "visible" on the "TIHomePage" page
    #Then the user validates "Text" that the "resultBranchNumber" element is "Equal" "00199" at the "TIHomePage" page "result" "HardStopOnFailure"
    Then the user validates the "resultBranchNumber" element is visible at the "TIHomePage" page "Result Branch Number" "HardStopOnFailure"