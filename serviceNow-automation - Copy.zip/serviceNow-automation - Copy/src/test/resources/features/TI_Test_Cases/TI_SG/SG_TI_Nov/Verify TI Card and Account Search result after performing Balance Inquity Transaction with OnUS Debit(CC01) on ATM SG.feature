Feature: TI-SG
  @TI_AUG
  Scenario: Verify TI Card and Account Search result after performing Balance Inquity Transaction with OnUS Debit(CC01) on ATM SG
    Given the web application "TI" is launched in a "NewWindow"
    And the user enters the user credential "TIUser" into the "userName" textbox at the "TILoginPage" page
    And the user enters the encrypted value "TIPassword" into the "password" textbox at the "TILoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "TILoginPage" page
    Then the user validates the "submit" element is visible at the "TILoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "TILoginPage" page
  # Verify the transaction type and Terminal ID
    And the user clicks the "cardAndAccountSearch" element at the "TIHomePage" page
    And the user enters "#(AccountNumber)" into the "accountNumber" textbox at the "TIHomePage" page
    And the user enters "#(CardNumber)" into the "cardNumber" textbox at the "TIHomePage" page
    And the user enters "#(DateFrom)" into the "postDateFrom" textbox at the "TIHomePage" page
    And the user enters "#(DateTo)" into the "postDateTo" textbox at the "TIHomePage" page
    And the user selects value "#(BalanceInquiry)" from the "transactionType" dropdown at the "TIHomePage" page
    And the user clicks the "searchButton" element at the "TIHomePage" page
    #And the user waits for the page to load
    And the user waits for the "resultCard" element to be "Visible" on the "TIHomePage" page
    Then the user validates the "resultCard" element is visible at the "TIHomePage" page "Balance Inquiry" "HardStopOnFailure"
    And the user scroll to the page until the object "resultTerminalID" is visible at the page "TIHomePage"
    And the user waits for the "resultTerminalID" element to be "visible" on the "TIHomePage" page
    Then the user validates the "resultTerminalID" element is visible at the "TIHomePage" page "Terminal Id" "HardStopOnFailure"