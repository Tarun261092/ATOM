Feature: TI-SG
  @TI_AUG

  Scenario: Validate TI ATM search with Transaction Type (Optional Field) SG
    Given the web application "TI" is launched in a "NewWindow"
    And the user enters the user credential "TIUser" into the "userName" textbox at the "TILoginPage" page
    And the user enters the encrypted value "TIPassword" into the "password" textbox at the "TILoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "TILoginPage" page
    Then the user validates the "submit" element is visible at the "TILoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "TILoginPage" page
    #Verify transaction type dropdown
    And the user enters "#(terminalID)" into the "terminalIdTI" textbox at the "TIHomePage" page
    And the user enters "#(DateFrom)" into the "postDateFrom" textbox at the "TIHomePage" page
    And the user enters "#(DateTo)" into the "postDateTo" textbox at the "TIHomePage" page
    #verify Login from DropDown
    And the user selects value "#(Login)" from the "transactionType" dropdown at the "TIHomePage" page
    Then the user validates the "transactionType" element is visible at the "TIHomePage" page "Login" "HardStopOnFailure"
    #verify FastCash from DropDown
    And the user selects value "#(FastCash)" from the "transactionType" dropdown at the "TIHomePage" page
    Then the user validates the "transactionType" element is visible at the "TIHomePage" page "FastCash" "HardStopOnFailure"
     #verify ReLogin from DropDown
    And the user selects value "#(ReLogin)" from the "transactionType" dropdown at the "TIHomePage" page
    Then the user validates the "transactionType" element is visible at the "TIHomePage" page "ReLogin" "HardStopOnFailure"
    #verify Withdrawal from DropDown
    And the user selects value "#(Withdrawal)" from the "transactionType" dropdown at the "TIHomePage" page
    Then the user validates the "transactionType" element is visible at the "TIHomePage" page "Withdrawal" "HardStopOnFailure"
      #verify Balance Inquiry from DropDown
    And the user selects value "#(BalanceInquiry)" from the "transactionType" dropdown at the "TIHomePage" page
    Then the user validates the "transactionType" element is visible at the "TIHomePage" page "Balance Inquiry" "HardStopOnFailure"
    #verify Account Overview from DropDown
    And the user selects value "#(AccountOverview)" from the "transactionType" dropdown at the "TIHomePage" page
    Then the user validates the "transactionType" element is visible at the "TIHomePage" page "Account overview" "HardStopOnFailure"
        #verify PIN Change from DropDown
    And the user selects value "#(PINChange)" from the "transactionType" dropdown at the "TIHomePage" page
    Then the user validates the "transactionType" element is visible at the "TIHomePage" page "PIN Change" "HardStopOnFailure"
    #verify Cash Deposit from DropDown
    And the user selects value "#(CashDeposit)" from the "transactionType" dropdown at the "TIHomePage" page
    Then the user validates the "transactionType" element is visible at the "TIHomePage" page "Cash Deposit" "HardStopOnFailure"
     #verify Cash Payments from DropDown
    And the user selects value "#(CashPayment)" from the "transactionType" dropdown at the "TIHomePage" page
    Then the user validates the "transactionType" element is visible at the "TIHomePage" page "Cash Payments" "HardStopOnFailure"
     #verify PIN Less Cash Deposit from DropDown
    And the user selects value "#(PINLessCashDeposit)" from the "transactionType" dropdown at the "TIHomePage" page
    Then the user validates the "transactionType" element is visible at the "TIHomePage" page "PIN Less Cash Deposit" "HardStopOnFailure"
     #verify Pin Less Check Deposit from DropDown
    And the user selects value "#(PINLessCheckDeposit)" from the "transactionType" dropdown at the "TIHomePage" page
    Then the user validates the "transactionType" element is visible at the "TIHomePage" page "PIN Less Check Deposit" "HardStopOnFailure"
     #verify Cash Payments from DropDown
    And the user selects value "#(PINLessCashPayment)" from the "transactionType" dropdown at the "TIHomePage" page
    Then the user validates the "transactionType" element is visible at the "TIHomePage" page "PIN Less Cash Payment" "HardStopOnFailure"
     #verify Pin Less Check Payment from DropDown
    And the user selects value "#(PINLessCheckPayment)" from the "transactionType" dropdown at the "TIHomePage" page
    Then the user validates the "transactionType" element is visible at the "TIHomePage" page "PIN Less Check Payment" "HardStopOnFailure"
     #verify Check Deposit from DropDown
    And the user selects value "#(CheckDeposit)" from the "transactionType" dropdown at the "TIHomePage" page
    Then the user validates the "transactionType" element is visible at the "TIHomePage" page "Check Deposit" "HardStopOnFailure"
     #verify Cash Internal Transfer from DropDown
    And the user selects value "#(InternalTransfer)" from the "transactionType" dropdown at the "TIHomePage" page
    Then the user validates the "transactionType" element is visible at the "TIHomePage" page "Internal Transfer" "HardStopOnFailure"

