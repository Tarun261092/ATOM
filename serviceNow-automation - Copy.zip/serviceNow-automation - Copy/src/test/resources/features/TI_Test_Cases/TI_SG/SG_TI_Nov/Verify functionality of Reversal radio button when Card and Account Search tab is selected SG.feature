Feature: TI-SG
  @TI_AUG

  Scenario: Verify functionality of Reversal radio button when Card and Account Search tab is selected SG
    Given the web application "TI" is launched in a "NewWindow"
    And the user enters the user credential "TIUser" into the "userName" textbox at the "TILoginPage" page
    And the user enters the encrypted value "TIPassword" into the "password" textbox at the "TILoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "TILoginPage" page
    Then the user validates the "submit" element is visible at the "TILoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "TILoginPage" page
    #verify True is selected
    And the user clicks the "cardAndAccountSearch" element at the "TIHomePage" page
    And the user clicks the "reversalYes" element at the "TIHomePage" page
    Then the user validates the "reversalRadioButton" element is visible at the "TIHomePage" page "True" "HardStopOnFailure"
    And the user clicks the "reversalNo" element at the "TIHomePage" page
    Then the user validates the "reversalRadioButton" element is visible at the "TIHomePage" page "False" "HardStopOnFailure"

