Feature: TI-SG
  @TI_AUG
  Scenario: Validate TI ATM search without Terminal ID SG
    Given the web application "TI" is launched in a "NewWindow"
    When the user enters the user credential "TIUser" into the "userName" textbox at the "TILoginPage" page
    When the user enters the encrypted value "TIPassword" into the "password" textbox at the "TILoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "TILoginPage" page
    Then the user validates the "submit" element is visible at the "TILoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "TILoginPage" page
    And the user waits for the page to load
    #Searching for Terminal details by node Id
    And the user enters "#(terminalID)" into the "terminalIdTI" textbox at the "TIHomePage" page
    And the user enters "#(DateFrom)" into the "postDateFrom" textbox at the "TIHomePage" page
    And the user enters "#(DateTo)" into the "postDateTo" textbox at the "TIHomePage" page
    Then the user validates the "postDateTo" element is visible at the "TIHomePage" page "To Date" "HardStopOnFailure"
    Then the user validates the "searchButton" element is disabled at the "TIHomePage" page "Search Bar" "HardStopOnFailure"