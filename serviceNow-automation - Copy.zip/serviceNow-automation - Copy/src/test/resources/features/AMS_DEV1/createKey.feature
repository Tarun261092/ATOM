Feature: AMS-DEV1-NAM
 @ATM_CreateKey @ATM1234 @Z_Auto @Test1 @Browser @PCD_MAR032025 @PED_AUG032024 @Sanity @LOB_AMS @CSIIDi-173062
  Scenario: ATM_Create_Key
        #Given the user sends request to the "getTokenATM_Dev1" API
        #Then the user validates the API response has status code of "200" "getToken" "HardStopOnFailure"
		#And store "token" from the API response into the data dictionary with key "#(token1)"
        #And store "token" within parent attribute "payload" from the API response into the data dictionary with key "#(token)"
        Given the user sends request to the "createKey_Dev1" API
        Then the user validates the API response has status code of "200" "Create Key Successfull" "HardStopOnFailure"