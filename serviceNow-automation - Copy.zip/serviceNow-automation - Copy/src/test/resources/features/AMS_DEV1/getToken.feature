Feature: AMS-DEV1-NAM
  @getATMtoken @ATM1234 @Test1 @JIRA_ATM-64941 @Z_Auto @Browser @PCD_MAR032025 @PED_AUG032024 @Sanity @LOB_AMS @CSIIDi-173062
  Scenario: ATM_TOKEN
        Given the user sends request to the "getTokenATM_Dev1" API
        Then the user validates the API response has status code of "200" "Token Generated Successfully" "HardStopOnFailure"
