Feature: AMS-DEV1-NAM
 @ATM_Account_List @ATM1234 @Test1 @Z_Auto @Browser @PCD_MAR032025 @PED_AUG032024 @Sanity @LOB_AMS @CSIIDi-173062
  Scenario: ATM_Balance_Inquiry
        #Given the user sends request to the "getTokenATM_Dev1" API
        #Then the user validates the API response has status code of "200" "getToken" "HardStopOnFailure"
        #And store "token" within parent attribute "payload" from the API response into the data dictionary with key "#(token)"
        Given the user sends request to the "BalanceInquiryATM_Dev1" API
        Then the user validates the API response has status code of "200" "Balance Returned Successfully" "HardStopOnFailure"