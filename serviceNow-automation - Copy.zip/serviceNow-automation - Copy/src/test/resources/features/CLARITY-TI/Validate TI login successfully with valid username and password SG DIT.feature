Feature: TI Environment
  @TI_Env @EVM_HealthCheck @Env1234 @Clarity_TI

  Scenario: Validate TI login successfully with valid username and password SG DIT
    #Login with valid user Id and password
    Given the web application "TI_DIT" is launched in a "NewWindow"
    And the user enters the user credential "TIUser" into the "userName" textbox at the "TILoginPage" page
    And the user enters the encrypted value "TIPassword" into the "password" textbox at the "TILoginPage" page
    And the user selects value "SG" from the "region" combobox at the "TILoginPage" page
    Then the user validates the "submit" element is visible at the "TILoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "TILoginPage" page
    #Verify successful login
    #Then the user validates the "ATMSearch" element is visible at the "TIHomePage" page "ATM Search" "HardStopOnFailure"

