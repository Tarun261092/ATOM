Feature: CMS-SG

  @CMS @CMS_SG @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate successful Login
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    #And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    Then the user validates that the partial text "assertSearch" element at the "CMSHomePage" page is "Equal To" "Asset Search" "Save" "HardStopOnFailure"
    Then the user validates the "assertSearch" element is visible at the "CMSHomePage" page "Asset Search" "HardStopOnFailure"


  @CMS @CMS_SG @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate successful logout
    Given the web application "CMS" is launched in a "NewWindow"
    And the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    And the user waits for the "assetSearch" element to be "Visible" on the "CMSHomePage" page
    Then the user validates the "assetSearch" element is visible at the "CMSHomePage" page "Assert Search" "HardStopOnFailure"
    And the user clicks the "logOut" element at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"

  @CMS @CMS_SG @CMS @CMS_SG4 @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate Create Site page UI
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    And the user clicks the "createSite" element at the "CreateSite" page
    Then the user validates the "status" element is visible at the "CreateSite" page "Status" "HardStopOnFailure"
    Then the user validates the "publicAccess" element is visible at the "CreateSite" page "Public Access" "HardStopOnFailure"
    And the user scroll to the page until the object "footerLogo" is visible at the page "CreateSite"
    And the user waits for the "footerLogo" element to be "Present" on the "CreateSite" page
    Then the user validates the "submitSiteButton" element is visible at the "CreateSite" page "Submit button present on the page" "HardStopOnFailure"
    And the user clicks the "siteSchedule" element at the "CreateSite" page
    Then the user validates the "siteSchedule" element is visible at the "CreateSite" page "Verify the page" "HardStopOnFailure"
    And the user clicks the "locationAssociation" element at the "CreateSite" page
    Then the user validates the "locationAssociation" element is visible at the "CreateSite" page "Verify the page" "HardStopOnFailure"

  @CMS @CMS_SG @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate Valid Site information saved
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    And the user clicks the "createSite" element at the "CMSHomepage" page
    And the user enters "#(SiteNumber)" into the "siteNumber" textbox at the "CreateSite" page
    And the user enters "#(Description)" into the "siteDescription" textbox at the "CreateSite" page
   # And the user enters "#(SiteIdVV)" into the "siteIdVV" textbox at the "CreateSite" page
    #And the user clicks the "accessType" element at the "CreateSite" page
    #And the user clicks the "accessTypeBranch" element at the "CreateSite" page
    And the user waits for the "status" element to be "VISIBLE" on the "CreateSite" page
    #And the user clicks the "status" element at the "CreateSite" page
   # And the user clicks the "statusActive" element at the "CreateSite" page
    And the user clicks the "onPremise" element at the "CreateSite" page
    And the user waits for the "onPremiseYes" element to be "VISIBLE" on the "CreateSite" page
    And the user clicks the "onPremiseYes" element at the "CreateSite" page
   # And the user clicks the "siteDescriptionLabel" element at the "CreateSite" page
    #Then the user validates that the partial text "OnPremise" element at the "CreateSite" page is "Equal To" "NO" "Validating the selection" "HardStopOnFailure"
   #Good until here
    #When the user waits for the "remoteSite" element to be "Visible" on the "CreateSite" page
    #And the user waits for the page to load
    #And the user clicks the "remoteSite" element at the "CreateSite" page
    #And the user clicks the "remoteSite" element at the "CreateSite" page

    #When the user waits for the "remoteSiteYes" element to be "VISIBLE" on the "CreateSite" page
    #And the user selects value "YES" from the "remoteSiteYes" dropdown at the "CreateSite" page
    #And the user sends keys "Key_DOWN"
    #And the user sends keys "Key_ENTER"
    #And the user clicks the "remoteSiteYes" element at the "CreateSite" page

     # And the user clicks the "siteDescriptionLabel" element at the "CreateSite" page
    #And the user clicks the "remoteSite" element at the "CreateSite" page
    #Then the user validates that the partial text "remoteSite" element at the "CreateSite" page is "Equal To" "NO" "Validating the selection" "HardStopOnFailure"
   # And the user clicks the "publicAccess" element at the "CreateSite" page
   #  When the user waits for the "publicAccessYes" element to be "VISIBLE" on the "CreateSite" page
   # When the user waits for the "publicAccessYes" element to be "Visible" on the "CreateSite" page
   #  And the user clicks the "publicAccessYes" element at the "CreateSite" page
   # And the user clicks the "siteDescriptionLabel" element at the "CreateSite" page

   #And the user waits for the "publicAccess" element to be "Present" on the "CreateSite" page
   # Then the user validates that the partial text "publicAccess" element at the "CreateSite" page is "Equal To" "YES" "Validating the selection" "HardStopOnFailure"

    #And the user clicks the "vendor24HourAccess" element at the "CreateSite" page
    #And the user clicks the "vendor24HourAccessYes" element at the "CreateSite" page
    #And the user clicks the "customer24HrAccess" element at the "CreateSite" page
    #And the user clicks the "customer24HrAccessYes" element at the "CreateSite" page
    #Then the user validates the "customer24HrAccessYes" element is visible at the "CreateSite" page "Schedule Page screenshot" "HardStopOnFailure"
    #Then the user validates that the partial text "customer24HrAccess" element at the "CreateSite" page is "Equal To" "YES" "Validating the selection" "HardStopOnFailure"
   # And the user clicks the "siteSchedule" element at the "CreateSite" page
    #Then the user validates the "siteSchedule" element is visible at the "CreateSite" page "Schedule Page screenshot" "HardStopOnFailure"
    #And the user clicks the "locationAssociation" element at the "CreateSite" page
    #And the user enters "#(LocationId)" into the "locationId" textbox at the "CreateSite" page
    #And the user clicks the "locationSearchButton" element at the "CreateSite" page
    #And the user waits for the "locationSelect" element to be "Visible" on the "CreateSite" page
    #And the user clicks the "locationSelect" element at the "CreateSite" page
    #And the user clicks the "submitSiteButton" element at the "CreateSite" page
    #Then the user validates the "submitSiteButton" element is visible at the "CreateSite" page "Schedule Page screenshot" "HardStopOnFailure"
    #Then the user validates that the partial text "confirmationRequired" element at the "CreateSite" page is "Equal To" "Confirmation Required" "Validating Text" "HardStopOnFailure"
    #And the user clicks the "confirmationOk" element at the "CreateSite" page
    #And the user waits for the "confirmationPage" element to be "Visible" on the "CreateSite" page
    #Then the user validates that the partial text "confirmationPage" element at the "CreateSite" page is "Equal To" "Your changes have been saved!" "Validated site created successfully" "HardStopOnFailure"

  @CMS @CMS_SG @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario:SG Validate Surcharge Fee Amount field_Site Tab
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    And the user clicks the "createAsset" element at the "CMSHomePage" page
    And the user clicks the "siteAssociation" element at the "Create Asset" page
    And the user clicks the "ATMForm" element at the "CreateAsset" page
    And the user waits for the "surchargeYes" element to be "Visible" on the "CreateAsset" page
    And the user clicks the "surchargeYes" element at the "CreateAsset" page
    Then the user validates the "surchargeNo" element is visible at the "CreateAsset" page "Validating both radio button are working" "HardStopOnFailure"
    And the user clicks the "surchargeNo" element at the "CreateAsset" page
    Then the user validates the "surchargeNo" element is visible at the "CreateAsset" page "Validating both radio button are working" "HardStopOnFailure"

  @CMS @CMS_SG @CMS @CMS_SG4 @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate site schedule field_Site Tab
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    And the user clicks the "createAsset" element at the "CMSHomePage" page
    And the user clicks the "siteAssociation" element at the "Create Asset" page
    And the user clicks the "statusSiteAssociation" element at the "CreateAsset" page
    Then the user validates the "statusSiteAssociation" element is visible at the "CreateAsset" page "Elements on the page" "HardStopOnFailure"
    And the user scroll to the page until the object "activeField" is visible at the page "CreateAsset"
    And the user waits for the "activeField" element to be "Visible" on the "CreateAsset" page
    And the user clicks the "activeField" element at the "CreateAsset" page
    And the user clicks the "searchSiteAssociation" element at the "CreateAsset" page
    And the user scroll to the page until the object "selectSite" is visible at the page "CreateAsset"
    And the user clicks the "selectSite" element at the "CreateAsset" page
    And the user clicks the "ATMForm" element at the "CreateAsset" page
    And the user waits for the "siteSchedule" element to be "Visible" on the "CreateAsset" page
    And the user clicks the "siteSchedule" element at the "CreateAsset" page
    Then the user validates the "siteSchedule24HR" element is present at the "CreateAsset" page "Validating both button are working" "HardStopOnFailure"
    And the user clicks the "siteSchedule24HR" element at the "CreateAsset" page
    Then the user validates the "siteSchedule24HR" element is present at the "CreateAsset" page "Validating both button are working" "HardStopOnFailure"

  @CMS @CMS_SG @CMS @CMS_SG4 @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate Invalid Site information
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    And the user clicks the "createSite" element at the "CMSHomePage" page
    And the user clicks the "submitSiteButton" element at the "CreateSite" page
    Then the user validates that the partial text "blankErrorMessage" element at the "CreateSite" page is "Equal To" "The following tabs have errors. Please review the following tabs:" "Verifying empty field" "HardStopOnFailure"

  @CMS @CMS_SG @CMS @CMS_SG5 @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate Create ATM page UI_ATM Basics
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    And the user clicks the "createAsset" element at the "CMSHomePage" page
#added few lines of code for UI changes in Create Asset page
    And the user clicks the "siteAssociation" element at the "Create Asset" page
    And the user clicks the "statusSiteAssociation" element at the "Create Asset" page
    Then the user validates the "statusSiteAssociation" element is visible at the "CreateAsset" page "Elements on the page" "HardStopOnFailure"
    And the user scroll to the page until the object "activeField" is visible at the page "CreateAsset"
    And the user waits for the "activeField" element to be "Visible" on the "CreateAsset" page
    And the user clicks the "activeField" element at the "CreateAsset" page
    And the user clicks the "searchSiteAssociation" element at the "CreateAsset" page
    And the user scroll to the page until the object "selectSite" is visible at the page "CreateAsset"
    And the user clicks the "selectSite" element at the "CreateAsset" page
    And the user clicks the "ATMForm" element at the "CreateAsset" page
    #untill this point we need to add in other failed test cases as well
    Then the user validates the "AMTBasisHerder" element is visible at the "CreateAsset" page "Header" "HardStopOnFailure"
    #Then the user validates the "saveAsset" element is visible at the "CreateAsset" page "Elements on the page" "HardStopOnFailure"
    And the user scroll to the page until the object "siteSchedule" is visible at the page "CreateAsset"
    And the user waits for the "siteSchedule" element to be "Visible" on the "CreateAsset" page
    Then the user validates the "siteSchedule" element is visible at the "CreateAsset" page "Elements on the page" "HardStopOnFailure"
    And the user scroll to the page until the object "REMSCode" is visible at the page "CreateAsset"
    And the user waits for the "REMSCode" element to be "Visible" on the "CreateAsset" page
    Then the user validates the "REMSCode" element is visible at the "CreateAsset" page "Elements on the page" "HardStopOnFailure"
    And the user scroll to the page until the object "voice" is visible at the page "CreateAsset"
    And the user waits for the "voice" element to be "Visible" on the "CreateAsset" page
    Then the user validates the "voice" element is visible at the "CreateAsset" page "Elements on the page" "HardStopOnFailure"
    And the user scroll to the page until the object "saveAsset" is visible at the page "CreateAsset"
    And the user waits for the "saveAsset" element to be "Visible" on the "CreateAsset" page
    Then the user validates the "saveAsset" element is visible at the "CreateAsset" page "Elements on the page" "HardStopOnFailure"

  @CMS @CMS_SG @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate Date Placed in Service field_ATM Basics
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    And the user clicks the "createAsset" element at the "CMSHomePage" page
    And the user clicks the "siteAssociation" element at the "Create Asset" page
    And the user clicks the "statusSiteAssociation" element at the "Create Asset" page
    Then the user validates the "statusSiteAssociation" element is visible at the "CreateAsset" page "Elements on the page" "HardStopOnFailure"
    And the user scroll to the page until the object "activeField" is visible at the page "CreateAsset"
    And the user waits for the "activeField" element to be "Visible" on the "CreateAsset" page
    And the user clicks the "activeField" element at the "CreateAsset" page
    And the user clicks the "searchSiteAssociation" element at the "CreateAsset" page
    And the user scroll to the page until the object "selectSite" is visible at the page "CreateAsset"
    And the user clicks the "selectSite" element at the "CreateAsset" page
    And the user clicks the "ATMForm" element at the "CreateAsset" page
    And the user clicks the "atmStatus" element at the "CreateAsset" page
    And the user waits for the "atmStatusDropDown" element to be "Visible" on the "CreateAsset" page
    And the user clicks the "atmStatusInUse" element at the "CreateAsset" page
    #And the user selects value "#(Status)" from the "atmStatusDropDown" dropdown at the "CreateAsset" page
    And the user enters "#(Installation Date)" into the "installationDate" textbox at the "CreateAsset" page
    And the user enters "#(Date Place In Service)" into the "datePlacedInService" textbox at the "CreateAsset" page
    Then the user validates that the partial text "datePlacedInService" element at the "CreateAsset" page is "Equal To" "#(Date Place In Service)" "Validate Date" "HardStopOnFailure"

  @CMS @CMS_SG @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate Terminal ID field_ATM Basics
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    And the user clicks the "createAsset" element at the "CMSHomePage" page
    And the user clicks the "siteAssociation" element at the "Create Asset" page
    And the user clicks the "statusSiteAssociation" element at the "Create Asset" page
    Then the user validates the "statusSiteAssociation" element is visible at the "CreateAsset" page "Elements on the page" "HardStopOnFailure"
    And the user scroll to the page until the object "activeField" is visible at the page "CreateAsset"
    And the user waits for the "activeField" element to be "Visible" on the "CreateAsset" page
    And the user clicks the "activeField" element at the "CreateAsset" page
    And the user clicks the "searchSiteAssociation" element at the "CreateAsset" page
    And the user scroll to the page until the object "selectSite" is visible at the page "CreateAsset"
    And the user clicks the "selectSite" element at the "CreateAsset" page
    And the user clicks the "ATMForm" element at the "CreateAsset" page


  @CMS @CMS_SG @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate Languages field_Terminal Capabilities
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    And the user clicks the "createAsset" element at the "CMSHomePage" page
    And the user clicks the "siteAssociation" element at the "Create Asset" page
    And the user clicks the "statusSiteAssociation" element at the "Create Asset" page
    Then the user validates the "statusSiteAssociation" element is visible at the "CreateAsset" page "Elements on the page" "HardStopOnFailure"
    And the user scroll to the page until the object "activeField" is visible at the page "CreateAsset"
    And the user waits for the "activeField" element to be "Visible" on the "CreateAsset" page
    And the user clicks the "activeField" element at the "CreateAsset" page
    And the user clicks the "searchSiteAssociation" element at the "CreateAsset" page
    And the user scroll to the page until the object "selectSite" is visible at the page "CreateAsset"
    And the user clicks the "selectSite" element at the "CreateAsset" page
    And the user clicks the "ATMForm" element at the "CreateAsset" page
    And the user scroll to the page until the object "language" is visible at the page "CreateAsset"
    And the user clicks the "language" element at the "CreateAsset" page
    And the user clicks the "languageEnglish" element at the "CreateAsset" page

  @CMS @CMS_SG @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate Create ATM Confirmation popup window
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    And the user waits for the "createAsset" element to be "Visible" on the "CMSHomePage" page
    And the user clicks the "createAsset" element at the "CMSHomePage" page
    And the user clicks the "siteAssociation" element at the "Create Asset" page
    And the user clicks the "statusSiteAssociation" element at the "Create Asset" page
    Then the user validates the "statusSiteAssociation" element is visible at the "CreateAsset" page "Elements on the page" "HardStopOnFailure"
    And the user scroll to the page until the object "activeField" is visible at the page "CreateAsset"
    And the user waits for the "activeField" element to be "Visible" on the "CreateAsset" page
    And the user clicks the "activeField" element at the "CreateAsset" page
    And the user clicks the "searchSiteAssociation" element at the "CreateAsset" page
    And the user scroll to the page until the object "selectSite" is visible at the page "CreateAsset"
    And the user clicks the "selectSite" element at the "CreateAsset" page
    And the user clicks the "ATMForm" element at the "CreateAsset" page
    And the user waits for the "serialNumber" element to be "Present" on the "CreateAsset" page
    And the user enters "1234" into the "serialNumber" textbox at the "CreateAsset" page
    Then the user validates that the partial text "serialNumber" element at the "CreateAsset" page is "Equal To" "1234" "Validation of correct serial number entered or not" "HardStopOnFailure"
    And the user enters "4567" into the "REMSCode" textbox at the "CreateAsset" page
    Then the user validates that the partial text "REMSCode" element at the "CreateAsset" page is "Equal To" "4567" "Validation of correct REMSCode entered or not" "HardStopOnFailure"
    And the user clicks the "search" element at the "CMSHomePage" page
    And the user validates that the partial text "confirmationPopUP" element at the "CreateAsset" page is "Equal To" "Confirmation Required" "verifying text" "HardStopOnFailure"
    And the user clicks the "confirmationPopUPOK" element at the "CreateAsset" page
    Then the user validates that the partial text "assertSearch" element at the "CMSHomePage" page is "Equal To" "Asset Search" "Verifying the landing Page" "HardStopOnFailure"

  @CMS @CMS_SG @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate Create ATM Confirmation popup window Cancel button
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    And the user waits for the "createAsset" element to be "Visible" on the "CMSHomePage" page
    And the user clicks the "createAsset" element at the "CMSHomePage" page
    And the user clicks the "siteAssociation" element at the "Create Asset" page
    And the user clicks the "statusSiteAssociation" element at the "Create Asset" page
    Then the user validates the "statusSiteAssociation" element is visible at the "CreateAsset" page "Elements on the page" "HardStopOnFailure"
    And the user scroll to the page until the object "activeField" is visible at the page "CreateAsset"
    And the user waits for the "activeField" element to be "Visible" on the "CreateAsset" page
    And the user clicks the "activeField" element at the "CreateAsset" page
    And the user clicks the "searchSiteAssociation" element at the "CreateAsset" page
    And the user scroll to the page until the object "selectSite" is visible at the page "CreateAsset"
    And the user clicks the "selectSite" element at the "CreateAsset" page
    And the user clicks the "ATMForm" element at the "CreateAsset" page
    And the user waits for the "serialNumber" element to be "Present" on the "CreateAsset" page
    And the user enters "#(Serial Number)" into the "serialNumber" textbox at the "CreateAsset" page
    Then the user validates that the partial text "serialNumber" element at the "CreateAsset" page is "Equal To" "#(Serial Number)" "Validation of correct serial number entered or not" "HardStopOnFailure"
    And the user enters "#(REMS Code)" into the "REMSCode" textbox at the "CreateAsset" page
    Then the user validates that the partial text "REMSCode" element at the "CreateAsset" page is "Equal To" "#(REMS Code)" "Validation of correct REMSCode entered or not" "HardStopOnFailure"
    And the user clicks the "search" element at the "CMSHomePage" page
    And the user validates that the partial text "confirmationPopUP" element at the "CreateAsset" page is "Equal To" "Confirmation Required" "verifying text" "HardStopOnFailure"
    And the user clicks the "confirmationPopUPCancel" element at the "CreateAsset" page
    Then the user validates that the partial text "AMTBasisHerder" element at the "CreateAsset" page is "Equal To" "ATM Basics" "Verifying still on edit page" "HardStopOnFailure"

  @CMS @CMS_SG @CMS @CMS_SG4 @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate Back and Forward button between Create ATM and Landing page
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    And the user clicks the "createAsset" element at the "CMSHomePage" page
    And the user clicks the "siteAssociation" element at the "Create Asset" page
    And the user clicks the "statusSiteAssociation" element at the "Create Asset" page
    Then the user validates the "statusSiteAssociation" element is visible at the "CreateAsset" page "Elements on the page" "HardStopOnFailure"
    And the user scroll to the page until the object "activeField" is visible at the page "CreateAsset"
    And the user waits for the "activeField" element to be "Visible" on the "CreateAsset" page
    And the user clicks the "activeField" element at the "CreateAsset" page
    And the user clicks the "searchSiteAssociation" element at the "CreateAsset" page
    And the user scroll to the page until the object "selectSite" is visible at the page "CreateAsset"
    And the user clicks the "selectSite" element at the "CreateAsset" page
    And the user clicks the "ATMForm" element at the "CreateAsset" page
    Then the user validates that the partial text "ATMBasisHeader" element at the "CreateAsset" page is "Equal To" "ATM Basics" "Validating the Page" "HardStopOnFailure"

  @CMS @CMS_SG @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario:SG Validate search with Terminal ID field
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    And the user waits for the "terminalID" element to be "Visible" on the "CMSHomePage" page
    And the user enters "#(TerminalID)" into the "terminalID" textbox at the "CMSHomePage" page
    Then the user validates the "terminalID" element is visible at the "CMSHomePage" page "Correct Terminal ID Enter" "HardStopOnFailure"
    And the user clicks the "searchButton" element at the "CMSHomePage" page
    And the user waits for the "terminalIdResult" element to be "Visible" on the "CMSHomePage" page
    Then the user validates that the partial text "terminalIdResult" element at the "CMSHomePage" page is "Equal TO" "#(TerminalID)" "Terminal Id Searched and verified" "HardStopOnFailure"

  @CMS @CMS_SG @CMS @CMS_SG4 @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate ATM search with valid data
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    #Searching with Valid Terminal ID
    And the user waits for the "terminalID" element to be "Visible" on the "CMSHomePage" page
    And the user enters "#(TerminalID)" into the "terminalID" textbox at the "CMSHomePage" page
    Then the user validates the "terminalID" element is visible at the "CMSHomePage" page "Correct Terminal ID Enter" "HardStopOnFailure"
    And the user clicks the "searchButton" element at the "CMSHomePage" page
    And the user waits for the "terminalIdResult" element to be "Visible" on the "CMSHomePage" page
    Then the user validates that the partial text "terminalIdResult" element at the "CMSHomePage" page is "Equal TO" "#(TerminalID)" "Terminal Id Searched and verified" "HardStopOnFailure"

    #Searching terminal with Status in Use
    And the user clears the value in the "terminalID" textbox at the "CMSHomePage" page
    And the user clicks the "status" element at the "CMSHomePage" page
    And the user clicks the "statusInUsed" element at the "CMSHomePage" page
    Then the user validates the "statusInUsed" element is visible at the "CMSHomePage" page "Choosing Status from Dropdown" "HardStopOnFailure"
    And the user clicks the "searchButton" element at the "CMSHomePage" page
    And the user waits for the "resultTable" element to be "Visible" on the "CMSHomePage" page
    Then the user validates the "resultTable" element is visible at the "CMSHomePage" page "Result Table" "HardStopOnFailure"

  @CMS @CMS_SG @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate ATM search with invalid data
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    And the user waits for the "terminalID" element to be "Visible" on the "CMSHomePage" page
    And the user enters "#(TerminalID)" into the "terminalID" textbox at the "CMSHomePage" page
    Then the user validates the "terminalID" element is visible at the "CMSHomePage" page "Incorrect Terminal ID" "HardStopOnFailure"
    And the user clicks the "searchButton" element at the "CMSHomePage" page
    And the user waits for the "noResultOrInvalidInput" element to be "Present" on the "CMSHomePage" page
    Then the user validates that the partial text "noResultOrInvalidInput" element at the "CMSHomePage" page is "Equal TO" "No matching search results" "Search with Invalid Terminal ID" "HardStopOnFailure"

  @CMS @CMS_SG @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate search results below ATM Search box navigates to Create ATM
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    And the user waits for the "terminalID" element to be "Visible" on the "CMSHomePage" page
    And the user enters "#(TerminalID)" into the "terminalID" textbox at the "CMSHomePage" page
    Then the user validates the "terminalID" element is visible at the "CMSHomePage" page "Correct Terminal ID Enter" "HardStopOnFailure"

    And the user clicks the "searchButton" element at the "CMSHomePage" page
    And the user waits for the "terminalIdResult" element to be "Visible" on the "CMSHomePage" page
    Then the user validates that the partial text "terminalIdResult" element at the "CMSHomePage" page is "Equal TO" "#(TerminalID)" "Verify the correct terminal ID" "HardStopOnFailure"
    And the user clicks the "terminalIdResult" element at the "CMSHomePage" page
    Then the user validates that the partial text "AMTBasisHerder" element at the "CreateAsset" page is "Equal TO" "ATM Basic" "ATM search navigates to Create ATM Page " "HardStopOnFailure"

  @CMS @CMS_SG @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate Manage ATM Edit page Confirmation popup window OK button
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    And the user waits for the "terminalID" element to be "Visible" on the "CMSHomePage" page
    And the user enters "#(TerminalID)" into the "terminalID" textbox at the "CMSHomePage" page
    Then the user validates the "terminalID" element is visible at the "CMSHomePage" page "Correct Terminal ID Enter" "HardStopOnFailure"
    And the user clicks the "searchButton" element at the "CMSHomePage" page
    And the user waits for the "terminalIdResult" element to be "Visible" on the "CMSHomePage" page
    And the user clicks the "terminalIdResult" element at the "CMSHomePage" page
    And the user scroll to the page until the object "editAndCancelButton" is visible at the page "CreateAsset"
    And the user waits for the "editAndCancelButton" element to be "Visible" on the "CreateAsset" page
   #And the user scroll to the page until the object "editAndCancelButton" is visible at the page "CreateAsset"
   #And the user waits for the "editAndCancelButton" element to be "Visible" on the "CreateAsset" page
    And the user clicks the "editAndCancelButton" element at the "CreateAsset" page
    Then the user validates the "editAndCancelButton" element is visible at the "CreateAsset" page "Checking the Button" "HardStopOnFailure"
    And the user clicks the "search" element at the "CMSHomePage" page
    And the user validates that the partial text "confirmationPopUP" element at the "CreateAsset" page is "Equal To" "Confirmation Required" "verifying text" "HardStopOnFailure"
    And the user clicks the "confirmationPopUPOK" element at the "CreateAsset" page
    Then the user validates that the partial text "assertSearch" element at the "CMSHomePage" page is "Equal To" "Asset Search" "Verifying the landing Page" "HardStopOnFailure"

  @CMS @CMS_SG @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate Manage ATM Edit page Confirmation popup window
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    And the user waits for the "terminalID" element to be "Visible" on the "CMSHomePage" page
    And the user enters "#(TerminalID)" into the "terminalID" textbox at the "CMSHomePage" page
    Then the user validates the "terminalID" element is visible at the "CMSHomePage" page "Correct Terminal ID Enter" "HardStopOnFailure"
    And the user clicks the "searchButton" element at the "CMSHomePage" page
    And the user waits for the "terminalIdResult" element to be "Visible" on the "CMSHomePage" page
    And the user clicks the "terminalIdResult" element at the "CMSHomePage" page
    And the user scroll to the page until the object "editAndCancelButton" is visible at the page "CreateAsset"
    And the user waits for the "editAndCancelButton" element to be "Visible" on the "CreateAsset" page
    And the user clicks the "editAndCancelButton" element at the "CreateAsset" page
    Then the user validates the "editAndCancelButton" element is visible at the "CreateAsset" page "Checking the Button" "HardStopOnFailure"
    And the user clicks the "search" element at the "CMSHomePage" page
    And the user validates that the partial text "confirmationPopUP" element at the "CreateAsset" page is "Equal To" "Confirmation Required" "verifying text" "HardStopOnFailure"
    And the user clicks the "confirmationPopUPCancel" element at the "CreateAsset" page
    Then the user validates that the partial text "AMTBasisHerder" element at the "CreateAsset" page is "Equal To" "ATM Basics" "Verifying still on edit page" "HardStopOnFailure"

  @CMS @CMS_SG @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate FIID field
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    When the user clicks the "createLocation" element at the "CMSHomePage" page
    And the user waits for the "FIID" element to be "Visible" on the "createLocation" page
    And the user enters "#(FIID2)" into the "FIID" textbox at the "createLocation" page
    And the user clicks the "streetAddress" element at the "createLocation" page
    And the user clicks the "FIID" element at the "createLocation" page
    Then the user validates that the partial text "errorMessageFIID" element at the "createLocation" page is "Equal To" "Numbers only, Must be 2 characters long" "Verify the Message" "HardStopOnFailure"
    Then the user validates the "FIID" element is visible at the "createLocation" page "Invalid FIID " "HardStopOnFailure"
    And the user enters "#(FIID1)" into the "FIID" textbox at the "createLocation" page
    And the user clicks the "streetAddress" element at the "createLocation" page
    Then the user validates that the partial text "errorMessageFIID" element at the "createLocation" page is "Equal To" "Must be 2 characters long" "Verify the Message" "HardStopOnFailure"
    And the user enters "#(FIID1)" into the "FIID" textbox at the "createLocation" page
    And the user clicks the "streetAddress" element at the "createLocation" page
    Then the user validates the "FIID" element is visible at the "createLocation" page "Valid FIID " "HardStopOnFailure"

  @CMS @CMS_SG @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate Phone Number field
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    When the user clicks the "createLocation" element at the "CMSHomePage" page
    And the user waits for the "countryCode" element to be "Visible" on the "createLocation" page
    And the user enters "#(CountryCode)" into the "countryCode" textbox at the "createLocation" page
    #And the user enters "#(PhoneNumber1)" into the "phoneNumber" textbox at the "createLocation" page
    When the user clicks the "phoneNumber" element at the "createLocation" page
    When the user clicks the "countryCode" element at the "createLocation" page
    #Then the user validates that the partial text "errorMessage" element at the "createLocation" page is "Equal To" "Required field" "Validation empty phone number" "HardStopOnFailure"
    #And the user enters "#(PhoneNumber2)" into the "phoneNumber" textbox at the "createLocation" page
    #When the user clicks the "countryCode" element at the "createLocation" page
    #Then the user validates that the partial text "errorMessage" element at the "createLocation" page is "Equal To" "Please enter a valid phone number" "validation invalid number" "HardStopOnFailure"
    And the user enters "#(PhoneNumber)" into the "phoneNumber" textbox at the "createLocation" page
    Then the user validates the "phoneNumber" element is visible at the "createLocation" page "Phone Number" "HardStopOnFailure"

  @CMS @CMS_SG @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate City Province field
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    When the user clicks the "createLocation" element at the "CMSHomePage" page
    And the user waits for the "city" element to be "Visible" on the "createLocation" page
    Then the user validates the "city" element is visible at the "createLocation" page "City" "HardStopOnFailure"

  @CMS @CMS_SG @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate Zip Code Postal Code field
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    When the user clicks the "createLocation" element at the "CMSHomePage" page
    And the user waits for the "zipCode" element to be "Visible" on the "createLocation" page
    #And the user clicks the "zipCode" element at the "createLocation" page
    #And the user clicks the "countryCode" element at the "createLocation" page
    #Then the user validates that the partial text "errorMessage" element at the "createLocation" page is "Equal To" "Required field" "" "HardStopOnFailure"
    And the user enters "#(ZIP)" into the "zipCode" textbox at the "createLocation" page
    Then the user validates the "zipCode" element is visible at the "createLocation" page "validation correct ZIP code " "HardStopOnFailure"
    And the user enters "#(ZIP1)" into the "zipCode" textbox at the "createLocation" page
    And the user clicks the "countryCode" element at the "createLocation" page
    Then the user validates that the partial text "errorMessageZIPSG" element at the "createLocation" page is "Equal To" "Must be 6 digits" "Validating element" "HardStopOnFailure"

  @CMS @CMS_SG @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate Invalid Location information
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    #creating location
    When the user clicks the "createLocation" element at the "CMSHomePage" page
    And the user enters "#(LocationDescription)" into the "description" textbox at the "createLocation" page
    And the user clicks the "locationStatus" element at the "createLocation" page
    Then the user validates the "locationStatus" element is visible at the "createLocation" page "Available Status" "HardStopOnFailure"
    And the user clicks the "ActiveLocationStatus" element at the "createLocation" page
    #And the user enters "#(CostCenter)" into the "costCenter" textbox at the "createLocation" page
    And the user enters "#(FIID)" into the "FIID" textbox at the "createLocation" page
    Then the user validates the "FIID" element is visible at the "createLocation" page "FIID" "HardStopOnFailure"
    Then the user scroll to the page until the object "saveLocation" is visible at the page "createLocation"
    And the user enters "#(StreetAddress)" into the "streetAddress" textbox at the "createLocation" page
    And the user enters "#(City)" into the "city" textbox at the "createLocation" page
    And the user enters "#(ZIP)" into the "zipCode" textbox at the "createLocation" page
    And the user enters "#(CountryCode)" into the "countryCode" textbox at the "createLocation" page
    And the user enters "#(PhoneNumber)" into the "phoneNumber" textbox at the "createLocation" page
    And the user clicks the "dayLightSavingBox" element at the "createLocation" page
    And the user waits for the "dayLightSaving" element to be "Visible" on the "createLocation" page
    And the user clicks the "dayLightSaving" element at the "createLocation" page
    Then the user validates the "BusinessSegmentList" element is visible at the "createLocation" page "BusinessSegmentList" "HardStopOnFailure"
    And the user clicks the "saveLocationButton" element at the "createLocation" page

  @CMS @CMS_SG @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate valid Location information
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    #creating location
    When the user clicks the "createLocation" element at the "CMSHomePage" page
    #And the user clicks the "locationName1" element at the "createLocation" page
    And the user enters "#(LocationDescription)" into the "description" textbox at the "createLocation" page
    And the user clicks the "locationStatus" element at the "createLocation" page
    Then the user validates the "locationStatus" element is visible at the "createLocation" page "Available Status" "HardStopOnFailure"
    And the user clicks the "ActiveLocationStatus" element at the "createLocation" page
   # And the user enters "#(CostCenter)" into the "costCenter" textbox at the "createLocation" page
    And the user enters "#(FIID)" into the "FIID" textbox at the "createLocation" page
    Then the user validates the "FIID" element is visible at the "createLocation" page "FIID" "HardStopOnFailure"
    Then the user scroll to the page until the object "saveLocation" is visible at the page "createLocation"
    And the user enters "#(StreetAddress)" into the "streetAddress" textbox at the "createLocation" page
    And the user enters "#(City)" into the "city" textbox at the "createLocation" page
    And the user enters "#(ZIP)" into the "zipCode" textbox at the "createLocation" page
    And the user enters "#(CountryCode)" into the "countryCode" textbox at the "createLocation" page
    And the user enters "#(PhoneNumber)" into the "phoneNumber" textbox at the "createLocation" page
    And the user clicks the "timeZoneBox" element at the "createLocation" page
    And the user waits for the "timeZoneET" element to be "Visible" on the "createLocation" page
    And the user clicks the "timeZoneET" element at the "createLocation" page
    And the user clicks the "dayLightSavingBox" element at the "createLocation" page
    And the user waits for the "dayLightSaving" element to be "Visible" on the "createLocation" page
    And the user clicks the "dayLightSaving" element at the "createLocation" page
    Then the user validates the "BusinessSegmentList" element is visible at the "createLocation" page "BusinessSegmentList" "HardStopOnFailure"
    And the user clicks the "saveLocationButton" element at the "createLocation" page
    #Then the user validates the "confirmOKButton" element is visible at the "createLocation" page "Confirm OK Button" "HardStopOnFailure"
    #And the user clicks the "confirmOKButton" element at the "createLocation" page
    #Then the user validates the "confirmText" element is visible at the "createLocation" page "Confirm text" "HardStopOnFailure"
    #Then the user validates that the partial text "confirmText" element at the "createLocation" page is "Equal To" "Your changes have been saved!" "Save" "HardStopOnFailure"

  @CMS @CMS_SG @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate Mobile Access Enabled Radio Button in Terminal Capabilities
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    And the user clicks the "createAsset" element at the "CMSHomePage" page
    And the user clicks the "siteAssociation" element at the "Create Asset" page
    And the user clicks the "statusSiteAssociation" element at the "Create Asset" page
    Then the user validates the "statusSiteAssociation" element is visible at the "CreateAsset" page "Elements on the page" "HardStopOnFailure"
    And the user scroll to the page until the object "activeField" is visible at the page "CreateAsset"
    And the user waits for the "activeField" element to be "Visible" on the "CreateAsset" page
    And the user clicks the "activeField" element at the "CreateAsset" page
    And the user clicks the "searchSiteAssociation" element at the "CreateAsset" page
    And the user scroll to the page until the object "selectSite" is visible at the page "CreateAsset"
    And the user clicks the "selectSite" element at the "CreateAsset" page
    And the user clicks the "ATMForm" element at the "CreateAsset" page
    And the user scroll to the page until the object "mobileAccessEnabled" is visible at the page "CreateAsset"
    When the user waits for the "mobileAccessEnabled" element to be "Visible" on the "CreateAsset" page
    And the user clicks the "mobileAccessEnabled" element at the "CreateAsset" page
    Then the user validates the "mobileAccessEnabled" element is present at the "CreateAsset" page "Validating radio button selected" "HardStopOnFailure"
    And the user clicks the "mobileAccessDisabled" element at the "CreateAsset" page
    Then the user validates the "mobileAccessDisabled" element is present at the "CreateAsset" page "Validating radio button selected" "HardStopOnFailure"

  @CMS @CMS_SG @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate Internal transfer Radio Button in Terminal Capabilities
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    And the user clicks the "createAsset" element at the "CMSHomePage" page
    And the user clicks the "siteAssociation" element at the "Create Asset" page
    And the user clicks the "statusSiteAssociation" element at the "Create Asset" page
    Then the user validates the "statusSiteAssociation" element is visible at the "CreateAsset" page "Elements on the page" "HardStopOnFailure"
    And the user scroll to the page until the object "activeField" is visible at the page "CreateAsset"
    And the user waits for the "activeField" element to be "Visible" on the "CreateAsset" page
    And the user clicks the "activeField" element at the "CreateAsset" page
    And the user clicks the "searchSiteAssociation" element at the "CreateAsset" page
    And the user scroll to the page until the object "selectSite" is visible at the page "CreateAsset"
    And the user clicks the "selectSite" element at the "CreateAsset" page
    And the user clicks the "ATMForm" element at the "CreateAsset" page
    And the user scroll to the page until the object "internalTransferDisabled" is visible at the page "CreateAsset"
    When the user waits for the "internalTransferDisabled" element to be "Visible" on the "CreateAsset" page
    And the user clicks the "internalTransferDisabled" element at the "CreateAsset" page
    Then the user validates the "internalTransferDisabled" element is present at the "CreateAsset" page "Validating radio button selected" "HardStopOnFailure"
    And the user clicks the "internalTransferEnabled" element at the "CreateAsset" page
    Then the user validates the "internalTransferEnabled" element is present at the "CreateAsset" page "Validating radio button selected" "HardStopOnFailure"

  @CMS @CMS_SG @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate Marketing Flag Dropdown in Terminal Capabilities
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    And the user clicks the "createAsset" element at the "CMSHomePage" page
    And the user clicks the "siteAssociation" element at the "Create Asset" page
    And the user clicks the "statusSiteAssociation" element at the "Create Asset" page
    Then the user validates the "statusSiteAssociation" element is visible at the "CreateAsset" page "Elements on the page" "HardStopOnFailure"
    And the user scroll to the page until the object "activeField" is visible at the page "CreateAsset"
    And the user waits for the "activeField" element to be "Visible" on the "CreateAsset" page
    And the user clicks the "activeField" element at the "CreateAsset" page
    And the user clicks the "searchSiteAssociation" element at the "CreateAsset" page
    And the user scroll to the page until the object "selectSite" is visible at the page "CreateAsset"
    And the user clicks the "selectSite" element at the "CreateAsset" page
    And the user clicks the "ATMForm" element at the "CreateAsset" page
    And the user scroll to the page until the object "marketingEnabled" is visible at the page "CreateAsset"
    When the user waits for the "marketingEnabled" element to be "Visible" on the "CreateAsset" page
    And the user clicks the "marketingEnabled" element at the "CreateAsset" page
    Then the user validates the "marketingEnabledDynamic" element is present at the "CreateAsset" page "Taking Screenshot" "HardStopOnFailure"
    And the user clicks the "marketingEnabledDynamic" element at the "CreateAsset" page
    Then the user validates that the partial text "marketingEnabled" element at the "CreateAsset" page is "Equal To" "DYNAMIC" "validating text" "HardStopOnFailure"
    And the user clicks the "marketingEnabled" element at the "CreateAsset" page
    Then the user validates the "marketingEnabledStatic" element is present at the "CreateAsset" page "Taking Screenshot" "HardStopOnFailure"
    And the user clicks the "marketingEnabledStatic" element at the "CreateAsset" page
    Then the user validates that the partial text "marketingEnabled" element at the "CreateAsset" page is "Equal To" "STATIC" "validating text" "HardStopOnFailure"

  @CMS @CMS_SG @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate Cash Recycler Mode dropdown at ATM Functions
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    And the user clicks the "createAsset" element at the "CMSHomePage" page
    And the user clicks the "siteAssociation" element at the "Create Asset" page
    And the user clicks the "statusSiteAssociation" element at the "Create Asset" page
    Then the user validates the "statusSiteAssociation" element is visible at the "CreateAsset" page "Elements on the page" "HardStopOnFailure"
    And the user scroll to the page until the object "activeField" is visible at the page "CreateAsset"
    And the user waits for the "activeField" element to be "Visible" on the "CreateAsset" page
    And the user clicks the "activeField" element at the "CreateAsset" page
    And the user clicks the "searchSiteAssociation" element at the "CreateAsset" page
    And the user scroll to the page until the object "selectSite" is visible at the page "CreateAsset"
    And the user clicks the "selectSite" element at the "CreateAsset" page
    And the user clicks the "ATMForm" element at the "CreateAsset" page
    When the user scroll to the page until the object "cashRecyclerMode" is visible at the page "CreateAsset"
    And the user waits for the "cashRecyclerMode" element to be "Visible" on the "CreateAsset" page
    And the user clicks the "cashRecyclerMode" element at the "CreateAsset" page
    Then the user validates the "cashRecyclerModeEnabled" element is present at the "CreateAsset" page "Validating Dropdown" "HardStopOnFailure"
    When the user clicks the "cashRecyclerModeEnabled" element at the "CreateAsset" page
    Then the user validates that the partial text "cashRecyclerMode" element at the "CreateAsset" page is "Equal To" "ENABLED" "Validating Text" "HardStopOnFailure"

  @CMS @CMS_SG @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate Cash Mode dropdown at ATM Functions
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    And the user clicks the "createAsset" element at the "CMSHomePage" page
    And the user clicks the "siteAssociation" element at the "Create Asset" page
    And the user clicks the "statusSiteAssociation" element at the "Create Asset" page
    Then the user validates the "statusSiteAssociation" element is visible at the "CreateAsset" page "Elements on the page" "HardStopOnFailure"
    And the user scroll to the page until the object "activeField" is visible at the page "CreateAsset"
    And the user waits for the "activeField" element to be "Visible" on the "CreateAsset" page
    And the user clicks the "activeField" element at the "CreateAsset" page
    And the user clicks the "searchSiteAssociation" element at the "CreateAsset" page
    And the user scroll to the page until the object "selectSite" is visible at the page "CreateAsset"
    And the user clicks the "selectSite" element at the "CreateAsset" page
    And the user clicks the "ATMForm" element at the "CreateAsset" page
    When the user scroll to the page until the object "cashMode" is visible at the page "CreateAsset"
    And the user waits for the "cashMode" element to be "Visible" on the "CreateAsset" page
    And the user clicks the "cashMode" element at the "CreateAsset" page
    Then the user validates the "cashModeFullFunction" element is present at the "CreateAsset" page "Validating Dropdown" "HardStopOnFailure"
    When the user clicks the "cashModeFullFunction" element at the "CreateAsset" page
    Then the user validates that the partial text "cashMode" element at the "CreateAsset" page is "Equal To" "FULL FUNCTION" "Validating Text" "HardStopOnFailure"

  @CMS @CMS_SG @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate Organization Unit fields in ATM Network Details
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    And the user clicks the "createAsset" element at the "CMSHomePage" page
    And the user clicks the "siteAssociation" element at the "Create Asset" page
    And the user clicks the "statusSiteAssociation" element at the "Create Asset" page
    Then the user validates the "statusSiteAssociation" element is visible at the "CreateAsset" page "Elements on the page" "HardStopOnFailure"
    And the user scroll to the page until the object "activeField" is visible at the page "CreateAsset"
    And the user waits for the "activeField" element to be "Visible" on the "CreateAsset" page
    And the user clicks the "activeField" element at the "CreateAsset" page
    And the user clicks the "searchSiteAssociation" element at the "CreateAsset" page
    And the user scroll to the page until the object "selectSite" is visible at the page "CreateAsset"
    And the user clicks the "selectSite" element at the "CreateAsset" page
    And the user clicks the "ATMForm" element at the "CreateAsset" page
    When the user scroll to the page until the object "organizationUnit" is visible at the page "CreateAsset"
    And the user waits for the "organizationUnit" element to be "Visible" on the "CreateAsset" page
    And the user enters "#(Organization Unit)" into the "organizationUnit" textbox at the "CreateAsset" page
    And the user clicks the "macAddress" element at the "CreateAsset" page
    Then the user validates that the partial text "organizationUnit" element at the "CreateAsset" page is "Equal To" "#(Organization Unit)" "Validating the correct Domain Name" "HardStopOnFailure"

  @CMS @CMS_SG @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate Domain Name fields in ATM Network Details
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    And the user clicks the "createAsset" element at the "CMSHomePage" page
    And the user clicks the "siteAssociation" element at the "Create Asset" page
    And the user clicks the "statusSiteAssociation" element at the "Create Asset" page
    Then the user validates the "statusSiteAssociation" element is visible at the "CreateAsset" page "Elements on the page" "HardStopOnFailure"
    And the user scroll to the page until the object "activeField" is visible at the page "CreateAsset"
    And the user waits for the "activeField" element to be "Visible" on the "CreateAsset" page
    And the user clicks the "activeField" element at the "CreateAsset" page
    And the user clicks the "searchSiteAssociation" element at the "CreateAsset" page
    And the user scroll to the page until the object "selectSite" is visible at the page "CreateAsset"
    And the user clicks the "selectSite" element at the "CreateAsset" page
    And the user clicks the "ATMForm" element at the "CreateAsset" page
    When the user scroll to the page until the object "domainName" is visible at the page "CreateAsset"
    And the user waits for the "domainName" element to be "Visible" on the "CreateAsset" page
    And the user enters "#(Domain Name)" into the "domainName" textbox at the "CreateAsset" page
    And the user clicks the "macAddress" element at the "CreateAsset" page
    Then the user validates that the partial text "domainName" element at the "CreateAsset" page is "Equal To" "#(Domain Name)" "Validating the correct Domain Name" "HardStopOnFailure"

  @CMS @CMS_SG @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate Primary Router IP Address fields in ATM Network Details
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    And the user clicks the "createAsset" element at the "CMSHomePage" page
    And the user clicks the "siteAssociation" element at the "Create Asset" page
    And the user clicks the "statusSiteAssociation" element at the "Create Asset" page
    Then the user validates the "statusSiteAssociation" element is visible at the "CreateAsset" page "Elements on the page" "HardStopOnFailure"
    And the user scroll to the page until the object "activeField" is visible at the page "CreateAsset"
    And the user waits for the "activeField" element to be "Visible" on the "CreateAsset" page
    And the user clicks the "activeField" element at the "CreateAsset" page
    And the user clicks the "searchSiteAssociation" element at the "CreateAsset" page
    And the user scroll to the page until the object "selectSite" is visible at the page "CreateAsset"
    And the user clicks the "selectSite" element at the "CreateAsset" page
    And the user clicks the "ATMForm" element at the "CreateAsset" page
    When the user scroll to the page until the object "primaryRouterIpAddress" is visible at the page "CreateAsset"
    And the user waits for the "primaryRouterIpAddress" element to be "Visible" on the "CreateAsset" page
    And the user enters "#(PrimaryRouterIPAddress)" into the "primaryRouterIpAddress" textbox at the "CreateAsset" page
    And the user clicks the "macAddress" element at the "CreateAsset" page
    Then the user validates that the partial text "primaryRouterIpAddress" element at the "CreateAsset" page is "Equal To" "#(PrimaryRouterIPAddress)" "Validating the correct MAC Address" "HardStopOnFailure"
    When the user clears the value in the "primaryRouterIpAddress" textbox at the "CreateAsset" page
    And the user enters "#(PrimaryRouterIPAddress1)" into the "primaryRouterIpAddress" textbox at the "CreateAsset" page
    And the user clicks the "macAddress" element at the "CreateAsset" page
    Then the user validates that the partial text "ipAddressErrorMessage" element at the "CreateAsset" page is "Equal To" "Please enter a valid IP Address" "Validating the Incorrect IP Address" "HardStopOnFailure"

  @CMS @CMS_SG @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate IP Subnet Mask fields in ATM Network Details
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    And the user clicks the "createAsset" element at the "CMSHomePage" page
    And the user clicks the "siteAssociation" element at the "Create Asset" page
    And the user clicks the "statusSiteAssociation" element at the "Create Asset" page
    Then the user validates the "statusSiteAssociation" element is visible at the "CreateAsset" page "Elements on the page" "HardStopOnFailure"
    And the user scroll to the page until the object "activeField" is visible at the page "CreateAsset"
    And the user waits for the "activeField" element to be "Visible" on the "CreateAsset" page
    And the user clicks the "activeField" element at the "CreateAsset" page
    And the user clicks the "searchSiteAssociation" element at the "CreateAsset" page
    And the user scroll to the page until the object "selectSite" is visible at the page "CreateAsset"
    And the user clicks the "selectSite" element at the "CreateAsset" page
    And the user clicks the "ATMForm" element at the "CreateAsset" page
    When the user scroll to the page until the object "ipSubnetMask" is visible at the page "CreateAsset"
    And the user waits for the "ipSubnetMask" element to be "Visible" on the "CreateAsset" page
    And the user enters "#(IPSubnetMask)" into the "ipSubnetMask" textbox at the "CreateAsset" page
    And the user clicks the "macAddress" element at the "CreateAsset" page
    Then the user validates that the partial text "ipSubnetMask" element at the "CreateAsset" page is "Equal To" "#(IPSubnetMask)" "Validating the correct MAC Address" "HardStopOnFailure"
    When the user clears the value in the "ipSubnetMask" textbox at the "CreateAsset" page
    And the user enters "#(IPSubnetMask1)" into the "ipSubnetMask" textbox at the "CreateAsset" page
    And the user clicks the "macAddress" element at the "CreateAsset" page
    Then the user validates that the partial text "ipAddressErrorMessage" element at the "CreateAsset" page is "Equal To" "Please enter a valid IP Address" "Validating the Incorrect IP Address" "HardStopOnFailure"

  @CMS @CMS_SG @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate ATM search with valid data(Model Number)
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    When the user waits for the "model" element to be "Visible" on the "CMSHomePage" page
    And the user clicks the "model" element at the "CMSHomePage" page
    And the user clicks the "modelDN200V" element at the "CMSHomePage" page
    Then the user validates the "modelDN200V" element is visible at the "CMSHomePage" page "Selecting model from Dropdown" "HardStopOnFailure"
    And the user clicks the "searchButton" element at the "CMSHomePage" page
    And the user waits for the "resultTable" element to be "Visible" on the "CMSHomePage" page
    Then the user validates the "resultTable" element is visible at the "CMSHomePage" page "Result Table" "HardStopOnFailure"

  @CMS @CMS_SG @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate ATM search with valid data(Serial Number)
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    When the user waits for the "serialNumber" element to be "Visible" on the "CMSHomePage" page
    And the user enters "#(SerialNumber)" into the "serialNumber" textbox at the "CMSHomePage" page
    Then the user validates the "serialNumber" element is visible at the "CMSHomePage" page "Correct MAC Address Enter" "HardStopOnFailure"
    And the user clicks the "searchButton" element at the "CMSHomePage" page
    And the user waits for the "serialNumberResult" element to be "Visible" on the "CMSHomePage" page
    Then the user validates that the partial text "serialNumberResult" element at the "CMSHomePage" page is "Equal TO" "#(SerialNumber)" "Serial Number Searched and verified" "HardStopOnFailure"

  @CMS @CMS_SG @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate ATM search with valid data(MAC Address)
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    When the user waits for the "mACAddress" element to be "Visible" on the "CMSHomePage" page
    And the user enters "#(MACAddress)" into the "mACAddress" textbox at the "CMSHomePage" page
    Then the user validates the "mACAddress" element is visible at the "CMSHomePage" page "Correct MAC Address Enter" "ContinueOnFailure"
    And the user clicks the "searchButton" element at the "CMSHomePage" page
    And the user waits for the "mACAddressResult" element to be "Visible" on the "CMSHomePage" page
    Then the user validates that the partial text "mACAddressResult" element at the "CMSHomePage" page is "Equal TO" "#(MACAddress)" "MAC Address Searched and verified" "ContinueOnFailure"

  @CMS @CMS_SG @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate ATM Managed Flag Radio Button in Terminal Capabilities
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    And the user clicks the "createAsset" element at the "CMSHomePage" page
    And the user clicks the "siteAssociation" element at the "Create Asset" page
    And the user clicks the "statusSiteAssociation" element at the "Create Asset" page
    Then the user validates the "statusSiteAssociation" element is visible at the "CreateAsset" page "Elements on the page" "HardStopOnFailure"
    And the user scroll to the page until the object "activeField" is visible at the page "CreateAsset"
    And the user waits for the "activeField" element to be "Visible" on the "CreateAsset" page
    And the user clicks the "activeField" element at the "CreateAsset" page
    And the user clicks the "searchSiteAssociation" element at the "CreateAsset" page
    And the user scroll to the page until the object "selectSite" is visible at the page "CreateAsset"
    And the user clicks the "selectSite" element at the "CreateAsset" page
    And the user clicks the "ATMForm" element at the "CreateAsset" page
    And the user scroll to the page until the object "cardReaderOrientation" is visible at the page "CreateAsset"
    When the user waits for the "cardReaderOrientation" element to be "Visible" on the "CreateAsset" page
    #And the user clicks the "cardReaderOrientation" element at the "CreateAsset" page
    Then the user validates the "cardReaderOrientation" element is present at the "CreateAsset" page "Validating radio button selected" "HardStopOnFailure"
    And the user clicks the "cardReaderType" element at the "CreateAsset" page
    Then the user validates the "cardReaderType" element is present at the "CreateAsset" page "Validating radio button selected" "HardStopOnFailure"

  @CMS @CMS_SG @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate NFC model dropdown in Terminal Capabilities
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    And the user clicks the "createAsset" element at the "CMSHomePage" page
    And the user clicks the "siteAssociation" element at the "Create Asset" page
    And the user clicks the "statusSiteAssociation" element at the "Create Asset" page
    Then the user validates the "statusSiteAssociation" element is visible at the "CreateAsset" page "Elements on the page" "HardStopOnFailure"
    And the user scroll to the page until the object "activeField" is visible at the page "CreateAsset"
    And the user waits for the "activeField" element to be "Visible" on the "CreateAsset" page
    And the user clicks the "activeField" element at the "CreateAsset" page
    And the user clicks the "searchSiteAssociation" element at the "CreateAsset" page
    And the user scroll to the page until the object "selectSite" is visible at the page "CreateAsset"
    And the user clicks the "selectSite" element at the "CreateAsset" page
    And the user clicks the "ATMForm" element at the "CreateAsset" page
    And the user scroll to the page until the object "nfcModel" is visible at the page "CreateAsset"
    When the user waits for the "nfcModel" element to be "Visible" on the "CreateAsset" page
    And the user clicks the "nfcModel" element at the "CreateAsset" page
    Then the user validates the "nfcModelSaturn" element is present at the "CreateAsset" page "Taking Screenshot" "HardStopOnFailure"
    And the user clicks the "nfcModelSaturn" element at the "CreateAsset" page
    Then the user validates that the partial text "nfcModel" element at the "CreateAsset" page is "Equal To" "SATURN 8700" "validating text" "HardStopOnFailure"

  @CMS @CMS_SG @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate the location type fields in create location page
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    #creating location
    When the user clicks the "createLocation" element at the "CMSHomePage" page
    #And the user clicks the "locationName2" element at the "createLocation" page
    Then the user validates the "locationStatus" element is visible at the "createLocation" page "List of select options" "HardStopOnFailure"

  @CMS @CMS_SG @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate the Location Status fields in create location page
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    When the user clicks the "createLocation" element at the "CMSHomePage" page
    And the user clicks the "locationStatus" element at the "createLocation" page
    Then the user validates the "locationStatus" element is visible at the "createLocation" page "Available Status" "HardStopOnFailure"
    And the user clicks the "ActiveLocationStatus" element at the "createLocation" page
    Then the user validates that the partial text "locationStatus" element at the "createLocation" page is "Equal To" "ACTIVE" "Verifying Status" "HardStopOnFailure"

  @CMS @CMS_SG @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate the City fields in create location page
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    When the user clicks the "createLocation" element at the "CMSHomePage" page
    And the user enters "#(City)" into the "city" textbox at the "createLocation" page
    Then the user validates that the partial text "city" element at the "createLocation" page is "Equal To" "#(City)" "Verifying text" "HardStopOnFailure"

  @CMS @CMS_SG @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate the State fields in create location page
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    When the user clicks the "createLocation" element at the "CMSHomePage" page
   # Then the user validates the "state" element is visible at the "createLocation" page "State" "HardStopOnFailure"
    #And the user enters "KY" into the "state" textbox at the "createLocation" page
    #Then the user validates that the partial text "state" element at the "createLocation" page is "Equal To" "#(State)" "Verifying text" "HardStopOnFailure"

  @CMS @CMS_SG @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate Terminal Type Dropdown field_ATM Basics
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    And the user clicks the "createAsset" element at the "CMSHomePage" page
    And the user clicks the "siteAssociation" element at the "Create Asset" page
    And the user clicks the "statusSiteAssociation" element at the "Create Asset" page
    Then the user validates the "statusSiteAssociation" element is visible at the "CreateAsset" page "Elements on the page" "HardStopOnFailure"
    And the user scroll to the page until the object "activeField" is visible at the page "CreateAsset"
    And the user waits for the "activeField" element to be "Visible" on the "CreateAsset" page
    And the user clicks the "activeField" element at the "CreateAsset" page
    And the user clicks the "searchSiteAssociation" element at the "CreateAsset" page
    And the user scroll to the page until the object "selectSite" is visible at the page "CreateAsset"
    And the user clicks the "selectSite" element at the "CreateAsset" page
    And the user clicks the "ATMForm" element at the "CreateAsset" page
    And the user clicks the "terminalType" element at the "CreateAsset" page
    And the user waits for the "terminalTypeStandaloneF" element to be "Visible" on the "CreateAsset" page
    Then the user validates the "terminalTypeStandaloneF" element is visible at the "CreateAsset" page "Dropdown List" "HardStopOnFailure"

  @CMS @CMS_SG @CMS @CMS_SG2 @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate Voice Radio Button in Terminal Capabilities
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    And the user clicks the "createAsset" element at the "CMSHomePage" page
    And the user clicks the "siteAssociation" element at the "Create Asset" page
    And the user clicks the "statusSiteAssociation" element at the "Create Asset" page
    Then the user validates the "statusSiteAssociation" element is visible at the "CreateAsset" page "Elements on the page" "HardStopOnFailure"
    And the user scroll to the page until the object "activeField" is visible at the page "CreateAsset"
    And the user waits for the "activeField" element to be "Visible" on the "CreateAsset" page
    And the user clicks the "activeField" element at the "CreateAsset" page
    And the user clicks the "searchSiteAssociation" element at the "CreateAsset" page
    And the user scroll to the page until the object "selectSite" is visible at the page "CreateAsset"
    And the user clicks the "selectSite" element at the "CreateAsset" page
    And the user clicks the "ATMForm" element at the "CreateAsset" page
    And the user scroll to the page until the object "voiceEnabled" is visible at the page "CreateAsset"
    When the user waits for the "voiceEnabled" element to be "Visible" on the "CreateAsset" page
    And the user clicks the "voiceEnabled" element at the "CreateAsset" page
    Then the user validates the "voiceEnabled" element is present at the "CreateAsset" page "Validating radio button selected" "HardStopOnFailure"
    And the user clicks the "voiceDisabled" element at the "CreateAsset" page
    Then the user validates the "voiceDisabled" element is present at the "CreateAsset" page "Validating radio button selected" "HardStopOnFailure"

  @CMS @CMS_SG @CMS @CMS_SG2 @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate Sign On State Radio Button at ATM Functions
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    And the user clicks the "createAsset" element at the "CMSHomePage" page
    And the user clicks the "siteAssociation" element at the "Create Asset" page
    And the user clicks the "statusSiteAssociation" element at the "Create Asset" page
    Then the user validates the "statusSiteAssociation" element is visible at the "CreateAsset" page "Elements on the page" "HardStopOnFailure"
    And the user scroll to the page until the object "activeField" is visible at the page "CreateAsset"
    And the user waits for the "activeField" element to be "Visible" on the "CreateAsset" page
    And the user clicks the "activeField" element at the "CreateAsset" page
    And the user clicks the "searchSiteAssociation" element at the "CreateAsset" page
    And the user scroll to the page until the object "selectSite" is visible at the page "CreateAsset"
    And the user clicks the "selectSite" element at the "CreateAsset" page
    And the user clicks the "ATMForm" element at the "CreateAsset" page
    When the user scroll to the page until the object "signOnStateYes" is visible at the page "CreateAsset"
    And the user waits for the "signOnStateYes" element to be "Visible" on the "CreateAsset" page
    And the user clicks the "signOnStateYes" element at the "CreateAsset" page
    Then the user validates the "signOnStateYes" element is present at the "CreateAsset" page "Validate Yes radio button selected" "HardStopOnFailure"
    When the user clicks the "signOnStateNo" element at the "CreateAsset" page
    Then the user validates the "signOnStateNo" element is present at the "CreateAsset" page "Validate No radio button selected" "HardStopOnFailure"

  @CMS @CMS_SG @CMS @CMS_SG1 @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate Deposit Payment media dropdown at ATM Functions
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    And the user clicks the "createAsset" element at the "CMSHomePage" page
    And the user clicks the "siteAssociation" element at the "Create Asset" page
    And the user clicks the "statusSiteAssociation" element at the "Create Asset" page
    Then the user validates the "statusSiteAssociation" element is visible at the "CreateAsset" page "Elements on the page" "HardStopOnFailure"
    And the user scroll to the page until the object "activeField" is visible at the page "CreateAsset"
    And the user waits for the "activeField" element to be "Visible" on the "CreateAsset" page
    And the user clicks the "activeField" element at the "CreateAsset" page
    And the user clicks the "searchSiteAssociation" element at the "CreateAsset" page
    And the user scroll to the page until the object "selectSite" is visible at the page "CreateAsset"
    And the user clicks the "selectSite" element at the "CreateAsset" page
    And the user clicks the "ATMForm" element at the "CreateAsset" page
    When the user scroll to the page until the object "depositMediaProcessingMode" is visible at the page "CreateAsset"
    And the user waits for the "depositMediaProcessingMode" element to be "Visible" on the "CreateAsset" page
    And the user clicks the "depositMediaProcessingMode" element at the "CreateAsset" page
    Then the user validates the "depositMediaCashAndCheck" element is present at the "CreateAsset" page "Validating Dropdown" "HardStopOnFailure"
    When the user clicks the "depositMediaCashAndCheck" element at the "CreateAsset" page
    Then the user validates that the partial text "depositMediaProcessingMode" element at the "CreateAsset" page is "Equal To" "CASH AND CHECK" "Validating Text" "HardStopOnFailure"

  @CMS @CMS_SG @CMS @CMS_SG1 @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate IP Address fields in ATM Network Details
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    And the user clicks the "createAsset" element at the "CMSHomePage" page
    And the user clicks the "siteAssociation" element at the "Create Asset" page
    And the user clicks the "statusSiteAssociation" element at the "Create Asset" page
    Then the user validates the "statusSiteAssociation" element is visible at the "CreateAsset" page "Elements on the page" "HardStopOnFailure"
    And the user scroll to the page until the object "activeField" is visible at the page "CreateAsset"
    And the user waits for the "activeField" element to be "Visible" on the "CreateAsset" page
    And the user clicks the "activeField" element at the "CreateAsset" page
    And the user clicks the "searchSiteAssociation" element at the "CreateAsset" page
    And the user scroll to the page until the object "selectSite" is visible at the page "CreateAsset"
    And the user clicks the "selectSite" element at the "CreateAsset" page
    And the user clicks the "ATMForm" element at the "CreateAsset" page
    When the user scroll to the page until the object "ipAddress" is visible at the page "CreateAsset"
    And the user waits for the "ipAddress" element to be "Visible" on the "CreateAsset" page
    And the user enters "#(IPAddress)" into the "ipAddress" textbox at the "CreateAsset" page
    And the user clicks the "macAddress" element at the "CreateAsset" page
    Then the user validates that the partial text "ipAddress" element at the "CreateAsset" page is "Equal To" "#(IPAddress)" "Validating the correct MAC Address" "HardStopOnFailure"
    When the user clears the value in the "ipAddress" textbox at the "CreateAsset" page
    And the user enters "#(IPAddress1)" into the "ipAddress" textbox at the "CreateAsset" page
    And the user clicks the "macAddress" element at the "CreateAsset" page
    Then the user validates that the partial text "ipAddressErrorMessage" element at the "CreateAsset" page is "Equal To" "Please enter a valid IP Address" "Validating the Incorrect IP Address" "HardStopOnFailure"

  @CMS @CMS_SG @CMS @CMS_SG4 @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate MAC Address fields in ATM Network Details
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    And the user clicks the "createAsset" element at the "CMSHomePage" page
    And the user clicks the "siteAssociation" element at the "Create Asset" page
    And the user clicks the "statusSiteAssociation" element at the "Create Asset" page
    Then the user validates the "statusSiteAssociation" element is visible at the "CreateAsset" page "Elements on the page" "HardStopOnFailure"
    And the user scroll to the page until the object "activeField" is visible at the page "CreateAsset"
    And the user waits for the "activeField" element to be "Visible" on the "CreateAsset" page
    And the user clicks the "activeField" element at the "CreateAsset" page
    And the user clicks the "searchSiteAssociation" element at the "CreateAsset" page
    And the user scroll to the page until the object "selectSite" is visible at the page "CreateAsset"
    And the user clicks the "selectSite" element at the "CreateAsset" page
    And the user clicks the "ATMForm" element at the "CreateAsset" page
    When the user scroll to the page until the object "macAddress" is visible at the page "CreateAsset"
    And the user waits for the "macAddress" element to be "Visible" on the "CreateAsset" page
    And the user enters "#(MACAddress)" into the "macAddress" textbox at the "CreateAsset" page
    And the user clicks the "ipAddress" element at the "CreateAsset" page
    Then the user validates that the partial text "macAddress" element at the "CreateAsset" page is "Equal To" "#(MACAddress)" "Validating the correct MAC Address" "HardStopOnFailure"
    When the user clears the value in the "macAddress" textbox at the "CreateAsset" page
    And the user enters "#(MACAddress1)" into the "macAddress" textbox at the "CreateAsset" page
    And the user clicks the "ipAddress" element at the "CreateAsset" page
    Then the user validates that the partial text "macAddressErrorMessage" element at the "CreateAsset" page is "Equal To" "Please enter a valid MAC Address" "Validating the Incorrect MAC Address" "HardStopOnFailure"

  @CMS @CMS_SG @CMS @CMS_SG1 @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate ATM search with valid data(Serial Number)
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    When the user waits for the "serialNumber" element to be "Visible" on the "CMSHomePage" page
    And the user enters "#(SerialNumber)" into the "serialNumber" textbox at the "CMSHomePage" page
    Then the user validates the "serialNumber" element is visible at the "CMSHomePage" page "Correct MAC Address Enter" "HardStopOnFailure"
    And the user clicks the "searchButton" element at the "CMSHomePage" page
    And the user waits for the "serialNumberResult" element to be "Visible" on the "CMSHomePage" page
    Then the user validates that the partial text "serialNumberResult" element at the "CMSHomePage" page is "Equal TO" "#(SerialNumber)" "Serial Number Searched and verified" "HardStopOnFailure"

  @CMS @CMS_SG @CMS @CMS_SG1 @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate the location description fields in create location Page
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    When the user clicks the "createLocation" element at the "CMSHomePage" page
    And the user enters "#(LocationDescription)" into the "description" textbox at the "createLocation" page
    Then the user validates that the partial text "description" element at the "createLocation" page is "Equal To" "#(LocationDescription)" "Verifying text" "HardStopOnFailure"

  @CMS @CMS_SG @CMS @CMS_SG1 @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate the Street Address fields in create location page
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    When the user clicks the "createLocation" element at the "CMSHomePage" page
    And the user enters "#(StreetAddress)" into the "streetAddress" textbox at the "createLocation" page
    Then the user validates that the partial text "streetAddress" element at the "createLocation" page is "Equal To" "#(StreetAddress)" "Verifying text" "HardStopOnFailure"

  @CMS @CMS_SG @CMS @CMS_SG1 @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate the Country Code fields in create location page
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    When the user clicks the "createLocation" element at the "CMSHomePage" page
    And the user enters "#(Country Code)" into the "countryCode" textbox at the "createLocation" page
    Then the user validates that the partial text "countryCode" element at the "createLocation" page is "Equal To" "#(Country Code)" "Verifying text" "HardStopOnFailure"

  @CMS @CMS_SG @CMS @CMS_SG1 @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate the Phone Number fields in create location page
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    When the user clicks the "createLocation" element at the "CMSHomePage" page
    And the user enters "#(Phone Number)" into the "phoneNumber" textbox at the "createLocation" page
    Then the user validates that the partial text "phoneNumber" element at the "createLocation" page is "Equal To" "#(Phone Number)" "Verifying text" "HardStopOnFailure"

  @CMS @CMS_SG @CMS @CMS_SG4 @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate REMS Code field_ATM Basics
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    And the user clicks the "createAsset" element at the "CMSHomePage" page
    And the user clicks the "siteAssociation" element at the "Create Asset" page
    And the user clicks the "statusSiteAssociation" element at the "Create Asset" page
    Then the user validates the "statusSiteAssociation" element is visible at the "CreateAsset" page "Elements on the page" "HardStopOnFailure"
    And the user scroll to the page until the object "activeField" is visible at the page "CreateAsset"
    And the user waits for the "activeField" element to be "Visible" on the "CreateAsset" page
    And the user clicks the "activeField" element at the "CreateAsset" page
    And the user clicks the "searchSiteAssociation" element at the "CreateAsset" page
    And the user scroll to the page until the object "selectSite" is visible at the page "CreateAsset"
    And the user clicks the "selectSite" element at the "CreateAsset" page
    And the user clicks the "ATMForm" element at the "CreateAsset" page
    And the user waits for the "REMSCode" element to be "Visible" on the "CreateAsset" page
    And the user enters "#(REMS Code)" into the "REMSCode" textbox at the "CreateAsset" page
    Then the user validates that the partial text "REMSCode" element at the "CreateAsset" page is "Equal To" "#(REMS Code)" "REMS Code Validation" "HardStopOnFailure"
    And the user clears the value in the "REMSCode" textbox at the "CreateAsset" page
    And the user enters "#(REMS Code1)" into the "REMSCode" textbox at the "CreateAsset" page
    And the user clicks the "siteSchedule" element at the "CreateAsset" page
    #Then the user validates that the partial text "REMSCodeError" element at the "CreateAsset" page is "Equal To" "Must be 10 characters long" "REMS Code Validation" "HardStopOnFailure"

  @CMS @CMS_SG @CMS @CMS_SG4 @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate FEMP Dropdown field_ATM Basics
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    And the user clicks the "createAsset" element at the "CMSHomePage" page
    And the user clicks the "siteAssociation" element at the "Create Asset" page
    And the user clicks the "statusSiteAssociation" element at the "Create Asset" page
    Then the user validates the "statusSiteAssociation" element is visible at the "CreateAsset" page "Elements on the page" "HardStopOnFailure"
    And the user scroll to the page until the object "activeField" is visible at the page "CreateAsset"
    And the user waits for the "activeField" element to be "Visible" on the "CreateAsset" page
    And the user clicks the "activeField" element at the "CreateAsset" page
    And the user clicks the "searchSiteAssociation" element at the "CreateAsset" page
    And the user scroll to the page until the object "selectSite" is visible at the page "CreateAsset"
    And the user clicks the "selectSite" element at the "CreateAsset" page
    And the user clicks the "ATMForm" element at the "CreateAsset" page
    #And the user waits for the "fimp" element to be "Visible" on the "CreateAsset" page
    #And the user clicks the "fimp" element at the "CreateAsset" page
    #Then the user validates the "fimpID" element is visible at the "CreateAsset" page "Dropdown List" "HardStopOnFailure"

  @CMS @CMS_SG @CMS @CMS_SG1 @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate Branch Dropdown field_ATM Basics
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    And the user clicks the "createAsset" element at the "CMSHomePage" page
    And the user clicks the "siteAssociation" element at the "Create Asset" page
    And the user clicks the "statusSiteAssociation" element at the "Create Asset" page
    Then the user validates the "statusSiteAssociation" element is visible at the "CreateAsset" page "Elements on the page" "HardStopOnFailure"
    And the user scroll to the page until the object "activeField" is visible at the page "CreateAsset"
    And the user waits for the "activeField" element to be "Visible" on the "CreateAsset" page
    And the user clicks the "activeField" element at the "CreateAsset" page
    And the user clicks the "searchSiteAssociation" element at the "CreateAsset" page
    And the user scroll to the page until the object "selectSite" is visible at the page "CreateAsset"
    And the user clicks the "selectSite" element at the "CreateAsset" page
    And the user clicks the "ATMForm" element at the "CreateAsset" page

  @CMS @CMS_SG @CMS @CMS_SG1 @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate Machine Type Dropdown field_ATM Basics
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    And the user clicks the "createAsset" element at the "CMSHomePage" page
    And the user clicks the "siteAssociation" element at the "Create Asset" page
    And the user clicks the "statusSiteAssociation" element at the "Create Asset" page
    Then the user validates the "statusSiteAssociation" element is visible at the "CreateAsset" page "Elements on the page" "HardStopOnFailure"
    And the user scroll to the page until the object "activeField" is visible at the page "CreateAsset"
    And the user waits for the "activeField" element to be "Visible" on the "CreateAsset" page
    And the user clicks the "activeField" element at the "CreateAsset" page
    And the user clicks the "searchSiteAssociation" element at the "CreateAsset" page
    And the user scroll to the page until the object "selectSite" is visible at the page "CreateAsset"
    And the user clicks the "selectSite" element at the "CreateAsset" page
    And the user clicks the "ATMForm" element at the "CreateAsset" page
    And the user clicks the "machineType" element at the "CreateAsset" page
    And the user waits for the "machineTypeATM" element to be "Visible" on the "CreateAsset" page
    Then the user validates the "machineTypeATM" element is visible at the "CreateAsset" page "Dropdown List" "HardStopOnFailure"

  @CMS @CMS_SG @CMS @CMS_SG1 @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate Serial Number field_ATM Basics
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    And the user clicks the "createAsset" element at the "CMSHomePage" page
    And the user clicks the "siteAssociation" element at the "Create Asset" page
    And the user clicks the "statusSiteAssociation" element at the "Create Asset" page
    Then the user validates the "statusSiteAssociation" element is visible at the "CreateAsset" page "Elements on the page" "HardStopOnFailure"
    And the user scroll to the page until the object "activeField" is visible at the page "CreateAsset"
    And the user waits for the "activeField" element to be "Visible" on the "CreateAsset" page
    And the user clicks the "activeField" element at the "CreateAsset" page
    And the user clicks the "searchSiteAssociation" element at the "CreateAsset" page
    And the user scroll to the page until the object "selectSite" is visible at the page "CreateAsset"
    And the user clicks the "selectSite" element at the "CreateAsset" page
    And the user clicks the "ATMForm" element at the "CreateAsset" page
    And the user waits for the "serialNumber" element to be "Visible" on the "CreateAsset" page
    And the user enters "#(SerialNumber)" into the "serialNumber" textbox at the "CreateAsset" page
    And the user clicks the "atmStatus" element at the "CreateAsset" page
    Then the user validates that the partial text "serialNumber" element at the "CreateAsset" page is "Equal To" "#(SerialNumber)" "Validating Serial Number" "HardStopOnFailure"
    And the user enters "#(SerialNumber1)" into the "serialNumber" textbox at the "CreateAsset" page
    And the user clicks the "atmStatus" element at the "CreateAsset" page
    Then the user validates that the partial text "serialNumber" element at the "CreateAsset" page is "Equal To" "#(SerialNumber1)" "Validating invalid Serial Number" "HardStopOnFailure"
    And the user enters "#(SerialNumber2)" into the "serialNumber" textbox at the "CreateAsset" page
    And the user clicks the "atmStatus" element at the "CreateAsset" page
    Then the user validates that the partial text "serialNumber" element at the "CreateAsset" page is "Equal To" "#(SerialNumber2)" "Validating Invalid Serial Number" "HardStopOnFailure"

  @CMS @CMS_SG @CMS @CMS_SG1 @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate Manufacturer Dropdown field_ATM Basics
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    And the user clicks the "createAsset" element at the "CMSHomePage" page
    And the user clicks the "siteAssociation" element at the "Create Asset" page
    And the user clicks the "statusSiteAssociation" element at the "Create Asset" page
    Then the user validates the "statusSiteAssociation" element is visible at the "CreateAsset" page "Elements on the page" "HardStopOnFailure"
    And the user scroll to the page until the object "activeField" is visible at the page "CreateAsset"
    And the user waits for the "activeField" element to be "Visible" on the "CreateAsset" page
    And the user clicks the "activeField" element at the "CreateAsset" page
    And the user clicks the "searchSiteAssociation" element at the "CreateAsset" page
    And the user scroll to the page until the object "selectSite" is visible at the page "CreateAsset"
    And the user clicks the "selectSite" element at the "CreateAsset" page
    And the user clicks the "ATMForm" element at the "CreateAsset" page
    And the user clicks the "manufacturer" element at the "CreateAsset" page
    And the user waits for the "manufacturerDN" element to be "Visible" on the "CreateAsset" page
    Then the user validates the "manufacturerDN" element is present at the "CreateAsset" page "Taking Screenshot" "HardStopOnFailure"
    And the user clicks the "manufacturerDN" element at the "CreateAsset" page
    Then the user waits for the "manufacturer" element to be "Visible" on the "CreateAsset" page
    Then the user validates that the partial text "manufacturer" element at the "CreateAsset" page is "Equal To" "DN" "Validating select correct Manufacturer" "HardStopOnFailure"
    And the user clicks the "manufacturer" element at the "CreateAsset" page


  @CMS @CMS_SG @CMS @CMS_SG1 @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate Model Dropdown field_ATM Basics
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    And the user clicks the "createAsset" element at the "CMSHomePage" page
    And the user clicks the "siteAssociation" element at the "Create Asset" page
    And the user clicks the "statusSiteAssociation" element at the "Create Asset" page
    Then the user validates the "statusSiteAssociation" element is visible at the "CreateAsset" page "Elements on the page" "HardStopOnFailure"
    And the user scroll to the page until the object "activeField" is visible at the page "CreateAsset"
    And the user waits for the "activeField" element to be "Visible" on the "CreateAsset" page
    And the user clicks the "activeField" element at the "CreateAsset" page
    And the user clicks the "searchSiteAssociation" element at the "CreateAsset" page
    And the user scroll to the page until the object "selectSite" is visible at the page "CreateAsset"
    And the user clicks the "selectSite" element at the "CreateAsset" page
    And the user clicks the "ATMForm" element at the "CreateAsset" page
    And the user clicks the "manufacturer" element at the "CreateAsset" page
    And the user waits for the "manufacturerDN" element to be "Visible" on the "CreateAsset" page
    Then the user validates the "manufacturerDN" element is present at the "CreateAsset" page "Taking Screenshot" "HardStopOnFailure"
    And the user clicks the "manufacturerDN" element at the "CreateAsset" page
    Then the user waits for the "manufacturer" element to be "Visible" on the "CreateAsset" page
    Then the user validates that the partial text "manufacturer" element at the "CreateAsset" page is "Equal To" "DN" "Validating select correct Manufacturer" "HardStopOnFailure"
    And the user clicks the "model" element at the "CreateAsset" page
    And the user waits for the "modelDN200V" element to be "Visible" on the "CreateAsset" page
    Then the user validates the "modelDN200V" element is present at the "CreateAsset" page "Screenshot" "HardStopOnFailure"
    And the user clicks the "modelDN200V" element at the "CreateAsset" page
    Then the user validates that the partial text "model" element at the "CreateAsset" page is "Equal To" "DN200V" "Validate the correct model selected " "HardStopOnFailure"


  @CMS @CMS_SG @CMS @CMS_SG1 @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate Owner Dropdown field_ATM Basics
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    And the user clicks the "createAsset" element at the "CMSHomePage" page
    And the user clicks the "siteAssociation" element at the "Create Asset" page
    And the user clicks the "statusSiteAssociation" element at the "Create Asset" page
    Then the user validates the "statusSiteAssociation" element is visible at the "CreateAsset" page "Elements on the page" "HardStopOnFailure"
    And the user scroll to the page until the object "activeField" is visible at the page "CreateAsset"
    And the user waits for the "activeField" element to be "Visible" on the "CreateAsset" page
    And the user clicks the "activeField" element at the "CreateAsset" page
    And the user clicks the "searchSiteAssociation" element at the "CreateAsset" page
    And the user scroll to the page until the object "selectSite" is visible at the page "CreateAsset"
    And the user clicks the "selectSite" element at the "CreateAsset" page
    And the user clicks the "ATMForm" element at the "CreateAsset" page
    And the user clicks the "owner" element at the "CreateAsset" page
    And the user waits for the "ownerCitiBankNA" element to be "Visible" on the "CreateAsset" page
    When the user clicks the "ownerCitiBankNA" element at the "CreateAsset" page
    And the user waits for the "owner" element to be "Visible" on the "CreateAsset" page
    Then the user validates that the partial text "owner" element at the "CreateAsset" page is "Equal To" "CITIBANK N.A(00002)" "<string>" "HardStopOnFailure"

  @CMS @CMS_SG @CMS @CMS_SG1 @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate Deposit Payments Capability Dropdown field_ATM Hardware
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    And the user clicks the "createAsset" element at the "CMSHomePage" page
    And the user clicks the "siteAssociation" element at the "Create Asset" page
    And the user clicks the "statusSiteAssociation" element at the "Create Asset" page
    Then the user validates the "statusSiteAssociation" element is visible at the "CreateAsset" page "Elements on the page" "HardStopOnFailure"
    And the user scroll to the page until the object "activeField" is visible at the page "CreateAsset"
    And the user waits for the "activeField" element to be "Visible" on the "CreateAsset" page
    And the user clicks the "activeField" element at the "CreateAsset" page
    And the user clicks the "searchSiteAssociation" element at the "CreateAsset" page
    And the user scroll to the page until the object "selectSite" is visible at the page "CreateAsset"
    And the user clicks the "selectSite" element at the "CreateAsset" page
    And the user clicks the "ATMForm" element at the "CreateAsset" page
    And the user scroll to the page until the object "depositPaymentCapability" is visible at the page "CreateAsset"
    When the user waits for the "depositPaymentCapability" element to be "Visible" on the "CreateAsset" page
    And the user clicks the "depositPaymentCapability" element at the "CreateAsset" page
    Then the user validates the "depositPaymentCapability" element is present at the "CreateAsset" page "Taking Screenshot" "HardStopOnFailure"
   # And the user clicks the "depositPaymentCapabilityCashAndCheck" element at the "CreateAsset" page
    #Then the user validates that the partial text "depositPaymentCapability" element at the "CreateAsset" page is "Equal To" "CASH AND CHECK" "validating text" "HardStopOnFailure"


  @CMS @CMS_SG @CMS @CMS_SG1 @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate Card Reader Orientation Dropdown field_ATM Hardware
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    And the user clicks the "createAsset" element at the "CMSHomePage" page
    And the user clicks the "siteAssociation" element at the "Create Asset" page
    And the user clicks the "statusSiteAssociation" element at the "Create Asset" page
    Then the user validates the "statusSiteAssociation" element is visible at the "CreateAsset" page "Elements on the page" "HardStopOnFailure"
    And the user scroll to the page until the object "activeField" is visible at the page "CreateAsset"
    And the user waits for the "activeField" element to be "Visible" on the "CreateAsset" page
    And the user clicks the "activeField" element at the "CreateAsset" page
    And the user clicks the "searchSiteAssociation" element at the "CreateAsset" page
    And the user scroll to the page until the object "selectSite" is visible at the page "CreateAsset"
    And the user clicks the "selectSite" element at the "CreateAsset" page
    And the user clicks the "ATMForm" element at the "CreateAsset" page
    And the user scroll to the page until the object "cardReaderOrientation" is visible at the page "CreateAsset"
    When the user waits for the "cardReaderOrientation" element to be "Visible" on the "CreateAsset" page
    And the user clicks the "cardReaderOrientation" element at the "CreateAsset" page
    Then the user validates the "cardReaderOrientationHorizontal" element is present at the "CreateAsset" page "Taking Screenshot" "HardStopOnFailure"
    And the user clicks the "cardReaderOrientationHorizontal" element at the "CreateAsset" page
    Then the user validates that the partial text "cardReaderOrientation" element at the "CreateAsset" page is "Equal To" "HORIZONTAL" "validating text" "HardStopOnFailure"
    And the user clicks the "cardReaderOrientation" element at the "CreateAsset" page
    Then the user validates the "cardReaderOrientationVertical" element is present at the "CreateAsset" page "Taking Screenshot" "HardStopOnFailure"
    And the user clicks the "cardReaderOrientationVertical" element at the "CreateAsset" page
    Then the user validates that the partial text "cardReaderOrientation" element at the "CreateAsset" page is "Equal To" "VERTICAL" "validating text" "HardStopOnFailure"



  @CMS @CMS_SG @CMS @CMS_SG1 @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate Card Reader Type Dropdown field_ATM Hardware
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    And the user clicks the "createAsset" element at the "CMSHomePage" page
    And the user clicks the "siteAssociation" element at the "Create Asset" page
    And the user clicks the "statusSiteAssociation" element at the "Create Asset" page
    Then the user validates the "statusSiteAssociation" element is visible at the "CreateAsset" page "Elements on the page" "HardStopOnFailure"
    And the user scroll to the page until the object "activeField" is visible at the page "CreateAsset"
    And the user waits for the "activeField" element to be "Visible" on the "CreateAsset" page
    And the user clicks the "activeField" element at the "CreateAsset" page
    And the user clicks the "searchSiteAssociation" element at the "CreateAsset" page
    And the user scroll to the page until the object "selectSite" is visible at the page "CreateAsset"
    And the user clicks the "selectSite" element at the "CreateAsset" page
    And the user clicks the "ATMForm" element at the "CreateAsset" page
    And the user scroll to the page until the object "cardReaderType" is visible at the page "CreateAsset"
    When the user waits for the "cardReaderType" element to be "Visible" on the "CreateAsset" page
    And the user clicks the "cardReaderType" element at the "CreateAsset" page
    Then the user validates the "cardReaderTypeDip" element is present at the "CreateAsset" page "Taking Screenshot" "HardStopOnFailure"
    And the user clicks the "cardReaderTypeDip" element at the "CreateAsset" page
    Then the user validates that the partial text "cardReaderType" element at the "CreateAsset" page is "Equal To" "DIP" "validating text" "HardStopOnFailure"
    And the user clicks the "cardReaderType" element at the "CreateAsset" page
    Then the user validates the "cardReaderTypeTransport" element is present at the "CreateAsset" page "Taking Screenshot" "HardStopOnFailure"
    And the user clicks the "cardReaderTypeTransport" element at the "CreateAsset" page
    Then the user validates that the partial text "cardReaderType" element at the "CreateAsset" page is "Equal To" "TRANSPORT" "validating text" "HardStopOnFailure"



  @CMS @CMS_SG @CMS @CMS_SG1 @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate EPP Series Number fields ATM Hardware
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    And the user clicks the "createAsset" element at the "CMSHomePage" page
    And the user clicks the "siteAssociation" element at the "Create Asset" page
    And the user clicks the "statusSiteAssociation" element at the "Create Asset" page
    Then the user validates the "statusSiteAssociation" element is visible at the "CreateAsset" page "Elements on the page" "HardStopOnFailure"
    And the user scroll to the page until the object "activeField" is visible at the page "CreateAsset"
    And the user waits for the "activeField" element to be "Visible" on the "CreateAsset" page
    And the user clicks the "activeField" element at the "CreateAsset" page
    And the user clicks the "searchSiteAssociation" element at the "CreateAsset" page
    And the user scroll to the page until the object "selectSite" is visible at the page "CreateAsset"
    And the user clicks the "selectSite" element at the "CreateAsset" page
    And the user clicks the "ATMForm" element at the "CreateAsset" page
    And the user scroll to the page until the object "eppSerialNumber" is visible at the page "CreateAsset"
    When the user waits for the "eppSerialNumber" element to be "Visible" on the "CreateAsset" page
    And the user enters "#(EPP Serial Number)" into the "eppSerialNumber" textbox at the "CreateAsset" page
    Then the user validates that the partial text "eppSerialNumber" element at the "CreateAsset" page is "Equal To" "#(EPP Serial Number)" "Validating the correct EPP Enter" "HardStopOnFailure"


  @CMS @CMS_SG @CMS @CMS_SG1 @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate EPP profile fields ATM Hardware
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    And the user clicks the "createAsset" element at the "CMSHomePage" page
    And the user clicks the "siteAssociation" element at the "Create Asset" page
    And the user clicks the "statusSiteAssociation" element at the "Create Asset" page
    Then the user validates the "statusSiteAssociation" element is visible at the "CreateAsset" page "Elements on the page" "HardStopOnFailure"
    And the user scroll to the page until the object "activeField" is visible at the page "CreateAsset"
    And the user waits for the "activeField" element to be "Visible" on the "CreateAsset" page
    And the user clicks the "activeField" element at the "CreateAsset" page
    And the user clicks the "searchSiteAssociation" element at the "CreateAsset" page
    And the user scroll to the page until the object "selectSite" is visible at the page "CreateAsset"
    And the user clicks the "selectSite" element at the "CreateAsset" page
    And the user clicks the "ATMForm" element at the "CreateAsset" page
    And the user scroll to the page until the object "eppProfile" is visible at the page "CreateAsset"
    When the user waits for the "eppProfile" element to be "Visible" on the "CreateAsset" page
    And the user enters "#(EPP profile)" into the "eppProfile" textbox at the "CreateAsset" page
    Then the user validates that the partial text "eppProfile" element at the "CreateAsset" page is "Equal To" "#(EPP profile)" "Validating the correct EPP Enter" "HardStopOnFailure"



  @CMS @CMS_SG @CMS @CMS_SG1 @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate Screen resolution fields ATM Hardware
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    And the user clicks the "createAsset" element at the "CMSHomePage" page
    And the user clicks the "siteAssociation" element at the "Create Asset" page
    And the user clicks the "statusSiteAssociation" element at the "Create Asset" page
    Then the user validates the "statusSiteAssociation" element is visible at the "CreateAsset" page "Elements on the page" "HardStopOnFailure"
    And the user scroll to the page until the object "activeField" is visible at the page "CreateAsset"
    And the user waits for the "activeField" element to be "Visible" on the "CreateAsset" page
    And the user clicks the "activeField" element at the "CreateAsset" page
    And the user clicks the "searchSiteAssociation" element at the "CreateAsset" page
    And the user scroll to the page until the object "selectSite" is visible at the page "CreateAsset"
    And the user clicks the "selectSite" element at the "CreateAsset" page
    And the user clicks the "ATMForm" element at the "CreateAsset" page
    And the user scroll to the page until the object "screenResolution" is visible at the page "CreateAsset"
    When the user waits for the "screenResolution" element to be "Visible" on the "CreateAsset" page
    And the user clicks the "screenResolution" element at the "CreateAsset" page
    Then the user validates the "screenResolution1024" element is present at the "CreateAsset" page "Taking Screenshot" "HardStopOnFailure"
    And the user clicks the "screenResolution1024" element at the "CreateAsset" page
    Then the user validates that the partial text "screenResolution" element at the "CreateAsset" page is "Equal To" "1024 X 768" "validating text" "HardStopOnFailure"

  @CMS @CMS_SG @CMS @CMS_SG1 @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate Screen size fields ATM Hardware
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    And the user clicks the "createAsset" element at the "CMSHomePage" page
    And the user clicks the "siteAssociation" element at the "Create Asset" page
    And the user clicks the "statusSiteAssociation" element at the "Create Asset" page
    Then the user validates the "statusSiteAssociation" element is visible at the "CreateAsset" page "Elements on the page" "HardStopOnFailure"
    And the user scroll to the page until the object "activeField" is visible at the page "CreateAsset"
    And the user waits for the "activeField" element to be "Visible" on the "CreateAsset" page
    And the user clicks the "activeField" element at the "CreateAsset" page
    And the user clicks the "searchSiteAssociation" element at the "CreateAsset" page
    And the user scroll to the page until the object "selectSite" is visible at the page "CreateAsset"
    And the user clicks the "selectSite" element at the "CreateAsset" page
    And the user clicks the "ATMForm" element at the "CreateAsset" page
    And the user scroll to the page until the object "screenSize" is visible at the page "CreateAsset"
    When the user waits for the "screenSize" element to be "Visible" on the "CreateAsset" page
    And the user clicks the "screenSize" element at the "CreateAsset" page
    Then the user validates the "screenSize15" element is present at the "CreateAsset" page "Taking Screenshot" "HardStopOnFailure"
    And the user clicks the "screenSize15" element at the "CreateAsset" page
    Then the user validates that the partial text "screenSize" element at the "CreateAsset" page is "Equal To" "15 INCHES" "validating text" "HardStopOnFailure"


  @CMS @CMS_SG @CMS @CMS_SG1 @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate ATM Sound Volume fields in ATM Hardware
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    And the user clicks the "createAsset" element at the "CMSHomePage" page
    And the user clicks the "siteAssociation" element at the "Create Asset" page
    And the user clicks the "statusSiteAssociation" element at the "Create Asset" page
    Then the user validates the "statusSiteAssociation" element is visible at the "CreateAsset" page "Elements on the page" "HardStopOnFailure"
    And the user scroll to the page until the object "activeField" is visible at the page "CreateAsset"
    And the user waits for the "activeField" element to be "Visible" on the "CreateAsset" page
    And the user clicks the "activeField" element at the "CreateAsset" page
    And the user clicks the "searchSiteAssociation" element at the "CreateAsset" page
    And the user scroll to the page until the object "selectSite" is visible at the page "CreateAsset"
    And the user clicks the "selectSite" element at the "CreateAsset" page
    And the user clicks the "ATMForm" element at the "CreateAsset" page
    And the user scroll to the page until the object "atmSoundVolume" is visible at the page "CreateAsset"
    When the user waits for the "atmSoundVolume" element to be "Visible" on the "CreateAsset" page
    And the user enters "#(Sound)" into the "atmSoundVolume" textbox at the "CreateAsset" page
    Then the user validates that the partial text "atmSoundVolume" element at the "CreateAsset" page is "Equal To" "#(Sound)" "Validating the correct EPP Enter" "HardStopOnFailure"

  @CMS @CMS_SG @CMS @CMS_SG1 @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate Processor Manufacturer fields ATM Hardware
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    And the user clicks the "createAsset" element at the "CMSHomePage" page
    And the user clicks the "siteAssociation" element at the "Create Asset" page
    And the user clicks the "statusSiteAssociation" element at the "Create Asset" page
    Then the user validates the "statusSiteAssociation" element is visible at the "CreateAsset" page "Elements on the page" "HardStopOnFailure"
    And the user scroll to the page until the object "activeField" is visible at the page "CreateAsset"
    And the user waits for the "activeField" element to be "Visible" on the "CreateAsset" page
    And the user clicks the "activeField" element at the "CreateAsset" page
    And the user clicks the "searchSiteAssociation" element at the "CreateAsset" page
    And the user scroll to the page until the object "selectSite" is visible at the page "CreateAsset"
    And the user clicks the "selectSite" element at the "CreateAsset" page
    And the user clicks the "ATMForm" element at the "CreateAsset" page
    And the user scroll to the page until the object "processorManufacturer" is visible at the page "CreateAsset"
    When the user waits for the "processorManufacturer" element to be "Visible" on the "CreateAsset" page
    And the user clicks the "processorManufacturer" element at the "CreateAsset" page
    Then the user validates the "processorManufacturerIntel" element is present at the "CreateAsset" page "Taking Screenshot" "HardStopOnFailure"
    And the user clicks the "processorManufacturerIntel" element at the "CreateAsset" page
    Then the user validates that the partial text "processorManufacturer" element at the "CreateAsset" page is "Equal To" "INTEL" "validating text" "HardStopOnFailure"

  @CMS @CMS_SG @CMS @CMS_SG1 @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate Bulkupload fields
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    And the user clicks the "bulkUpload" element at the "CMSHomePage" page
    And the user validates the "bulkuploadheader" element is visible at the "CMSBulkuploadPage" page "Bulk Upload" "HardStopOnFailure"
    And the user validates the "terminal" element is visible at the "CMSBulkuploadPage" page "Terminal" "HardStopOnFailure"
    And the user validates the "location" element is visible at the "CMSBulkuploadPage" page "Location" "HardStopOnFailure"
    And the user validates the "site" element is visible at the "CMSBulkuploadPage" page "Site" "HardStopOnFailure"
    And the user validates the "chooseFile" element is enabled at the "CMSBulkuploadPage" page "Choose File" "HardStopOnFailure"
    Then the user validates the "submit" element is not clickable at the "CMSBulkuploadPage" page "Submit" "HardStopOnFailure"

  @CMS @CMS_SG @CMS @CMS_SG4 @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate the required fields in create location
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    #validating required fields in creating location
    When the user clicks the "createLocation" element at the "CMSHomePage" page
    And the user clicks the "saveLocationButton" element at the "createLocation" page
    Then the user validates the "locationStatusRequiredField" element is present at the "createLocation" page "Location Status Required Field" "HardStopOnFailure"
    Then the user validates the "FIIDRequiredField" element is present at the "createLocation" page "FIID Required Field" "HardStopOnFailure"
    Then the user validates the "timeZoneRequiredField" element is present at the "createLocation" page "Time Zone Required Field" "HardStopOnFailure"
    Then the user validates the "daylightsavingRequiredField" element is present at the "createLocation" page "Daylight Saving Status Required Field" "HardStopOnFailure"

  @CMS @CMS_SG @CMS @CMS_SG1 @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate the business segment code default value
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    #validating required fields in creating location
    When the user clicks the "createLocation" element at the "CMSHomePage" page
    Then the user validates the "DefaultBusinessSegmentCode" element is visible at the "createLocation" page "DefaultBusinessSegmentCode" "HardStopOnFailure"

  @CMS @CMS_SG @CMS @CMS_SG1 @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate the invalid latitude and longitude fields value
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    #validating required fields in creating location
    When the user clicks the "createLocation" element at the "CMSHomePage" page
    And the user enters "1.1111111" into the "latitude" textbox at the "createLocation" page
    And the user enters "1.1111111" into the "longitude" textbox at the "createLocation" page
    And the user clicks the "latitude" element at the "createLocation" page
    Then the user validates the "latitudeerrormessage" element is visible at the "createLocation" page "latitude error" "HardStopOnFailure"
    Then the user validates the "longitudeerrormessage" element is visible at the "createLocation" page "longitude error" "HardStopOnFailure"

  @CMS @CMS_SG @CMS @CMS_SG4 @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG 091_Validate the Report tab fields
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    #validating fields in Report tab
    When the user clicks the "reportTab" element at the "CMSHomePage" page
    And the user validates the "terminalMetadata" element is visible at the "CMSReport" page "Terminal Metadata" "HardStopOnFailure"
    And the user validates the "terminalRegistration" element is visible at the "CMSReport" page "Terminal Registration" "HardStopOnFailure"
    Then the user validates the "terminalMetadata" element is enabled at the "CMSReport" page "Terminal Metadata" "HardStopOnFailure"
    Then the user validates the "terminalRegistration" element is enabled at the "CMSReport" page "Terminal Registration" "HardStopOnFailure"

  @CMS @CMS_SG @CMS @CMS_SG1 @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG 092_Validate theTerminal Metadata feilds under Report tab
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    #validating fields in Terminal Metadata tab
    When the user clicks the "reportTab" element at the "CMSHomePage" page
    And the user validates the "terminalMetadata" element is visible at the "CMSReport" page "Terminal Metadata" "HardStopOnFailure"
    And the user clicks the "terminalMetadata" element at the "CMSReport" page
    And the user validates the "terminalMetadataHeader" element is visible at the "CMSReport" page "Terminal Metadata Header" "HardStopOnFailure"
    Then the user validates the "downloadReport" element is enabled at the "CMSReport" page "Download Report" "HardStopOnFailure"

  @CMS @CMS_SG @CMS @CMS_SG4 @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG 093_Validate the Terminal Registration fields under Report tab
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    #validating fields in Terminal Registration tab
    When the user clicks the "reportTab" element at the "CMSHomePage" page
    When the user clicks the "terminalRegistration" element at the "CMSReport" page
    And the user validates the "ATMNodeId" element is visible at the "CMSReport" page "ATM Node ID" "HardStopOnFailure"
    And the user validates the "FromDate" element is visible at the "CMSReport" page "From Date" "HardStopOnFailure"
    Then the user validates the "ToDate" element is enabled at the "CMSReport" page "To Date" "HardStopOnFailure"
    Then the user validates the "Search" element is enabled at the "CMSReport" page "Search" "HardStopOnFailure"


  @CMS @CMS_SG @CMS @CMS_SG1 @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate the Terminal Registration Results under Report tab
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    #validating Search Results in Terminal Registration tab
    When the user clicks the "reportTab" element at the "CMSHomePage" page
    When the user clicks the "terminalRegistration" element at the "CMSReport" page
    And the user enters "#(From Date)" into the "FromDate" textbox at the "CMSReport" page
    And the user enters "#(To Date)" into the "ToDate" textbox at the "CMSReport" page
    When the user clicks the "Search" element at the "CMSReport" page
   # And the user waits for the page to load
    #Then the user validates the "SearchResults" element is visible at the "CMSReport" page "Search Results" "HardStopOnFailure"

  @CMS @CMS_SG @CMS @CMS_SG1 @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate the Required Fields in  Registration Fields
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    #validating Search Results in Terminal Registration tab
    When the user clicks the "reportTab" element at the "CMSHomePage" page
    When the user clicks the "terminalRegistration" element at the "CMSReport" page
    When the user clicks the "FromDate" element at the "CMSReport" page
    When the user clicks the "ToDate" element at the "CMSReport" page
    When the user clicks the "FromDate" element at the "CMSReport" page
    Then the user validates the "FromDateRequired" element is visible at the "CMSReport" page "FromDateRequired" "HardStopOnFailure"
    Then the user validates the "ToDateRequired" element is visible at the "CMSReport" page "ToDateRequired" "HardStopOnFailure"
    #Then the user validates the "FromDateasterisk" element is visible at the "CMSReport" page "FromDateasterisk" "HardStopOnFailure"
    #Then the user validates the "ToDateasterisk" element is visible at the "CMSReport" page "ToDateasterisk" "HardStopOnFailure"

  @CMS @CMS_SG @CMS @CMS_SG1 @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate the Search Tab Fields
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    #validating Search Results in Terminal Registration tab
    Then the user validates the "AssetSearch" element is visible at the "CMSSearch" page "AssetSearch" "HardStopOnFailure"
    Then the user validates the "LocationSearch" element is visible at the "CMSSearch" page "LocationSearch" "HardStopOnFailure"
    Then the user validates the "SiteSearch" element is visible at the "CMSSearch" page "SiteSearch" "HardStopOnFailure"


  @CMS @CMS_SG @CMS @CMS_SG1 @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate the Asset Search Fields
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    #validating Search Results in Terminal Registration tab
    Then the user validates the "AssetSearch" element is visible at the "CMSSearch" page "AssetSearch" "HardStopOnFailure"
    Then the user validates the "ATMNum" element is visible at the "CMSSearch" page "Asset ID" "HardStopOnFailure"
    Then the user validates the "TerminalID" element is visible at the "CMSSearch" page "Terminal ID" "HardStopOnFailure"
    Then the user validates the "Status" element is visible at the "CMSSearch" page "Status" "HardStopOnFailure"
    Then the user validates the "Model" element is visible at the "CMSSearch" page "Model" "HardStopOnFailure"
    Then the user validates the "SerialNumber" element is visible at the "CMSSearch" page "Serial Number" "HardStopOnFailure"
    Then the user validates the "MacAddress" element is visible at the "CMSSearch" page "Mac Address" "HardStopOnFailure"


  @CMS @CMS_SG @CMS @CMS_SG1 @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate the Location Search Fields
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    #validating Search Results in Terminal Registration tab
    And the user validates the "LocationSearch" element is visible at the "CMSSearch" page "LocationSearch" "HardStopOnFailure"
    When the user clicks the "LocationSearch" element at the "CMSSearch" page
    Then the user validates the "LocationID" element is visible at the "CMSSearch" page "Location ID" "HardStopOnFailure"
    Then the user validates the "LocationDescription" element is visible at the "CMSSearch" page "Location Description" "HardStopOnFailure"
    Then the user validates the "LocationStatus" element is visible at the "CMSSearch" page "Location Status" "HardStopOnFailure"

  @CMS @CMS_SG @CMS @CMS_SG1 @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate the Site Search Fields
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    #validating Search Results in Terminal Registration tab
    And the user validates the "SiteSearch" element is visible at the "CMSSearch" page "LocationSearch" "HardStopOnFailure"
    When the user clicks the "SiteSearch" element at the "CMSSearch" page
    Then the user validates the "SiteNumber" element is visible at the "CMSSearch" page "SIte Number" "HardStopOnFailure"
    Then the user validates the "SiteDescription" element is visible at the "CMSSearch" page "Site Description" "HardStopOnFailure"
    Then the user validates the "SiteStatus" element is visible at the "CMSSearch" page "Site Status" "HardStopOnFailure"


  @CMS @CMS_SG @CMS @CMS_SG1 @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate the Error Popup in Asset Search
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    #validating Search Results in Terminal Registration tab
    Then the user validates the "AssetSearch" element is visible at the "CMSSearch" page "AssetSearch" "HardStopOnFailure"
    And the user clicks the "Search" element at the "CMSSearch" page
    Then the user validates the "AssetSearchPopup" element is visible at the "CMSSearch" page "Error Popup" "HardStopOnFailure"

  @CMS @CMS_SG @CMS @CMS_SG1 @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate the Search Results using Asset ID
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    #validating Search Results in using ASSET ID
    Then the user validates the "AssetSearch" element is visible at the "CMSSearch" page "Asset Search" "HardStopOnFailure"
    And the user enters "BSG" into the "ATMNum" textbox at the "CMSSearch" page
    And the user clicks the "Search" element at the "CMSSearch" page
    And the user waits for the "AssetIDSearchResultSG" element to be "Visible" on the "CMSSearch" page
    Then the user validates the "AssetIDSearchResultSG" element is visible at the "CMSSearch" page "Asset ID Search Result" "HardStopOnFailure"

  @CMS @CMS_SG @CMS @CMS_SG1 @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate the Search Results using Asset ID with invalid data
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    #validating Search Results in using ASSET ID
    When the user validates the "AssetSearch" element is visible at the "CMSSearch" page "Asset Search" "HardStopOnFailure"
    And the user enters "abc" into the "ATMNum" textbox at the "CMSSearch" page
    And the user clicks the "Search" element at the "CMSSearch" page
    Then the user validates the "NoMatchPopup" element is visible at the "CMSSearch" page "Asset ID Error Message" "HardStopOnFailure"


  @CMS @CMS_SG @CMS @CMS_SG1 @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate the Search Results using Asset ID with serial number
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    #validating Search Results in using ASSET ID
    When the user validates the "AssetSearch" element is visible at the "CMSSearch" page "Asset Search" "HardStopOnFailure"
    And the user enters "2312345667" into the "SerialNumber" textbox at the "CMSSearch" page
    And the user clicks the "Search" element at the "CMSSearch" page
    Then the user validates the "SearchResultSerialNumber" element is visible at the "CMSSearch" page "Search Result Serial Number" "HardStopOnFailure"

  @CMS @CMS_SG @CMS @CMS_SG1 @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate the Search Results using Asset ID with MAC address
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    #validating Search Results in using ASSET ID
    When the user validates the "AssetSearch" element is visible at the "CMSSearch" page "Asset Search" "HardStopOnFailure"
    And the user enters "aa-aa-aa-aa-aa-aa" into the "MacAddress" textbox at the "CMSSearch" page
    And the user clicks the "Search" element at the "CMSSearch" page
    Then the user validates the "SearchResultMACaddress" element is visible at the "CMSSearch" page "Search Result Serial Number" "HardStopOnFailure"

  @CMS @CMS_SG @CMS @CMS_SG1 @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate the Search Results using Asset ID with invalid MAC address
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    #validating Search Results in using ASSET ID
    When the user validates the "AssetSearch" element is visible at the "CMSSearch" page "Asset Search" "HardStopOnFailure"
    And the user enters "n" into the "MacAddress" textbox at the "CMSSearch" page
    And the user clicks the "Search" element at the "CMSSearch" page
    #Then the user validates the "SearchResultMACaddress" element is visible at the "CMSSearch" page "MAC Address Error Message" "HardStopOnFailure"


  @CMS @CMS_SG @CMS @CMS_SG1 @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate Search Result using Location ID
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    #validating Search Results in using LOCATION ID
    And the user validates the "LocationSearch" element is visible at the "CMSSearch" page "LocationSearch" "HardStopOnFailure"
    When the user clicks the "LocationSearch" element at the "CMSSearch" page
    Then the user validates the "LocationID" element is visible at the "CMSSearch" page "Location ID" "HardStopOnFailure"
    And the user enters "100802" into the "LocationID" textbox at the "CMSSearch" page
    And the user clicks the "Search" element at the "CMSSearch" page
    Then the user validates the "LocationIDResultSG" element is visible at the "CMSSearch" page "Location ID Result" "HardStopOnFailure"

  @CMS @CMS_SG @CMS @CMS_SG1 @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate Search Result using Location Description
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    #validating Search Results in using LOCATION ID
    And the user validates the "LocationSearch" element is visible at the "CMSSearch" page "LocationSearch" "HardStopOnFailure"
    When the user clicks the "LocationSearch" element at the "CMSSearch" page
    Then the user validates the "LocationDescription" element is visible at the "CMSSearch" page "Location Description" "HardStopOnFailure"
    And the user enters "Test" into the "LocationDescription" textbox at the "CMSSearch" page
    And the user clicks the "Search" element at the "CMSSearch" page
    Then the user validates the "SearchDescriptionResult" element is visible at the "CMSSearch" page "Search Description Result" "HardStopOnFailure"

  @CMS @CMS_SG @CMS @CMS_SG1 @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate Search Result using Location Status
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    #validating Search Results in using LOCATION Status
    And the user validates the "LocationSearch" element is visible at the "CMSSearch" page "LocationSearch" "HardStopOnFailure"
    When the user clicks the "LocationSearch" element at the "CMSSearch" page
    And the user validates the "LocationStatus" element is visible at the "CMSSearch" page "Location Status" "HardStopOnFailure"
    And the user clicks the "LocationStatus" element at the "CMSSearch" page
    And the user clicks the "LocationActive" element at the "CMSSearch" page
    And the user clicks the "Search" element at the "CMSSearch" page
    Then the user validates the "LocationStatusResults" element is visible at the "CMSSearch" page "Location Status Result" "HardStopOnFailure"
    And the user clicks the "LocationStatus" element at the "CMSSearch" page
    And the user clicks the "LocationInActive" element at the "CMSSearch" page
    And the user clicks the "Search" element at the "CMSSearch" page
    Then the user validates the "LocationStatusResults" element is visible at the "CMSSearch" page "Location Status Result" "HardStopOnFailure"


  @CMS @CMS_SG @CMS @CMS_SG1 @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate Location ID Error Message
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    #validating Error Message
    And the user validates the "LocationSearch" element is visible at the "CMSSearch" page "LocationSearch" "HardStopOnFailure"
    When the user clicks the "LocationSearch" element at the "CMSSearch" page
    And the user validates the "LocationID" element is visible at the "CMSSearch" page "Location ID" "HardStopOnFailure"
    And the user enters "@#" into the "LocationID" textbox at the "CMSSearch" page
    And the user clicks the "Search" element at the "CMSSearch" page
    Then the user validates the "LocationIDErrorMessage" element is visible at the "CMSSearch" page "Location ID Error Message" "HardStopOnFailure"
    Then the user validates the "LocationIDErrorPopup" element is visible at the "CMSSearch" page "Location ID Error Popup" "HardStopOnFailure"

  @CMS @CMS_SG @CMS @CMS_SG1 @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate the Error Message for Site Number
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    #validating Site Number error message
    And the user validates the "SiteSearch" element is visible at the "CMSSearch" page "LocationSearch" "HardStopOnFailure"
    When the user clicks the "SiteSearch" element at the "CMSSearch" page
    And the user validates the "SiteNumber" element is visible at the "CMSSearch" page "SIte Number" "HardStopOnFailure"
    And the user enters "@#" into the "SiteNumber" textbox at the "CMSSearch" page
    And the user clicks the "Search" element at the "CMSSearch" page
    Then the user validates the "SiteNumberErrorMessage2Digit" element is visible at the "CMSSearch" page "Site Number Error Message" "HardStopOnFailure"
    #Then the user validates the "SiteNumberErrorPopup" element is visible at the "CMSSearch" page "Site Number Error Popup" "HardStopOnFailure"

  @CMS @CMS_SG @CMS @CMS_SG1 @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate the Search Results for Site Number
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    #validating Site Number error message
    And the user validates the "SiteSearch" element is visible at the "CMSSearch" page "LocationSearch" "HardStopOnFailure"
    When the user clicks the "SiteSearch" element at the "CMSSearch" page
    And the user validates the "SiteNumber" element is visible at the "CMSSearch" page "SIte Number" "HardStopOnFailure"
    And the user enters "12" into the "SiteNumber" textbox at the "CMSSearch" page
    And the user clicks the "Search" element at the "CMSSearch" page
    Then the user validates the "SiteNumberResultsSG" element is visible at the "CMSSearch" page "Site Number Error Message" "HardStopOnFailure"


  @CMS @CMS_SG @CMS @CMS_SG1 @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate the Search Results for Site Number
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    #validating Site Number Return to Search Results Button
    And the user validates the "SiteSearch" element is visible at the "CMSSearch" page "LocationSearch" "HardStopOnFailure"
    When the user clicks the "SiteSearch" element at the "CMSSearch" page
    And the user validates the "SiteNumber" element is visible at the "CMSSearch" page "SIte Number" "HardStopOnFailure"
    And the user enters "12" into the "SiteNumber" textbox at the "CMSSearch" page
    And the user clicks the "Search" element at the "CMSSearch" page
    And the user validates the "SiteNumberResultsSG" element is visible at the "CMSSearch" page "Site Number Results" "HardStopOnFailure"
    And the user clicks the "SiteNumberResultsSG" element at the "CMSSearch" page




  @CMS @CMS_SG @CMS @CMS_SG1 @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate Edit Button in Manage Site _Site Number
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    #validating Edit,Cancel, and Save button in Manage Site
    And the user validates the "SiteSearch" element is visible at the "CMSSearch" page "LocationSearch" "HardStopOnFailure"
    When the user clicks the "SiteSearch" element at the "CMSSearch" page
    And the user validates the "SiteNumber" element is visible at the "CMSSearch" page "SIte Number" "HardStopOnFailure"
    And the user enters "12" into the "SiteNumber" textbox at the "CMSSearch" page
    And the user clicks the "Search" element at the "CMSSearch" page
    And the user validates the "SiteNumberResultsSG" element is visible at the "CMSSearch" page "Site Number Results" "HardStopOnFailure"

  @CMS @CMS_SG @CMS @CMS_SG1 @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate Save Site Button in Manage Site _Site Number with numeric data
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    #validating Save Site button functionality
    And the user validates the "SiteSearch" element is visible at the "CMSSearch" page "LocationSearch" "HardStopOnFailure"
    When the user clicks the "SiteSearch" element at the "CMSSearch" page
    And the user validates the "SiteNumber" element is visible at the "CMSSearch" page "SIte Number" "HardStopOnFailure"
    And the user enters "12" into the "SiteNumber" textbox at the "CMSSearch" page
    And the user clicks the "Search" element at the "CMSSearch" page
    And the user validates the "SiteNumberResultsSG" element is visible at the "CMSSearch" page "Site Number Results" "HardStopOnFailure"
    And the user clicks the "SiteNumberResultsSG" element at the "CMSSearch" page
    #And the user validates the "SiteEditButton" element is visible at the "CMSSearch" page "Edit Button" "HardStopOnFailure"
    #And the user clicks the "SiteEditButton" element at the "CMSSearch" page
    #And the user validates the "SaveSiteButton" element is visible at the "CMSSearch" page "Cancel Button" "HardStopOnFailure"
    #And the user clicks the "SaveSiteButton" element at the "CMSSearch" page
    #validating OK confirmation button
    #And the user validates the "ConfirmationOKButton" element is visible at the "CMSSearch" page "OK Confirmation Button" "HardStopOnFailure"
    #And the user clicks the "ConfirmationOKButton" element at the "CMSSearch" page
    #Validate Summary Screen
    #And the user validates the "SummaryScreen" element is visible at the "CMSSearch" page "Summary Screen" "HardStopOnFailure"



  @CMS @CMS_SG @CMS @CMS_SG1 @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate Save Site Button in Manage Site _Site Number
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    #validating Site Description data not found popup
    And the user validates the "SiteSearch" element is visible at the "CMSSearch" page "LocationSearch" "HardStopOnFailure"
    When the user clicks the "SiteSearch" element at the "CMSSearch" page
    And the user validates the "SiteDescription" element is visible at the "CMSSearch" page "Site Description" "HardStopOnFailure"
    And the user enters "#$%" into the "SiteDescription" textbox at the "CMSSearch" page
    And the user clicks the "Search" element at the "CMSSearch" page
    #validate NoMatch popup
    Then the user validates the "NoMatchPopup" element is visible at the "CMSSearch" page "No Match Popup" "HardStopOnFailure"

  @CMS @CMS_SG @CMS @CMS_SG1 @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate Save Site Button in Manage Site _Site Number
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    And the user validates the "SiteSearch" element is visible at the "CMSSearch" page "LocationSearch" "HardStopOnFailure"
    When the user clicks the "SiteSearch" element at the "CMSSearch" page
    And the user validates the "SiteDescription" element is visible at the "CMSSearch" page "Site Description" "HardStopOnFailure"
    #validate Site Description error message
    And the user enters "asasasassssssssssssssssssssssssssssss12122345677777" into the "SiteDescription" textbox at the "CMSSearch" page
    #Then the user validates the "SiteDescriptionError" element is visible at the "CMSSearch" page "Site Description Error" "HardStopOnFailure"


  @CMS @CMS_SG @CMS @CMS_SG1 @Test @JIRA_ATM-64941 @Z_Auto @Browser @PCD_OCT102025 @PED_OCT102025 @Sanity @Regression @LOB_ATM @CSIIDi-174391
  Scenario: SG Validate Site Description Search Results using Wildcard
    Given the web application "CMS" is launched in a "NewWindow"
    When the user enters the user credential "CMSUser" into the "userName" textbox at the "CMSLoginPage" page
    And the user enters the user credential "CMSPassword" into the "password" textbox at the "CMSLoginPage" page
    And the user selects value "SGRegion" from the "region" combobox at the "CMSLoginPage" page
    Then the user validates the "submit" element is visible at the "CMSLoginPage" page "Submit" "HardStopOnFailure"
    And the user clicks the "submit" element at the "CMSLoginPage" page
    #validating Site Description data not found popup
    And the user validates the "SiteSearch" element is visible at the "CMSSearch" page "LocationSearch" "HardStopOnFailure"
    When the user clicks the "SiteSearch" element at the "CMSSearch" page
    And the user validates the "SiteDescription" element is visible at the "CMSSearch" page "Site Description" "HardStopOnFailure"
    #validate Wild Card Search Results
    And the user enters "Test" into the "SiteDescription" textbox at the "CMSSearch" page
    And the user clicks the "Search" element at the "CMSSearch" page
    Then the user validates the "SearchResultTable" element is visible at the "CMSSearch" page "Site Result Table" "HardStopOnFailure"

