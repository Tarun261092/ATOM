[Profile]
ID=WS
Version=9
[Telnet3270]
HostName=169.164.18.1
Security=Y
SecurityPackage=MS
SNIServerName=
CertSelection=AUTOSELECT
[Communication]
Link=telnet3270
[3270]
QueryReplyMode=Auto
HostCodePage=037-U
[Keyboard]
CuaKeyboard=1
Language=United-States
IBMDefaultKeyboard=N
DefaultKeyboard=C:\ProgramData\IBM\Personal Communications\PCOM Config.kmp
[LastExitView]
A=4 28 28 1056 681 7 24 36 400 0 PComm Session� 37
