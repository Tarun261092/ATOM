[Profile]
ID=WS
Version=9
[Telnet3270]
HostName=tsys.gcb-us-hosts.citicorp.com
Security=Y
SecurityPackage=MS
SNIServerName=
CertSelection=AUTOSELECT
[Communication]
Link=telnet3270
AutoConnect=Y
[3270]
QueryReplyMode=Auto
HostCodePage=037-U
[Keyboard]
CuaKeyboard=1
Language=United-States
IBMDefaultKeyboard=N
DefaultKeyboard=C:\ProgramData\IBM\Personal Communications\pcswinkb3.kmp
TypeAHead=Y
[LastExitView]
A=4 66 281 1056 281 7 24 36 400 0 PComm Session� 37
[Transfer]
DefaultDirectory=C:\Users\NP51177\Documents
[Window]
SessFlags=38C62
ViewFlags=CE00
RuleLinePos=0 0
