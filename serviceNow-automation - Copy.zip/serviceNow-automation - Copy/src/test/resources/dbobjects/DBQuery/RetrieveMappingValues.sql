SELECT rua_20byte_string_002 from Q_BCD_V_C_SAS_FR2.FRH_CCNM
WHERE (( RQO_TRAN_DATE_ALT = '#(dateTranDate)' ) AND
(REGEXP_SIMILAR(AQO_ACCT_NUM,'.{0,1}#(accountNumber)\s*', 'x') = 1) AND
(TNG_TRAN_TYPE ='OB' ))