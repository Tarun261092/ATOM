@echo OFF
setlocal enableDelayedExpansion
call :PathValidation
::echo %ProjectPath%
echo ***** Please export the feature file from ARD before running the object associator (press CTRL+C to quit) *****
SET runList[0]=1: Specific Feature File", "Feature File
SET runList[1]=2: All Feature Files", "All Feature Files
CALL :GetPathToFeatures
CALL :GetListOfFilesAsChoiceList %featureDirectory% .feature
::Start the User Input
CALL :ChoosingOptinOfFeature
::CALL :Validation %UserInputFeature% Continue ChoosingOptinOfFeature 1
EXIT /B %ERRORLEVEL%
::Functions
:PathValidation
::echo PathValidation
set CurrentPath=%CD%
set src=\src
set lib=\lib
::set Cut=src\
set splitsub=@
call set tempstring=!CurrentPath:%src%=%splitsub%!
for /f "tokens=1* delims=%splitsub%" %%A in ("%tempstring%") do set ProjectPath=%%A
)
call set tempstring=!ProjectPath:%lib%=%splitsub%!
for /f "tokens=1* delims=%splitsub%" %%A in ("%tempstring%") do set ProjectPath=%%A
)
cd %ProjectPath%
::pause

::set PartialPath=src\test\resources\features
::if %CurrentPath:~-27%==%PartialPath%  (call :CorrectedPath)
EXIT /B 0

:Validation
::ECHO Validation
:: Validator using OR condition
set /a Valid=0
for /L %%G IN (0,1,%4) DO (
                if [%1]==[%%G] (SET /a Valid=1)
)
CLS
if [%Valid%]==[1] (CALL :%2) ELSE (GOTO :%3)
::ECHO EXIT
::PAUSE
EXIT /B 0

:Continue
::echo Continue
if [%UserInputFeature%]==[0] (CALL :specificFeatureUserInput) ELSE (CALL :allFeature)
EXIT /B 0

:FinalSetup
::echo FinalSetup
SET commandBefore=mvn clean install -Dmaven.test.skip=true -Djavax.net.ssl.trustStore=c:/certs/cacerts.jks -Djavax.net.ssl.trustStorePassword=changeit
SET finalRunCommand=mvn test %cmdTestOption%
SET reportcoomand=mvn allure:serve -Djavax.net.ssl.trustStore=c:/certs/cacerts.jks -Djavax.net.ssl.trustStorePassword=changeit
CLS
CALL %commandBefore%
echo %finalRunCommand%
::PAUSE
CALL %finalRunCommand%
::PAUSE
echo Generating the Allure Report..
CALL %reportcoomand%
::PAUSE
EXIT /B %ERRORLEVEL%

:ChoosingOptinOfFeature
::ECHO ChoosingOptinOfFeature
setlocal
set UserInputFeature=0
endlocal
SET /a IDDoGetListOfFilesExclude=IDDoGetListOfFilesExclude-1
FOR /l %%n in (0,1,1) do (
                echo [%%n] - !runList[%%n]!
)
SET /p UserInputFeature=Run a specific feature file or all feature files?:
CLS
::PAUSE
CALL :Validation %UserInputFeature% Continue ChoosingOptinOfFeature 1
EXIT /B 0

:specificFeatureUserInput
::echo specificFeature
::echo %index%
FOR /l %%n in (0,1,%index%) do (
                echo [%%n] - !ListOfFeature[%%n]!
)
set /p selectedFeature="Select feature:"
CALL :Validation %selectedFeature% specificFeature specificFeatureUserInput %index%
EXIT /B 0
:specificFeature
::echo specificFeature
set cmdTestOption=-Dtest=ObjectAssociationRunner -Dfw.featureFileName=^"!ListOfFeature[%selectedFeature%]!"^
CALL :FinalSetup
EXIT /B 0
:allFeature
::ECHO allFeature
set cmdTestOption=-Dtest=ObjectAssociationRunner -Dfw.featureFileName=All
CALL :FinalSetup
EXIT /B 0

:GetListOfFilesAsChoiceList
::echo GetListOfFilesAsChoiceList
set workingDir=%ProjectPath%
set fileSeparator=\
set pathToDirectory=%1
set fileExtension=*%2
set pathToFiles=%workingDir%%fileSeparator%%pathToDirectory%
set /a index=0
::ECHO pathToFiles: %pathToFiles%
::echo fileExtension %fileExtension%
FOR /R %pathToFiles% %%G in (%fileExtension%) DO (
                set ListOfFeature[!index!]=%%~nG
                ::call echo %%ListOfFeature[!index!]%%
                set /a index+=1
)
SET /a index-=1
EXIT /B 0
:GetPathToFeatures
::echo GetPathToFeatures
set fileSeparator=\
set featureDirectory=src%fileSeparator%test%fileSeparator%resources%fileSeparator%features%fileSeparator%
EXIT /B 0

endlocal
