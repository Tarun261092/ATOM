@ECHO OFF
setlocal
set "USER_PROFILE=%USERPROFILE%"

set "TEMP_FILE=%TEMP%\temp_version.txt"

rem Execute mvn help:evaluate and store output in the temporary file
call mvn help:evaluate -Dexpression=library.engine.version -q -DforceStdout > "%TEMP_FILE%"

rem Wait for the file to be created (optional, if needed)
timeout /t 2 /nobreak > nul

rem Read the content of the temporary file to set the VERSION variable

set /p VERSION=<"%TEMP_FILE%"

echo %VERSION%

rem Delete the temp file
del "%TEMP_FILE%"
rem Run the JAR file
java -cp %USER_PROFILE%\.m2\repository\com\acn\ntc\library-zephyr\%VERSION%\library-zephyr-%VERSION%.jar automation.library.zephyr.ZephyrTest
endlocal