package automation.library.tdaas.core;

public class Constants {
    private static final String BASEPATH = System.getProperty("user.dir") + "/src/test/resources/";
    public static final String RUNTIMEPATH = BASEPATH + "config/" + "runtime.properties";

    public static final String REQUEST_ID = "requestId";
    public static final String JSON = ".json";
    public static final String TEST_ID = "test_id";
    public static final String FINAL_RESULT = "Final result: \n{}";
    public static final String TEST_NAME = "Test Name";
    public static final String ALM_TEST_ID = "ALM Test ID";
    public static final String CONTENT_TYPE = "Content-Type";
    public static final String ACCEPT = "Accept";
    public static final String JSON_CONTENT_TYPE = "application/json";
    public static final String UNEXPECTED_CODE = "Unexpected code: ";
    public static final String ERROR_RESPONSE = "-1";
    public static final String APPLICATION_JSON = "application/json";
    public static final String MESSAGE = "message";
    public static final String RESPONSE_PAYLOAD = "Response payload:\n {}";
    public static final String ERROR_PAYLOAD = "Error payload:\n {}";
    public static final String SALESFORCE = "salesforce";

    //REQUEST VERBS
    public static final String GET = "GET";
    public static final String POST = "POST";
    public static final String PUT = "PUT";
    public static final String DELETE = "DELETE";
    public static final String ERROR = "error";
}
