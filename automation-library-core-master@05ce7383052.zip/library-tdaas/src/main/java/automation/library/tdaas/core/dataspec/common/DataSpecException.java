package automation.library.tdaas.core.dataspec.common;

public class DataSpecException extends RuntimeException {

    public DataSpecException(String message) {
        super(message);
    }

    public DataSpecException(String message, Throwable cause) {
        super(message, cause);
    }

    public DataSpecException(RuntimeException e) {
        super(e);
    }
}
