package automation.library.tdaas.core.dataspec.common;

import automation.library.common.Property;
import automation.library.tdaas.core.Constants;
import automation.library.tdaas.core.dataspec.gsonmaps.DataSpec;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import okhttp3.OkHttpClient;
import org.apache.commons.configuration2.PropertiesConfiguration;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import static automation.library.tdaas.core.Constants.JSON;

public class CommonUtils {
    private CommonUtils() {
        //utility class
    }

    public static int getNumericEntryFromListOfOptions(List<String> listOfOptions, InputStream inputStream) {
        AtomicInteger i = new AtomicInteger();
        listOfOptions.forEach(option -> getLogger().info("({}) {}", i.getAndIncrement(), option));

        getLogger().info("Enter # from list above -->");
        Scanner scanner = new Scanner(inputStream);

        int numToReturn = scanner.nextInt();
        if(numToReturn < listOfOptions.size()) {
            getLogger().debug("--> user selected option ({})", numToReturn);
            return numToReturn;
        } else {
            getLogger().warn("Picked an invalid option. Default to highest option ({})", listOfOptions.size());
            return listOfOptions.size() - 1;
        }
    }

    public static void clearScreen() {
        try {
            new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
        } catch (InterruptedException | IOException e) {
            getLogger().error(e);
            Thread.currentThread().interrupt();
        }
    }

    public static String formatObjectToJson(Object jsonObject) {
        if (jsonObject instanceof Map) {
            return new GsonBuilder().setPrettyPrinting()
                                    .disableHtmlEscaping()
                                    .create()
                                    .toJson(jsonObject, Map.class);
        } else if (jsonObject instanceof DataSpec) {
            return new GsonBuilder().setPrettyPrinting()
                                    .disableHtmlEscaping()
                                    .create()
                                    .toJson(jsonObject, DataSpec.class);
        } else if (jsonObject instanceof List) {
            return new GsonBuilder().setPrettyPrinting()
                                    .disableHtmlEscaping()
                                    .create()
                                    .toJson(jsonObject, List.class);
        } else {
            return jsonObject.toString();
        }
    }

    public static String getTestName(Path dataSpecJsonPath) {
        return dataSpecJsonPath.getFileName().toString().split(JSON)[0];
    }

    private static Logger getLogger() {
        return LogManager.getLogger(CommonUtils.class);
    }

    public static OkHttpClient getTDaaSClient() {
        PropertiesConfiguration props = Property.getProperties(Constants.RUNTIMEPATH);
        int connectionTimeout = props.getString("TDaaSConnectionWait") == null ? 60 : props.getInt("TDaaSConnectionWait");
        int timeout = connectionTimeout >= 0 ? connectionTimeout : 60;

        return new OkHttpClient.Builder()
                .connectTimeout(timeout, TimeUnit.SECONDS)
                .readTimeout(timeout, TimeUnit.SECONDS)
                .writeTimeout(timeout, TimeUnit.SECONDS)
                .build();
    }

    public static Gson getCommonGsonObj() {
        return new GsonBuilder().serializeNulls().setLenient().setPrettyPrinting().create();
    }
}
