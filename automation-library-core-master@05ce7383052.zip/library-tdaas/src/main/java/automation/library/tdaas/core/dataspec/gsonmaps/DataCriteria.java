package automation.library.tdaas.core.dataspec.gsonmaps;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;
import java.util.Map;

public class DataCriteria {
    @SerializedName("customer")
    @Expose
    private Map<String, Map<String, String>> customer;

    @SerializedName("account")
    @Expose
    private List<Map<String, Map<String, String>>> account;

    @SerializedName("dbfields")
    @Expose
    private List<Map<String, String>> dbfields;

    public Map<String, Map<String, String>> getCustomer() {
        return customer;
    }

    public List<Map<String, Map<String, String>>> getAccount() {
        return account;
    }

    public void setCustomer(Map<String, Map<String, String>> customer) {
        this.customer = customer;
    }

    public void setAccount(List<Map<String, Map<String, String>>> account) {
        this.account = account;
    }

    public List<Map<String, String>> getDbfields() {
        return dbfields;
    }

    public void setDbfields(List<Map<String, String>> dbfields) {
        this.dbfields = dbfields;
    }
}
