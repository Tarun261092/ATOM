package automation.library.tdaas.core.dataspec.gsonmaps;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;
import java.util.Map;

public class DataAutomation {
    @SerializedName("sharedAttributes")
    @Expose
    private Map<String, String> sharedAttributes;
    @SerializedName("staticData")
    @Expose
    private Map<String, String> staticData;
    @SerializedName("dataCriteria")
    @Expose
    private DataCriteria dataCriteria;
    @SerializedName("dataOutput")
    @Expose
    private List<String> dataOutput;
    @SerializedName("api")
    @Expose
    private Map<String, Object> api;

    public Map<String, String> getSharedAttributes() {
        return sharedAttributes;
    }

    public Map<String, String> getStaticData() {
        return staticData;
    }

    public DataCriteria getDataCriteria() {
        return dataCriteria;
    }

    public Map<String, Object> getApi() {
        return api;
    }

    public void setApi(Map<String, Object> api) {
        this.api = api;
    }

    public void setStaticData(Map<String, String> staticData) {
        this.staticData = staticData;
    }
}
