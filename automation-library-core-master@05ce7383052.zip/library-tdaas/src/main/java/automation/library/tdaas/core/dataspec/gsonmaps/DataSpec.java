package automation.library.tdaas.core.dataspec.gsonmaps;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class DataSpec {
    @SerializedName("DataAutomation")
    @Expose
    private DataAutomation dataAutomation;

    public DataAutomation getDataAutomation() {
        return dataAutomation;
    }
}
