package automation.library.tdaas.core.dataspec.common;

import automation.library.tdaas.core.dataspec.gsonmaps.DataSpec;
import automation.library.tlm.TlmContext;
import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import org.apache.commons.configuration2.PropertiesConfiguration;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Path;
import java.util.*;

import static automation.library.tdaas.core.Constants.REQUEST_ID;

public class DataSpecIO {
    private final Logger log;

    public DataSpecIO() {
        log = LogManager.getLogger(DataSpecIO.class);
    }

    public DataSpecIO(Logger log) {
        this.log = log;
    }

    public DataSpec getDataSpec(Gson gsonObj, FileReader jsonReader, String envToUse, String releaseToUse) {
        try {
            DataSpec dataSpec = gsonObj.fromJson(jsonReader, DataSpec.class);
            dataSpec.getDataAutomation().getSharedAttributes().put("environment", envToUse);
            dataSpec.getDataAutomation().getSharedAttributes().put("release", releaseToUse);

            //TODO: clean up when moved to TLM context
            PropertiesConfiguration tlmProps = TlmContext.getInstance().getPropertiesFile();
            if (tlmProps != null) {
                dataSpec.getDataAutomation().getSharedAttributes().put("almDomain", tlmProps.getString("almDomain"));
                dataSpec.getDataAutomation().getSharedAttributes().put("almProject", tlmProps.getString("almProject"));
            } else {
                throw new DataSpecException("Unable to get ALM domain and project. Is ALM properties file available?");
            }

            return dataSpec;
        } catch (JsonSyntaxException | NullPointerException e) {
            throw new DataSpecException(e.getMessage());
        }
    }

    public DataSpec getDataSpec(Gson gsonObj, FileReader jsonReader) {
        return gsonObj.fromJson(jsonReader, DataSpec.class);
    }

    public void setRequestIdInJson(DataSpec dataSpec, String requestId) {
        Map<String, Object> apiSection = dataSpec.getDataAutomation().getApi();

        if (apiSection.get(REQUEST_ID) != null) {
            final List<String> temp = (List) apiSection.get(REQUEST_ID);
            final Deque<String> otherRequestIds = new LinkedList<>(temp);
            otherRequestIds.addFirst(requestId);
            apiSection.put(REQUEST_ID, otherRequestIds);
        } else {
            Deque<String> requestIds = new ArrayDeque<>();
            requestIds.addFirst(requestId);
            apiSection.put(REQUEST_ID, requestIds);
        }

        dataSpec.getDataAutomation().setApi(apiSection);
    }

    public void writeJsonToFile(Gson gsonObj, DataSpec dataSpec, Path dataSpecJsonPath) {
        try (FileWriter jsonWriter = new FileWriter(dataSpecJsonPath.toFile())) {
            gsonObj.toJson(dataSpec, DataSpec.class, jsonWriter);
        } catch (IOException e) {
            log.error(e);
        }
    }
}
