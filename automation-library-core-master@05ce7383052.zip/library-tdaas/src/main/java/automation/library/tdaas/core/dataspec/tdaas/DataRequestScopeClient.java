package automation.library.tdaas.core.dataspec.tdaas;

import automation.library.common.Property;
import automation.library.tdaas.core.dataspec.common.DataSpecException;
import automation.library.tdaas.core.dataspec.gsonmaps.DataSpec;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.RequestBody;
import org.apache.commons.configuration2.PropertiesConfiguration;
import org.apache.logging.log4j.Logger;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import static automation.library.tdaas.core.Constants.*;
import static automation.library.tdaas.core.dataspec.common.CommonUtils.formatObjectToJson;

public class DataRequestScopeClient extends TDaaSBaseClient {

    public DataRequestScopeClient(OkHttpClient client) {
        super(client);
        setScopeNotifyBaseURL();
    }

    public DataRequestScopeClient(OkHttpClient tdaasOKHttpClient, Logger log) {
        super(tdaasOKHttpClient, log);
        setScopeNotifyBaseURL();
    }

    private void setScopeNotifyBaseURL() {
        //remove once scopeNotify moves to same base URL
        PropertiesConfiguration props = Property.getProperties(RUNTIMEPATH);
        this.baseURL = props.getString("TDaaSURLScopeNotify");

        if (baseURL == null) {
            log.error("TDaaSURLScopeNotify not defined in the runtime.properties file");
        }
    }

    public Map<String, Object> submitJsonSpecToTDaaS(DataSpec dataSpec) {
        if (baseURL != null) {
            Map<String, Object> scopeNotifyResponse = (Map) submitDataSpec(dataSpec);

            if (!scopeNotifyResponse.isEmpty()) {
                if (scopeNotifyResponse.get("tdmReqId") != null) {
                    return getSuccessResponse(scopeNotifyResponse);
                } else if (scopeNotifyResponse.get(MESSAGE) != null) {
                    return getErrorResponse(scopeNotifyResponse);
                }
            }
        }

        throw new DataSpecException("Unable to submit data spec.");
    }

    private Object submitDataSpec(DataSpec dataSpec) {
    	 final String requestBody = formatObjectToJson(dataSpec);
         
         //Made change to handle  Credit line check for Data spec utility
         JsonObject jsonObject = (new JsonParser()).parse(requestBody).getAsJsonObject();
         
         if(  (jsonObject.getAsJsonObject("DataAutomation"))!=null &&
 				 ((jsonObject.getAsJsonObject("DataAutomation")).getAsJsonObject("sharedAttributes"))!=null &&
 				 (((jsonObject.getAsJsonObject("DataAutomation")).getAsJsonObject("sharedAttributes")).get("cardLine")) !=null			) {
         	
         	 log.info("Checking  requestBody json now for cardLine value ");        	 
         	 
         	 JsonElement ele= (jsonObject.getAsJsonObject("DataAutomation")).getAsJsonObject("sharedAttributes").get("cardLine");
 			 String cardLineStr= ele.getAsString();
 			 String validCardLines[]= {"IBS", "IBSX", "IBSC"};
 			 List<String> list = Arrays.asList(validCardLines);
 			 if(!list.contains(cardLineStr) ) {
 				 log.info("no valid cardline found so modifying  cardline");
 				 JsonObject obj= (jsonObject.getAsJsonObject("DataAutomation")).getAsJsonObject("sharedAttributes");
 				 obj.addProperty("cardLine", "IBS");
 			 }
         }
         
         String requestBodyUpd=jsonObject.toString();
         log.info("Submitting JSON data spec 1:\n {}", requestBodyUpd);

         return callTDaaSAPI("/scopeNotify",
                             "Submit data spec",
                             POST,
                             RequestBody.create(MediaType.parse(APPLICATION_JSON), requestBodyUpd));
    }

    private Map<String, Object> getSuccessResponse(Map<String, Object> scopeNotifyResponse) {
        Map<String, Object> requestAndMessage = new HashMap<>();
        log.info(RESPONSE_PAYLOAD, () -> formatObjectToJson(scopeNotifyResponse));
        requestAndMessage.put(REQUEST_ID, String.format("%.0f", scopeNotifyResponse.get("tdmReqId")));
        requestAndMessage.put(MESSAGE, scopeNotifyResponse.get(MESSAGE).toString());
        return requestAndMessage;
    }

    private Map<String, Object> getErrorResponse(Map<String, Object> scopeNotifyResponse) {
        Map<String, Object> requestAndMessage = new HashMap<>();
        Map<String, Object> errorMsgPayload = parseErrorMsg(scopeNotifyResponse);
        scopeNotifyResponse.put(MESSAGE, errorMsgPayload);

        log.error(ERROR_PAYLOAD, () -> formatObjectToJson(scopeNotifyResponse));

        requestAndMessage.put(REQUEST_ID, ERROR_RESPONSE);
        requestAndMessage.put(MESSAGE, errorMsgPayload);
        return requestAndMessage;
    }

    public String cancelTDaaSRequest(String requestId) {
        if (baseURL != null) {
            final String requestBody = formatObjectToJson(Collections.singletonMap("reqID", Integer.parseInt(requestId)));

            log.info("Canceling request ID {} using response payload body:\n {}", requestId, requestBody);

            Object response = callTDaaSAPI("/cancelReqNotify",
                                           "Cancel existing request",
                                           POST,
                                           RequestBody.create(MediaType.parse(APPLICATION_JSON), requestBody));

            if (response != null) {
                Map<String, Object> cancelReqResponse = (Map) response;

                if (!cancelReqResponse.isEmpty()) {
                    if (cancelReqResponse.get("status") != null) {
                        log.info(RESPONSE_PAYLOAD, () -> formatObjectToJson(cancelReqResponse));
                        return String.valueOf(cancelReqResponse.get("status"));
                    } else if (cancelReqResponse.get(MESSAGE) != null) {
                        log.error(ERROR_PAYLOAD, () -> formatObjectToJson(cancelReqResponse).replace("#/", "\n"));
                        return ERROR_RESPONSE;
                    }
                }
            }
        }

        return ERROR_RESPONSE;
    }

    public List<Map<String, Object>> cancelTDaaSTest(String testId) {
        if (baseURL != null) {
            final String requestBody = formatObjectToJson(Collections.singletonMap("testID", Integer.parseInt(testId)));

            log.info("Descoping test ID {} using response payload body:\n {}", testId, requestBody);

            Object response = callTDaaSAPI("/descopeNotify ",
                                           "Descope test",
                                           POST,
                                           RequestBody.create(MediaType.parse(APPLICATION_JSON), requestBody));

            if (response != null) {
                Map<String, Object> descopeTestResponse = (Map) response;

                if (!descopeTestResponse.isEmpty()) {
                    if (descopeTestResponse.get("statusList") != null) {
                        log.info(RESPONSE_PAYLOAD, () -> formatObjectToJson(descopeTestResponse));
                        return (List) descopeTestResponse.get("statusList");
                    } else if (descopeTestResponse.get(MESSAGE) != null) {
                        log.error(ERROR_PAYLOAD, () -> formatObjectToJson(descopeTestResponse).replace("#/", "\n"));
                        return Collections.emptyList();
                    }
                }
            }
        }

        return Collections.emptyList();
    }

    private Map<String, Object> parseErrorMsg(Map<String, Object> responsePayload) {
        Map<String, Object> errorMsgDetail = new HashMap<>();

        //parse string that contains the error object
        final String regExPattern = "(.+?),(\\{.+})";
        Matcher m = Pattern.compile(regExPattern).matcher(String.valueOf(responsePayload.get(MESSAGE)));
        if (m.matches()) {
            errorMsgDetail.put("Schema:", m.group(1));
            errorMsgDetail.put("Error Detail", new Gson().fromJson(m.group(2), Map.class));
        } else {
            errorMsgDetail.put("Error Detail", responsePayload.get(MESSAGE));
        }

        return errorMsgDetail;
    }


}
