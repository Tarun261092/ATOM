package automation.library.api.test.utils;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.core.config.Configurator;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

public class ReadJSONTest {
    private static String path;

     @BeforeAll
	 public static void beforeAllTestMethods() {
		 path = new File("src/test/resources/test.json").getAbsolutePath();
		 Configurator.setLevel("automation.library.api.test.utils", Level.OFF);
	 }

	@Test
    public void readFileAsStringTest() throws IOException {
		assertThat(ReadJSON.readFileAsString(path)).isNotNull();
	}

	@Test
    public void parseTest() {
		assertThat(ReadJSON.parse("test.json")).isNotNull();
		assertThat(ReadJSON.parse("test1.json")).isNull();
    }

    @Test
    public void parseLocationTest() {
    	assertThat(ReadJSON.parse("test resources", "test.json")).isNotNull();
    	assertThat(ReadJSON.parse("test resources", "test1.json")).isNull();
    }


    @Test
    public void getStringTest() {
    	JSONObject jsonObject = new JSONObject().put("JSON", "Hello, World!");
    	assertThat(ReadJSON.getString(jsonObject, "JSON")).isEqualTo("Hello, World!");
    	jsonObject = new JSONObject().put("JSON", Integer.parseInt("1"));
    	assertThat(ReadJSON.getString(jsonObject, "JSON")).isEmpty();
    }

    @Test
    public void getIntTest() {
    	JSONObject jsonObject = new JSONObject().put("JSON", "100");
    	assertThat(ReadJSON.getInt(jsonObject, "JSON")).isEqualTo(100);
    	jsonObject = new JSONObject().put("JSON", "abc");
    	assertThat(ReadJSON.getInt(jsonObject, "JSON")).isEqualTo(-1);
    }

    @Test
    public void getBooleanTest() {
    	JSONObject jsonObject = new JSONObject().put("JSON", true);
    	assertThat(ReadJSON.getBoolean(jsonObject, "JSON")).isTrue();
    	jsonObject = new JSONObject().put("JSON", "true1");
    	assertThat(ReadJSON.getBoolean(jsonObject, "JSON")).isFalse();
    }

    @Test
    public void getObjectIndexTest() {
    	JSONObject jsonObject = new JSONObject();
    	jsonObject.put("firstName", "jsonObjecthn");
    	jsonObject.put("lastName", "Doe");

    	JSONArray jsonArray = new JSONArray();
    	jsonArray.put(jsonObject);
    	assertThat(ReadJSON.getObject(jsonArray,0)).isNotNull();
    	assertThat(ReadJSON.getObject(jsonArray,1)).isNull();
    }

    @Test
    public void getObjectTest() {
    	JSONObject jsonObject = new JSONObject();
    	jsonObject.put("Test", "NewUser");
    	JSONObject jsonObject1 = new JSONObject();
    	jsonObject1.put("firstName", "John");
    	jsonObject1.put("lastName", "Doe");
    	jsonObject.put("User", jsonObject1);
    	assertThat(ReadJSON.getObject(jsonObject,"User")).isNotNull();
    	assertThat(ReadJSON.getObject(jsonObject,"Test")).isNull();
    }

    @Test
    public void getStringFromArrayTest() {
    	JSONObject jsonObject = new JSONObject();
    	JSONArray jsonArrayUsers = new JSONArray();

    	JSONObject jsonObject1 = new JSONObject();
    	jsonObject1.put("firstName", "John");
    	jsonObject1.put("lastName", "Doe");
    	jsonObject1.put("ID", "1");

    	jsonArrayUsers.put(jsonObject1);
    	jsonObject.put("Users", jsonArrayUsers);

    	assertThat(ReadJSON.getStringFromArray(jsonObject,"Users",0)).isNotNull();
    	assertThat(ReadJSON.getStringFromArray(jsonObject,"firstName",0)).isNotNull();
    }

    @Test
    public void getStringInNodeTest() {
    	JSONObject jsonObject = new JSONObject();
    	jsonObject.put("Test", "NewUser");
    	JSONObject jsonObject1 = new JSONObject();
    	jsonObject1.put("firstName", "John");
    	jsonObject1.put("lastName", "Doe");
    	jsonObject.put("User", jsonObject1);
    	assertThat(ReadJSON.getStringInNode(jsonObject,"User","Test")).isNull();
    	assertThat(ReadJSON.getStringInNode(jsonObject,"User","firstName")).isNotNull();
    }

    @Test
    public void getArrayTest() {
    	JSONObject jsonObject = new JSONObject();
    	jsonObject.put("firstName", "jsonObjecthn");
    	List<String> usersList = new ArrayList<String>();
    	usersList.add("TestUser1");
    	usersList.add("TestUser2");
    	usersList.add("TestUser3");
    	JSONArray jsonArray = new JSONArray();
    	for(int i=0;i<usersList.size();i++) {
    		jsonArray.put(usersList.get(i));
    	}
    	jsonObject.put("Users", jsonArray);
    	assertThat(ReadJSON.getArray(jsonObject,"Users")).isNotNull();
    	assertThat(ReadJSON.getArray(jsonObject,"firstName")).isNull();
    }
}