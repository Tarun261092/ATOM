package automation.library.api.test.utils;

import static org.assertj.core.api.Assertions.assertThat;
import org.junit.jupiter.api.Test;

public class GetDateTimeTest {

	@Test
	public void addDaysToDate_yyyymmddTest() {
	    assertThat(GetDateTime.addDaysToDate_yyyymmdd(10)).isNotNull();
	}
		
}
