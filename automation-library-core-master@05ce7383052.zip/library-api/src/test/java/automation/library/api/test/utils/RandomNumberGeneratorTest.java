package automation.library.api.test.utils;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

public class RandomNumberGeneratorTest {

	@Test
	public void randomNumberTest() {
		assertThat(RandomNumberGenerator.randomNumber()).isGreaterThan(0);
	}
}
