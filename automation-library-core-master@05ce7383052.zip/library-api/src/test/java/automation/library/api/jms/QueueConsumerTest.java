package automation.library.api.jms;

import static org.assertj.core.api.Assertions.assertThat;
import org.junit.jupiter.api.Test;

public class QueueConsumerTest {
	
	private static String hostname = "hostname"; 
	private static String channel = "channel"; 
	private static int port = 8032; 
	private static String userID = "userID";
	
	@Test
    public void QueueConsumerTest1() {
		QueueConsumer queueConsumer = new QueueConsumer(hostname, channel, port, userID);
		assertThat(queueConsumer).isNotNull();	
    }
	
	@Test
    public void QueueConsumerTest2() {
		QueueConsumer queueConsumer = new QueueConsumer(hostname, channel, port);
		assertThat(queueConsumer).isNotNull();	
    }

}
