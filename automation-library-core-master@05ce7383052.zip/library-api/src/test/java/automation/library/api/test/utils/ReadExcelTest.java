package automation.library.api.test.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.core.config.Configurator;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class ReadExcelTest {
   
	private static String path;
	private static String sheetName;
	private static String columnName;
	private static String columnHeader;
	private static String columnHeader2;
	private static String columnHeader3;
	private static String columnValue;
	private static String columnValue2;
	private static String columnValue3;
	private static String columnNumValue;
	 
	@BeforeAll
	public static void beforeAllTestMethods() {
		 path = new File("src/test/resources/test.xlsx").getAbsolutePath();
		 sheetName = "Sheet1";
		 columnName = "Heading 1";
		 columnHeader = "Heading 1";
		 columnHeader2 = "Heading 2";
		 columnHeader3 = "Heading 3";
		 columnValue = "DataA3";
		 columnValue2 = "DataB3";
		 columnValue3 = "DataC3";
		 columnNumValue = "100";
		 Configurator.setLevel("automation.library.api.test.utils", Level.OFF);
	}
   
	@Test
	public void getCellValueTest() {
		try {
				assertThat(ReadExcel.getCellValue(2, path, sheetName, columnName)).isNotNull();
			} catch (Exception e) {
			}
	}
	
	@Test
	public void getCellValueTest1() {
		try {
				assertThat(ReadExcel.getCellValue(3, path, sheetName, columnName)).isNotNull();
			} catch (Exception e) {
			}
	}
	  
	@Test
    public void getTotIterationsTest() {
    	try {
				assertThat(ReadExcel.getTotIterations(path, sheetName)).isGreaterThan(0);
			} catch (IOException e) {
			}
    }

    @Test
    public void openInputStreamTest() {
    	try {
    			assertThat(ReadExcel.openInputStream(path)).isNotNull();
			} catch (IOException e) {
			}
    }

    @Test
    public void openExcelSheet()  {
    	try {
    			FileInputStream fileInputStream = new FileInputStream(new File(path));
    			assertThat(ReadExcel.openExcelSheet(fileInputStream, sheetName)).isNotNull();
			} catch (IOException e) {
			}
    }

    @Test
    public void closeExcelSheet()  {
    	FileInputStream strFilePath;
		try {
				strFilePath = new FileInputStream(new File(path));
				ReadExcel.closeExcelSheet(strFilePath);
				assertThat(strFilePath).isNotNull();
			} catch(IOException e) {
			}
    	
    }

   @Test
   public void getPathToExcel() {
	   	assertThat(ReadExcel.getPathToExcel("test.xlsx")).isNotNull();
    }
   
   @Test
   public void getPathToExcelTest() {
	   	assertThat(ReadExcel.getPathToExcel("test1.xlsx")).isNull();
    }
   
   @Test
   public void getRowNumberTest() {
	   	try {
			assertThat(ReadExcel.getRowNumber(columnHeader,columnValue,path,sheetName,columnName)).isGreaterThan(0);
			assertThat(ReadExcel.getRowNumber(columnHeader,columnNumValue,path,sheetName,columnName)).isGreaterThan(0);
			assertThat(ReadExcel.getRowNumber(columnHeader, columnValue, columnHeader2, columnValue2, columnHeader3, columnValue3, path, sheetName)).isGreaterThan(0);
			assertThat(ReadExcel.getRowNumber(columnHeader, columnNumValue, columnHeader2, columnValue2, columnHeader3, columnValue3, path, sheetName)).isLessThan(0);
		} catch (IOException e) {
		}
    }

}