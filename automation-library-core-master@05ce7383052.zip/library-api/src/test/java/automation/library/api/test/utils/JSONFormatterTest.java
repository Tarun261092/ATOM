package automation.library.api.test.utils;

import static org.assertj.core.api.Assertions.assertThat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.core.config.Configurator;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class JSONFormatterTest {

	String jsonString = "{ \r\n" + 
			"  \"Retail\": [\r\n" + 
			"    \"U1-UAT2\",\r\n" + 
			"    \"U2-UAT1\",\r\n" + 
			"    \"I1-SIT2\"\r\n" + 
			"  ],\r\n" + 
			"  \"Cards\": [\r\n" + 
			"    \"B\",\r\n" + 
			"    \"C\",\r\n" + 
			"    \"D\",\r\n" + 
			"    \"F\",\r\n" + 
			"    \"G\"\r\n" + 
			"  ]\r\n" + 
			"}" ;
	
	String jsonString1 = "{ \r\n" + 
			"  \"Retail\": [\r\n" + 
			"    \"U1-UAT2\",\r\n" + 
			"    \"U2-UAT1\",\r\n" + 
			"    \"I1-SIT2\"\r\n" + 
			"  ],\r\n" + 
			"  \"Cards\": [\r\n" + 
			"    \"B\",\r\n" + 
			"    \"C\",\r\n" + 
			"    \"D\",\r\n" + 
			"    \"F\",\r\n" + 
			"    \"G\"\r\n" + 
			"  ]\r\n" + 
			"" ;

	@BeforeAll
	static void beforeAll() {
		Configurator.setLevel("automation.library.api.test.utils", Level.OFF);
	}

	@Test
    public void formatJSONTest() {
		assertThat(JSONFormatter.formatJSON(jsonString)).isNotNull();
    }
	
	@Test
    public void formatJSONMapTest() {
		Map<String, String> elements = new HashMap<String, String>();
	    elements.put("Key1", "Value1");
	    elements.put("Key2", "Value2");
	    elements.put("Key3", "Value3");
		
		assertThat(JSONFormatter.formatJSON(elements)).isNotNull();
    }
	
	@Test
    public void formatJSONArrayTest() {
		JSONObject jsonObj = new JSONObject();
		jsonObj.put("firstName", "John");
		jsonObj.put("lastName", "Doe");

		JSONArray jsonArray = new JSONArray();
		jsonArray.put(jsonObj);
		
		assertThat(JSONFormatter.formatJSON(jsonArray)).isNotNull();
    }
	
	@Test
    public void formatJSONListTest() {
		ArrayList<String> list = new ArrayList<String>();
		list.add("John");
		list.add("Doe");
		
		assertThat(JSONFormatter.formatJSON(list)).isNotNull();
    }
	
	@Test
    public void formatJSONErrorTest() {
		assertThat(JSONFormatter.formatJSON("error")).isNotNull();
    }
	
	@Test
    public void formatJsonExceptionTest() {	
		assertThat(JSONFormatter.formatJSON(jsonString1)).isNotNull();
    }
	
}