@ignore
Feature: Call an api with tag selector

  @callAPI
  Scenario:
    * string pathToFeatureWithTag = __arg.fullPathToFeature + __arg.tagName
    * print pathToFeatureWithTag
    * call read(pathToFeatureWithTag) __arg