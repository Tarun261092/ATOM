@ignore
Feature: Store attribute within parent from a response

  @StoreAttributeWithParent
  Scenario:
    * xml responseBody = __arg.responseAsXml
    * def argumentsToUse = {parentAttributeName: #(__arg.parentAttributeName), attributeName: #(__arg.attributeName), response: #(responseBody) }
    * call read('storeAttributeWithParent.feature') argumentsToUse
