@ignore
Feature: Connect to MQ using queue

  @connectMQ
  Scenario: Sync
    * def QueueConsumer = Java.type('automation.library.api.jms.QueueConsumer')
    * def queue = new QueueConsumer(__arg.hostname,__arg.channel,__arg.port,__arg.userID)
    * string pathToPayload = __arg.pathToPayload
    * print pathToPayload
    * string msg = read(pathToPayload)
    * queue.init(__arg.queueManagerName)
    * queue.putMessage(__arg.queueName,msg,__arg.respQueue)
    * def response = queue.getMessage(__arg.respQueue)
    * print response


