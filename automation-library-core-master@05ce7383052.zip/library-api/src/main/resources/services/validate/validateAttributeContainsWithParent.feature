@ignore
Feature: Validate if response contains attribute or not

  Background:
    * def isArray = read('classpath:utils/isArray.js')

  @ValidateAttributeEqualsWithParent
  Scenario:
    * json responseAsJson = __arg.response
    * json compareJSON = '{' + __arg.attributeName + ' : #regex .*' + __arg.attributeVal + '.*}'
    * def responseToCompare = karate.jsonPath(responseAsJson, "$.."+__arg.parentAttributeName)
    * def responseToCompare = isArray(responseToCompare[0]) ? responseToCompare[0] : responseToCompare
    * match each responseToCompare == '#(^compareJSON)'
