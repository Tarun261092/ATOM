@ignore
Feature: Validate against a defined schema

  @ValidateSchema
  Scenario:
    * json responseAsJson = __arg.response
    And def schemaRef = read(pathToSchema)
    Then match responseAsJson == schemaRef

