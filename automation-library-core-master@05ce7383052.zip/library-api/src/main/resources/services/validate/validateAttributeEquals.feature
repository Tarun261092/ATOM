@ignore
Feature: Validate if response contains attribute or not

  @ValidateAttributeEquals
  Scenario:
    * json responseAsJson = __arg.response

    * def getAttributeType = read('classpath:utils/getAttributeType.js')
    * def attributeToCompare = getAttributeType(__arg.attributeVal)

    * json compareJSON = '{' + __arg.attributeName + ' : ' + attributeToCompare + '}'
    * match responseAsJson contains compareJSON

