@ignore
Feature: Validate response does not contain the attribute

  @ValidateAttributeNotEquals
  Scenario:
    * json responseAsJson = __arg.response
    * json compareJSON = '{' + __arg.attributeName + ' : ' + __arg.attributeVal + '}'
    * match responseAsJson !contains compareJSON

