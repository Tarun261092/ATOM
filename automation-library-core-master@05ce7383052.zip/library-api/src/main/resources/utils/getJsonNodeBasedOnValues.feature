@ignore
Feature: Get Response Node with all values based on some known values
	         
	Scenario: Get the index of one response when we know some values
		# The input of this feature is:
			# nodeToFind = {} (json with the key and values to filter to, keys to ignore can be marked as #ignore)
			# Example nodeToFind : * def nodeToFind = { zoneCd: 'DOMESTIC', actionCd: 'UNBLOCKED', dataBlockTypeCd: 'OPTIONAL',  blockAmt: '0.0'}	
			# listFromJson = [{}] the actual list of nodes to be evaluated
					 
		# 1. Define the variable that will keep the index
		* def foundAt = []
		
		# 2. Function that will do the loop on the list
		* def fun = function(x, i){ if (karate.match(x, nodeToFind).pass) foundAt.add(i) }
		
		# 3. Trigger the function
		* eval karate.forEach(listFromJson, fun)
		
		# 4. Check that it was found
		* match foundAt != []
		* def index = foundAt[0]
