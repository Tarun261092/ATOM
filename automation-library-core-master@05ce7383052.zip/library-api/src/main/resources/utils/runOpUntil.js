function runOpUntil(operation, data, pathToCheck, expectedValue, iterations){
	var status = '';
	karate.log('START RUNNING Operation: '+operation+' for '+iterations+' times');		  				
	
	for (let i=1; i <= iterations; i++)
	{ 		
		karate.log('****Iteration: '+i);		  				
		var result = karate.call(operation, data);
		var resultVal =  karate.jsonPath(result,pathToCheck); 	
		karate.log('Values to compare: actual: '+resultVal+' / expected: '+expectedValue);
		if (resultVal === expectedValue)
		{
			karate.log('CONDITION SATISFIED');
			return result;
		} else if(i === iterations)
		{
			karate.log('CONDITION NEVER SATISFIED - CURRENT RESPONSE: '+resultVal+' / EXPECTED: ' + expectedValue);
			return result;
		} else
		{
			karate.log('CONDITION NOT SATISFIED - CURRENT RESPONSE: '+resultVal+' / EXPECTED: ' + expectedValue);
		}
		java.lang.Thread.sleep(10000);	   	 
	}
}