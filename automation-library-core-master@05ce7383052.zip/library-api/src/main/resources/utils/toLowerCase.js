function toLowerCase(string){
	var valInUpperCase = "";
	valInUpperCase = string.toLowerCase()
	return valInUpperCase;
}