function getJsonPathQuery(comparisonOpString) {
    switch(comparisonOpString) {
        case 'Equal To':
            return '==';

        case 'Not Equal To':
            return '!=';

        case 'Greater Than':
            return '>';

        case 'Greater Than or Equal To':
            return '>=';

        case 'Less Than':
            return '<';

        case 'Less Than or Equal To':
            return '<=';

        default:
            karate.log('Unsupported comparison operator: ' + comparisonOpString + '. Defaulting to equals.');
            return '==';
    }

}