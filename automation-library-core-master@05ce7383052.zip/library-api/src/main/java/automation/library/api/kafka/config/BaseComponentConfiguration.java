package automation.library.api.kafka.config;

import automation.library.common.Property;
import org.apache.commons.configuration2.PropertiesConfiguration;

import java.nio.file.Paths;

import static automation.library.api.Constants.ENVIRONMENT_PATH;

public class BaseComponentConfiguration {
    PropertiesConfiguration envProps;

    public BaseComponentConfiguration() {
        final String pathToProps = Paths.get(String.format("%s/%s.properties", ENVIRONMENT_PATH,
                                                           Property.getVariable("cukes.env")))
                                        .toAbsolutePath()
                                        .toString();
        this.envProps = Property.getProperties(pathToProps);

        if(envProps == null) {
            throw new IllegalArgumentException("Environment properties file is not defined. " +
                                               "Please check path and set -Dcukes.env VM argument. Path: " + pathToProps);
        }
    }

    protected String getStringEnvProp(String propName) {
        final String propValue = envProps.getString(propName);

        if(propValue != null) {
            return propValue;
        } else {
            throw new IllegalArgumentException(propName + " is not found in the environment property file for: " + Property.getVariable("cukes.env"));
        }
    }

    protected int getIntEnvProp(String propName) {
        return envProps.getInt(propName);
    }

    protected String getStringEnvPropAllowNull(String propName) {
        return envProps.getString(propName);
    }

}
