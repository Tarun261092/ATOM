package automation.library.api.kafka;

import automation.library.api.kafka.config.KafkaComponentConfiguration;
import automation.library.api.kafka.config.MockComponentConfiguration;
import automation.library.common.Property;
import com.google.gson.Gson;
import com.google.gson.JsonIOException;
import com.google.gson.JsonSyntaxException;
import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.NotifyBuilder;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.mock.MockEndpoint;
import org.apache.camel.impl.DefaultCamelContext;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import static automation.library.api.Constants.KAFKA_PROPS_FILE;
import static org.apache.camel.builder.Builder.body;
import static org.apache.camel.builder.Builder.header;

public class KafkaHandler {
    CamelContext camelContext;
    Map<String, MockEndpoint> mockKafkaConsumers;
    private final Logger log = LogManager.getLogger(KafkaHandler.class);
    private static final String EVENTHUB_KAFKA = "eventhub-kafka";
    private static final String TEST_TYPE = "test-type";
    private static final String AUTOMATION = "automation";

    public KafkaHandler(String scenarioName) {
        camelContext = new DefaultCamelContext();
        camelContext.setTracing(Boolean.parseBoolean(Property.getProperty(KAFKA_PROPS_FILE, "debug.tracing")));
        camelContext.addComponent(EVENTHUB_KAFKA,
                                  new KafkaComponentConfiguration(camelContext).configureKafkaComponent(scenarioName));
        mockKafkaConsumers = new HashMap<>();
    }

    public boolean subscribeToTopic(String topicName, String attributeVal, String attributeVal2) throws Exception {
        MockEndpoint mockKafkaConsumer = new MockComponentConfiguration().getMockEndpoint(camelContext,
                                                                                          getMockEndPointURI(topicName));

        // Add route for this test, so it will consume the messages
        //  from the kafka topic and put them into our mock
        camelContext.addRoutes(new AutoEngRouteBuilder(getSubscribeEndpointURI(topicName),
                                                       getRouteId(topicName),
                                                       mockKafkaConsumer,
                                                       attributeVal,
                                                       attributeVal2));

        if (!camelContext.isStarted()) {
            camelContext.start();
        }

        mockKafkaConsumers.put(getMockEndPointURI(topicName), mockKafkaConsumer);

        return true;
    }

    public void unsubscribe(String topicName) throws Exception {
        camelContext.getRouteController().stopRoute(getRouteId(topicName));
    }

    public void shutDown() {
        camelContext.stop();
    }

    public boolean sendMessageToTopic(String topicName, Map<String, Object> msgHeaders, Object msgPayload) {
        try (ProducerTemplate msgSource = camelContext.createProducerTemplate()) {

            camelContext.addRoutes(new RouteBuilder() {
                @Override
                public void configure() throws Exception {
                    from("direct:start")
                            .routeId(getRouteId(topicName) + "-send")
                            .log("Sending message to kafka topic:  ${body}")
                            .log("  with headers: ${headers}")
                            .to(getSubscribeEndpointURI(topicName));
                }
            });

            msgHeaders.put(TEST_TYPE, AUTOMATION);
            msgSource.sendBodyAndHeaders("direct:start", msgPayload, msgHeaders);
        } catch (Exception e) {
            log.error("Error sending message: {}", e::getMessage);
            return false;
        }

        return true;
    }

    private String getSubscribeEndpointURI(String topicName) {
        return String.format("%s:%s", EVENTHUB_KAFKA, topicName);
    }

    private String getMockEndPointURI(String topicName) {
        return String.format("mock:kafka-consumer-%s", topicName);
    }

    private String getRouteId(String topicName) {
        return "testing-" + topicName;
    }

    public List<Object> saveListOfMessagesFromEndPoint(String topicName) {
        return saveListOfMessagesFromEndPoint(topicName, null, null);
    }

    public List<Object> saveListOfMessagesFromEndPoint(String topicName, String attributeVal, String attributeVal2) {
        MockEndpoint mockEndpointWithMessages = mockKafkaConsumers.get(getMockEndPointURI(topicName));
        List<Object> listOfPostedMsgs = new ArrayList<>();

        if (mockEndpointWithMessages != null) {
            NotifyBuilder notify = getNotifyObject(topicName, attributeVal, attributeVal2);

            if(notify.matches(getWaitTimeout(), TimeUnit.SECONDS)) {
                log.debug("Found match in subscribe endpoint");
            }

            for (Exchange exchange : mockEndpointWithMessages.getExchanges()) {
                listOfPostedMsgs.add(parseMessageBody(exchange.getIn().getBody()));
            }
        }

        return listOfPostedMsgs;
    }

    private NotifyBuilder getNotifyObject(String topicName, String attributeVal, String attributeVal2) {
        if(attributeVal == null && attributeVal2 == null) {
            return new NotifyBuilder(camelContext).from(getSubscribeEndpointURI(topicName))
                                                  .whenDone(1)
                                                  .create();
        } else if(attributeVal2 == null) {
            return new NotifyBuilder(camelContext).from(getSubscribeEndpointURI(topicName))
                                                  .filter(body().contains(attributeVal))
                                                  .whenDone(1)
                                                  .create();
        } else {
            return new NotifyBuilder(camelContext).from(getSubscribeEndpointURI(topicName))
                                                  .filter(body().contains(attributeVal))
                                                  .filter(body().contains(attributeVal2))
                                                  .whenDone(1)
                                                  .create();
        }
    }

    private Object parseMessageBody(Object body) {
        try {
            return new Gson().fromJson(String.valueOf(body), Object.class);
        } catch (JsonSyntaxException | JsonIOException e) {
            log.warn("Unable to parse as JSON. Returning object as-is");
            return body;
        }
    }

    private int getWaitTimeout() {
        String timeout = Property.getProperty(KAFKA_PROPS_FILE, "mock.waitTimeout");
        return timeout != null ? Integer.parseInt(timeout) : 15;
    }

}
