package automation.library.api.kafka.config;

import automation.library.common.Property;
import org.apache.camel.CamelContext;
import org.apache.camel.component.kafka.KafkaComponent;
import org.apache.camel.component.kafka.KafkaConfiguration;
import org.apache.commons.configuration2.PropertiesConfiguration;

import java.nio.file.Paths;

import static automation.library.api.Constants.KAFKA_PROPS_FILE;
import static automation.library.api.Constants.KAFKA_PROPS_PATH;


public class KafkaComponentConfiguration extends BaseComponentConfiguration {
    CamelContext camelContext;

    public KafkaComponentConfiguration(CamelContext camelContext) {
        super();
        this.camelContext = camelContext;
    }

    public KafkaComponent configureKafkaComponent(String scenarioName) {
        KafkaComponent component = new KafkaComponent();
        component.setCamelContext(camelContext);
        component.setConfiguration(configuration(scenarioName));
        return component;
    }

    public KafkaConfiguration configuration(String scenarioName) {
        KafkaConfiguration configuration = new KafkaConfiguration();

        final String groupId = String.format("%s-%s",
                                             getStringEnvProp("kafka.consumer.group"),
                                             scenarioName);
        configuration.setGroupId(groupId);
        configuration.setBrokers(getStringEnvProp("kafka.brokers"));
        configuration.setSecurityProtocol(getStringEnvProp("kafka.security.protocol"));

        if (getStringEnvProp("kafka.security.protocol").equalsIgnoreCase("ssl")) {
            setSSLProps(configuration);
        } else {
            setKerberosProps(configuration);
        }

        setOptionalProps(configuration);

        return configuration;
    }

    private void setKerberosProps(KafkaConfiguration configuration) {
        configuration.setSaslKerberosServiceName(getStringEnvProp("kafka.sasl.kerberos.service.name"));
        configuration.setSaslJaasConfig(
                "com.sun.security.auth.module.Krb5LoginModule required useKeyTab=true doNotPrompt=true storeKey=true " +
                "keyTab=\"" + getKeyTabFile(getStringEnvProp("kafka.keytab")) +
                "\" principal=\"" + getStringEnvProp("kafka.principal") +
                "\" debug=\"" + getStringEnvProp("kafka.debug") + "\";");
    }

    private void setSSLProps(KafkaConfiguration configuration) {
        configuration.setSslKeystoreLocation(getSSLKeystoreFile(getStringEnvProp("kafka.keystore")));
        configuration.setSslKeystorePassword(getStringEnvProp("kafka.keystore.password"));
        configuration.setSslKeyPassword(getStringEnvProp("kafka.key.password"));
        configuration.setSslTruststoreLocation(getStringEnvProp("kafka.truststore"));
        configuration.setSslTruststorePassword(getStringEnvProp("kafka.truststore.password"));
    }

    private String getKeyTabFile(String fileName) {
        return String.format("file:%s/certs/%s",
                             Paths.get(KAFKA_PROPS_PATH).toAbsolutePath().toString().replace("\\", "/"),
                             fileName);
    }

    private String getSSLKeystoreFile(String fileName) {
        return String.format("%s/certs/%s",
                             Paths.get(KAFKA_PROPS_PATH).toAbsolutePath().toString().replace("\\", "/"),
                             fileName);
    }

    private void setOptionalProps(KafkaConfiguration configuration) {
        PropertiesConfiguration kafkaProps = Property.getProperties(KAFKA_PROPS_FILE);

        if(kafkaProps != null) {
            if(kafkaProps.getString("consumer.maxPollRecords") != null) {
                configuration.setMaxPollRecords(kafkaProps.getInt("consumer.maxPollRecords"));
            }

            if(kafkaProps.getString("consumer.autoOffsetReset") != null) {
                configuration.setAutoOffsetReset(kafkaProps.getString("consumer.autoOffsetReset"));
            }

            if(kafkaProps.getString("consumer.seekTo") != null) {
                configuration.setSeekTo(kafkaProps.getString("consumer.seekTo"));
            }

            if(kafkaProps.getString("consumer.consumersCount") != null) {
                configuration.setConsumersCount(kafkaProps.getInt("consumer.consumersCount"));
            }
        }

    }

}