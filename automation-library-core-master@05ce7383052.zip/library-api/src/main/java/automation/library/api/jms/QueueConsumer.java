package automation.library.api.jms;

import com.ibm.mq.*;
import com.ibm.msg.client.wmq.compat.base.internal.MQC;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;

public class QueueConsumer {

    private final Logger logger = LogManager.getLogger(QueueConsumer.class);
    private MQQueueManager queueManager = null;
    private int openOptions = MQC.MQOO_INPUT_AS_Q_DEF | MQC.MQOO_OUTPUT | MQC.MQOO_INQUIRE;

    public QueueConsumer(String hostname, String channel, int port, String userID) {
        MQEnvironment.hostname = hostname;
        MQEnvironment.channel = channel;
        MQEnvironment.port = port;
        MQEnvironment.userID = userID;

    }

    public QueueConsumer(String hostname, String channel, int port) {
        MQEnvironment.hostname = hostname;
        MQEnvironment.channel = channel;
        MQEnvironment.port = port;
    }

    //Establish connection to QueueManager
    public boolean init(String queueManagerName) throws MQException {
        queueManager = new MQQueueManager(queueManagerName);
        return queueManager.isConnected();
    }

    //Establishes access to a MQ queue on the queue manager & put message to a queue
    public void putMessage(String queueName, String message, String respQueue) throws IOException, MQException {
        MQQueue putQueue = queueManager.accessQueue(queueName, openOptions);
        MQMessage mqMsg = new MQMessage();
        mqMsg.writeString(message);

        MQPutMessageOptions putmqgm = new MQPutMessageOptions();
        mqMsg.replyToQueueName = respQueue;
        putQueue.put(mqMsg, putmqgm);

        logger.debug("PUT QUEUE CONNECTION STATUS: {}", putQueue::isOpen);
    }


    //Read message from a queue
    public String getMessage(String queueName) throws MQException, IOException {
        MQMessage mqMsg = new MQMessage();
        MQGetMessageOptions mqgm = new MQGetMessageOptions();
        MQQueue getQueue = queueManager.accessQueue(queueName, openOptions);

        logger.debug("GET QUEUE CONNECTION STATUS: {}", getQueue::isOpen);
        logger.debug("The current response count is: {}", getQueue.getCurrentDepth());

        getQueue.get(mqMsg, mqgm);
        return mqMsg.readStringOfCharLength(mqMsg.getMessageLength());
    }
}


