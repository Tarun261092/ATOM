package automation.library.api;

import java.io.File;

public class Constants {
    private static final String USER_DIR = System.getProperty("user.dir");
    private static final String GENERATEDCLASSPATH = USER_DIR + "/target/test-classes/";
    public static final String APIOBJECTSFOLDER = "apiobjects";
    public static final String APIOBJECTSPATH = GENERATEDCLASSPATH + APIOBJECTSFOLDER + File.separator;
    public static final String APIOBJECTSJAR = USER_DIR + "/target/lib/";
    public static final String ENVIRONMENT_PATH = USER_DIR + "/src/test/resources/config/environments";
    public static final String KAFKA_PROPS_PATH = USER_DIR + "/src/test/resources/config/kafka/";
    public static final String KAFKA_PROPS_FILE = KAFKA_PROPS_PATH + "kafkaRuntime.properties";
    public static final String KAFKA_TOPICS_FILE = KAFKA_PROPS_PATH + "kafkaTopicList.json";

    public static final String STOREUTILSPATH = "services/store/";
    public static final String VALIDATEUTILSPATH = "services/validate/";
    public static final String SETUTILSPATH = "services/set/";
    public static final String REMOVEUTILSPATH = "services/remove/";
    public static final String CALLUTILSPATH = "services/call/";
    public static final String MQUTILSPATH = "services/mq/";
    public static final String BASEPATH = USER_DIR + "/src/test/resources/";
    public static final String TESTDATAPATH = BASEPATH + "testdata/";
    public static final String MQOBJECT = "mqobjects/";
    public static final String MQPAYLOADPATH = BASEPATH + MQOBJECT;


    private Constants() {
        //Utility class
    }
}
