package automation.library.api.kafka;

import org.apache.camel.Predicate;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.mock.MockEndpoint;

import static org.apache.camel.builder.Builder.body;
import static org.apache.camel.support.builder.PredicateBuilder.and;
import static org.apache.camel.support.builder.PredicateBuilder.or;

public class AutoEngRouteBuilder extends RouteBuilder {
    public static final String MSG_RECEIVED_FROM_KAFKA = "Message received from Kafka : ${body}";
    public static final String ON_THE_TOPIC = "    on the topic ${headers[kafka.TOPIC]}";
    public static final String WITH_THE_OFFSET = "    with the offset ${headers[kafka.OFFSET]}";
    private String endPointURI;
    private String routeId;
    private String attributeVal;
    private String attributeVal2;
    private MockEndpoint mockKafkaConsumer;

    public AutoEngRouteBuilder(String endPointURI,
                               String routeId,
                               MockEndpoint mockKafkaConsumer,
                               String attributeVal,
                               String attributeVal2) {
        super();
        this.endPointURI = endPointURI;
        this.routeId = routeId;
        this.mockKafkaConsumer = mockKafkaConsumer;
        this.attributeVal = attributeVal;
        this.attributeVal2 = attributeVal2;
    }

    @Override
    public void configure() throws Exception {

        if(attributeVal == null && attributeVal2 == null) {
            from(endPointURI)
                    .routeId(routeId)
                    .log(MSG_RECEIVED_FROM_KAFKA)
                    .log(ON_THE_TOPIC)
                    .log(WITH_THE_OFFSET)
                    .to(mockKafkaConsumer);
        } else {
            Predicate bodyContains;

            if(attributeVal2 == null) {
                bodyContains = body().contains(attributeVal);
            } else {
                bodyContains = and(body().contains(attributeVal), body().contains(attributeVal2));
            }

            from(endPointURI)
                    .routeId(routeId)
                    .choice()
                    .when(bodyContains)
                                  .log(MSG_RECEIVED_FROM_KAFKA)
                                  .log(ON_THE_TOPIC)
                                  .log(WITH_THE_OFFSET)
                                  .to(mockKafkaConsumer);
        }
    }
}
