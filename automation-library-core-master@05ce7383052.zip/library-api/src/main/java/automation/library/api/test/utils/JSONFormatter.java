package automation.library.api.test.utils;

import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;
import net.minidev.json.JSONArray;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.List;
import java.util.Map;

public class JSONFormatter {

    private JSONFormatter() {
        //Utility class
    }

    public static String formatJSON(Object jsonString) {
        try {
            if (jsonString instanceof String) {
                JsonElement jsonElement = JsonParser.parseString(jsonString.toString());
                return new GsonBuilder().serializeNulls().setPrettyPrinting()
                                        .setLenient()
                                        .create()
                                        .toJson(jsonElement);
            } else if (jsonString instanceof Map) {
                return new GsonBuilder().serializeNulls().setPrettyPrinting()
                                        .create()
                                        .toJson(jsonString, Map.class);
            } else if (jsonString instanceof JSONArray) {
                return new GsonBuilder().serializeNulls().setPrettyPrinting()
                                        .create()
                                        .toJson(jsonString, JSONArray.class);
            } else if (jsonString instanceof List) {
                return new GsonBuilder().serializeNulls().setPrettyPrinting()
                                        .create()
                                        .toJson(jsonString, List.class);
            } else {
                getLogger().warn("Unrecognized response body type: {}", jsonString);
                return jsonString.toString();
            }
        } catch (JsonSyntaxException e) {
            getLogger().debug("Not a valid JSON: {}. Returning string.", jsonString);
            return jsonString.toString();
        }
    }

    private static Logger getLogger() {
        return LogManager.getLogger(JSONFormatter.class);
    }
}
