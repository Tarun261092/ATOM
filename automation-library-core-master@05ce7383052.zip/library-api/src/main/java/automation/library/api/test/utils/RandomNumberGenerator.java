package automation.library.api.test.utils;

import java.util.Random;

public class RandomNumberGenerator {

	private RandomNumberGenerator() {
		//utility class
	}

	public static int randomNumber() {
		Random r = new Random( System.currentTimeMillis() );
	    return ((1 + r.nextInt(2)) * 10000 + r.nextInt(10000));
	}
}
