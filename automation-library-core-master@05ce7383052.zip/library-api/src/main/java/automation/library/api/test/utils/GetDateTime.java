package automation.library.api.test.utils;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class GetDateTime {

	private GetDateTime() {
		//utility class
	}

	public static String addDaysToDate_yyyymmdd(int addDays) {

		String DATE_FORMAT = "yyyyMMdd";
	    SimpleDateFormat sdf =
	    new SimpleDateFormat(DATE_FORMAT);
	    Calendar dtCalendar = Calendar.getInstance(); // today	   	    	    
	    dtCalendar.add(Calendar.DATE, addDays);

	    return sdf.format(dtCalendar.getTime());
	}
		
}
