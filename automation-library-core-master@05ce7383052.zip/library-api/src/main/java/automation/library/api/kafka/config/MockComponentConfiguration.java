package automation.library.api.kafka.config;

import automation.library.common.Property;
import org.apache.camel.CamelContext;
import org.apache.camel.component.mock.MockEndpoint;
import org.apache.commons.configuration2.PropertiesConfiguration;

import static automation.library.api.Constants.KAFKA_PROPS_FILE;

public class MockComponentConfiguration {
    public MockEndpoint getMockEndpoint(CamelContext camelContext, String mockEndpointURI) {
        MockEndpoint mockKafkaConsumer = camelContext.getEndpoint(mockEndpointURI, MockEndpoint.class);
        mockKafkaConsumer.reset();
        setOptionalMockConfiguration(mockKafkaConsumer);

        return mockKafkaConsumer;
    }

    private void setOptionalMockConfiguration(MockEndpoint mockKafkaConsumer) {
        PropertiesConfiguration kafkaProps = Property.getProperties(KAFKA_PROPS_FILE);

        if(kafkaProps != null) {
            if (kafkaProps.getString("mock.retainLast") != null) {
                mockKafkaConsumer.setRetainLast(kafkaProps.getInt("mock.retainLast"));
            } else {
                mockKafkaConsumer.setRetainLast(10);
            }

            if (kafkaProps.getString("mock.retainFirst") != null) {
                mockKafkaConsumer.setRetainFirst(kafkaProps.getInt("mock.retainFirst"));
            }

        }
    }
}
