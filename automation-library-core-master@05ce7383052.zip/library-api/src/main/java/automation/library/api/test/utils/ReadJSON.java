package automation.library.api.test.utils;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class ReadJSON {
    private static final String FAILED_TO_LOCATE_ARRAY_ERROR_MSG = "Failed to locate JSON array object... %s";
    private static final String FAILED_TO_LOCATE_OBJECT_ERR = "Failed to locate JSON object... %s";

    private ReadJSON() {
        //utility class
    }

    /**
     * Reads file and converts to String.
     *
     * @param filePath
     * @throws IOException
     */
    static String readFileAsString(String filePath) throws IOException {
        StringBuilder fileData = new StringBuilder(1000);

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
			char[] buf = new char[1024];
			int numRead = 0;
			while ((numRead = reader.read(buf)) != -1) {
				String readData = String.valueOf(buf, 0, numRead);
				fileData.append(readData);
				buf = new char[1024];
			}
			return fileData.toString();
		}
    }

    /**
     * Given a file name within the ./json/ folder, it will read the file and
     * return the contents as a string.
     *
     * @param
     * @return Contents of the file as a String
     */
    public static String parse(String fileName) {
        try {
            String path = System.getProperty("user.dir") + "//src//test//resources//";
            return readFileAsString(path + fileName);
        } catch (IOException e) {
            getLogger().error(e.getMessage(), e);
            return null;
        }
    }

    /**
     * Given a file name within the ./json/ folder, it will read the file and
     * return the contents as a string.
     *
     * @param
     * @return Contents of the file as a String
     */
    public static String parse(String location, String fileName) {
        String dir = "/";
		if ("test resources".equals(location)) {
			dir = "\\src\\test\\resources\\";
		}

        try {
            String path = System.getProperty("user.dir") + dir;
            return readFileAsString(path + fileName);
        } catch (IOException ex) {
            getLogger().error(ex.getMessage(), ex);
            return null;
        }
    }

    /**
     * Gets the String stored in the JSONObject with the given key
     *
     * @param obj The JSONObject to use
     * @param key The locator key to use
     * @return Value as a String
     */
    public static String getString(JSONObject obj, String key) {

        String output = "";

        try {
            output = obj.getString(key);
        } catch (JSONException e) {
            String errMsg = String.format(FAILED_TO_LOCATE_OBJECT_ERR, e.getMessage());
            getLogger().error(errMsg, e);
        }
        return output;
    }

    public static String getStringInNode(JSONObject json, String node, String key) {
        JSONObject obj = null;
        String output = null;
        try {
            obj = json.getJSONObject(node);
            output = obj.getString(key);
        } catch (JSONException e) {
            String errMsg = String.format(FAILED_TO_LOCATE_OBJECT_ERR, e.getMessage());
            getLogger().error(errMsg, e);
        }
        return output;
    }

    /**
     * Gets the Integer stored in the JSONObject with the given key
     *
     * @param obj The JSONObject to use
     * @param key The locator key to use
     * @return Value as a Integer
     */
    public static int getInt(JSONObject obj, String key) {
        int output = -1;
        try {
            output = obj.getInt(key);
        } catch (JSONException e) {
            String errMsg = String.format(FAILED_TO_LOCATE_OBJECT_ERR, e.getMessage());
            getLogger().error(errMsg, e);
        }
        return output;
    }

    /**
     * Gets the Boolean value stored in the JSONObject with the given key
     *
     * @param obj The JSONObject to use
     * @param key The locator key to use
     * @return Value as a Boolean
     */
    public static boolean getBoolean(JSONObject obj, String key) {
        boolean output = false;
        try {
            output = obj.getBoolean(key);
        } catch (JSONException e) {
            String errMsg = String.format(FAILED_TO_LOCATE_OBJECT_ERR, e.getMessage());
            getLogger().error(errMsg, e);
        }
        return output;
    }

    /**
     * Gets the JSONObject at given index within the JSONArray
     *
     * @param array The JSONArray to use
     * @param index Index of where the JSONObject is
     * @return The JSONObject at the given index
     */
    public static JSONObject getObject(JSONArray array, int index) {
        JSONObject obj = null;
        try {
            obj = (JSONObject) array.get(index);
        } catch (JSONException e) {
            String errMsg = String.format(FAILED_TO_LOCATE_ARRAY_ERROR_MSG, e.getMessage());
            getLogger().error(errMsg, e);
        }
        return obj;
    }

    public static JSONObject getObject(JSONObject array, String node) {
        JSONObject obj = null;
        try {
            obj = array.getJSONObject(node);
        } catch (JSONException e) {
            String errMsg = String.format(FAILED_TO_LOCATE_ARRAY_ERROR_MSG, e.getMessage());
            getLogger().error(errMsg, e);
        }
        return obj;
    }

    /**
     * Gets the JSONObject at given index within the JSONArray
     *
     * @param obj The JSONObject to use
     * @param index Index of where the JSONObject is
     * @return The JSONObject at the given index
     */
    public static JSONObject getStringFromArray(JSONObject obj, String node, int index) {
        JSONArray applicationLogin = new JSONArray();

        try {
            applicationLogin = obj.getJSONArray(node);
            obj = (JSONObject) applicationLogin.get(index);
        } catch (JSONException e) {
            String errMsg = String.format(FAILED_TO_LOCATE_ARRAY_ERROR_MSG, e.getMessage());
            getLogger().error(errMsg, e);
        }
        return obj;
    }

    /**
     * Gets the JSONObject at given index within the JSONArray
     *
     * @param array The JSONArray to use
     * @param node Index of where the JSONObject is
     * @return The JSONObject at the given index
     */
    public static JSONArray getArray(JSONObject array, String node) {
        JSONArray obj = null;
        try {
            obj = array.getJSONArray(node);
        } catch (JSONException e) {
            String errMsg = String.format(FAILED_TO_LOCATE_ARRAY_ERROR_MSG, e.getMessage());
            getLogger().error(errMsg, e);
        }
        return obj;
    }

    private static Logger getLogger() {
        return LogManager.getLogger(ReadJSON.class);
    }
}
