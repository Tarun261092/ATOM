package automation.library.api.test.utils;

import automation.library.api.Constants;
import automation.library.common.FileHelper;
import automation.library.common.TestContext;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DateUtil;


/**
 * ***************************************************************************
 * HIGHLIGHTS:
 * > Methods used to get data from an excel file.
 * > It returns the data as a string that can be saved on a variable.
 * This class requires the "org.apache.poi" libraries.
 * ***************************************************************************
 *
 *
 */

public class ReadExcel {
    private ReadExcel() {
        //utility class
    }

    /**
     * OBJECTIVE: Get the value of an excel file cell.
     * DESCRIPTION: Use it when it is required to store data on excel that will be used as input on steps.
     * INPUT: row (this can involve for where called). This can work with a tot rows to perform a loop.
     * filePath: example "C://accenture//Confidential//Automation//MyProjects//" + strFileName + ".xlsx";
     * strSheetName: name of the excel sheet to be checked. Like global and local data tables in UFT.
     * strColName: name of the column to be checked.
     * OUTPUT: string with the value from the cell.
     */
    public static String getCellValue(int row, String strFilePath, String strSheetName, String strColName) throws IOException {

        //Call reusable methods to open input stream and excel sheet
        FileInputStream fis = openInputStream(strFilePath);
        XSSFSheet mySheet = openExcelSheet(fis, strSheetName);

        Row myRowCols = mySheet.getRow(0);
        String myDataValue = null;
        for (int j = 0; j < myRowCols.getLastCellNum(); j++) {
            String curColName = myRowCols.getCell(j).getStringCellValue();
            if (curColName.contentEquals(strColName)) {
                Row myRow = mySheet.getRow(row);
                CellType cellType = myRow.getCell(j).getCellType();
                if (cellType == CellType.NUMERIC) {
                    int myIntDataValue = (int) myRow.getCell(j).getNumericCellValue();
                    myDataValue = Integer.toString(myIntDataValue);
                } else {
                    myDataValue = myRow.getCell(j).getStringCellValue();
                }
                break;
            }
        }
        fis.close();
        return myDataValue;
    }
//new method added to iterate the entire sheet to fetch the corresponding column header and not assuming the first column is header column
    public  static String getCellValueForExcel(int row, String strFilePath, String strSheetName, String strColName) throws IOException {
    	
    	  FileInputStream fis = openInputStream(strFilePath);
          XSSFSheet mySheet = openExcelSheet(fis, strSheetName);
          Object myDataValue = null;
  		 Map<String ,Object>outPut = fetchColumnIndexRowIndex(strColName,mySheet);
  		 int columnIndex =	Integer.valueOf(outPut.get("ColumnIndex").toString());
  		 Row myRow = mySheet.getRow(row);
  		 myDataValue = getCellData(myRow.getCell(columnIndex)); 		
          fis.close();
       
        return myDataValue.toString();
    }
   

   //This method will return the map of  column index of the COlumn Header Passed and the row number corresponding to the column index
    private static Map<String,Object> fetchColumnIndexRowIndex(String strColName, XSSFSheet mySheet) {
   	 int lastRow = mySheet.getLastRowNum();
  		int currentRowNum = 0;
  		Row headerRow = null;
  		String dataSetKey=null;
  		Map<String,Object> dataMap =  new HashMap<>();
    	while (currentRowNum < lastRow) {
			if (isRowEmpty(mySheet.getRow(currentRowNum))) {
				currentRowNum++;
				continue;
			}
			headerRow = mySheet.getRow(currentRowNum);
			int primaryKeyInd = 0;
			for(int ind = headerRow.getFirstCellNum() ; ind <headerRow.getLastCellNum() ; ind++) {
				//this case is when the header row is 0th zero, WE RETURN FROM HERE
				if (headerRow.getCell(ind)!=null && headerRow.getCell(ind).getStringCellValue().equalsIgnoreCase(strColName)){
					primaryKeyInd = ind;
					System.out.println("primary" + primaryKeyInd);		
					dataMap.put("ColumnIndex", primaryKeyInd);
					dataMap.put("HeaderRowNumber", currentRowNum);
					return dataMap;
				} 
			}
			for (int j = currentRowNum + 1; j <= lastRow; j++) {
				if (isRowEmpty(mySheet.getRow(j))) {
					currentRowNum = j + 1;
					break;
				}
				int lastCellNumber = mySheet.getRow(j).getLastCellNum();
				int startColumnIndex =primaryKeyInd;
				while(startColumnIndex<lastCellNumber) {
					String cellValue = null;
							if(mySheet.getRow(j).getCell(startColumnIndex)!=null && getCellData(mySheet.getRow(j).getCell(startColumnIndex))!=null) {
								cellValue=getCellData(mySheet.getRow(j).getCell(startColumnIndex)).toString();
							}
					if(strColName.equalsIgnoreCase(cellValue)) {
						startColumnIndex = j;
						System.out.println("primary" + startColumnIndex);		
						dataMap.put("ColumnIndex", startColumnIndex);
						dataMap.put("HeaderRowNumber", j);
						return dataMap;
					}
					startColumnIndex++;
					
				}
				
					currentRowNum++;
			}
			
			
 		}
		return null;
	}

	/**
     * OBJECTIVE: Get the total of iterations to be used on a loop.
     * DESCRIPTION: Used it when the test flow is driven by an an excel file. Like the UFT data table.
     * INPUT: strFilePath: example "C://accenture//Confidential//Automation//MyProjects//" + strFileName + ".xlsx";
     * strSheetName: name of the excel sheet to be checked. Like global and local data tables in UFT.
     * OUTPUT: string with the value from the cell.
     */

    public static int getTotIterations(String strFilePath, String strSheetName) throws IOException {

        //Call reusable methods to open input stream and excel sheet
        FileInputStream fis = openInputStream(strFilePath);
        XSSFSheet excelSheet = openExcelSheet(fis, strSheetName);
        int count = excelSheet.getLastRowNum();
        fis.close();
        return count;
    }

    /**
     * OBJECTIVE: Open input stream.
     * DESCRIPTION: Input stream is reusable among methods. Then use this to method to open the fis.
     * INPUT: strFilePath: example "C://accenture//Confidential//Automation//MyProjects//" + strFileName + ".xlsx";
     * OUTPUT: file input stream
     */
    public static FileInputStream openInputStream(String strFilePath) throws IOException {
        File fis = new File(strFilePath);

        return new FileInputStream(fis);
    }

    /**
     * OBJECTIVE: Open excel sheet.
     * DESCRIPTION: Code to open excel sheet is reusable, so use this code.
     * INPUT: file input stream, use the "openInputStream" to create it and provide sheet name.
     * OUTPUT: excel file object open
     */
    public static XSSFSheet openExcelSheet(FileInputStream fileInputStream, String strSheetName) throws IOException {

        @SuppressWarnings("resource")
        XSSFWorkbook workbook = new XSSFWorkbook(fileInputStream);
        return workbook.getSheet(strSheetName);
    }

    /**
     * OBJECTIVE: Close the file input stream.
     * DESCRIPTION: Code to close excel sheet is reusable, so use this code.
     * INPUT: file input stream, use the "openInputStream" to create it.
     * OUTPUT: None (file will be closed)
     */
    public static void closeExcelSheet(FileInputStream strFilePath) throws IOException {
        strFilePath.close();
    }

    public static void setCellValue(int rowNum,
                                    String strFilePath,
                                    String strSheetName,
                                    String strColName,
                                    String value) throws IOException {

        //Call reusable methods to open input stream and excel sheet
        FileInputStream fis = openInputStream(strFilePath);
        XSSFSheet mySheet = openExcelSheet(fis, strSheetName);
        XSSFWorkbook workbook = mySheet.getWorkbook();
        XSSFRow row = null;
        boolean flag = false;
        int colNum = -1;

        for (int i = 0; i <= mySheet.getLastRowNum(); ++i) {
            row = mySheet.getRow(i);
            for (int j = 0; j < row.getLastCellNum(); j++) {
            	if(row.getCell(j) != null && row.getCell(j).getStringCellValue() != null && row.getCell(j).getStringCellValue().trim().equals(strColName.split(",")[0])) {
                    colNum = j;
                    flag = true;
                    break;
                }
            }
            if (flag)
                break;
        }
        mySheet.setColumnWidth(colNum, 7500);
        row = mySheet.getRow(rowNum - 1);
        XSSFCell cell = row.getCell(colNum);
        cell.setCellValue(cell.getStringCellValue() + "\n" + value );
        FileOutputStream fos = new FileOutputStream(strFilePath);
        workbook.write(fos);
        fos.close();
        workbook.close();
        fis.close();
    }

    public static String getPathToExcel(String fileName) {
        String tempPath = FileHelper.findFileInPath(Constants.TESTDATAPATH, fileName);
        TestContext.getInstance().testdataPut("fw.filePath",tempPath);
        if (tempPath != null) {
            return tempPath;
        } else
            return null;
    }
    
    public static String getPathToExcel(String filePath, String fileName) {
        String tempPath = FileHelper.findFileInPath(filePath, fileName);
        TestContext.getInstance().testdataPut("fw.filePath",tempPath);
        if (tempPath != null) {
            return tempPath;
        } else
            return null;
    }


    public static int getRowNumber(String colHeader, String colValue, String strFilePath, String strSheetName, String strColName) throws IOException {
        //Call reusable methods to open input stream and excel sheet
        FileInputStream fis = openInputStream(strFilePath);
        XSSFSheet mySheet = openExcelSheet(fis, strSheetName);

        Row myRowCols = mySheet.getRow(0);
        String myDataValue = null;
        int rowNum = -1;
        for (int j = 0; j < myRowCols.getLastCellNum(); j++) {
            String curColName = myRowCols.getCell(j).getStringCellValue();
            if (curColName.contentEquals(colHeader)) {
                for (int k = 1; k < mySheet.getLastRowNum(); k++) {
                    Row myRow = mySheet.getRow(k);
                    CellType cellType = myRow.getCell(j).getCellType();
                    if (cellType == CellType.NUMERIC) {
                        int myIntDataValue = (int) myRow.getCell(j).getNumericCellValue();
                        myDataValue = Integer.toString(myIntDataValue);
                    } else {
                        myDataValue = myRow.getCell(j).getStringCellValue();
                    }
                    if (myDataValue.equals((colValue))) {
                        rowNum = k;
                        break;
                    }
                }
                break;
            }
        }
        fis.close();
        return rowNum;
    }

    public static int getRowNumber(String colHeader1,
                                   String colValue1,
                                   String colHeader2,
                                   String colValue2,
                                   String colHeader3,
                                   String colValue3,
                                   String strFilePath,
                                   String strSheetName) throws IOException {

        //Call reusable methods to open input stream and excel sheet
        FileInputStream fis = openInputStream(strFilePath);
        XSSFSheet mySheet = openExcelSheet(fis, strSheetName);
        int rowNum = -1;
        String myDataValue1;
        String myDataValue2;
        String myDataValue3;
        int colNum1 = -1;
        int colNum2 = -1;
        int colNum3 = -1;

        colNum1 = getColumnNumber(colHeader1,mySheet);
        colNum2 = getColumnNumber(colHeader2,mySheet);
        colNum3 = getColumnNumber(colHeader3,mySheet);

        for (int k = 1; k < mySheet.getLastRowNum(); k++) {
            myDataValue1 = getCellDataFromExcel(k,colNum1,mySheet);
            myDataValue2 = getCellDataFromExcel(k,colNum2,mySheet);
            myDataValue3 = getCellDataFromExcel(k,colNum3,mySheet);

            if (myDataValue1.equals(colValue1) && myDataValue2.equals(colValue2) && myDataValue3.equals(colValue3)) {
                rowNum = k;
                break;
            }
        }
        fis.close();
        return rowNum;
    }

    private static Integer getColumnNumber(String colHeader,
                                           XSSFSheet strSheetName) {
        int colNum = -1;

        Row myRowCols = strSheetName.getRow(0);
        for (int j = 0; j < myRowCols.getLastCellNum(); j++) {
            String curColName = myRowCols.getCell(j).getStringCellValue();
            if (curColName.contentEquals(colHeader)) {
                colNum = j;
                break;
            }
        }
        return colNum;
    }

    private static String getCellDataFromExcel(int rowNum, int colNum,
                                               XSSFSheet strSheetName) {
        String myDataValue = null;
        Row myRow = strSheetName.getRow(rowNum);
        CellType cellType = myRow.getCell(colNum).getCellType();
        if (cellType == CellType.NUMERIC) {
            int myIntDataValue = (int) myRow.getCell(colNum).getNumericCellValue();
            myDataValue = Integer.toString(myIntDataValue);
        } else {
            myDataValue = myRow.getCell(colNum).getStringCellValue();
        }
        return myDataValue;
    }
    
    public static int getRowNumber(String colHeader, String colValue, String strFilePath, String strSheetName) throws IOException {
        //Call reusable methods to open input stream and excel sheet
        FileInputStream fis = openInputStream(strFilePath);
        XSSFSheet mySheet = openExcelSheet(fis, strSheetName);

        Row myRowCols = mySheet.getRow(0);
        String myDataValue = null;
        int rowNum = -1;
        for (int j = 0; j < myRowCols.getLastCellNum(); j++) {
            String curColName = myRowCols.getCell(j).getStringCellValue();
            if (curColName.contentEquals(colHeader)) {
            	int s=mySheet.getLastRowNum();
                for (int k = 1; k <= mySheet.getLastRowNum(); k++) {
                    Row myRow = mySheet.getRow(k);
                    CellType cellType = myRow.getCell(j).getCellType();
                    if (cellType == CellType.NUMERIC) {
                        int myIntDataValue = (int) myRow.getCell(j).getNumericCellValue();
                        myDataValue = Integer.toString(myIntDataValue);
                    } else {
                        myDataValue = myRow.getCell(j).getStringCellValue();
                    }
                    if (myDataValue.equals((colValue))) {
                        rowNum = k;
                        break;
                    }
                }
                break;
            }
        }
        fis.close();
        return rowNum;
    }
    
    public static int getRowNumber(String colHeader1,
            String colValue1,
            String colHeader2,
            String colValue2,
            String strFilePath,
            String strSheetName) throws IOException {
    	
    	//Call reusable methods to open input stream and excel sheet
    	FileInputStream fis = openInputStream(strFilePath);
    	XSSFSheet mySheet = openExcelSheet(fis, strSheetName);
    	int rowNum = -1;
    	String myDataValue1;
    	String myDataValue2;
    	int colNum1 = -1;
    	int colNum2 = -1;

    	colNum1 = getColumnNumber(colHeader1,mySheet);
    	colNum2 = getColumnNumber(colHeader2,mySheet);
    	
    	for (int k = 1; k <= mySheet.getLastRowNum(); k++) {
    		myDataValue1 = getCellDataFromExcel(k,colNum1,mySheet);
    		myDataValue2 = getCellDataFromExcel(k,colNum2,mySheet);
    		
    		if (myDataValue1.equals(colValue1) && myDataValue2.equals(colValue2)) {
    			rowNum = k;
    			break;
    		}
    	}
    	
    	fis.close();
    	return rowNum;
    }

    private static boolean isRowEmpty(Row row) {

		if (row == null) return true;

		for (int c = row.getFirstCellNum(); c < row.getLastCellNum(); c++) {
			Cell cell = row.getCell(c);
			if (cell != null && cell.getCellType() != CellType.BLANK) {
				return false;
			}
		}
		return true;
	}
    
    private static Object getCellData(Cell cell) {
		Object obj = null;
		 CellType cellType =cell.getCellType();

		if (cell == null) return null;

		switch (cellType) {
		case NUMERIC:
			if (DateUtil.isCellDateFormatted(cell)) {
				obj = (new SimpleDateFormat("yyyy-MM-dd").format(cell.getDateCellValue()));
			} else {
				obj = (cell.getNumericCellValue());
			}
			break;
		case STRING:
			obj = (cell.getStringCellValue());
			break;
		case BLANK:
			obj = null;
			break;
		case BOOLEAN:
			obj = (cell.getBooleanCellValue());
			break;
		default:
			obj = (cell.getStringCellValue());
		}
		return obj;
	}

    //kirthika changes to iterate the entire rows of the excel to fetch column header name
    public static int getRowNumberForExcel(String colHeader, String colValue, String strFilePath, String strSheetName) throws IOException {
        //Call reusable methods to open input stream and excel sheet
        FileInputStream fis = openInputStream(strFilePath);
        XSSFSheet mySheet = openExcelSheet(fis, strSheetName);
        int rowNum = -1;
		Map<String ,Object>outPut = fetchColumnIndexRowIndex(colHeader,mySheet);//new method added
	int headerRowNumber =	Integer.valueOf(outPut.get("HeaderRowNumber").toString());
	if(colValue.contains("outlinescenario")){
		rowNum= headerRowNumber;
	}else{
		Row myRowCols = mySheet.getRow(headerRowNumber);
	 String myDataValue = null;
     for (int j = 0; j < myRowCols.getLastCellNum(); j++) {
         String curColName = myRowCols.getCell(j).getStringCellValue();
         if (curColName.contentEquals(colHeader)) {
             for (int k = headerRowNumber+1; k <= mySheet.getLastRowNum(); k++) {
                 Row myRow = mySheet.getRow(k);
                 myDataValue = myRow.getCell(j).toString();
                 if (myDataValue.equals((colValue))) {
                     rowNum = k;
                     break;
                 }
             }
             break;
         }
     }
	}
     fis.close();	
		 
	
	 
        fis.close();
        return rowNum;
    }
		
    }

    
