package automation.library.cyara.core.maps;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

public class StepTest {
	
	@Test
    public void getStepNoTest() {
		Step step = new Step();
		assertThat(step.getStepNo()).isNull();	
    }
	
	@Test
    public void getDescriptionTest() {
		Step step = new Step();
		assertThat(step.getDescription()).isNull();	
    }
	
	@Test
    public void getExpectTest() {
		Step step = new Step();
		assertThat(step.getExpect()).isNull();	
    }

	@Test
    public void getReplyTest() {
		Step step = new Step();
		assertThat(step.getReply()).isNull();	
    }
	
	@Test
    public void getThresholdTimeTest() {
		Step step = new Step();
		assertThat(step.getThresholdTime()).isNull();	
    }
	
	@Test
    public void getPauseTimeTest() {
		Step step = new Step();
		assertThat(step.getPauseTime()).isNull();	
    }
	
	@Test
    public void getConfidenceTest() {
		Step step = new Step();
		assertThat(step.getConfidence()).isNull();	
    }
	
	@Test
    public void getPostSpeechSilenceTimeoutTest() {
		Step step = new Step();
		assertThat(step.getPostSpeechSilenceTimeout()).isNull();	
    }
	
	@Test
    public void getBlockPathTest() {
		Step step = new Step();
		assertThat(step.getBlockPath()).isNull();	
    }
}