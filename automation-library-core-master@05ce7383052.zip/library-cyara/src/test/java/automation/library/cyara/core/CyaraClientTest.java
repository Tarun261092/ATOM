package automation.library.cyara.core;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.HashMap;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import automation.library.cyara.core.maps.CallStepResult;
import automation.library.cyara.core.maps.CampaignStatus;

public class CyaraClientTest {
  
    static String cyaraBaseURL ="cyaraBaseURL", accountId = "accountId", cyaraUser = "cyaraUser", cyaraPassword = "cyaraPassword"; 
    static int connectionTimeout = 10;
    
    static CyaraClient cyaraClient = null;
    		
    @BeforeAll
    public static void setUp()
    {
    	cyaraClient = new CyaraClient(cyaraBaseURL, accountId, cyaraUser, cyaraPassword, connectionTimeout);
    }


    @Test
    public void CyaraClientTest1() {
    	CyaraClient cyaraClient = new CyaraClient(cyaraBaseURL, accountId, cyaraUser, cyaraPassword, connectionTimeout);
    	assertThat(cyaraClient).isNotNull();
    }

    @Test
    public void formatObjectToJson() {
    	
    	HashMap<String,String> jsonObject1 = new HashMap<String,String>();
    	assertThat(cyaraClient.formatObjectToJson(jsonObject1)).isNotNull();
    	
    	CallStepResult jsonObject2 = new CallStepResult();
    	assertThat(cyaraClient.formatObjectToJson(jsonObject2)).isNotNull();
    	
    	CampaignStatus jsonObject3 = new CampaignStatus();
    	assertThat(cyaraClient.formatObjectToJson(jsonObject3)).isNotNull();
    	
    	assertThat(cyaraClient.formatObjectToJson("")).isNotNull();    	
    }
    
}