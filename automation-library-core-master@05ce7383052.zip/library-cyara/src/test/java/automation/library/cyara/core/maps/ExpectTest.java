package automation.library.cyara.core.maps;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

public class ExpectTest {
  
	@Test
    public void getExchangeTypeTest() {
		Expect expect = new Expect();
		assertThat(expect.getExchangeType()).isNull();
    }
	
	@Test
    public void getTextTest() {
    	Expect expect = new Expect();
		assertThat(expect.getText()).isNull();
    }
}
