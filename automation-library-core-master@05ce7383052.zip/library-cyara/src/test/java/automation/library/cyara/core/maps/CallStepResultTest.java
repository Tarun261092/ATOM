package automation.library.cyara.core.maps;
import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

public class CallStepResultTest {

    @Test
    public void getStepResultTest() {
    	CallStepResult callStepResult = new CallStepResult();
    	assertThat(callStepResult.getStepResult()).isNull();	
    }

    @Test
    public void getStepTest() {
    	CallStepResult callStepResult = new CallStepResult();
    	assertThat(callStepResult.getStep()).isNull();
    }

}