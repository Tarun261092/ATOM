package automation.library.cyara.core.maps;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

public class TestStepResultListTest {
    
	@Test
    public void getCallStepResultTest() {
		TestStepResultList testStepResultListTest = new TestStepResultList();
		assertThat(testStepResultListTest.getCallStepResult()).isNull();	
    }

	@Test
    public void getRingStepResultTest() {
		TestStepResultList testStepResultListTest = new TestStepResultList();
		assertThat(testStepResultListTest.getRingStepResult()).isNull();	
    }
}
