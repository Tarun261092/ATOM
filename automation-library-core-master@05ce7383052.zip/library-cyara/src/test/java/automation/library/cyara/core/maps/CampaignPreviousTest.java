package automation.library.cyara.core.maps;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

public class CampaignPreviousTest {
  
	@Test
    public void getRunTest() {
		CampaignPrevious campaignPrevious = new CampaignPrevious();
		assertThat(campaignPrevious.getRun()).isNull();
    }
}