package automation.library.cyara.core.maps;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

public class CampaignStatusTest {
   
	@Test
    public void getRequestTest() {
		CampaignStatus campaignStatus = new CampaignStatus();
		assertThat(campaignStatus.getRequest()).isNull();
    }

	@Test
    public void getPreviousTest() {
    	CampaignStatus campaignStatus = new CampaignStatus();
    	assertThat(campaignStatus.getPrevious()).isNull();
    }
}
