package automation.library.cyara.core.maps;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

public class StepResultTest {

	@Test
    public void setAndGetResultTest() {
		StepResult stepResult = new StepResult();
		stepResult.setResult("result");
		assertThat(stepResult.getResult()).isNotNull();	
    }
		
	@Test
    public void setAndGetDetailTest() {
		StepResult stepResult = new StepResult();
		stepResult.setDetail("detail");
		assertThat(stepResult.getDetail()).isNotNull();	
    }
  
}