package automation.library.cyara.core;

import automation.library.cyara.core.maps.CallStepResult;
import automation.library.cyara.core.maps.CampaignStatus;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import okhttp3.*;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import static automation.library.cyara.core.CyaraConstants.*;

public class CyaraClient {
    private final Logger log = LogManager.getLogger(CyaraClient.class);
    private final String credential;
    private OkHttpClient client = null;
    private final String baseURL;


    public CyaraClient(String cyaraBaseURL, String accountId, String cyaraUser, String cyaraPassword, int connectionTimeout) {
        this.credential = Credentials.basic(cyaraUser, cyaraPassword);
        this.baseURL = getBaseURL(cyaraBaseURL, accountId);
        client = getClient(connectionTimeout);
    }

    private OkHttpClient getClient(int connectionTimeout) {
        int timeout = connectionTimeout >= 0 ? connectionTimeout : 60;

        return new OkHttpClient.Builder()
                .connectTimeout(timeout, TimeUnit.SECONDS)
                .readTimeout(timeout, TimeUnit.SECONDS)
                .writeTimeout(timeout, TimeUnit.SECONDS)
                .build();
    }

    private String getBaseURL(String cyaraBaseURL, String accountId) {
        return cyaraBaseURL +
               EP_BASE +
               EP_ACCOUNT +
               "/" +
               accountId +
               EP_VOICE;
    }

    private Object callCyaraAPI(String endPoint,
                                String msg,
                                String requestMethod,
                                RequestBody requestBody) {
        final String endPointURL = baseURL + endPoint;

        Request request = new Request.Builder()
                .url(endPointURL)
                .header(CONTENT_TYPE, JSON_CONTENT_TYPE)
                .header(ACCEPT, JSON_CONTENT_TYPE)
                .header("Authorization", credential)
                .method(requestMethod, requestBody)
                .build();

        try (Response response = client.newCall(request).execute()) {
            if (!response.isSuccessful()) throw new IOException(UNEXEPECTED_CODE + response);
            log.info("{} successful. URL: {}", msg, endPointURL);
            return new GsonBuilder().setLenient().serializeNulls().create().fromJson(response.body().charStream(), Object.class);
        } catch (IOException e) {
            log.error("{} unsuccessful. URL: {}. {}", msg, endPointURL, e.getMessage());
            return null;
        }
    }

    public List<Map<String, String>> getListOfTests() {
        final Object response = callCyaraAPI(EP_TESTCASE,
                                             "Test case list retrieval",
                                             GET,
                                             null);

        if (response != null) {
            Map<String, Object> testCaseObj = (Map) response;
            return (List) testCaseObj.get("testCase");
        } else {
            return Collections.emptyList();
        }
    }

    public String startTest(String testCaseId) {
        final String launchTestEndpoint = String.format(CYARA_ENDPOINT_PATTERN, EP_TESTCASE, testCaseId, EP_TESTCASE_RUN);
        final Object response = callCyaraAPI(launchTestEndpoint,
                                             "Start test",
                                             POST,
                                             RequestBody.create(null, new byte[]{}));

        if (response != null) {
            Map<String, String> testLaunchObj = (Map) response;
            return StringUtils.substringBetween(testLaunchObj.get("ticket"), "{", "}");
        } else {
            return ERROR_RESPONSE;
        }
    }

    public Map<String, Object> getTestResultObject(String testCaseId, String ticketNum) {
        final String pollTestEndpoint = String.format("%s/%s%s/%s", EP_TESTCASE, testCaseId, EP_TESTCASE_RUN, ticketNum);

        Object response = callCyaraAPI(pollTestEndpoint, "Get current test result", GET, null);

        if (response != null) {
            return (Map) response;
        } else {
            return Collections.emptyMap();
        }
    }

    public Map<String, Object> abortTest(String testCaseId, String ticketNum) {
        final String pollTestEndpoint = String.format("%s/%s%s/%s", EP_TESTCASE, testCaseId, EP_TESTCASE_RUN, ticketNum);
        callCyaraAPI(pollTestEndpoint,
                     "Abort test",
                     DELETE,
                     null);

        return getTestResultObject(testCaseId, ticketNum);
    }

    public List<Map<String, String>> getListOfCampaigns() {
        final Object response = callCyaraAPI(EP_CAMPAIGN,
                                             "Campaign list retrieval",
                                             GET,
                                             null);

        if (response != null) {
            Map<String, Object> testCaseObj = (Map) response;
            return (List) testCaseObj.get("data");
        } else {
            return Collections.emptyList();
        }
    }

    public Map<String, String> getCampaignStatus(String campaignId) {
        final String campaignStatusEndpoint = String.format(CYARA_ENDPOINT_PATTERN, EP_CAMPAIGN, campaignId, EP_CAMPAIGN_RUN);
        final Object response = callCyaraAPI(campaignStatusEndpoint,
                                             "Campaign status retrieval",
                                             GET,
                                             null);

        if(response != null) {
            CampaignStatus campaignStatusObj = new Gson().fromJson(formatObjectToJson(response), CampaignStatus.class);

            if (campaignStatusObj.getRequest() != null) {
                return campaignStatusObj.getRequest();
            } else if (campaignStatusObj.getPrevious() != null) {
                return campaignStatusObj.getPrevious().getRun();
            }
        }

        return Collections.emptyMap();
    }

    public Map<String, String> startCampaign(String campaignId) {
        final String campaignStatusEndpoint = String.format(CYARA_ENDPOINT_PATTERN, EP_CAMPAIGN, campaignId, EP_CAMPAIGN_RUN);
        final Object response = callCyaraAPI(campaignStatusEndpoint,
                                             "Start campaign",
                                             PUT,
                                            createCampaignStartRequest());

        if(response != null) {
            CampaignStatus campaignStatusObj = new Gson().fromJson(formatObjectToJson(response), CampaignStatus.class);
            return(campaignStatusObj.getRequest());
        }

        return Collections.emptyMap();
    }

    private RequestBody createCampaignStartRequest() {
        Map<String, Map<String, String>> request = new HashMap<>();
        Map<String, String> runDate = new HashMap<>();

        final String runDateAsString = String.format("%s+1:00", LocalDateTime.now());
        runDate.put("runDate", runDateAsString);
        request.put("request", runDate);

        return RequestBody.create(MediaType.parse("application/json"), formatObjectToJson(request));
    }

    public String formatObjectToJson(Object jsonObject) {
        if (jsonObject instanceof Map) {
            return new GsonBuilder().setPrettyPrinting()
                                    .create()
                                    .toJson(jsonObject, Map.class);
        } else if (jsonObject instanceof CallStepResult) {
            return new GsonBuilder().setPrettyPrinting()
                                    .create()
                                    .toJson(jsonObject, CallStepResult.class);
        } else if (jsonObject instanceof CampaignStatus) {
            return new GsonBuilder().setPrettyPrinting()
                                    .create()
                                    .toJson(jsonObject, CampaignStatus.class);
        } else {
            return jsonObject.toString();
        }
    }

}