package automation.library.cyara.core.maps;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.Map;

public class Step {

    @SerializedName("stepNo")
    @Expose
    private Double stepNo;

    @SerializedName("expect")
    @Expose
    private Expect expect;

    //UNUSED
    private String description;
    private Map<String, Object> reply;
    private Map<String, Object> thresholdTime;
    private Map<String, Object> pauseTime;
    private Map<String, Object> confidence;
    private String postSpeechSilenceTimeout;
    private String blockPath;

    public Double getStepNo() {
        return stepNo;
    }

    public String getDescription() {
        return description;
    }

    public Expect getExpect() {
        return expect;
    }

    public Map<String, Object> getReply() {
        return reply;
    }

    public Map<String, Object> getThresholdTime() {
        return thresholdTime;
    }

    public Map<String, Object> getPauseTime() {
        return pauseTime;
    }

    public Map<String, Object> getConfidence() {
        return confidence;
    }

    public String getPostSpeechSilenceTimeout() {
        return postSpeechSilenceTimeout;
    }

    public String getBlockPath() {
        return blockPath;
    }
}