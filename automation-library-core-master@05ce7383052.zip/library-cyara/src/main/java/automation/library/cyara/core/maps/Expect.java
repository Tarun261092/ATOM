package automation.library.cyara.core.maps;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Expect {
    @SerializedName("exchangeType")
    @Expose
    private String exchangeType;
    @SerializedName("text")
    @Expose
    private String text;

    public String getExchangeType() {
        return exchangeType;
    }

    public String getText() {
        return text;
    }
}
