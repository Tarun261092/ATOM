package automation.library.cyara.core;

public class CyaraConstants {
    //FILE PATHS
    private static final String USER_DIR = System.getProperty("user.dir");
    private static final String BASEPATH = USER_DIR + "/src/test/resources/";
    public static final String ALM_PROPERTIES_FOLDER_PATH = BASEPATH + "config/environments/";
    public static final String ALM_PROPERTIES_FILE_PATH = ALM_PROPERTIES_FOLDER_PATH + "alm.properties";
    public static final String RUNTIMEPATH = BASEPATH + "config/" + "runtime.properties";
    public static final String CYARA_LAUNCHED = "fw.CyaraLaunched";

    //END POINTS
    static final String EP_BASE = "/API/2.3";
    static final String EP_ACCOUNT = "/account";
    static final String EP_VOICE = "/voice";
    static final String EP_TESTCASE = "/testcase";
    static final String EP_TESTCASE_RUN = "/run";
    static final String EP_CAMPAIGN = "/campaign";
    static final String EP_CAMPAIGN_RUN = "/run";
    static final String EP_TEST_RESULT = "/TestResult";

    static final String CONTENT_TYPE = "Content-Type";
    static final String ACCEPT = "Accept";
    static final String JSON_CONTENT_TYPE = "application/json";
    static final String XML_CONTENT_TYPE = "application/xml";
    static final String OCTET_CONTENT_TYPE = "application/octet-stream";
    static final String ERROR_RESPONSE = "-1";
    static final String UNEXEPECTED_CODE = "Unexpected code: ";
    static final String TRIGGER_FLOW = "{BypassRecognition} Trigger Automation Flow";

    //REQUEST VERBS
    static final String GET = "GET";
    static final String POST = "POST";
    static final String PUT = "PUT";
    static final String DELETE = "DELETE";
    public static final String CYARA_ENDPOINT_PATTERN = "%s/%s%s";
    public static final String TEST_CASE_ID = "testCaseId";


    private CyaraConstants() {
        //utility class
    }

}