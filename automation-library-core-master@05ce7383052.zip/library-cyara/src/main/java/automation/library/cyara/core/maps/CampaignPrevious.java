package automation.library.cyara.core.maps;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.Map;

public class CampaignPrevious {
    @SerializedName("run")
    @Expose
    private Map<String, String> run;

    public Map<String, String> getRun() {
        return run;
    }
}
