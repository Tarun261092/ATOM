package automation.library.cyara.core.maps;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.Map;

public class CampaignStatus {
    @SerializedName("request")
    @Expose
    private Map<String, String> request;

    @SerializedName("previous")
    @Expose
    private CampaignPrevious previous;

    public Map<String, String> getRequest() {
        return request;
    }

    public CampaignPrevious getPrevious() {
        return previous;
    }
}
