package automation.library.cyara.core.maps;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.Map;

public class CallStepResult {

    @SerializedName("step")
    @Expose
    private Step step;
    @SerializedName("stepResult")
    @Expose
    private StepResult stepResult;
    @SerializedName("responseTime")
    @Expose
    private Map<String, Object> responseTime;
    @SerializedName("duration")
    @Expose
    private Map<String, Object> duration;

    public StepResult getStepResult() {
        return stepResult;
    }

    public Step getStep() {
        return step;
    }

}