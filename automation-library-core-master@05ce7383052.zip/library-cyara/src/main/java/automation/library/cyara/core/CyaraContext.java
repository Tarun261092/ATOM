package automation.library.cyara.core;

import automation.library.common.Property;
import automation.library.common.TestContext;
import automation.library.cyara.core.maps.CallStepResult;
import automation.library.cyara.core.maps.TestStepResultList;
import automation.library.tlm.TlmContext;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.apache.commons.configuration2.PropertiesConfiguration;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static automation.library.cyara.core.CyaraConstants.*;

public class CyaraContext {
    private static ThreadLocal<CyaraContext> instance = ThreadLocal.withInitial(CyaraContext::new);
    protected Logger log = LogManager.getLogger(this.getClass().getName());
    private CyaraClient curCyaraSession = null;
    private int waitBetweenPoll;
    private int maxWaitTime;

    private CyaraContext() {
        PropertiesConfiguration cyaraProps = Property.getProperties(CyaraConstants.RUNTIMEPATH);

        if (cyaraProps != null) {
            String cyaraUser = "NAM\\" + TlmContext.getInstance().getTlmManager().getTlmUser();
            String cyaraPassword = TlmContext.getInstance().getTlmManager().getTlmPassword();

            final int connectionTimeout = cyaraProps.getString("CyaraConnectionWait") == null ? 60 : cyaraProps.getInt("CyaraConnectionWait");
            final String accountId = cyaraProps.getString("accountId");
            final String cyaraBaseURL = cyaraProps.getString("CyaraURL");
            waitBetweenPoll = cyaraProps.getString("waitBetweenPoll") == null ? 3000 : cyaraProps.getInt("waitBetweenPoll") * 1000;
            maxWaitTime = cyaraProps.getString("maxWaitTime") == null ? 30000 : cyaraProps.getInt("maxWaitTime") * 1000;

            this.curCyaraSession = new CyaraClient(cyaraBaseURL, accountId, cyaraUser, cyaraPassword, connectionTimeout);
        }

        TestContext.getInstance().testdataPut(CYARA_LAUNCHED, "true");
    }

    public static synchronized CyaraContext getInstance() {
        return instance.get();
    }

    public static void removeInstance() {
        instance.remove();
    }

    public Map<String, String> launchTest(String testName) {
        final String testNameRegEx = String.format("(?i)%s", testName.replace(" ", ""));


        final List<String> testCaseID = curCyaraSession.getListOfTests()
                                                       .stream()
                                                       .filter(testEntry -> testEntry.get("name").replace(" ", "").matches(testNameRegEx))
                                                       .map(testEntry -> String.format("%.0f", testEntry.get(TEST_CASE_ID)))
                                                       .collect(Collectors.toList());

        if (!testCaseID.isEmpty()) {
            log.debug("Starting \"{}\" test with id \"{}\"", testName, testCaseID.get(0));
            final String ticketNum = curCyaraSession.startTest(testCaseID.get(0));

            if (!ticketNum.equalsIgnoreCase(ERROR_RESPONSE)) {
                Map<String, String> currentlyRunningTest = new HashMap<>();
                currentlyRunningTest.put(TEST_CASE_ID, testCaseID.get(0));
                currentlyRunningTest.put("ticketNum", ticketNum);
                return currentlyRunningTest;
            } else {
                return Collections.emptyMap();
            }
        } else {
            final String errorMsg = String.format("Cyara test not found: %s", testName);
            log.error(errorMsg);
            throw new IllegalArgumentException(errorMsg);
        }
    }

    public Map<String, Object> waitForTestToComplete(String testCaseId, String ticketNum) {
        try {
            log.debug("Waiting for test to complete...");
            Thread.sleep(waitBetweenPoll);

            for (int totalTimeWaited = 0; totalTimeWaited <= maxWaitTime; totalTimeWaited += waitBetweenPoll) {
                Map<String, Object> testResultObj = curCyaraSession.getTestResultObject(testCaseId, ticketNum);

                if (testResultObj != null) {
                    if (placeHolderStepReached(testResultObj)) {
                        return testResultObj;
                    } else if (testStillRunning(testResultObj)) {
                        log.debug("Test not finished. Waiting {} ms and will re-check", waitBetweenPoll);
                        Thread.sleep(waitBetweenPoll);
                    } else {
                        log.warn("Test did not complete successfully");
                        return testResultObj;
                    }
                } else {
                    return Collections.emptyMap();
                }
            }
        } catch (InterruptedException e) {
            log.error(e);
            Thread.currentThread().interrupt();
        }

        log.warn("Maximum time limit of {} ms reached and test has not finished. Aborting test", maxWaitTime);
        return curCyaraSession.abortTest(testCaseId, ticketNum);
    }

    public String getTestResultID() {
        final Map<String, String> currentlyRunningTest = (Map) TestContext.getInstance().testdataGet("fw.cyaraTestInfo");

        Map<String, Object> testResultObj = curCyaraSession.getTestResultObject(currentlyRunningTest.get(TEST_CASE_ID),
                                                                                currentlyRunningTest.get("ticketNum"));

        if (testResultObj != null && testResultObj.get("testResultId") instanceof Double) {
            return String.valueOf(((Double) testResultObj.get("testResultId")).intValue());
        }
        return null;
    }

    private boolean placeHolderStepReached(Map<String, Object> testResultObj) {
        final TestStepResultList testStepResultList = new Gson().fromJson(getJSONFromObject(testResultObj.get("testStepResultList")),
                                                                          TestStepResultList.class);
        final List<CallStepResult> callStepResultList = testStepResultList.getCallStepResult();

        for (CallStepResult stepResult : callStepResultList) {
            if (stepResult.getStep().getExpect() != null &&
                stepResult.getStep().getExpect().getText().equalsIgnoreCase(TRIGGER_FLOW)) {
                return true;
            }
        }

        if (!callStepResultList.isEmpty()) {
            log.debug("Last completed step #: {}. Expect text: {}. \nStep Result: {}",
                      () -> callStepResultList.get(callStepResultList.size() - 1).getStep().getStepNo(),
                      () -> callStepResultList.get(callStepResultList.size() - 1).getStep().getExpect().getText(),
                      () -> curCyaraSession.formatObjectToJson(callStepResultList.get(callStepResultList.size() - 1)));
        }

        return false;
    }

    private String getJSONFromObject(Object callStepResult) {
        return new GsonBuilder().setLenient().serializeNulls().create().toJson(callStepResult);
    }

    private boolean testStillRunning(Map<String, Object> testResultObj) {
        final Map<String, Object> testResult = (Map) testResultObj.get("testResult");

        return (testResult.get("detail") != null &&
                testResult.get("detail").toString().equalsIgnoreCase("Running")) ||
               (testResult.get("result") != null &&
                !testResult.get("result").toString().equalsIgnoreCase("Failed"));
    }

    public Map<String, Object> abortCurrentTest(String testCaseId, String ticketNum) {
        return curCyaraSession.abortTest(testCaseId, ticketNum);
    }

    public Map<String, String> checkForRunningCampaign(String campaignName) {
        final String campaignNameRegEx = String.format("(?i)%s", campaignName.replace(" ", ""));


        final List<String> campaignID = curCyaraSession.getListOfCampaigns()
                                                       .stream()
                                                       .filter(campaignEntry -> campaignEntry.get("name").replace(" ", "").matches(campaignNameRegEx))
                                                       .map(campaignEntry -> String.format("%.0f", campaignEntry.get("campaignId")))
                                                       .collect(Collectors.toList());

        if (!campaignID.isEmpty()) {
            log.debug("Checking status of \"{}\" campaign with id \"{}\"", campaignName, campaignID.get(0));
            Map<String, String> campaignStatus = curCyaraSession.getCampaignStatus(campaignID.get(0));

            if (campaignStatus.get("status").equalsIgnoreCase("Running")) {
                return campaignStatus;
            } else {
                log.debug("Campaign not running. Status is '{}'. Attempting to launch campaign", campaignStatus.get("status"));
                curCyaraSession.startCampaign(campaignID.get(0));
                return curCyaraSession.getCampaignStatus(campaignID.get(0));
            }
        } else {
            final String errorMsg = String.format("Cyara campaign not found: %s", campaignName);
            log.error(errorMsg);
            throw new IllegalArgumentException(errorMsg);
        }
    }

}