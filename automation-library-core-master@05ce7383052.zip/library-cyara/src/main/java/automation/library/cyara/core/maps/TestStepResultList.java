package automation.library.cyara.core.maps;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;
import java.util.Map;

public class TestStepResultList {
    @SerializedName("callStepResult")
    @Expose
    private List<CallStepResult> callStepResult;
    @SerializedName("ringStepResult")
    @Expose
    private Map<String, Object> ringStepResult;

    public List<CallStepResult> getCallStepResult() {
        return callStepResult;
    }

    public Map<String, Object> getRingStepResult() {
        return ringStepResult;
    }
}
