package automation.library.cyara.core.maps;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class StepResult {

    @SerializedName("result")
    @Expose
    private String result;
    @SerializedName("detail")
    @Expose
    private String detail;

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }

}