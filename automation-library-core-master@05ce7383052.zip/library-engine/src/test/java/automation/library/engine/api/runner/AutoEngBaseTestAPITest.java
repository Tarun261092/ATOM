package automation.library.engine.api.runner;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class AutoEngBaseTestAPITest {
	
    @Test
    public void beforeClassTest() {
    	System.setProperty("cukes.env", "UAT");
    	AutoEngBaseTestAPI.beforeClass();
    	assertThat(System.getProperty("fw.apiObjectsFolder")).isNotNull();
    }
}