package automation.library.engine.core.objectmatcher.fetch;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class FetchFeatureFilesTests {

    @Test
    void populateListOfFeatureFilesTest() {
        assertThat(FetchFeatureFiles.populateListOfFeatureFiles()).isNotEmpty();
    }

}