package automation.library.engine.core.objectmatcher.rating;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class FieldRatingTests {
    static FieldRating fieldRating;

    @BeforeAll
    static void setupObject() {
        fieldRating = new FieldRating("test", 1.0, "Found", "List");
    }

    @Test
    void getFieldNameTest() {
        assertThat(fieldRating.getFieldName()).isEqualTo("test");
    }

    @Test
    void setAndGetSimilarityScoreTest() {
        fieldRating.setSimilarityScore(0.5);
        assertThat(fieldRating.getSimilarityScore()).isEqualTo(0.5);
    }

    @Test
    void setAndGetMessageTest() {
        fieldRating.setSearchResultMsg("Found New Field");
        assertThat(fieldRating.getSearchResultMsg()).isEqualTo("Found New Field");
    }

    @Test
    void setAndGetAPIListTest() {
        fieldRating.setFieldList("List Of Fields");
        assertThat(fieldRating.getFieldList()).isEqualTo("List Of Fields");
    }

    @Test
    void twoArgConstructorTest() {
        FieldRating fieldRatingTwoArg = new FieldRating("Two Field", 1.0);
        assertThat(fieldRatingTwoArg.getFieldName()).isEqualTo("Two Field");
        assertThat(fieldRatingTwoArg.getSimilarityScore()).isEqualTo(1.0);
    }
}
