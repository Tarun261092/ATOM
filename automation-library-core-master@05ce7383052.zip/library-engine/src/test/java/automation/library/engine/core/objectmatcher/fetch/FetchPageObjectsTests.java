package automation.library.engine.core.objectmatcher.fetch;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class FetchPageObjectsTests {

	static FetchPageObjects fetchPageObjects;
	
   @Test
   void populateListOfFeatureFilesTest() {
       assertThat(FetchPageObjects.populateListOfPO()).isNotEmpty();
   }

}
