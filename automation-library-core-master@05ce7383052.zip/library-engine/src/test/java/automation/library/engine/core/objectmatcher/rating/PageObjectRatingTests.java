package automation.library.engine.core.objectmatcher.rating;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class PageObjectRatingTests {
    static PageObjectRating pageObjectRating;
    private static Class<?> pageObjectClazz;

    @BeforeAll
    static void setupObject() {
        pageObjectRating = new PageObjectRating("test", 1.0, pageObjectClazz,"Found", "List");
    }

    @Test
    void returnsAPIObjectNameTest() {
        assertThat(pageObjectRating.getPageObjectName()).isEqualTo("test");
    }

    @Test
    void returnsAPIObjectClassTest() {
        assertThat(pageObjectRating.getPageObjectClazz()).isNull();
    }

    @Test
    void setAndGetSimilarityScoreTest() {
        pageObjectRating.setSimilarityScore(0.5);
        assertThat(pageObjectRating.getSimilarityScore()).isEqualTo(0.5);
    }

    @Test
    void setAndGetMessageTest() {
        pageObjectRating.setSearchResultMsg("Found New Object");
        assertThat(pageObjectRating.getSearchResultMsg()).isEqualTo("Found New Object");
    }

    @Test
    void setAndGetAPIListTest() {
        pageObjectRating.setPageObjList("List Of APIs");
        assertThat(pageObjectRating.getPageObjList()).isEqualTo("List Of APIs");
    }

    @Test
    void twoArgConstructorTest() {
        PageObjectRating pageObjectRatingTwoArg = new PageObjectRating("Two Object", 1.0, pageObjectClazz);
        assertThat(pageObjectRatingTwoArg.getPageObjectName()).isEqualTo("Two Object");
        assertThat(pageObjectRatingTwoArg.getSimilarityScore()).isEqualTo(1.0);
    }
}
