package automation.library.engine.core.validator;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class AssertHelperTests {

    AssertHelper assertHelper;
    
    @Test
    public void AssertHelperConstructorTests(){
    	assertHelper = new AssertHelper("COMPARE_STRINGS","Equal To","HardStopONFailure");
    	assertHelper = new AssertHelper(ComparisonType.COMPARE_STRINGS,ComparisonOperator.EQIC,"ContinueOnFailure");
    	assertHelper = new AssertHelper("COMPARE_NUMBERS","Greater Than or Equal To","HardStopONFailure");
    	assertHelper = new AssertHelper(ComparisonType.COMPARE_LISTS,ComparisonOperator.CONTAINS,"ContinueOnFailure");
    	assertHelper = new AssertHelper("COMPARE_DATES","Equal To","HardStopONFailure");
    	assertHelper = new AssertHelper(ComparisonType.COMPARE_API_RESPONSE,ComparisonOperator.EQ,"ContinueOnFailure");
        assertThat(assertHelper).isNotNull();
    }
    
    @Test
    public void AssertHelperConstructorTests1() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
        	assertHelper = new AssertHelper("Test","Greater Than or Equal To","HardStopONFailure");
	    });
		assertThat(exception.getMessage()).isNotNull();
    } 
    
    @Test
    public void AssertHelperConstructorTests2() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
        	assertHelper = new AssertHelper("COMPARE_STRINGS","Test","HardStopONFailure");
	    });
		assertThat(exception.getMessage()).isNotNull();
    }
    
    @Test
    public void getResultMessageTest() {
    	assertHelper = new AssertHelper("COMPARE_STRINGS","Equal To","HardStopONFailure");
		assertThat(assertHelper.getResultMessage("Test", "Test")).isNotNull();
    }
    
}