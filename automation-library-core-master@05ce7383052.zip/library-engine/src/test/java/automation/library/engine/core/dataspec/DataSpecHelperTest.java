package automation.library.engine.core.dataspec;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class DataSpecHelperTest {
 
	DataSpecHelper dataSpecHelper = new DataSpecHelper();

    @Test
    public void processDataSpecTest() {
    	assertThat(dataSpecHelper.processDataSpec("MODE02_Letter")).isNotNull();    	
    }

}