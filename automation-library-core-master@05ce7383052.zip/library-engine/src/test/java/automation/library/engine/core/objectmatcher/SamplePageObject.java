package automation.library.engine.core.objectmatcher;

import automation.library.common.CommonPageObject;
import automation.library.selenium.exec.BasePO;
import org.openqa.selenium.By;

public class SamplePageObject extends CommonPageObject {
    private By testElement = By.xpath("//input");

    public Object testElement() {
        return "Found Element";
    }

}
