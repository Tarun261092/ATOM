package automation.library.engine.core.objectmatcher.fetch;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class FetchFlatFileObjectsTests {

    @Test
    void populateListOfAPIObjects() {
        assertThat(FetchFlatFileObjects.populateListOfAPIObjects()).isNotEmpty();
    }
    
    @Test
    void populateListOfDBObjects() {
        assertThat(FetchFlatFileObjects.populateListOfDBObjects()).isNotEmpty();
    }

}
