package automation.library.engine.core.objectmatcher;

import automation.library.common.TestContext;
import automation.library.engine.core.objectmatcher.fetch.FetchFeatureFiles;
import automation.library.engine.core.objectmatcher.fetch.FetchPageObjects;
import automation.library.engine.core.parser.FeatureFileParser;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.assertj.core.api.Assertions.assertThat;

public class FeatureFileParserTests {
    FeatureFileParser featureFileParser = new FeatureFileParser();

    @BeforeAll
    public static void setup() {
        TestContext.getInstance().setOfPO().addAll(FetchPageObjects.populateListOfPO());
        TestContext.getInstance().setOfFeatureFiles().addAll(FetchFeatureFiles.populateListOfFeatureFiles());
    }

    @Test
    void constructorTest() {
        FeatureFileParser featureFileParser2 = new FeatureFileParser();
        assertThat(featureFileParser2).isNotNull();
    }
}
