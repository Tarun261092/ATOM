package automation.library.engine.core.objectmatcher.fflookup;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class FunctionFeatureTests {
    static FunctionFeature functionFeature;

    @BeforeAll
    static void setupObject() {
        functionFeature = new FunctionFeature();
    }

    @Test
    void setAndGetFunctionTest() {
        functionFeature.setFunction("DemoFunction");
        assertThat(functionFeature.getFunction()).isEqualTo("DemoFunction");
    }

    @Test
    void setAndGetSubFunctionTest() {
        functionFeature.setSubFeature("DemoSubFeature");
        assertThat(functionFeature.getSubFeature()).isEqualTo("DemoSubFeature");
    }

}