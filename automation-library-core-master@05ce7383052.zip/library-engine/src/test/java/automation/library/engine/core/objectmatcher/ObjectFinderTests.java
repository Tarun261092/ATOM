package automation.library.engine.core.objectmatcher;

import automation.library.common.TestContext;
import automation.library.engine.core.objectmatcher.rating.FieldRating;
import automation.library.engine.core.objectmatcher.rating.FlatFileObjectRating;
import automation.library.engine.core.objectmatcher.rating.PageObjectRating;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.core.config.Configurator;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.HashSet;
import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;

public class ObjectFinderTests {

    private static final String PAGE_OBJECT_CLASS = "PageObjectRating";
    private static final String API_OBJECT_NAME = "getOmniChannelCache";
    private static final String DB_OBJECT_NAME = "retrieveTransactions";

    @BeforeAll
    static void setup() {
        Set<Class<?>> pageClassSet = new HashSet<>();
        pageClassSet.add(PageObjectRating.class);
        pageClassSet.add(FlatFileObjectRating.class);
        pageClassSet.add(SamplePageObject.class);
        TestContext.getInstance().setOfPO().addAll(pageClassSet);

        Set<String> apiFileSet = new HashSet<>();
        apiFileSet.add(API_OBJECT_NAME);
        apiFileSet.add("postAddSupression");
        TestContext.getInstance().setOfAPI().addAll(apiFileSet);

        Set<String> dbFileSet = new HashSet<>();
        dbFileSet.add(DB_OBJECT_NAME);
        dbFileSet.add("getErrorEntries");
        TestContext.getInstance().setOfDB().addAll(dbFileSet);

        Configurator.setLevel("automation.library.engine.core.objectmatcher", Level.OFF);
    }

    @Test
    @DisplayName("Find exact page match")
    void findMatchingPageTestExact() {
        final String pageToFind = PAGE_OBJECT_CLASS;
        PageObjectRating pageObjectRating = ObjectFinder.findMatchingPage(pageToFind);

        assertThat(pageObjectRating.getPageObjectName()).isEqualTo(pageToFind);
        assertThat(pageObjectRating.getSimilarityScore()).isEqualTo(1.0);
    }

    @Test
    @DisplayName("Find above threshold page match")
    void findMatchingPageTestAboveThreshold() {
        final String pageToFind = "PagObjectRating";
        PageObjectRating pageObjectRating = ObjectFinder.findMatchingPage(pageToFind);

        assertThat(pageObjectRating.getPageObjectName()).isEqualTo(PAGE_OBJECT_CLASS);
        assertThat(pageObjectRating.getSimilarityScore()).isGreaterThan(0.85);

    }

    @Test
    @DisplayName("Find between above and below threshold page match")
    void findMatchingPageTestBetweenAboveAndBelowThreshold() {
        final String pageToFind = "PaObj";
        PageObjectRating pageObjectRating = ObjectFinder.findMatchingPage(pageToFind);

        //method sets similarity score to -1.0
        assertThat(pageObjectRating.getSimilarityScore()).isEqualTo(-1.0);
        assertThat(pageObjectRating.getPageObjList()).isNotNull();
    }

    @Test
    @DisplayName("Find below threshold page match")
    void findMatchingPageTestBelowThreshold() {
        final String pageToFind = "NoMatch";
        PageObjectRating pageObjectRating = ObjectFinder.findMatchingPage(pageToFind);

        assertThat(pageObjectRating.getSimilarityScore()).isEqualTo(-1.0);
        assertThat(pageObjectRating.getPageObjList()).isNotNull();
    }

    @Test
    @DisplayName("Find exact element match")
    void findMatchingElementTestExact() {
        final String elementToFind = "pageObjectName";
        PageObjectRating pageObjMatch = ObjectFinder.findMatchingPage(PAGE_OBJECT_CLASS);
        FieldRating fieldRating = ObjectFinder.findMatchingElement(elementToFind, pageObjMatch.getPageObjectClazz());

        assertThat(fieldRating.getFieldName()).isEqualTo(elementToFind);
        assertThat(fieldRating.getSimilarityScore()).isEqualTo(1.0);
    }

    @Test
    @DisplayName("Find above threshold element match")
    void findMatchingElementTestAboveThreshold() {
        final String elementToFind = "pageObjectNa";
        PageObjectRating pageObjMatch = ObjectFinder.findMatchingPage(PAGE_OBJECT_CLASS);
        FieldRating fieldRating = ObjectFinder.findMatchingElement(elementToFind, pageObjMatch.getPageObjectClazz());

        assertThat(fieldRating.getFieldName()).isEqualTo("pageObjectName");
        assertThat(fieldRating.getSimilarityScore()).isGreaterThan(0.85);
    }

    @Test
    @DisplayName("Find between above and below threshold element match")
    void findMatchingElementTestBetweenAboveAndBelowThreshold() {
        final String elementToFind = "paObjeNam";
        PageObjectRating pageObjMatch = ObjectFinder.findMatchingPage(PAGE_OBJECT_CLASS);
        FieldRating fieldRating = ObjectFinder.findMatchingElement(elementToFind, pageObjMatch.getPageObjectClazz());

        //method sets similarity score to -1.0
        assertThat(fieldRating.getSimilarityScore()).isEqualTo(-1.0);
        assertThat(fieldRating.getFieldList()).isNotNull();
    }

    @Test
    @DisplayName("Find below threshold element match")
    void findMatchingElementTestBelowThreshold() {
        final String elementToFind = "NoMatch";
        PageObjectRating pageObjMatch = ObjectFinder.findMatchingPage(PAGE_OBJECT_CLASS);
        FieldRating fieldRating = ObjectFinder.findMatchingElement(elementToFind, pageObjMatch.getPageObjectClazz());

        assertThat(fieldRating.getSimilarityScore()).isEqualTo(-1.0);
        assertThat(fieldRating.getFieldList()).isNotNull();
    }

    @Test
    @DisplayName("Find exact match on API object")
    void getMatchingAPIFileExact() {
        FlatFileObjectRating flatFileObjectRating = ObjectFinder.getMatchingAPIFeature(API_OBJECT_NAME);

        assertThat(flatFileObjectRating.getFlatFileObjectName()).isEqualTo(API_OBJECT_NAME);
        assertThat(flatFileObjectRating.getSimilarityScore()).isEqualTo(1.0);
    }

    @Test
    @DisplayName("Find above threshold API match")
    void getMatchingAPIFileAboveThreshold() {
        final String apiToFind = API_OBJECT_NAME.substring(0, API_OBJECT_NAME.length()-1);
        FlatFileObjectRating flatFileObjectRating = ObjectFinder.getMatchingAPIFeature(apiToFind);

        assertThat(flatFileObjectRating.getFlatFileObjectName()).isEqualTo(API_OBJECT_NAME);
        assertThat(flatFileObjectRating.getSimilarityScore()).isGreaterThan(0.85);
    }

    @Test
    @DisplayName("Find between above and below threshold API match")
    void getMatchingAPIFileBetweenAboveAndBelow() {
        final String apiToFind = "getOmCh";
        FlatFileObjectRating flatFileObjectRating = ObjectFinder.getMatchingAPIFeature(apiToFind);

        assertThat(flatFileObjectRating.getSimilarityScore()).isEqualTo(-1.0);
        assertThat(flatFileObjectRating.getFlatFileObjectList()).isNotNull();
    }

    @Test
    @DisplayName("Find below threshold API match")
    void getMatchingAPIFileBelow() {
        final String apiToFind = "NoMatch";
        FlatFileObjectRating flatFileObjectRating = ObjectFinder.getMatchingAPIFeature(apiToFind);

        assertThat(flatFileObjectRating.getSimilarityScore()).isEqualTo(-1.0);
        assertThat(flatFileObjectRating.getFlatFileObjectList()).isNotNull();
    }

    @Test
    @DisplayName("Find exact match on DB object")
    void getMatchingDBFileExact() {
        FlatFileObjectRating flatFileObjectRating = ObjectFinder.getMatchingDBQuery(DB_OBJECT_NAME);

        assertThat(flatFileObjectRating.getFlatFileObjectName()).isEqualTo(DB_OBJECT_NAME);
        assertThat(flatFileObjectRating.getSimilarityScore()).isEqualTo(1.0);
    }

    @Test
    @DisplayName("Find above threshold DB match")
    void getMatchingDBFileAboveThreshold() {
        final String queryToFind = DB_OBJECT_NAME.substring(0, DB_OBJECT_NAME.length()-1);
        FlatFileObjectRating flatFileObjectRating = ObjectFinder.getMatchingDBQuery(queryToFind);

        assertThat(flatFileObjectRating.getFlatFileObjectName()).isEqualTo(DB_OBJECT_NAME);
        assertThat(flatFileObjectRating.getSimilarityScore()).isGreaterThan(0.85);
    }

    @Test
    @DisplayName("Find between above and below threshold DB match")
    void getMatchingDBFileBetweenAboveAndBelow() {
        final String queryToFind = "retriTr";
        FlatFileObjectRating flatFileObjectRating = ObjectFinder.getMatchingDBQuery(queryToFind);

        assertThat(flatFileObjectRating.getSimilarityScore()).isEqualTo(-1.0);
        assertThat(flatFileObjectRating.getFlatFileObjectList()).isNotNull();
    }

    @Test
    @DisplayName("Find below threshold DB match")
    void getMatchingDBFileBelow() {
        final String queryToFind = "NoMatch";
        FlatFileObjectRating flatFileObjectRating = ObjectFinder.getMatchingDBQuery(queryToFind);

        assertThat(flatFileObjectRating.getSimilarityScore()).isEqualTo(-1.0);
        assertThat(flatFileObjectRating.getFlatFileObjectList()).isNotNull();
    }

    @Test
    @DisplayName("Test full match of page object and element")
    void getMatchingElementTestWithMatch() {
        Object testElement = ObjectFinder.getMatchingElement("testElement", "SamplePageObject");
        assertThat(testElement).isNotNull();
    }

    @Test
    @DisplayName("Test non match of element in page object")
    void getMatchingElementTestWithoutMatch() {
        Object testElement = ObjectFinder.getMatchingElement("noMatch", "SamplePageObject");
        assertThat(testElement).isNull();
    }
}
