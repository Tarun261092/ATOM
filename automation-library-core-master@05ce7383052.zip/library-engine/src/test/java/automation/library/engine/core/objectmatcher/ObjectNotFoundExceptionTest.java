package automation.library.engine.core.objectmatcher;

import org.junit.jupiter.api.Test;
import static org.assertj.core.api.Assertions.assertThat;

public class ObjectNotFoundExceptionTest  {

	@Test
    public void objectNotFoundExceptionTest() {
		assertThat(new ObjectNotFoundException()).isNotNull();
		assertThat(new ObjectNotFoundException("message")).isNotNull();
		assertThat(new ObjectNotFoundException("message", new Throwable("cause"))).isNotNull();
		assertThat(new ObjectNotFoundException(new Throwable("cause"))).isNotNull();
		assertThat(new ObjectNotFoundException("message", new Throwable("cause"), true, true)).isNotNull();       
    }
	
}
