package automation.library.engine.core;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import automation.library.common.TestContext;

public class AutoEngParserTest {
	
	private static TestContext textContext = TestContext.getInstance();
	private static String key = "TestKey";
	private static Object data = "TestData";
	private static String user = "sawgrass_sqlserver_dbUserName";
	private static String pass = "sawgrass_sqlserver_dbPassword";
	private static String userValue = "UDVUSER";
	private static String passValue = "userudv0";
	
	@BeforeAll
	 public static void beforeAllTestMethods() {
		textContext.testdataPut(key, data);
		System.setProperty("cukes.env", "UAT");
		
	}
	
	@Test
    public void parseValueTest() {
		String str = "#(TestKey)";
		assertThat(data).isEqualTo(AutoEngParser.parseValue(str).toString());
    }
	
	@Test
    public void getValueOrVariableTest() {
		String str = "#(TestKey)";
		assertThat(key).isEqualTo(AutoEngParser.getValueOrVariable(str).toString());
    }
	
	@Test
    public void parseUserTest() {
		assertThat(userValue).isEqualTo(AutoEngParser.parseUser(user).toString());
    }
	
	@Test
    public void parseIfVariableTest() {
		String str = "#(sawgrass_sqlserver_dbUserName)";
		assertThat(userValue).isEqualTo(AutoEngParser.parseIfVariable(str).toString());
    }
	
	@Test
    public void parseDictionaryKeyTest() {
		String str = "#(TestKey)";
		assertThat(key).isEqualTo(AutoEngParser.parseDictionaryKey(str).toString());
    }
	
	@Test
    public void parseSecureTextTest() {
		assertThat(passValue).isEqualTo(AutoEngParser.parseSecureText(pass).toString());
    }
	
	@Test
    public void parseValueToObjectExceptionTest() {
		String str = "#(TestKey1)";
		Exception exception = assertThrows(IllegalArgumentException.class, () -> {
			AutoEngParser.parseValueToObject(str);
	    });
		assertThat(exception.getMessage()).isNotNull();
    }
	
	@Test
    public void parseValueToObjectTest() {
		assertThat("TestKey").isEqualTo(AutoEngParser.parseValueToObject(key).toString());
    }
	
	@Test
    public void parseIfVariableTest1() {
		assertThat("sawgrass_sqlserver_dbUserName").isEqualTo(AutoEngParser.parseIfVariable(user).toString());
    }
	
}