package automation.library.engine.core.objectmatcher.rating;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

public class FlatFileObjectRatingTests {
    static FlatFileObjectRating flatFileObjectRating;

    @BeforeAll
    static void setupObject() {
        flatFileObjectRating = new FlatFileObjectRating("test", 1.0, "Found", "List");
    }

    @Test
    void returnsAPIObjectName() {
        assertThat(flatFileObjectRating.getFlatFileObjectName()).isEqualTo("test");
    }

    @Test
    void setAndGetSimilarityScore() {
        flatFileObjectRating.setSimilarityScore(0.5);
        assertThat(flatFileObjectRating.getSimilarityScore()).isEqualTo(0.5);
    }

    @Test
    void setAndGetMessage() {
        flatFileObjectRating.setSearchResultMsg("Found New Object");
        assertThat(flatFileObjectRating.getSearchResultMsg()).isEqualTo("Found New Object");
    }

    @Test
    void setAndGetAPIList() {
        flatFileObjectRating.setFlatFileObjectList("List Of APIs");
        assertThat(flatFileObjectRating.getFlatFileObjectList()).isEqualTo("List Of APIs");
    }

    @Test
    void twoArgConstructor() {
        FlatFileObjectRating flatFileObjectRatingTwoArg = new FlatFileObjectRating("Two Object", 1.0);
        assertThat(flatFileObjectRatingTwoArg.getFlatFileObjectName()).isEqualTo("Two Object");
        assertThat(flatFileObjectRatingTwoArg.getSimilarityScore()).isEqualTo(1.0);
    }
}
