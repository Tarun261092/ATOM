package pageobjects;

import automation.library.common.CommonPageObject;
import org.openqa.selenium.By;

public class SamplePageObject1 extends CommonPageObject {
    private By testElement = By.xpath("//input");

    public Object testElement() {
        return "Found Element";
    }

}
