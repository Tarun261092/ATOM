Feature: ExcelDataValidation
  BD XAMT EndBDUDC
  @ALM_ @BD55 @ExcelValidation
  Scenario: ExcelDataValidation123

    Given user loads the text of the file "MISWorkBasketExtract_200625130000763.txt" into the data dictionary with key "txtData"
    And split the text with pattern "\|" and store value of column "4" where row contains "#(caseId)" from the data dictionary "#(txtData)" into the data dictionary with key "currWorkBasketFile"
    And the user validates "COMPARE_STRINGS" that the data dictionary value of "#(currWorkBasketFile)" is "CONTAINS" "#(currWorkBasket)" "vald1" "HardStopOnFailure"
    And split the text with pattern "\|" and store value of column "5" where row contains "#(caseId)" from the data dictionary "#(txtData)" into the data dictionary with key "dateEnteredWorkbasketFile"
    And the user validates "COMPARE_STRINGS" that the data dictionary value of "#(dateEnteredWorkbasketFile)" is "CONTAINS" "#(dateEnteredWorkbasket)" "vald1" "HardStopOnFailure"
    And the user enters "#(userName)" into the "testElement" textbox at the "SamplePageObject" page

