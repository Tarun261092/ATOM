Feature: Create Notes
  @MongoTest20
  Scenario: postCreateNotesAPI IBS Primary MOB
    #Comment: DB Query for IBS Primary Accounts from DB2 - PID 142
    Given DB connection for application "API_Mongo" is established
    When the user executes the "ReturnMailMongo" query
#    Then store the "city" DB column value into the data dictionary with key "#(city)"
#    Then store index "2" of the "address" DB column value into the data dictionary with key "#(city)"
#    Then store index "0" of the "address" DB column value into the data dictionary with key "mongo_value"
#              Then the user extracts value at index "0" from the JSON array at dictionary key "mongo_value" and stores into dictionary key "Value"
  Then store the "ARRANGEMENTNUMBER" DB column value into the data dictionary with key "Mongo_Acc"
  And store the length of the data dictionary value at "#(Mongo_Acc)" into the data dictionary with key "mongoFldLen"
##  Then store the "PLASTICS" DB column value into the data dictionary with key "Mongo_Add"
##  Then store "city" at index "3" from the JSON payload at dictionary key "Mongo_Add" into the data dictionary with key "City_value"
##  And store "city" from the JSON payload at dictionary key "#(Mongo_Add)" into the data dictionary with key "City_value"
#    And the user validates "COMPARE_NUMBERS" that the data dictionary value of "#(Mongo_Add)" is "Not Equal To" "30" "vald1" "HardStopOnFailure"
    And the user validates "COMPARE_NUMBERS" that the data dictionary value of "#(mongoFldLen)" is "Less Than" "#(mongoFldLen1)" "vald1" "HardStopOnFailure"
    When the user sends request to the "postPersonalInstallLoan" API
    Then the user validates the API response has status code of "200" "Account_Success" "ContinueOnFailure"
#  And store index "1" of the "ADDRESS" DB column value into the data dictionary with key "Add_Mongo"
#              And store "city" from the JSON payload at dictionary key "Mongo_Add" into the data dictionary with key "City_mongo"
#        And store "status" from the JSON payload at dictionary key "Value" into the data dictionary with key "status_mongo"
#        And store "type" from the JSON payload at dictionary key "Value" into the data dictionary with key "type_mongo"
#        And store "channel" from the JSON payload at dictionary key "Value" into the data dictionary with key "channel_mongo"
#        And store "productId" from the JSON payload at dictionary key "Value" into the data dictionary with key "productId_mongo"
           #And DB connection for application "MicroServices_DB2" is closed
#           Given DB connection for application "API_Mongo" is established
#        When the user executes the "Redemption" query
#        Then store index "0" of the "redemptions" DB column value into the data dictionary with key "mongo_value"
#              Then the user extracts value at index "0" from the JSON array at dictionary key "mongo_value" and stores into dictionary key "Value"
#              And store "uuid" from the JSON payload at dictionary key "Value" into the data dictionary with key "uuid_mongo"
#        And store "status" from the JSON payload at dictionary key "Value" into the data dictionary with key "status_mongo"
#        And store "type" from the JSON payload at dictionary key "Value" into the data dictionary with key "type_mongo"
#        And store "channel" from the JSON payload at dictionary key "Value" into the data dictionary with key "channel_mongo"
#        And store "productId" from the JSON payload at dictionary key "Value" into the data dictionary with key "productId_mongo"
#        And DB connection for application "API_Mongo" is closed
#           
#    
 