package automation.library.rpa.api.exception;

public class InvalidPropertyException extends RuntimeException {

	public InvalidPropertyException(String msg) {
		super(msg);
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	

}
