package automation.library.rpa.api.authentication;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.HashMap;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import automation.library.common.EncryptionHelper;
import automation.library.rpa.api.exception.APIException;
import automation.library.rpa.api.exception.InvalidPropertyException;
import automation.library.rpa.api.util.AppConstants;
import automation.library.rpa.api.util.PropertyReaderUtility;

public class Authentication {

	public String token ;
	public Authentication() {
	
	}
	
	public String login(String userName, String password) throws InvalidPropertyException, IOException, InvalidKeyException, NoSuchAlgorithmException, InvalidKeySpecException, NoSuchPaddingException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
		JsonElement je =  JsonParser.parseString(getToken(userName,password));
		if(je.isJsonObject()) {
		JsonObject tokenObj =	je.getAsJsonObject();
		token = tokenObj.get("token").getAsString();
		return token;
		}
		throw new APIException("Unable to login");
		
	}
	public String logout()  throws InvalidPropertyException, IOException{
		URL url = new URL(AppConstants.CONTROL_ROOM_URL+AppConstants.AUTHENTICATE_LOGOUT_ENDPOINT);
		HttpURLConnection connection = (HttpURLConnection) url.openConnection();
		connection.setRequestMethod(AppConstants.HTTP_METHOD_POST);
		connection.setRequestProperty("Content-Type", "application/json; utf-8");
		connection.setRequestProperty( "charset", "utf-8");
		connection.setRequestProperty("X-Authorization", token);
		InputStream is = null;
		  if(connection.getResponseCode()!=204 ) { 
			 
			  BufferedReader br = new BufferedReader(new InputStreamReader(is));
				String response = "";
				String line = null;
				while ((line = br.readLine() )!=null) {
					response = response+line;
				}
			 throw new APIException(response);
		  }
		connection.disconnect();
		return "SuccessFully Logged Out";
	}

	private static String getToken(String userName, String password)  {

		try {
		URL url = new URL(AppConstants.CONTROL_ROOM_URL+AppConstants.AUTHENTICATE_ENDPOINT);
		HttpURLConnection connection = (HttpURLConnection) url.openConnection();
		connection.setRequestMethod(AppConstants.HTTP_METHOD_POST);
		connection.setRequestProperty("Content-Type", "application/json; utf-8");
		
		Map<String , String> credsMap = new HashMap<String, String>();
		credsMap.put(AppConstants.USER_NAME,userName);
		credsMap.put(AppConstants.PASSWORD,password);
		String creds = new Gson().toJson(credsMap);
		
		connection.setDoOutput( true );
		connection.setInstanceFollowRedirects( false );
		connection.setRequestProperty( "charset", "utf-8");
		try(OutputStream os = connection.getOutputStream()) {
		    byte[] input = creds.getBytes("utf-8");
		    os.write(input, 0, input.length);			
		}
		InputStream is = null;
		
		  if(connection.getResponseCode()!=200) { 
			  is= connection.getErrorStream();
			  BufferedReader br = new BufferedReader(new InputStreamReader(is));
				String response = "";
				String line = null;
				while ((line = br.readLine() )!=null) {
					response = response+line;
				}
			 throw new APIException(response);
		  }else {
			  is = connection.getInputStream();
		  }
		 
		BufferedReader br = new BufferedReader(new InputStreamReader(is));
		String response = "";
		String line = null;
		while ((line = br.readLine() )!=null) {
			response = response+line;
		}
		connection.disconnect();
		return response;
		
		}catch (Exception e) {

			 throw new APIException(e.getMessage());
		}
		
	
	}
}
