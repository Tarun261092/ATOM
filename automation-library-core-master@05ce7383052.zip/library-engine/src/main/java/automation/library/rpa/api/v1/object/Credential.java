package automation.library.rpa.api.v1.object;

public class Credential {

	public Credential() {
		// TODO Auto-generated constructor stub
	}

}
