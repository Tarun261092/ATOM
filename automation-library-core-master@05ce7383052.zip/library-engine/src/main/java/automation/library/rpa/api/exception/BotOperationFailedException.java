package automation.library.rpa.api.exception;

public class BotOperationFailedException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8024635908314484978L;

	public BotOperationFailedException() {
		// TODO Auto-generated constructor stub
	}

	public BotOperationFailedException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public BotOperationFailedException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public BotOperationFailedException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public BotOperationFailedException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}
