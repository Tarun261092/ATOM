package automation.library.rpa.api.util;

import java.util.Calendar;
import java.util.TimeZone;

public class AppConstants {
	private static Calendar now = Calendar.getInstance();
    
    //get current TimeZone using getTimeZone method of Calendar class
    private static TimeZone timeZone = now.getTimeZone();
	public static final String BOT_ROOT_PATH = "\\\\namdfs\\rel\\MWD\\GROUPS\\EBizAutomation\\RPA_EMAIL_ATTACHMENTS";	
	public static final String DEVICE_NAME = "R02P93AD000422";
	public static final String USER_NAME = "username";
	public static final String PASSWORD = "password";//encription needed to check
	public static final String DOMAIN = "domain";
	public static final String HTTP_METHOD_POST = "POST";
	public static final String HTTP_METHOD_GET = "GET";
	public static final String CONTENT_TYPE = "Content-Type";
	public static final String CONTENT_TYPE_APPLICATION_JSON_UTF_8 = "application/json; utf-8";

	public static final String CONTROL_ROOM_URL = "https://dev.digitalopsrobotics.2.citigroup.net";
	public static final String AUTHENTICATE_LOGOUT_ENDPOINT ="/v1/authentication/logout";
	public static final String AUTHENTICATE_ENDPOINT = "/v1/authentication";
	public static final String USERS_LIST_ENDPOINT = "/v1/usermanagement/users/list";

	public static final String BOT_DEPLOY_ENDPOINT = "/v3/automations/deploy";
	public static final String BOT_SCHEDULE_DEPLOY_ENDPOINT ="/v1/schedule/automations";

	public static final String UN_ATTENDED_RUNNER_USERS_ENDPOINT = "/v1/devices/runasusers/list";
	public static final String FILE_LIST_ENDPOINT = "/v2/repository/workspaces/private/files/list";
	public static final String DEVICE_LIST_ENDPOINT = "/v2/devices/list"; 
	public static final String FOLDER_LIST_ENDPOINT = "/v1/repository/filefolder/list";
	public static final String DIRECTORY_LIST_ENDPOINT = "/v1/repository/directories";
	public static final String MY_TASKS_FOLDER_PATH = "Automation Anywhere\\My Tasks";
	public static final String USE_CASE_PATH ="\\010061";
	public static final String DIRECTORY_ID = "{directoryid}";
	public static final String USECASE_DIRECTORY_LIST = "/v1/repository/directories/"+DIRECTORY_ID+"/directories";
	public static final String FILE_LIST = "/v1/repository/directories/"+DIRECTORY_ID+"/files/list";//
	public static final String BOT_FILE_NAME = "downloadAttachmentsDbInput.atmx";//"downloadAttachments.atmx"; //"Docusign Excell Data Validation.atmx";//"StringOperationValidation.atmx";
	public static final String DEFAULT_TIME_ZONE = timeZone.getID(); // "Asia/Calcutta";
	public static final String CYPER_KEY = "CityRPA";
	public static final String DB_HOST_NAME = "hostname";
	public static final String DB_PORT = "port";
	public static final String DB_SERVICE_NAME = "servicename";
	public static final String DB_DRIVER = "driver";
	public static final String PATH_TO_DB_CREDENTIALS1 = "automation\\library\\rpa\\api\\util\\DbCredentials.properties";
	public static final String PATH_TO_DB_CREDENTIALS2 = "\\automation\\library\\rpa\\api\\util\\DbCredentials.properties";
	public static final String PATH_TO_DB_CREDENTIALS3 = "DbCredentials.properties";
	public static final String PATH_TO_DB_CREDENTIALS4 = "\\DbCredentials.properties";
	public static final String PATH_TO_DB_CREDENTIALS = "DbCredentials.properties" ;// "\\\\namdfs\\rel\\MWD\\GROUPS\\EBizAutomation\\RPA_BOT_SECURE_INPUT_FILES\\DbCredentils.properties";
	public static final String PATH_TO_BOT_CREDENTIALS =  "\\\\namdfs\\rel\\MWD\\GROUPS\\EBizAutomation\\RPA_BOT_SECURE_INPUT_FILES\\BotCredentils.properties";

	
	public static final String STATUS_REQUESTED = "Requested";
	public static final String STATUS_PROCESSED = "Processed";

	
	private AppConstants() {
		
	}
	 
}
