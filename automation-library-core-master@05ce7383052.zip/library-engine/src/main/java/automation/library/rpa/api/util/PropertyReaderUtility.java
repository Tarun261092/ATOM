package automation.library.rpa.api.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import automation.library.rpa.api.exception.InvalidPropertyException;

public class PropertyReaderUtility {
	private  Map<String, Properties> fileProperties = new HashMap();
	private static PropertyReaderUtility instance = null;
	private PropertyReaderUtility() {
		
	}
	
	private static PropertyReaderUtility getInstance() {
		if(instance == null) {
			instance = new PropertyReaderUtility();
		}
		return instance;
	}
	
	public static Properties getProperties(String pathToPropertyFile) {
	PropertyReaderUtility propertiesReader =	getInstance();
		Properties properties = propertiesReader.fileProperties.get(pathToPropertyFile);
		if(properties==null) {
			InputStream is = propertiesReader.getClass().getResourceAsStream(pathToPropertyFile);
			
			//InputStream is = propertiesReader.getClass().getClassLoader().getResourceAsStream(pathToPropertyFile);
			properties = new Properties();
			try {
				properties.load(is);
				propertiesReader.fileProperties.put(pathToPropertyFile, properties);
			} catch (Exception e) {
				e.printStackTrace();
				properties = null;
			}
		}
		return properties;
		
	}

	public static Properties getProperties(String pathToPropertyFile , boolean isAbsolutePath) {
		if(isAbsolutePath) {
			PropertyReaderUtility propertiesReader =	getInstance();
			Properties properties = propertiesReader.fileProperties.get(pathToPropertyFile);
			File file = new File (pathToPropertyFile);
			if(properties==null) {
				try (InputStream is = new FileInputStream(file);) {
				properties = new Properties();
				properties.load(is);
					propertiesReader.fileProperties.put(pathToPropertyFile, properties);
				} catch (IOException e) {
					e.printStackTrace();
					properties = null;
				}
			}
			return properties;
			
		
		}else {
			return getProperties(pathToPropertyFile);	
		}
	}
	public static  String getPropertyValue(String pathToPropertyFile , String propertyKey) throws InvalidPropertyException {
		
		Properties properties =  getProperties(pathToPropertyFile);
		if(properties!=null) {
			String value =  (String) properties.get(propertyKey);
			if(value ==null) {

				throw new InvalidPropertyException(propertyKey+" property not found");
			}
			return value;
		}
		throw new InvalidPropertyException(pathToPropertyFile+" Properties File not found");
	}
	
	public static  String getPropertyValue(String pathToPropertyFile , String propertyKey, boolean isAbsolutePath) throws InvalidPropertyException {
		
		Properties properties =  getProperties(pathToPropertyFile,isAbsolutePath);
		if(properties!=null) {
			String value =  (String) properties.get(propertyKey);
			if(value ==null) {

				throw new InvalidPropertyException(propertyKey+" property not found");
			}
			return value;
		}
		throw new InvalidPropertyException(pathToPropertyFile+" Properties File not found");
	}

}
