package automation.library.rpa.api.repositoryManagement;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import automation.library.rpa.api.util.AppConstants;

public class FileRepositoryManagement {
///v1/repository/filefolder/list 
	public FileRepositoryManagement() {
	
	}
	
	public static String getListOfFolders(String token ) throws IOException {

		
		URL url = new URL(AppConstants.CONTROL_ROOM_URL+AppConstants.DIRECTORY_LIST_ENDPOINT);// "https://dev.digitalopsrobotics.2.citigroup.net/v1/authentication");
		HttpURLConnection connection = (HttpURLConnection) url.openConnection();
		connection.setRequestMethod("GET");
		connection.setRequestProperty("Content-Type", "application/json; utf-8");

		connection.setRequestProperty("X-Authorization", token);
	
	//	String creds = "";
		//connection.setDoOutput( true );
		connection.setInstanceFollowRedirects( false );
		connection.setRequestProperty( "charset", "utf-8");
		/*
		 * try(OutputStream os = connection.getOutputStream()) { byte[] input =
		 * creds.getBytes("utf-8"); os.write(input, 0, input.length); }
		 */	
		InputStream is = null;
		 if(connection.getResponseCode()==201) { 
		 is= connection.getInputStream();
		 }
		else if(connection.getResponseCode()!=200) { 
			  is =connection.getErrorStream();
		  }else {
			  is = connection.getInputStream();
		  }
		BufferedReader br = new BufferedReader(new InputStreamReader(is));
		String response = "";
		String line = null;
		while ((line = br.readLine() )!=null) {
			response = response+line;
		}
		connection.disconnect();
		return response;
	
	}
public static String getListOfUseCaseFolders(String token,String folderId ) throws IOException {

		URL url = new URL(AppConstants.CONTROL_ROOM_URL+((AppConstants.USECASE_DIRECTORY_LIST).replace(AppConstants.DIRECTORY_ID, folderId)));// "https://dev.digitalopsrobotics.2.citigroup.net/v1/authentication");
		HttpURLConnection connection = (HttpURLConnection) url.openConnection();
		connection.setRequestMethod("GET");
		connection.setRequestProperty("Content-Type", "application/json; utf-8");

		connection.setRequestProperty("X-Authorization", token);
	
	//	String creds = "";
		//connection.setDoOutput( true );
		connection.setInstanceFollowRedirects( false );
		connection.setRequestProperty( "charset", "utf-8");
		/*
		 * try(OutputStream os = connection.getOutputStream()) { byte[] input =
		 * creds.getBytes("utf-8"); os.write(input, 0, input.length); }
		 */	
		InputStream is = null;
		 if(connection.getResponseCode()==201) { 
		 is= connection.getInputStream();
		 }
		else if(connection.getResponseCode()!=200) { 
			  is =connection.getErrorStream();
		  }else {
			  is = connection.getInputStream();
		  }
		BufferedReader br = new BufferedReader(new InputStreamReader(is));
		String response = "";
		String line = null;
		while ((line = br.readLine() )!=null) {
			response = response+line;
		}
		connection.disconnect();
		return response;
	
	}

	public static String getListOfFIles(String token, String parentFolderId,String botFileName) throws IOException {

		URL url = new URL(AppConstants.CONTROL_ROOM_URL+AppConstants.FILE_LIST.replace(AppConstants.DIRECTORY_ID, parentFolderId));// "https://dev.digitalopsrobotics.2.citigroup.net/v1/authentication");
		HttpURLConnection connection = (HttpURLConnection) url.openConnection();
		connection.setRequestMethod("POST");
		connection.setRequestProperty("Content-Type", "application/json; utf-8");

		connection.setRequestProperty("X-Authorization", token);
		
		String creds = "{" + 
				"    \"sort\": [" + 
				"        {" + 
				"            \"field\": \"directory\"," + 
				"            \"direction\": \"desc\"" + 
				"        }," + 
				"        {" + 
				"            \"field\": \"name\"," + 
				"            \"direction\": \"asc\"" + 
				"        }" + 
				"    ]," + 
				"    \"filter\": {" + 
				"        \"operator\": \"eq\"," + 
				"        \"value\": \""+botFileName+"\"," + 
				"        \"field\": \"name\"" + 
				"    }," + 
				"    \"fields\": []," + 
				"    \"page\": {" + 
				"        \"offset\": 0," + 
				"        \"total\": 722," + 
				"        \"totalFilter\": 1," + 
				"        \"length\": 200" + 
				"    }" + 
				"}";
		connection.setDoOutput( true );
		connection.setInstanceFollowRedirects( false );
		connection.setRequestProperty( "charset", "utf-8");

		try (OutputStream os = connection.getOutputStream()) {
			byte[] input = creds.getBytes("utf-8");
			os.write(input, 0, input.length);
		}
	 	InputStream is = null;
		 if(connection.getResponseCode()==201) { 
		 is= connection.getInputStream();
		 }
		else if(connection.getResponseCode()!=200) { 
			  is =connection.getErrorStream();
		  }else {
			  is = connection.getInputStream();
		  }
		BufferedReader br = new BufferedReader(new InputStreamReader(is));
		String response = "";
		String line = null;
		while ((line = br.readLine() )!=null) {
			response = response+line;
		}
		connection.disconnect();
		return response;
	
	}

}
