package automation.library.rpa.api.authentication;

import java.io.IOException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.TimeZone;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.shapesecurity.salvation2.Values.Hash;

import automation.library.common.EncryptionHelper;
import automation.library.common.Property;
import automation.library.cucumber.core.Constants;
import automation.library.rpa.api.deploy.BotDeployer;
import automation.library.rpa.api.exception.BotOperationFailedException;
import automation.library.rpa.api.exception.InvalidPropertyException;
import automation.library.rpa.api.repositoryManagement.FileRepositoryManagement;
import automation.library.rpa.api.usermanagement.UserManagement;
import automation.library.rpa.api.util.AppConstants;
import automation.library.rpa.api.util.PropertyReaderUtility;
import automation.library.rpa.api.v1.enums.AutomationStatus;
import automation.library.rpa.api.v1.enums.ScheduleType;
import automation.library.rpa.api.v1.object.BotRequest;
import automation.library.rpa.api.v1.object.Schedule;

public class AutomationAnywhereApp {
	private static Map<String, String> statusMap = new HashMap<String, String>();
	static {
		statusMap.put("NMF", "Mail with Given Subject Is Not Yet Received Or Not Found");

		statusMap.put("NAF", "Mail with Given Subject Doesn't contains Attachment");

		statusMap.put("Processed", "Attachment Downloaded Successfully");

		statusMap.put("Requested", "Processing Downloading Attachment From Mail");
	}
	protected static final Logger log =  LogManager.getLogger(AutomationAnywhereApp.class);


	public String triggerDownloadEmailAttachmentBot(String soeid, String mailSubject)
			throws BotOperationFailedException {
		try {
			Integer requestId = createBotRequest(soeid, mailSubject);

			if (requestId != null) {


				String userName = Property.getProperty(Constants.ALMPROPERTIESPATH, "aLMUser");


				String password = EncryptionHelper.parseSecureText(Constants.SECURE_ALMPROPERTIESPATH, "password");
				BotRequest reqObj = new BotRequest();

				/*
				 * reqObj.setUserName(PropertyReaderUtility.getPropertyValue(AppConstants.
				 * PATH_TO_BOT_CREDENTIALS, AppConstants.DOMAIN,true) + "\\\\" +
				 * PropertyReaderUtility.getPropertyValue(AppConstants.PATH_TO_BOT_CREDENTIALS,
				 * AppConstants.USER_NAME,true));
				 * 
				 * 
				 * 
				 * reqObj.setPassword(EncryptionHelper.parseSecureText(PropertyReaderUtility
				 * .getPropertyValue(AppConstants.PATH_TO_BOT_CREDENTIALS,
				 * AppConstants.PASSWORD,true)));
				 */


				reqObj.setUserName("NAM\\\\" +userName);
				reqObj.setPassword(password);


				reqObj.setHostName(AppConstants.DEVICE_NAME);
				reqObj.setBotPath(AppConstants.MY_TASKS_FOLDER_PATH);
				reqObj.setBotName(AppConstants.BOT_FILE_NAME);
				reqObj.setUseCaseNo(AppConstants.USE_CASE_PATH);
				triggerBot(reqObj);
				checkRequestStatus(requestId);
				return requestId.toString();
			}
			throw new BotOperationFailedException("UNABLE TO CREATE REQUEST");
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e.getMessage());
			throw new BotOperationFailedException(e.getMessage());
		}
	}


	public void triggerBot(BotRequest reqObj)
			throws IOException, InvalidKeyException, InvalidPropertyException, NoSuchAlgorithmException,
			InvalidKeySpecException, NoSuchPaddingException, InvalidAlgorithmParameterException,
			IllegalBlockSizeException, BadPaddingException, BotOperationFailedException {
		Authentication auth = new Authentication();
		final String token = auth.login(reqObj.getUserName(), reqObj.getPassword());
		JsonElement deviceResponseElement = JsonParser
				.parseString(UserManagement.listDevices(token, reqObj.getHostName()));// AppConstants.DEVICE_NAME));
		JsonArray devicesList = deviceResponseElement.getAsJsonObject().get("list").getAsJsonArray();
		if (devicesList != null) {
			final String deviceId = devicesList.get(0).getAsJsonObject().get("id").getAsString();
			ArrayList<String> deviceIDs = new ArrayList<String>();
			deviceIDs.add(deviceId);

			JsonElement folderResponseElement = JsonParser
					.parseString(FileRepositoryManagement.getListOfFolders(token));
			JsonArray folderList = folderResponseElement.getAsJsonArray();
			final String folderId = getFolderId(folderList, reqObj.getBotPath());// AppConstants.MY_TASKS_FOLDER_PATH);

			JsonElement useCaseFolderResponseElement = JsonParser
					.parseString(FileRepositoryManagement.getListOfUseCaseFolders(token, folderId));
			JsonArray useCaseFolderList = useCaseFolderResponseElement.getAsJsonArray();
			final String useCaseFolderId = getFolderId(useCaseFolderList, reqObj.getBotPath() + reqObj.getUseCaseNo());// AppConstants.MY_TASKS_FOLDER_PATH);
			JsonElement fileRes = JsonParser
					.parseString(FileRepositoryManagement.getListOfFIles(token, useCaseFolderId, reqObj.getBotName()));
			JsonObject fileResObj = fileRes.getAsJsonObject();
			JsonArray fileList = fileResObj.get("list").getAsJsonArray();

			if (fileList != null && fileList.size() > 0) {
				final String fileID = fileList.get(0).getAsJsonObject().get("id").getAsString();
				Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone(AppConstants.DEFAULT_TIME_ZONE));
				final String currentDate = calendar.get(Calendar.YEAR) + "-" + (calendar.get(Calendar.MONTH) + 1) + "-"
						+ ((calendar.get(Calendar.DATE)));

				Schedule sc = new Schedule("API_" + fileID + "_" + currentDate, fileID, AutomationStatus.ACTIVE.name(),
						deviceIDs, fileID + "|" + currentDate, false, AppConstants.DEFAULT_TIME_ZONE, currentDate,
						ScheduleType.INSTANT.name());
				JsonElement botResponse = JsonParser.parseString(new BotDeployer().scheduleBot(token, sc));
				if(!"Completed".equalsIgnoreCase(botResponse.getAsJsonObject().get("status").getAsString())) {

					log.debug(botResponse.getAsJsonObject().get("status").getAsString());	
				}

			}

		}
		auth.logout();
		log.debug("Processing OutLook and Looking for Attachment ........");
		//return getResponse();

	}

	private static String getFolderId(JsonArray folderList, String myTasksFolderPath) {
		for (int i = 0; i < folderList.size(); i++) {
			JsonElement folderListElement =  folderList.get(i);
			JsonObject js= folderListElement.getAsJsonObject();
			if(js !=null && js.has("path") && myTasksFolderPath.equals(js.get("path").getAsString())){
				return js.get("id").getAsString();
			}
		}	

		throw new RuntimeException("Folder NOT FOUND");
	}

	private Integer createBotRequest(String soeid, String mailSubject) throws BotOperationFailedException {
		String dbConnectionString = getConnectionString(AppConstants.PATH_TO_DB_CREDENTIALS);
		String userName = PropertyReaderUtility.getPropertyValue(AppConstants.PATH_TO_DB_CREDENTIALS,
				AppConstants.USER_NAME);
		String password = EncryptionHelper.parseSecureText(
				PropertyReaderUtility.getPropertyValue(AppConstants.PATH_TO_DB_CREDENTIALS, AppConstants.PASSWORD));

		if (dbConnectionString != null && userName != null && password != null) {

			try (Connection conn = DriverManager.getConnection(dbConnectionString, userName, password)){

				if (conn != null) {

					String query = "insert into EMAIL_FILE_RPA (EMAIL_SUB, REQ_STATUS, SOEID) values (?,?,?)";

					try(PreparedStatement pstmt = conn.prepareStatement(query);){
						pstmt.setString(1, mailSubject);
						pstmt.setString(2, "Requested");
						pstmt.setString(3, soeid);
						int status = pstmt.executeUpdate();
						if(status!=0) {
							try(PreparedStatement pstmt2 = conn.prepareStatement("select MAX(REQUESTID) from EMAIL_FILE_RPA where SOEID = ?");){
								pstmt2 .setString(1, soeid);
								ResultSet rs = pstmt2.executeQuery();
								if (rs != null && rs.next()) {

									return rs.getInt(1);
								}
							}catch(Exception e) {
								
							}
						}
					}
				}

			} catch (SQLException e) {
				e.printStackTrace();
				log.debug("Error While Establishing database connection :"+e.getMessage());

			}
		}
		throw new BotOperationFailedException("UNABLE TO CREATE REQUEST");
	}
	private String getConnectionString(String path) throws InvalidPropertyException {

		String hostName = PropertyReaderUtility.getPropertyValue(path, AppConstants.DB_HOST_NAME);
		String port = PropertyReaderUtility.getPropertyValue(path, AppConstants.DB_PORT);
		String serviceName = PropertyReaderUtility.getPropertyValue(path, AppConstants.DB_SERVICE_NAME);
		String driver = PropertyReaderUtility.getPropertyValue(path, AppConstants.DB_DRIVER);
		return driver.concat("@").concat(hostName).concat(":").concat(port).concat("/").concat(serviceName);

	}

	private String checkRequestStatus(Integer requestId) throws BotOperationFailedException {

		Boolean isCompleted = false;
		String status = null;
		Long startTime = new Date().getTime();
		long every2Sec = 30000;
		while (!isCompleted) {
			Long currentTime = new Date().getTime();
			if ((currentTime - startTime) > every2Sec) {
				every2Sec = (currentTime - startTime) + 20000;
				status = getCurrentRequestStatus(requestId);
				if (status != null && AppConstants.STATUS_PROCESSED.equalsIgnoreCase(status)) {
					isCompleted = true;
				} else if (status != null && !AppConstants.STATUS_REQUESTED.equalsIgnoreCase(status)) {

					String statusVal = statusMap.get(status);
					throw new BotOperationFailedException((statusVal!=null)?statusVal:status);
				}
			}
		}
		return status;
	}
	private String getCurrentRequestStatus(Integer requestId) {
		String dbConnectionString = getConnectionString(AppConstants.PATH_TO_DB_CREDENTIALS);
		String userName = PropertyReaderUtility.getPropertyValue(AppConstants.PATH_TO_DB_CREDENTIALS,
				AppConstants.USER_NAME);

		String password = EncryptionHelper.parseSecureText(
				PropertyReaderUtility.getPropertyValue(AppConstants.PATH_TO_DB_CREDENTIALS, AppConstants.PASSWORD));
		if (dbConnectionString != null && userName != null && password != null) {

			try(Connection conn = DriverManager.getConnection(dbConnectionString, userName, password);
					PreparedStatement pstmt = conn.prepareStatement("select REQ_STATUS from EMAIL_FILE_RPA where REQUESTID = ?");) {

					pstmt .setInt(1, requestId);
					ResultSet rs = pstmt.executeQuery();
					if (rs != null && rs.next()) {
						if("Processed".equalsIgnoreCase(rs.getString(1))) {
							log.debug("Status : " + rs.getString(1));
						}
						return rs.getString(1);
					}


			} catch (SQLException | NullPointerException e) {
				e.printStackTrace();
				log.debug("Error While Establishing database connection :"+e.getMessage());

			}
		}
		return null;

	}
}
