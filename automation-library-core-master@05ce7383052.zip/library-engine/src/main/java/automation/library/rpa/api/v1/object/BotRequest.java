package automation.library.rpa.api.v1.object;

import java.io.Serializable;

public class BotRequest implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 4739563383642232459L;

	public BotRequest() {
	}
	private String userName;
	private	String password;
	private	String hostName;
	private	String botPath;
	private	String botName;
	private	String useCaseNo;

	
	public String getUseCaseNo() {
		return useCaseNo;
	}
	public void setUseCaseNo(String useCaseNo) {
		this.useCaseNo = useCaseNo;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getHostName() {
		return hostName;
	}
	public void setHostName(String hostName) {
		this.hostName = hostName;
	}
	public String getBotPath() {
		return botPath;
	}
	public void setBotPath(String botPath) {
		this.botPath = botPath;
	}
	public String getBotName() {
		return botName;
	}
	public void setBotName(String botName) {
		this.botName = botName;
	}
	
	
	

}
