/**
 * 
 */
package automation.library.rpa.api.v1.object;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * @author 
 *
 */
public class Schedule implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String name;
	private String fileId ;// 35872;
	private String  status ;// ACTIVE;
	private ArrayList<String>  deviceIds ;
	private String   description ;// Test Run;
	private Boolean   rdpEnabled;// false;
	private String  timeZone ;// Asia/Calcutta;
	private String  startDate ;// 2021-10-06;
	private String  scheduleType;
	
	public Schedule(String name, String fileId, String status, ArrayList<String> deviceIds, String description,
			Boolean rdpEnabled, String timeZone, String startDate, String scheduleType) {
		super();
		this.name = name;
		this.fileId = fileId;
		this.status = status;
		this.deviceIds = deviceIds;
		this.description = description;
		this.rdpEnabled = rdpEnabled;
		this.timeZone = timeZone;
		this.startDate = startDate;
		this.scheduleType = scheduleType;
		
	}
	private String getDeviceIds() {
		if(deviceIds!=null) {
			return deviceIds.toString().replace('[', '"').replace(']', '"').replace(", ", "\",\"");
		}
		return "\"\"";
	}
	public String getPayload(){
		
		String payload = "{" + 
				"\"name\": \""+name+"\"," + 
				"\"fileId\": \""+fileId+"\"," + 
				"\"status\": \""+status+"\"," + 
				"\"deviceIds\": [" + 
				 getDeviceIds()+
				"]," + 
				"\"description\": \""+description+"\"," + 
				"\"rdpEnabled\": "+rdpEnabled+"," + 
				"\"timeZone\": \""+timeZone+"\"," + 
				"\"startDate\": \""+startDate+"\"," + 
				"\"scheduleType\": \""+scheduleType+"\"" + 
				"}";
		return payload;
	
	}
}
