package automation.library.rpa.api.v1.enums;

public enum ScheduleType {
	NONE, 
	INSTANT,
	DAILY,
	WEEKLY, 
	MONTHLY;

}
