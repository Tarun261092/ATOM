package automation.library.rpa.api.v1.enums;

public enum AutomationStatus {
	ACTIVE, 
	INACTIVE;
}
