package automation.library.engine.core.validator;

import automation.library.common.TestContext;
import automation.library.engine.core.validator.managers.*;
import automation.library.reporting.Reporter;
import automation.library.tlm.TlmContext;
import automation.library.tlm.common.entity.TlmRunStep;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import static automation.library.engine.core.AutoEngConstants.VALIDATION_TAG;

public class AssertHelper {
    private ThreadLocal<ValidatorManager> validatorManager = new InheritableThreadLocal<>();
    private ThreadLocal<ComparisonType> comparisonType = new InheritableThreadLocal<>();
    private ThreadLocal<ComparisonOperator> comparisonOperator = new InheritableThreadLocal<>();
    private ThreadLocal<String> onFailureFlag = new InheritableThreadLocal<>();
    protected Logger log = LogManager.getLogger(this.getClass().getName());

    public AssertHelper(String comparisonType, String comparisonOperator, String onFailureFlag) {
        this.comparisonType.set(ComparisonType.valueOfLabel(comparisonType));
        this.comparisonOperator.set(ComparisonOperator.valueOfLabel(comparisonOperator));
        this.validatorManager.set(setValidator(onFailureFlag));
        this.onFailureFlag.set(onFailureFlag);
    }

    public AssertHelper(ComparisonType comparisonType, ComparisonOperator comparisonOperator, String onFailureFlag) {
        this.comparisonType.set(comparisonType);
        this.comparisonOperator.set(comparisonOperator);
        this.validatorManager.set(setValidator(onFailureFlag));
        this.onFailureFlag.set(onFailureFlag);
    }

    private ValidatorManager setValidator(String onFailureFlag) {
        switch (comparisonType.get()) {
            case COMPARE_DATES:
                return new DateValidator(onFailureFlag);
            case COMPARE_STRINGS:
                return new StringValidator(onFailureFlag);
            case COMPARE_NUMBERS:
                return new NumberValidator(onFailureFlag);
            case COMPARE_LISTS:
                return new ListValidator(onFailureFlag);
            case COMPARE_API_RESPONSE:
                return new APIValidator(onFailureFlag);
            default:
                throw new IllegalArgumentException(String.format("Comparison Type of '%s' not supported", comparisonType.get()));
        }
    }

    public void performValidation(Object actual, Object expected, String validationId, String assertMsg) {
        setExpectedAndActual(actual, expected, validationId);

        try {
            switch (comparisonOperator.get()) {
                case EQ:
                    this.validatorManager.get().assertEquals(actual, expected, assertMsg);
                    break;
                case EQIC:
                    this.validatorManager.get().assertEqualsIgnoreCase(actual, expected, assertMsg);
                    break;
                case NE:
                    this.validatorManager.get().assertNotEquals(actual, expected, assertMsg);
                    break;
                case GT:
                    this.validatorManager.get().assertGreaterThan(actual, expected, assertMsg);
                    break;
                case LT:
                    this.validatorManager.get().assertLessThan(actual, expected, assertMsg);
                    break;
                case GTE:
                    this.validatorManager.get().assertGreaterThanOrEqual(actual, expected, assertMsg);
                    break;
                case LTE:
                    this.validatorManager.get().assertLessThanOrEqual(actual, expected, assertMsg);
                    break;
                case CONTAINS:
                    this.validatorManager.get().assertContains(actual, expected, assertMsg);
                    break;
                case NOT_CONTAINS:
                    this.validatorManager.get().assertDoesNotContain(actual, expected, assertMsg);
                    break;
            }

            if (!TestContext.getInstance().sa().wasSuccess() &&
                this.onFailureFlag.get().equalsIgnoreCase("ContinueOnFailure")) {
                Reporter.addStepLog("FAIL", getResultMessage(actual.toString(), expected.toString()));
            }

            cleanUpThreadLocal();
        } catch (AssertionError e) {
            log.error(e.getMessage());
            throw e;
        }
    }

    private void cleanUpThreadLocal() {
        validatorManager.remove();
        comparisonType.remove();
        comparisonOperator.remove();
        onFailureFlag.remove();
    }

    public String getResultMessage(String actual, String expected) {
        return String.format("%s -> Expecting \"%s\" to be %s \"%s\".",
                             comparisonType.get(),
                             actual,
                             comparisonOperator.get().label.toLowerCase(),
                             expected);
    }

    private void setExpectedAndActual(Object actual, Object expected, String validationID) {
        String expectedResult = String.format("Expected value: \"%s\"", getResultAsString(expected));
        String actualResult = String.format("Actual value: \"%s\"", getResultAsString(actual));

        Reporter.addStepLog(expectedResult);
        Reporter.addStepLog(actualResult);
        log.debug(expectedResult);
        log.debug(actualResult);

        if (TlmContext.getInstance().updateTlmFlag()) {
            TlmContext.getInstance().getTlmManager().addLastStep(new TlmRunStep(expectedResult, actualResult));
        }

        TestContext.getInstance().testdataPut(VALIDATION_TAG + validationID,
                                              getResultMessage(actual.toString(), expected.toString()));
    }

    private Object getResultAsString(Object result) {
        if (comparisonType.get() == ComparisonType.COMPARE_NUMBERS) {
            return Double.parseDouble(result.toString());
        } else {
            return result;
        }
    }
}
