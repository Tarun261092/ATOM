package automation.library.engine.web.steps;

import automation.library.common.FileHelper;
import automation.library.common.TestContext;
import automation.library.engine.core.validator.AssertHelper;
import automation.library.engine.core.validator.ComparisonOperator;
import automation.library.engine.core.validator.ComparisonType;
import automation.library.engine.web.BaseWebSteps;
import automation.library.reporting.Reporter;
import automation.library.selenium.core.Element;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import automation.library.cucumber.core.Constants;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.util.*;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbookFactory;

import static automation.library.engine.core.AutoEngConstants.VALIDATION_TAG;
import static org.assertj.core.api.Assertions.assertThat;

public class AutoEngWebValidate extends BaseWebSteps {

	private static final String HARD_STOP_ON_FAILURE = "HardStopOnFailure";
	private static final String STATUS_FAIL = "FAIL";
	private static final String VALIDATION_FAILED = "Validation Failed: ";
	private static final String SCRIPT_FILE_PATH_TO_LOG_VALIDATION = "/ff-lookup/LogValidationMacroTool/PCF.vbs";
	private static final String MACRO_FILE_PATH_TO_LOG_VALIDATION = "/ff-lookup/LogValidationMacroTool/PCF_Log_Validation.xlsm";

	@Then("^the user validates the \"([^\"]*)\" element is disabled at the \"([^\"]*)\" page \"([^\"]*)\" \"([^\"]*)\"$")
	public void theUserValidatesTheElementIsDisabledAtThePage(String objectName,
			String pageName,
			String validationID,
			String onFailureFlag) {

		final boolean isElementEnabled = getObject(objectName, pageName).element().isEnabled();
		final String compareDescription = String.format("Expected %s to be disabled at the %s page", objectName, pageName);

		TestContext.getInstance().testdata().put(VALIDATION_TAG + validationID, compareDescription + ": " + isElementEnabled);

		if (onFailureFlag.equals(HARD_STOP_ON_FAILURE)) {
			assertThat(isElementEnabled).as(compareDescription).isFalse();
		} else {
			sa().assertThat(isElementEnabled).as(compareDescription).isFalse();
			if (isElementEnabled) {
				Reporter.addStepLog(STATUS_FAIL, VALIDATION_FAILED + compareDescription);
			}
		}
	}

	@Then("^the user validates the \"([^\"]*)\" element is enabled at the \"([^\"]*)\" page \"([^\"]*)\" \"([^\"]*)\"$")
	public void theUserValidatesTheElementIsEnabledAtThePage(String objectName,
			String pageName,
			String validationID,
			String onFailureFlag) {

		final boolean isElementEnabled = getObject(objectName, pageName).element().isEnabled();
		final String compareDescription = String.format("Expecting %s to be enabled at the %s page", objectName, pageName);

		TestContext.getInstance().testdata().put(VALIDATION_TAG + validationID, compareDescription + ": " + isElementEnabled);

		if (onFailureFlag.equals(HARD_STOP_ON_FAILURE)) {
			assertThat(isElementEnabled).as(compareDescription).isTrue();
		} else {
			sa().assertThat(isElementEnabled).as(compareDescription).isTrue();
			if (isElementEnabled) {
				Reporter.addStepLog(STATUS_FAIL, VALIDATION_FAILED + compareDescription);
			}
		}
	}

	@Then("^the user validates the \"([^\"]*)\" element is not visible at the \"([^\"]*)\" page \"([^\"]*)\" \"([^\"]*)\"$")
	public void theUserValidatesTheElementIsNotVisibleAtThePage(String objectName,
			String pageName,
			String validationID,
			String onFailureFlag) {

		final boolean isElementVisible = getObject(objectName, pageName).element().isDisplayed();
		final String compareDescription = String.format("Expecting %s to not be visible at the %s page", objectName, pageName);

		TestContext.getInstance().testdata().put(VALIDATION_TAG + validationID, compareDescription + ": " + isElementVisible);

		if (onFailureFlag.equals(HARD_STOP_ON_FAILURE)) {
			assertThat(isElementVisible).as(compareDescription).isFalse();
		} else {
			sa().assertThat(isElementVisible).as(compareDescription).isFalse();
			if (isElementVisible) {
				Reporter.addStepLog(STATUS_FAIL, VALIDATION_FAILED + compareDescription);
			}
		}
	}

	@Then("^the user validates the \"([^\"]*)\" element is visible at the \"([^\"]*)\" page \"([^\"]*)\" \"([^\"]*)\"$")
	public void theUserValidatesTheElementIsVisibleAtThePage(String objectName,
			String pageName,
			String validationID,
			String onFailureFlag) {

		final boolean isElementVisible = getObject(objectName, pageName).element().isDisplayed();
		final String compareDescription = String.format("Expecting %s to be visible at the %s page", objectName, pageName);

		TestContext.getInstance().testdata().put(VALIDATION_TAG + validationID, compareDescription + ": " + isElementVisible);

		if (onFailureFlag.equals(HARD_STOP_ON_FAILURE)) {
			assertThat(isElementVisible).as(compareDescription).isTrue();
		} else {
			sa().assertThat(isElementVisible).as(compareDescription).isTrue();
			if (!isElementVisible) {
				Reporter.addStepLog(STATUS_FAIL, VALIDATION_FAILED + compareDescription);
			}
		}
	}

	@Then("^the user validates the \"([^\"]*)\" element is not clickable at the \"([^\"]*)\" page \"([^\"]*)\" \"([^\"]*)\"$")
	public void theUserValidatesTheElementIsNotClickableAtThePage(String objectName, String pageName,
			String validationID, String onFailureFlag) {

		final boolean isElementNotClickable = getObject(objectName, pageName).isNotClickable();
		final String compareDescription = String.format("Expecting %s to be not clickable at the %s page", objectName,
				pageName);

		TestContext.getInstance().testdata().put(VALIDATION_TAG + validationID,
				compareDescription + ": " + isElementNotClickable);

		if (onFailureFlag.equals(HARD_STOP_ON_FAILURE)) {
			assertThat(isElementNotClickable).as(compareDescription).isFalse();
		} else {
			sa().assertThat(isElementNotClickable).as(compareDescription).isFalse();
			if (isElementNotClickable) {
				Reporter.addStepLog(STATUS_FAIL, VALIDATION_FAILED + compareDescription);
			}
		}
	}

	@Then("^the user validates \"([^\"]*)\" that the \"([^\"]*)\" element is \"([^\"]*)\" \"([^\"]*)\" at the \"([^\"]*)\" page \"([^\"]*)\" \"([^\"]*)\"$")
	public void theUserValidatesThatTheElementIs(String comparisonType,
			String objectName,
			String comparisonOperator,
			String expectedValue,
			String pageName,
			String validationID,
			String onFailureFlag) {

		String actualValue = getTextFromElement(getObject(objectName, pageName));
		expectedValue = parseValue(expectedValue);
		AssertHelper validator = new AssertHelper(comparisonType, comparisonOperator, onFailureFlag);
		validator.performValidation(actualValue, expectedValue,
				validationID,
				String.format("'%s' element value validation", objectName));

	}

	@Then("^the user validates that the \"([^\"]*)\" element is equal to the concatenated string of \"([^\"]*)\" at the \"([^\"]*)\" page \"([^\"]*)\" \"([^\"]*)\"$")
	public void theUserValidatesThatTheElementIsEqualToConcatenatedString(String objectName,
			String expectedValues,
			String pageName,
			String validationID,
			String onFailureFlag) {
		//route to existing comparison method
		theUserValidatesThatTheElementIs("Compare_Strings",
				objectName,
				"Equal To",
				getConcatenatedVal(expectedValues, "\\|", " "),
				pageName,
				validationID,
				onFailureFlag);
	}

	@Then("^the user validates that \"([^\"]*)\" is present in the system dialog pop up \"([^\"]*)\" \"([^\"]*)\"$")
	public void theUserValidatesThatIsPresentInTheSystemDialogPopUp(String textToValidate,
			String validationID,
			String onFailureFlag) {

		try {
			long keyToPressDelay = Integer.parseInt(System.getProperty("fw.keyToPressDelay"));
			Thread.sleep(keyToPressDelay);
		} catch (InterruptedException e) {
			log.error(e.getMessage());
			Thread.currentThread().interrupt();
		}
		textToValidate = parseValue(textToValidate);
		String actualAlertText = getDriver().switchTo().alert().getText();
		AssertHelper validator = new AssertHelper(ComparisonType.COMPARE_STRINGS, ComparisonOperator.CONTAINS, onFailureFlag);
		validator.performValidation(actualAlertText, textToValidate,
				validationID,
				String.format("'%s' text present in system dialog pop up", textToValidate));

	}

	@Then("^the user validates the \"([^\"]*)\" table is present on the \"([^\"]*)\" page \"([^\"]*)\" \"([^\"]*)\"$")
	public void theUserValidatesTheTableIsPresentOnThePage(String tableName,
			String pageName,
			String validationID,
			String onFailureFlag) {

		final String compareDesc = String.format("Expecting the %s table to be present on the page: %s. ",
				tableName, pageName);

		TestContext.getInstance().testdata().put(VALIDATION_TAG + validationID,
				compareDesc + (getObject(tableName, pageName) != null));

		if (onFailureFlag.equals(HARD_STOP_ON_FAILURE)) {
			assertThat(getObject(tableName, pageName).refind()).as(compareDesc).isNotNull();
		} else {
			sa().assertThat(getObject(tableName, pageName).refind()).as(compareDesc).isNotNull();
			if (getObject(tableName, pageName).refind() == null) {
				Reporter.addStepLog(STATUS_FAIL, VALIDATION_FAILED + compareDesc);
			}
		}

	}

	@Then("^the user validates the \"([^\"]*)\" table at the \"([^\"]*)\" page sorted in \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void theUserValidatesTheTableAtThePageSortedIn(String tableName,
			String pageName,
			String sortOrder,
			String validationID,
			String onFailureFlag) {
		List<Element> theList = getObject(tableName, pageName).getAllRows();

		String compareDesc = "Expecting the %s table to be sorted in %s order. ";
		TestContext.getInstance().testdata().put(VALIDATION_TAG + validationID, compareDesc);

		if (onFailureFlag.equals(HARD_STOP_ON_FAILURE)) {
			if (sortOrder.equalsIgnoreCase("Ascending")) {
				assertThat(theList).isSortedAccordingTo(Comparator.comparing(Element::getValue));
			} else if (sortOrder.equalsIgnoreCase("Descending")) {
				assertThat(theList).isSortedAccordingTo(Comparator.comparing(Element::getValue, Comparator.reverseOrder()));
			}
		} else {
			if (sortOrder.equalsIgnoreCase("Ascending")) {
				sa().assertThat(theList).isSortedAccordingTo(Comparator.comparing(Element::getValue));
			} else if (sortOrder.equalsIgnoreCase("Descending")) {
				sa().assertThat(theList).isSortedAccordingTo(Comparator.comparing(Element::getValue, Comparator.reverseOrder()));
			}

			if (!sa().wasSuccess()) {
				Reporter.addStepLog(STATUS_FAIL, compareDesc);
			}
		}
	}

	@Then("^the user validates the cell at row \"([^\"]*)\" and column \"([^\"]*)\" of the \"([^\"]*)\" table at the \"([^\"]*)\" page \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void theUserValidatesTheCellAtRowAndColumnOfTheTableAtThePage(String rowNum,
			String colNum,
			String tableName,
			String pageName,
			String comparisonOperator,
			String expectedValue,
			String validationID,
			String onFailureFlag) {

		expectedValue = parseValue(expectedValue);
		String actualValue = getObject(tableName, pageName).getDataCellElement(Integer.parseInt(rowNum), Integer.parseInt(colNum)).getText();
		AssertHelper validator = new AssertHelper(ComparisonType.COMPARE_STRINGS, ComparisonOperator.valueOfLabel(comparisonOperator), onFailureFlag);
		validator.performValidation(actualValue, expectedValue,
				validationID,
				String.format("Table cell value at row '%s' and column '%s' of the '%s' table", rowNum, colNum, tableName));
	}

	@Then("^the user validates the color of the \"([^\"]*)\" element is \"([^\"]*)\" at the \"([^\"]*)\" page \"([^\"]*)\" \"([^\"]*)\"$")
	public void theUserValidatesTheColorOfTheElementIsAtThePage(String objectName,
			String expectedColor,
			String pageName,
			String validationID,
			String onFailureFlag) {

		expectedColor = parseValue(expectedColor);
		String actualColor = getObject(objectName, pageName).element().getCssValue("color");
		AssertHelper validator = new AssertHelper(ComparisonType.COMPARE_STRINGS, ComparisonOperator.EQ, onFailureFlag);
		validator.performValidation(actualColor, expectedColor,
				validationID,
				String.format("'%s' element color validation", objectName));
	}


	@Then("^the user validates the \"([^\"]*)\" item in the \"([^\"]*)\" radiobutton is selected at the \"([^\"]*)\" page \"([^\"]*)\" \"([^\"]*)\"$")
	public void theUserValidatesTheItemInTheRadiobuttonIsSelectedAtThePage(String rdoBtnVal,
			String objectName,
			String pageName,
			String validationID,
			String onFailureFlag) {
		rdoBtnVal = parseValue(rdoBtnVal);

		List<Element> radios = getObjects(objectName, pageName);
		boolean radioValSelected = false;
		for (Element radioItem : radios) {
			if (radioItem.findMatchingRadioButtonExact(rdoBtnVal) &&
					radioItem.element().isSelected()) {
				radioValSelected = true;
			}
		}

		final String compareDesc = String.format("Expecting radio button value of '%s' to be selected in the '%s' radio button.",
				rdoBtnVal, objectName);
		Reporter.addStepLog(compareDesc);
		TestContext.getInstance().testdata().put(VALIDATION_TAG + validationID, compareDesc + ": " + radioValSelected);

		if (onFailureFlag.equals(HARD_STOP_ON_FAILURE)) {
			assertThat(radioValSelected).as(compareDesc).isTrue();
		} else {
			sa().assertThat(radioValSelected).as(compareDesc).isTrue();
			if (!radioValSelected) {
				Reporter.addStepLog(STATUS_FAIL, compareDesc);
			}
		}
	}

	@Then("^the user validates the \"([^\"]*)\" item in the \"([^\"]*)\" checkbox is checked at the \"([^\"]*)\" page \"([^\"]*)\" \"([^\"]*)\"$")
	public void theUserValidatesTheItemInTheCheckboxIsCheckedAtThePage(String chkBoxVal,
			String objectName,
			String pageName,
			String validationID,
			String onFailureFlag) {
		chkBoxVal = parseValue(chkBoxVal);

		List<Element> checkbox = getObjects(objectName, pageName);
		boolean checkBoxValSelected = false;
		for (Element checkboxItem : checkbox) {
			if (checkboxItem.getText().equals(chkBoxVal) || checkboxItem.getAttribute("value").equals(chkBoxVal) || checkboxItem.getAttribute("title").equals(chkBoxVal)) {
				checkBoxValSelected = checkboxItem.element().isSelected();
			}
		}

		final String compareDesc = String.format("Expecting checkbox item of '%s' to be selected in the '%s' checkbox.",
				chkBoxVal, objectName);
		Reporter.addStepLog(compareDesc);
		TestContext.getInstance().testdata().put(VALIDATION_TAG + validationID, compareDesc + ": " + checkBoxValSelected);

		if (onFailureFlag.equals(HARD_STOP_ON_FAILURE)) {
			assertThat(checkBoxValSelected).as(compareDesc).isTrue();
		} else {
			sa().assertThat(checkBoxValSelected).as(compareDesc).isTrue();
			if (!checkBoxValSelected) {
				Reporter.addStepLog(STATUS_FAIL, compareDesc);
			}
		}

	}

	@Then("^the user validates the \"([^\"]*)\" item in the \"([^\"]*)\" checkbox is not checked at the \"([^\"]*)\" page \"([^\"]*)\" \"([^\"]*)\"$")
	public void theUserValidatesTheItemInTheCheckboxIsNotCheckedAtThePage(String chkBoxVal,
			String objectName,
			String pageName,
			String validationID,
			String onFailureFlag) {
		chkBoxVal = parseValue(chkBoxVal);

		List<Element> checkbox = getObjects(objectName, pageName);
		boolean checkBoxValSelected = false;
		for (Element checkboxItem : checkbox) {
			if (checkboxItem.getText().equals(chkBoxVal) || checkboxItem.getAttribute("value").equals(chkBoxVal)) {
				checkBoxValSelected = checkboxItem.element().isSelected();
			}
		}

		final String compareDesc = String.format("Expecting checkbox item of '%s' to be not selected in the '%s' checkbox.",
				chkBoxVal, objectName);
		Reporter.addStepLog(compareDesc);
		TestContext.getInstance().testdata().put(VALIDATION_TAG + validationID, compareDesc + ": " + checkBoxValSelected);

		if (onFailureFlag.equals(HARD_STOP_ON_FAILURE)) {
			assertThat(checkBoxValSelected).as(compareDesc).isFalse();
		} else {
			sa().assertThat(checkBoxValSelected).as(compareDesc).isFalse();
			if (checkBoxValSelected) {
				Reporter.addStepLog(STATUS_FAIL, compareDesc);
			}
		}

	}

	@Then("^^the user validates the value of the \"([^\"]*)\" element at the \"([^\"]*)\" page is formatted as \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void theUserValidatesTheValueOfTheElementIsFormattedAs(String objectName,
			String pageName,
			String formatType,
			String validationID,
			String onFailureFlag) throws ParseException {

		String actualValue = getObject(objectName, pageName).getValue();
		String expectedValue = format(getObject(objectName, pageName).getValue(), formatType);
		AssertHelper validator = new AssertHelper(ComparisonType.COMPARE_STRINGS, ComparisonOperator.EQ, onFailureFlag);
		validator.performValidation(actualValue, expectedValue,
				validationID,
				String.format("'%s' element value formatted as '%s'", objectName, formatType));

	}

	@Then("^the user validates that the partial text \"([^\"]*)\" element at the \"([^\"]*)\" page is \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void theUserValidatesThatThePartialTextElementAtThePageIs(String objectName,
			String pageName,
			String comparisonOperator,
			String expectedValue,
			String validationID,
			String onFailureFlag) {
		expectedValue = parseValue(expectedValue);
		String actualValue = getTextFromElement(getObject(objectName, pageName));

		//If Equal To, set to a Contains comparison. Otherwise, use Not Contains
		ComparisonOperator comparisonOp = (ComparisonOperator.valueOfLabel(comparisonOperator).equals(ComparisonOperator.EQ)) ?
				ComparisonOperator.CONTAINS :
					ComparisonOperator.NOT_CONTAINS;

		AssertHelper validator = new AssertHelper(ComparisonType.COMPARE_STRINGS, comparisonOp, onFailureFlag);
		validator.performValidation(actualValue, expectedValue,
				validationID,
				String.format("Partial text validation for the '%s' element", objectName));
	}

	@Then("^the user validates that the page title \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void theUserValidatesThatTheTitleAtThePageIs(String comparisonOperator,
			String expectedValue,
			String validationID,
			String onFailureFlag) {
		expectedValue = parseValue(expectedValue);
		String actualTitle = getDriver().getTitle();
		AssertHelper validator = new AssertHelper(ComparisonType.COMPARE_STRINGS, ComparisonOperator.valueOfLabel(comparisonOperator), onFailureFlag);
		validator.performValidation(actualTitle, expectedValue, validationID, "Page title validation");
	}

	@Then("^the user validates the background color of the \"([^\"]*)\" element is \"([^\"]*)\" at the \"([^\"]*)\" page \"([^\"]*)\" \"([^\"]*)\"$")
	public void theUserValidatesTheBackgroundColorOfTheElementIsAtThePage(String objectName,
			String expectedColor,
			String pageName,
			String validationID,
			String onFailureFlag) {

		expectedColor = parseValue(expectedColor);
		final String actualBackgroundColor = getObject(objectName, pageName).element().getCssValue("background-color");
		AssertHelper validator = new AssertHelper(ComparisonType.COMPARE_STRINGS, ComparisonOperator.EQ, onFailureFlag);
		validator.performValidation(actualBackgroundColor.toLowerCase(), expectedColor.toLowerCase(),
				validationID,
				String.format("Background color validation for the '%s' element", objectName));
	}

	@Then("^the user validates the \"([^\"]*)\" element is present at the \"([^\"]*)\" page \"([^\"]*)\" \"([^\"]*)\"$")
	public void theUserValidatesTheElementIsPresentAtThePage(String objectName,
			String pageName,
			String validationID,
			String onFailureFlag) {

		final Element elementPresent = getObject(objectName, pageName);

		final String compareDesc = String.format("Expecting the '%s' element to be present on the '%s' page. ", objectName, pageName);
		TestContext.getInstance().testdata().put(VALIDATION_TAG + validationID, compareDesc);

		if (onFailureFlag.equals(HARD_STOP_ON_FAILURE)) {
			assertThat(elementPresent).as(compareDesc).isNotNull();
		} else {
			sa().assertThat(elementPresent).as(compareDesc).isNotNull();
			if (elementPresent == null) {
				Reporter.addStepLog(STATUS_FAIL, compareDesc);
			}
		}

	}

	@Then("^the user validates the \"([^\"]*)\" element is not present at the \"([^\"]*)\" page \"([^\"]*)\" \"([^\"]*)\"$")
	public void theUserValidatesTheElementIsNotPresenteAtThePage(String objectName,
			String pageName,
			String validationID,
			String onFailureFlag) {

		final Element elementPresent = getObjectAllowNull(objectName, pageName);

		final String compareDesc = String.format("Expecting the '%s' element to not be present on the '%s' page. ",
				objectName, pageName);
		TestContext.getInstance().testdata().put(VALIDATION_TAG + validationID, compareDesc);

		if (onFailureFlag.equals(HARD_STOP_ON_FAILURE)) {
			assertThat(elementPresent.element()).as(compareDesc).isNull();
		} else {
			sa().assertThat(elementPresent.element()).as(compareDesc).isNull();
			if (elementPresent.element() != null) {
				Reporter.addStepLog(STATUS_FAIL, compareDesc);
			}
		}
	}

	@Then("^the user validates the sequence of columns in the \"([^\"]*)\" table at the \"([^\"]*)\" page is \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void theUserValidatesTheSequenceOfColumnsInTheTableAtThePageIs(String tableName,
			String pageName,
			String expectedSequence,
			String validationID,
			String onFailureFlag) {
		String expectedColumnListValue = parseValue(expectedSequence);
		List<String> actualColumnList = getObject(tableName, pageName).getHeaderColumnsWithGivenAttribute();
		List<String> expectedColumnList = Arrays.asList(expectedColumnListValue.split("\\|"));

		AssertHelper validator = new AssertHelper(ComparisonType.COMPARE_LISTS, ComparisonOperator.EQ, onFailureFlag);
		validator.performValidation(actualColumnList, expectedColumnList,
				validationID,
				String.format("Column sequence validation for the '%s' table", tableName));
	}

	@Then("^the user validates the sequence of rows in the \"([^\"]*)\" column in the \"([^\"]*)\" table at the \"([^\"]*)\" page contains \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void theUserValidatesTheSequenceOfRowsInTheTableAtThePageIs(String colName,
			String tableName,
			String pageName,
			String expectedSequence,
			String validationID,
			String onFailureFlag) {
		String expectedColumnListValue = parseValue(expectedSequence);
		List<String> actualColumnList = getObject(tableName, pageName).getRowValuesForGivenColumn(colName);
		List<String> expectedColumnList = Arrays.asList(expectedColumnListValue.split("\\|"));

		AssertHelper validator = new AssertHelper(ComparisonType.COMPARE_LISTS, ComparisonOperator.CONTAINS, onFailureFlag);
		validator.performValidation(actualColumnList, expectedColumnList,
				validationID,
				String.format("Column sequence validation for the '%s' table", tableName));
	}

	@Then("^the user validates the \"([^\"]*)\" table at the \"([^\"]*)\" page is filtered by the value \"([^\"]*)\" in the \"([^\"]*)\" column \"([^\"]*)\" \"([^\"]*)\"$")
	public void theUserValidatesTheTableAtThePageIsFilteredByTheValueInTheColumn(String tableName,
			String pageName,
			String expectedColValue,
			String colHeader,
			String validationID,
			String onFailureFlag) {
		List<String> actualValues = getObject(tableName, pageName).getRowValuesForGivenColumn(colHeader);
		expectedColValue = parseValue(expectedColValue);
		List<String> expectedValueList = Arrays.asList(expectedColValue);
		AssertHelper validator = new AssertHelper(ComparisonType.COMPARE_LISTS, ComparisonOperator.EQ, onFailureFlag);
		validator.performValidation(actualValues, expectedValueList,
				validationID,
				String.format("'%s' table is filtered by '%s'", tableName, expectedColValue));
	}

	@Then("^the user validates the \"([^\"]*)\" value for \"([^\"]*)\" element is selected at the \"([^\"]*)\" page \"([^\"]*)\" \"([^\"]*)\"$")
	public void theUserValidatesTheValueForElementIsSelectedAtThePage(String expectedValue,
			String objectName,
			String pageName,
			String validationID,
			String onFailureFlag) {
		String selectedText = getObject(objectName, pageName).dropdown().getFirstSelectedOption().getText();
		expectedValue = parseValue(expectedValue);
		AssertHelper validator = new AssertHelper(ComparisonType.COMPARE_STRINGS, ComparisonOperator.EQ, onFailureFlag);
		validator.performValidation(selectedText, expectedValue,
				validationID,
				String.format("'%s' is selected in the '%s' element", expectedValue, objectName));
	}

	@Then("^the user validates the value of cell at the last row and last column is \"([^\"]*)\" \"([^\"]*)\" in the \"([^\"]*)\" table at the \"([^\"]*)\" page \"([^\"]*)\" \"([^\"]*)\"$")
	public void theUserValidatesTheValueForCellAtTheLastRowAndLastColumnInTheTableAtThePageIs(String comparisonOperator,
			String expectedValue,
			String tableName,
			String pageName,
			String validationID,
			String onFailureFlag) {
		expectedValue = parseValue(expectedValue);
		Element table = getObject(tableName, pageName);
		String actualValue = table.getDataCellElement(table.getDataRowCount() - 1, table.getDataColumnCount(0) - 1).getText();

		AssertHelper validator = new AssertHelper(ComparisonType.COMPARE_STRINGS, ComparisonOperator.valueOfLabel(comparisonOperator), onFailureFlag);
		validator.performValidation(actualValue, expectedValue,
				validationID,
				String.format("Last row and last column of the '%s' table", tableName));
	}

	@Then("^the user validates that \"([^\"]*)\" is ((?:found|not found)?) in the \"([^\"]*)\" column in the \"([^\"]*)\" table on the \"([^\"]*)\" page \"([^\"]*)\" \"([^\"]*)\"$")
	public void theUserValidatesTheValueisFoundInColumn(String expectedValue,
			String option,
			String colName,
			String tableName,
			String pageName,
			String validationID,
			String onFailureFlag) {

		Element matchingTableCell = findMatchingTableCell(parseValue(colName),
				parseValue(expectedValue),
				getObject(tableName, pageName));

		final String compareDesc = String.format("Expecting %s to be %s in the %s column of the %s table at the %s page",
				parseValue(expectedValue), option, colName, tableName, pageName);

		TestContext.getInstance().testdata().put(VALIDATION_TAG + validationID, compareDesc);

		if (option.equals("found")){
			if (onFailureFlag.equals(HARD_STOP_ON_FAILURE)) {
				assertThat(matchingTableCell).as(compareDesc).isNotNull();
			} else {
				sa().assertThat(matchingTableCell).as(compareDesc).isNotNull();
				if (matchingTableCell == null) {
					Reporter.addStepLog(STATUS_FAIL, VALIDATION_FAILED + compareDesc);
				}
			}
		}else if (option.equals("not found")){
			if (onFailureFlag.equals(HARD_STOP_ON_FAILURE)) {
				assertThat(matchingTableCell).as(compareDesc).isNull();
			} else {
				sa().assertThat(matchingTableCell).as(compareDesc).isNull();
				if (matchingTableCell != null) {
					Reporter.addStepLog(STATUS_FAIL, VALIDATION_FAILED + compareDesc);
				}
			}
		}
	}

	@Then("^the user validates that the \"([^\"]*)\" column equal to \"([^\"]*)\" where the \"([^\"]*)\" column contains \"([^\"]*)\" and the \"([^\"]*)\" column contains \"([^\"]*)\" from the \"([^\"]*)\" table at the \"([^\"]*)\" page \"([^\"]*)\" \"([^\"]*)\"$")
	public void theUserValidatesColumnEqualToValueWhereTheColumnContainsAndTheColumnContainsFromTheTableAtThePage(String firstColName,
			String firstColValue,
			String secondColName,
			String secondColValue,
			String thirdColName,
			String thirdColValue,
			String tableName,
			String pageName,
			String validationID,
			String onFailureFlag) {

		firstColValue = parseValue(firstColValue);
		String actualValue = findMatchingTableCell(firstColName, firstColValue,
				secondColName, parseValue(secondColValue),
				thirdColName, parseValue(thirdColValue),
				getObject(tableName, pageName)).getText();

		AssertHelper validator = new AssertHelper(ComparisonType.COMPARE_STRINGS, ComparisonOperator.EQ, onFailureFlag);
		validator.performValidation(actualValue, firstColValue,
				validationID,
				String.format("'%s' column in the '%s' table", firstColName, tableName));
	}

	@Then("^the user validates that all values in the \"([^\"]*)\" dropdown at the \"([^\"]*)\" page matches \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void theUserValidatesTheValuesInTheDropdownAtThePageIs(String dropdown,
			String pageName,
			String expectedSequence,
			String validationID,
			String onFailureFlag) {

		List<String> actualList = getObject(dropdown, pageName).getDropdownOptionValues();

		List<String> expectedList = Arrays.asList(parseValue(expectedSequence).split("\\|"));

		AssertHelper validator = new AssertHelper(ComparisonType.COMPARE_LISTS, ComparisonOperator.EQ, onFailureFlag);
		validator.performValidation(actualList, expectedList,
				validationID,
				String.format("'%s' dropdown values comparison", dropdown));
	}

	@Then("^the user validates that all exact values in the \"([^\"]*)\" dropdown using xpath \"([^\"]*)\" at the \"([^\"]*)\" page matches \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void theUserValidatesTheExactValuesInTheDropdownAtThePageIs(String dropdown,
			String pattern,
			String pageName, 
			String expectedSequence,
			String validationID,
			String onFailureFlag) throws InterruptedException, FileNotFoundException { 
		String PageobjectsFile=Constants.PAGEOBJECTJAVAPATH+pageName+".java";               	
		File file_element =new File(PageobjectsFile);             
		Scanner in = new Scanner(file_element);
		String element="";
		String access_method_values="";

		while(in.hasNext())
		{
			String line=in.nextLine();
			if(line.contains("private By "+pattern)) { 

				element=(StringUtils.substringBetween(line, "private By", "=")).trim();
				access_method_values=(StringUtils.substringBetween(line, "(\"", "\")")).trim();
			}
		}
		in.close();
		List<String> actualList = getObject(dropdown, pageName).getDropdownexactAnchoreText(access_method_values);


		List<String> expectedList = Arrays.asList(parseValue(expectedSequence).split("\\|"));

		AssertHelper validator = new AssertHelper(ComparisonType.COMPARE_LISTS, ComparisonOperator.EQ, onFailureFlag);
		validator.performValidation(actualList, expectedList,
				validationID,
				String.format("'%s' dropdown values comparison", dropdown));
	}

	@Then("^the user validates that all elements that match the pattern of the \"([^\"]*)\" element are disabled at the \"([^\"]*)\" page \"([^\"]*)\" \"([^\"]*)\"$")
	public void theUserValidatesThatAllElementsThatMatchThePatternOfTheElementAreDisabledAtThePage(String objectName,
			String pageName,
			String validationID,
			String onFailureFlag) {
		List<Element> els = getObjects(objectName, pageName);
		boolean isElementEnabled = true;
		for (Element el : els) {
			if (el.element().isDisplayed()) {
				isElementEnabled = el.element().isEnabled();

				final String compareDescription = String.format("Expected %s to be disabled at the page", el);

				TestContext.getInstance().testdata().put(VALIDATION_TAG + validationID,
						compareDescription + ": " + isElementEnabled);

				if (onFailureFlag.equals(HARD_STOP_ON_FAILURE)) {
					assertThat(isElementEnabled).as(compareDescription).isFalse();
				} else {
					sa().assertThat(isElementEnabled).as(compareDescription).isFalse();
					if (isElementEnabled) {
						Reporter.addStepLog(STATUS_FAIL, VALIDATION_FAILED + compareDescription);
					}
				}
			}

		}
	}

	@Then("^the user validates the order of the \"([^\"]*)\" object list at the \"([^\"]*)\" page is \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void theUserValidatesTheOrderingOfSectionsAtThePageIs(String listOfObjects,
			String pageName,
			String expectedSequence,
			String validationID,
			String onFailureFlag) {

		List<String> objectOrderOnPage = getObjects(listOfObjects, pageName).stream()
				.map(this::getTextFromElement)
				.collect(Collectors.toList());

		List<String> expectedObjectOrder = Arrays.asList(expectedSequence.split("\\|"));
		AssertHelper validator = new AssertHelper(ComparisonType.COMPARE_LISTS, ComparisonOperator.EQ, onFailureFlag);
		validator.performValidation(objectOrderOnPage, expectedObjectOrder,
				validationID,
				String.format("List order in the '%s' element", listOfObjects));

	}

	@Then("^the user validates the focus is present at the \"([^\"]*)\" element at the \"([^\"]*)\" page \"([^\"]*)\" \"([^\"]*)\"$")
	public void theUserValidatesFocusPresentAtElementAtThePage(String objectName,
			String pageName,
			String validationID,
			String onFailureFlag) {

		boolean focused = getAllAttributesOfElement(getObject(objectName, pageName).element()).equals(getAllAttributesOfElement(getDriver().switchTo().activeElement()));
		final String compareDescription = String.format("Expecting %s to be focused at the %s page", objectName, pageName);

		TestContext.getInstance().testdata().put(VALIDATION_TAG + validationID, compareDescription + ": " + focused);

		if (onFailureFlag.equals(HARD_STOP_ON_FAILURE)) {
			assertThat(focused).as(compareDescription).isTrue();
		} else {
			sa().assertThat(focused).as(compareDescription).isTrue();
		}
	}

	@Then("^the user validates maximum character limit of \"([^\"]*)\" element is \"([^\"]*)\" at the \"([^\"]*)\" page \"([^\"]*)\" \"([^\"]*)\"$")
	public void theUserValidatesMaximumCharLimitOfElementAtThePage(String objectName,
			String maxCharLimit,
			String pageName,
			String validationID,
			String onFailureFlag) {
		Element element = getObject(objectName, pageName);
		enterCharInTextBox("D", Integer.parseInt(maxCharLimit), element);
		boolean maxCharMatched = element.getValue().toCharArray().length == Integer.parseInt(maxCharLimit);

		final String compareDescription = String.format("Expecting %s element has maximum character limit %s at the %s page", objectName, maxCharLimit, pageName);
		TestContext.getInstance().testdata().put(VALIDATION_TAG + validationID, compareDescription + ": " + maxCharMatched);

		if (onFailureFlag.equals(HARD_STOP_ON_FAILURE)) {
			assertThat(maxCharMatched).as(compareDescription).isTrue();
		} else {
			sa().assertThat(maxCharMatched).as(compareDescription).isTrue();
		}
	}

	@Then("^the user validates that the element1 \"([^\"]*)\" is present on the \"([^\"]*)\" of element2 \"([^\"]*)\" on the \"([^\"]*)\" page \"([^\"]*)\" \"([^\"]*)\"$")
	public void theUservalidatesTheElement1PresentOnThePositionOfElement2(String objectName1,
			String expectedPosition,
			String objectName2,
			String pageName,
			String validationID,
			String onFailureFlag) {

		Element element1 = getObject(objectName1, pageName);
		Element element2 = getObject(objectName2, pageName);

		int xPosition1 = getXLocation(element1);
		int yPosition1 = getYLocation(element1);

		int xPosition2 = getXLocation(element2);
		int yPosition2 = getYLocation(element2);

		boolean checkPosition=positionValidationCheck(xPosition1, yPosition1, xPosition2, yPosition2, parseValue(expectedPosition));
		final String compareDescription = String.format("Expected element %s to be present on %s of element %s at the page", objectName2,expectedPosition,objectName1);
		TestContext.getInstance().testdata().put(VALIDATION_TAG + validationID, compareDescription + ": " + checkPosition);

		if (onFailureFlag.equals(HARD_STOP_ON_FAILURE)) {
			assertThat(checkPosition).as(compareDescription).isTrue();
		} else {
			sa().assertThat(checkPosition).as(compareDescription).isTrue();
		}
	}

	@Then("^the user validates the tag for the \"([^\"]*)\" element is \"([^\"]*)\" at the \"([^\"]*)\" page \"([^\"]*)\" \"([^\"]*)\"$")
	public void theUserValidatesTheTagForTheElementIsAtThePage(String objectName,
			String expectedTagName,
			String pageName,
			String validationID,
			String onFailureFlag) {


		expectedTagName = parseValue(expectedTagName);
		boolean matchTagName = getObject(objectName, pageName).isTagNameMatched(expectedTagName);

		final String compareDescription = String.format("Expecting element '%s' tag to be '%s' at the page '%s'", objectName, expectedTagName, pageName);
		TestContext.getInstance().testdata().put(VALIDATION_TAG + validationID, compareDescription + ": " + matchTagName);

		if (onFailureFlag.equals(HARD_STOP_ON_FAILURE)) {
			assertThat(matchTagName).as(compareDescription).isTrue();
		} else {
			sa().assertThat(matchTagName).as(compareDescription).isTrue();
		}
	}

	@Then("^the user validates that the value in \"([^\"]*)\" textbox is ((?:empty|not empty)?) at the \"([^\"]*)\" page \"([^\"]*)\" \"([^\"]*)\"$")
	public void theUserValidatesTheValueofTheElementIsAtThePage(String objectName,
			String option,
			String pageName,
			String validationID,
			String onFailureFlag) {

		String value = getObject(objectName, pageName).getValue();
		final String compareDesc = String.format("Expecting %s to be %s at the %s page",objectName, option, pageName);
		TestContext.getInstance().testdata().put(VALIDATION_TAG + validationID, compareDesc);
		if (option.equals("not empty")){
			if (onFailureFlag.equals(HARD_STOP_ON_FAILURE)) {
				assertThat(value).as(compareDesc).isNotBlank();
			} else {
				sa().assertThat(value).as(compareDesc).isNotBlank();
			}
		}else if (option.equals("empty")){
			if (onFailureFlag.equals(HARD_STOP_ON_FAILURE)) {
				assertThat(value).as(compareDesc).isBlank();
			} else {
				sa().assertThat(value).as(compareDesc).isBlank();
			}
		}
	}

	@Then("^the user clicks on \"([^\"]*)\" element at the \"([^\"]*)\" page and validates the hyperlink if \"([^\"]*)\" element is present at the \"([^\"]*)\" page \"([^\"]*)\" \"([^\"]*)\"$")
	public void theUserValidatesTheHyperlinkAtThePage(String clickobjectname,String clickpagename,String objectName,
			String pageName,
			String validationID,
			String onFailureFlag) throws InterruptedException
	{
		String compareDesc=null;
		boolean foundWindow = false;
		Element elementPresent=null;
		ArrayList<String> tabs2=null;
		int size=0;
		String NewtabClose=(String)TestContext.getInstance().testdataGet("NewTabClose");
		if(NewtabClose!=null && NewtabClose.equals("true"))
		{	
			ArrayList<String> tabs=(ArrayList<String>) TestContext.getInstance().testdataGet("windowhandle");
			getDriver().close();
			int tabssize=(int)TestContext.getInstance().testdataGet("SIZE");
			getDriver().switchTo().window(tabs.get(tabssize-2));
			TestContext.getInstance().testdataPut("NewTabClose", "false");
		}
		getObject(clickobjectname, clickpagename).click();
		try
		{
			for(int i=1;i<=5;i++)
			{
				Set<String> windowHandles = getDriver().getWindowHandles();             
				for (String windowHandleName : windowHandles) {
					if (!TestContext.getInstance().windowHandleExists(windowHandleName)) {                    
						tabs2 = new ArrayList<String> (getDriver().getWindowHandles());
						TestContext.getInstance().testdataPut("windowhandle", tabs2);
						size=tabs2.size();
						TestContext.getInstance().testdataPut("SIZE", size);
						getDriver().switchTo().window(tabs2.get(size-1));
						foundWindow = true;
					}
				}
				if (!foundWindow) {
					long windowSwitchDelay = Integer.parseInt(System.getProperty("fw.windowSwitchDelay"));
					log.debug("Next window not found. Waiting {} ms and trying again. Number of retries left: {}", windowSwitchDelay, i);
					Thread.sleep(windowSwitchDelay);
				}
				else
				{
					break;
				}
			}
			compareDesc = String.format("Expecting the '%s' element to be present on the '%s' page. ", objectName, pageName);
			getPO().waitPageToLoad();
			compareDesc = String.format("Expecting the '%s' element to be present on the '%s' page. ", objectName, pageName);
			getObject(objectName, pageName).visible();
			elementPresent = getObject(objectName, pageName);

			compareDesc = String.format("Expecting the '%s' element to be present on the '%s' page. ", objectName, pageName);
			TestContext.getInstance().testdata().put(VALIDATION_TAG + validationID, compareDesc);

			if (onFailureFlag.equals(HARD_STOP_ON_FAILURE)) {
				if (elementPresent == null) {
					Reporter.addStepLog(STATUS_FAIL, "Validation Failed.. It's not a hyperlink");
					Reporter.addStepLog(STATUS_FAIL, compareDesc);
					if(foundWindow)
					{                                	
						TestContext.getInstance().testdataPut("NewTabClose", "true");
					}
					assertThat("Fail").isEqualTo("Pass");

				}
				else
				{
					assertThat(elementPresent).as(compareDesc).isNotNull();
					Reporter.addStepLog("PASS", "Validation Passed.. It's a hyperlink");
					if(foundWindow)
					{                     	                 
						TestContext.getInstance().testdataPut("NewTabClose", "true");
					}
				}

			} else {
				if (elementPresent == null) {
					Reporter.addStepLog(STATUS_FAIL, "Validation Failed.. It's not a hyperlink");
					Reporter.addStepLog(STATUS_FAIL, compareDesc);
					if(foundWindow)
					{               	 
						TestContext.getInstance().testdataPut("NewTabClose", "true");
					}
				}
				assertThat("Fail").isEqualTo("Pass");
			}

		}catch(Exception e)
		{
			Reporter.addStepLog(STATUS_FAIL, "Validation Failed.. It's not a hyperlink");
			Reporter.addStepLog(STATUS_FAIL, compareDesc);
			if(foundWindow)
			{           	 
				TestContext.getInstance().testdataPut("NewTabClose", "true");
			}
			assertThat("Fail").isEqualTo("Pass");
		}
	}
	@Then("^the user validates that the element \"([^\"]*)\" on the \"([^\"]*)\" page has instance \"([^\"]*)\" of text \"([^\"]*)\" immediately preceding text \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void verifyMailTextSucceeding(String objectName, String pageName, String instance, String precedingText, String succeedingText, String validationId, String onFailureFlag) {

		String fullText = getObject(objectName, pageName).getText(5);

		if (fullText == null || fullText == "") {
			fullText = getObject(objectName, pageName).getAttribute("innerHTML", 5);
		}

		if (fullText == null || fullText == "") {
			Reporter.addStepLog(STATUS_FAIL, "Chosen element has no text.");
			assertThat("Chosen element has no text.").isEqualTo("Found element text");
			return;
		}

		log.info("Found Element Text: " + fullText);
		Integer intInstance = Integer.parseInt(instance); 

		if (!fullText.contains(precedingText)) {
			Reporter.addStepLog(STATUS_FAIL, "No preceding text in the element");
			assertThat("No preceding text in the element").isEqualTo("Found preceding text");
			return;
		}


		String[] splitText = fullText.split(precedingText);
		ArrayList<String> splitStrings = new ArrayList<String>();
		for(String string: splitText){
			log.info("Located String: " + string);
			splitStrings.add(string);
		}

		fullText = splitStrings.get(intInstance);

		if (fullText.length() < succeedingText.length()) {
			Reporter.addStepLog(STATUS_FAIL, "Length of following string too short to compare to following text\nFollowing Text: " + succeedingText + "\nActual Text: " + fullText);
			assertThat("Length of following string too short to compare to following text\nFollowing Text: " + succeedingText + "\nActual Text: " + fullText).isEqualTo("Correct length detected");
			return;
		}


		AssertHelper validator = new AssertHelper(ComparisonType.COMPARE_STRINGS, ComparisonOperator.EQ, onFailureFlag);
		validator.performValidation(fullText.substring(0, Math.min(fullText.length(), succeedingText.length())), succeedingText,
				validationId,
				String.format("Element given text after given text"));




	}
	@When("^the user validates that the web image element \"([^\"]*)\" on the \"([^\"]*)\" page is identical to the image at \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void theUserValidatesThatOneImageIsIdenticalToAnother(String objectName, String pageName, String templatePath,
			String validationID,
			String onFailureFlag) throws IOException {
		
		String testSrc = getObject(objectName, pageName).getAttribute("src", 5).trim();
		File templateFile = new File(parseValue(templatePath));
		
		HttpPost post = new HttpPost("http://sd-35d4-9d73:8820/ImageValid/tempvstest");

		MultipartEntityBuilder builder = MultipartEntityBuilder.create();
		builder.setMode(HttpMultipartMode.BROWSER_COMPATIBLE);
		post.addHeader("sourceurl", testSrc);
		builder.addBinaryBody("file", templateFile, ContentType.DEFAULT_BINARY, "");
		HttpEntity entity = builder.build();
		post.setEntity(entity);

		String result;
		try (DefaultHttpClient client = new DefaultHttpClient()){
			HttpResponse response = client.execute(post);
			if (response.getStatusLine() != null) {
				log.info("Step HTTP Response not null");
				log.info("Step HTTP Status Code: " + response.getStatusLine().getStatusCode());
			} else {
				log.info("Step HTTP Response is null");
			}
			if (response.getStatusLine() != null && response.getStatusLine().getStatusCode() == 200) {
				result = (response.getFirstHeader("ImageValidation").getValue());
				log.info("Status: " + result);
			}
			else {
				result = (response.getFirstHeader("ImageValidation").getValue());
				log.info("print data in response error" + response.getStatusLine().getStatusCode());
				log.info("data in response is blank");
			}

		}

		AssertHelper validator = new AssertHelper(ComparisonType.COMPARE_STRINGS, ComparisonOperator.EQ, onFailureFlag);
		validator.performValidation(result, "Both test and template images are matching.Image validation success",
				validationID,
				String.format("Image comparison between subject and template"));
	}


	@Then("^the user validates the source as \"([^\"]*)\" for element \"([^\"]*)\" at page \"([^\"]*)\"$")
	public void theuserValidatesthesrcextension(String src,String ObjectName,
			String pageName
			) {

		String expectedSource=parseValue(src).toLowerCase();      
		String actualSource=getObject(ObjectName,pageName).getAttribute("src").toLowerCase();
		if(actualSource.contains(expectedSource))
		{
			Reporter.addStepLog("PASS", "Validation Passed.. the actual source is matching the expected source");
			String compareDesc = String.format("The expected source is= %s and actual source is= %s ", expectedSource, actualSource);
			Reporter.addStepLog("PASS", compareDesc);
		}
		else
		{
			Reporter.addStepLog(STATUS_FAIL, "Validation Failed.. the actual source is not matching the expected source");
			String compareDesc = String.format("Expecting the '%s' source to be present but source is %s ", expectedSource, actualSource);
			Reporter.addStepLog(STATUS_FAIL, compareDesc);
			assertThat("Fail").isEqualTo("Pass");
		}

	}
	@Then("^the user uses directory \"([^\"]*)\" to validate log file at \"([^\"]*)\" with SID \"([^\"]*)\" and API \"([^\"]*)\" checking field \"([^\"]*)\" for value \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void validateLogUsingMacro(
			String directoryPath,
			String filePath,
			String SID,
			String API,
			String fieldToCheck,
			String valueToCheck,
			String testingID,
			String onFailureFlag) {

		String result = "Could not retrieve data";

		try{
			filePath = parseValue(filePath);
			SID = parseValue(SID);
			API = parseValue(API);
			fieldToCheck = parseValue(fieldToCheck);
			valueToCheck = parseValue(valueToCheck);

			Runtime.getRuntime().exec("taskkill /F /IM excel.exe");

			File file = new File(directoryPath + "PCF.vbs");
			File toolFile = new File(directoryPath + "PCF_Log_Validation.xlsm");

			if(toolFile.exists()) {
				toolFile.delete(); 
			}  
			if(file.exists()) {
				file.delete();
			}


			try (InputStream toolStream = getClass().getResourceAsStream(SCRIPT_FILE_PATH_TO_LOG_VALIDATION))
			{
				FileHelper.copyFileFromInputStream(toolStream, file.getAbsolutePath());
			}   
			try(InputStream toolStream =getClass().getResourceAsStream(MACRO_FILE_PATH_TO_LOG_VALIDATION);){

				FileHelper.copyFileFromInputStream(toolStream, toolFile.getAbsolutePath());
			}


			String cmd = "cscript "+
					file.getAbsolutePath()+" " +
					toolFile.getAbsolutePath()+" " +
					filePath + " "+
					SID + " " + 
					API + " " +
					fieldToCheck.replaceAll(" ", "~") + " " +
					valueToCheck.replaceAll(" ", "~");
			log.info("\n\n\nCommand: " + cmd + "\n\n\n");
			Runtime.getRuntime().exec(cmd);

			int retries = 10;
			while (retries != 0) {
				try (XSSFWorkbook workbook = XSSFWorkbookFactory.createWorkbook(new File(toolFile.getAbsolutePath()), true)){
					XSSFSheet sheet = workbook.getSheet("Output");

					for (int y = 0; y< 5; y++) {
						for (int x = 0; x < 8; x++) {
							try {
								Row row;
								row = sheet.getRow(y);
								Cell cellResult = row.getCell(x);
								String tempResult = cellResult.getStringCellValue();
								if (x == 7 && y == 4) {
									result = tempResult;
								}
								if(!tempResult.equals("")) {
									//log.info("\nCell: " + x + "-" + y+ "       " + tempResult + "\n");
								}
							}catch(Exception e) {
							}
						}	
					}


				} catch(Exception e) {
					e.printStackTrace();
				}

				if (result.equals("Failed") || result.equals("Passed")) {
					break;
				}
				retries--;
				Thread.sleep(5000);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		try {
			Runtime.getRuntime().exec("taskkill /F /IM excel.exe");
		} catch(Exception e) {

		}

		File file = new File(directoryPath + "PCF.vbs");
		File toolFile = new File(directoryPath + "PCF_Log_Validation.xlsm");

		if(toolFile.exists()) {
			toolFile.delete(); 
		}  
		if(file.exists()) {
			file.delete();
		}

		AssertHelper validator = new AssertHelper(ComparisonType.COMPARE_STRINGS, ComparisonOperator.EQ, onFailureFlag);
		validator.performValidation(result, "Passed",
				testingID,
				String.format("Macro Log Validation"));

	}
}
