package automation.library.engine.desktop.steps;

import automation.library.common.TestContext;
import automation.library.engine.desktop.BaseDesktopSteps;
import automation.library.leanft.exec.DesktopContext;
import com.hp.lft.sdk.GeneralLeanFtException;
import io.cucumber.java.en.And;
import io.cucumber.java.en.When;

public class AutoEngDesktopGet extends BaseDesktopSteps {

    @And("^store the clipboard into the data dictionary with key \"([^\"]*)\"$")
    public void storeTheDisplayedTextAtThePageIntoTheDataDictionaryWithKey(String dictionaryKey) {
        dictionaryKey = parseDictionaryKey(dictionaryKey);
        String valToStore = copyClipboardToVar();
        TestContext.getInstance().testdataPut(dictionaryKey, valToStore);
        logStepMessage(String.format(STORED_VALUE, valToStore, dictionaryKey));
    }

    @When("^the user gets the value from the \"([^\"]*)\" label on the \"([^\"]*)\" desktop window and stores into data dictionary with key \"([^\"]*)\"$")
    public void theUserGetsTheValueFromTheLabelOnTheDesktopWindowAndStoresIntoDataDictionaryWithKey(String objectName,
                                                                                               String windowName,
                                                                                               String dictionaryKey) throws GeneralLeanFtException {
        DesktopContext.getInstance().setCurrentLeanFTWindow(getDesktopWindow(windowName));
        dictionaryKey = parseDictionaryKey(dictionaryKey);
        String valToStore = getDesktopLabel(objectName,windowName).getText();
        TestContext.getInstance().testdataPut(dictionaryKey, valToStore);
        logStepMessage(String.format(STORED_VALUE, valToStore, dictionaryKey));
    }

    @When("^the user gets the value from the \"([^\"]*)\" editor on the \"([^\"]*)\" desktop window and stores into data dictionary with key \"([^\"]*)\"$")
    public void theUserGetsTheValueFromTheEditorOnTheDesktopWindowAndStoresIntoDataDictionaryWithKey(String objectName,
                                                                                                    String windowName,
                                                                                                    String dictionaryKey) throws GeneralLeanFtException {
        DesktopContext.getInstance().setCurrentLeanFTWindow(getDesktopWindow(windowName));
        dictionaryKey = parseDictionaryKey(dictionaryKey);
        String valToStore = getDesktopEditor(objectName,windowName).getText();
        TestContext.getInstance().testdataPut(dictionaryKey, valToStore);
        logStepMessage(String.format(STORED_VALUE, valToStore, dictionaryKey));
    }

}
