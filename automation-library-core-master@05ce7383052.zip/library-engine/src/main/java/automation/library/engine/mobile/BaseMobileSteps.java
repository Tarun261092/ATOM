package automation.library.engine.mobile;

import automation.library.common.JSONHelper;
import automation.library.common.Property;
import automation.library.common.TestContext;
import automation.library.engine.core.BaseStepsEngine;
import automation.library.reporting.Reporter;
import automation.library.selenium.core.Constants;
import automation.library.selenium.core.Screenshot;
import automation.library.selenium.exec.driver.factory.DriverContext;
import static automation.library.cucumber.core.Constants.ENVIRONMENTPATH;
import static automation.library.cucumber.core.Constants.TESTDATAPATH;
import static automation.library.reporting.Reporter.addScreenCaptureFromPath;
import static automation.library.tdaas.core.Constants.ERROR_RESPONSE;

import org.apache.commons.configuration2.PropertiesConfiguration;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.entity.mime.content.ContentBody;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NotFoundException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class BaseMobileSteps extends BaseStepsEngine {
    PropertiesConfiguration props = Property.getProperties(Constants.MOBILERUNTIMEPATH);

    protected void launchMobile() {
        getMobileDriver();
    }

    public WebDriver getMobileDriver() {
        log.debug("obtaining the mobile driver for current thread");
        return DriverContext.getInstance().getMobileDriver();
    }

    public void switchContext(String context) {
        DriverContext.getInstance().switchContext(context);
    }

    protected void openApplication(String applicationName, WebDriver driver) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        Map<String, String> startapp = new HashMap<>();
        startapp.put("name", applicationName);
        js.executeScript("mobile:application:open", startapp);
    }   
    
    protected String getOTPMessage(WebDriver driver, String label) {
    	try {
    		closeAppilcation("Messages", driver);
    		log.info("The Messages application is closed before opening again.");
		} catch (Exception e) {
			log.info("The Messages application is not running in the background.");
		}    	
        openApplication("Messages", driver);
        log.info("The Messages application is opened.");
        if (label == null) {
        	try {
				label = ((Map<String, String>)JSONHelper.getDataPOJO(Constants.OTPSMSFORMATJSON, Map.class).get("findSMSParams")).get("content");
			} catch (IOException e) {
				log.error(e.getMessage());
			}
        }			             
        switchContext("NATIVE_APP");        
        List<WebElement> msgElements = null;
		try {
			driver.findElement(By.xpath(String.format("(//*[contains(@text, '%s') or contains(@label, '%s')])[1]", label, label))).click();
			msgElements = driver.findElements(By.xpath(String.format("//*[contains(@text, '%s') or contains(@label, '%s')]", label, label)));
		} catch (Exception e) {
			captureAndAttachScreenshot(driver);
			String errorMsg = String.format("Unable to find the message with label or content: %s", label);
			log.error(errorMsg);
			throw new NotFoundException(errorMsg);
		}
        String message1 = msgElements.get(msgElements.size() - 1).getText();
        captureAndAttachScreenshot(driver);
        
        closeAppilcation("Messages", driver);
        return message1.replaceAll("\n", " ");
    }
    
    protected String getSixDigitOTP(String otpMessage) {
        Pattern p = Pattern.compile("(\\d{" + Integer.parseInt(props.getString("perfectoOTPLength")) + "})");
        final Matcher m = p.matcher(otpMessage);
        if (m.find()) {
            return m.group(0);
        }
        return "";
    }


    protected void closeAppilcation(String applicationName, WebDriver driver) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        Map<String, String> startapp = new HashMap<>();
        startapp.put("name", applicationName);
        js.executeScript("mobile:application:close", startapp);
    }
    
    protected void openWebApplicationInBrowser(String webAppName, String browserName, WebDriver driver) {    	
    	final String propsFilePath = ENVIRONMENTPATH + Property.getVariable(ENV_PROP) + PROPERTIES_EXT;
    	if(browserName == null) {
    		browserName = DriverContext.getInstance().getMobileTechStack().get("browserName");
    	} 
    	String url = Property.getProperty(propsFilePath, webAppName);
        if (url != null) {
        	url = replaceParameterVals(url);
        	JavascriptExecutor js = (JavascriptExecutor) driver;
            Map<String, String> launchURLParam = new HashMap<>();
            launchURLParam.put("automation", browserName.toLowerCase());
            launchURLParam.put("waitForPageLoad", "true");
            launchURLParam.put("url", url);
            js.executeScript("mobile:browser:goto", launchURLParam);            
        	logStepMessage(String.format("Browser: %s| URL: %s | Environment: %s", browserName, url, Property.getVariable(ENV_PROP)));
        } else {
        	String errMsg = "App URL for '" + webAppName + "' not found in properties file: " + propsFilePath;
            log.error(errMsg);
            throw new IllegalArgumentException(errMsg);
        }
    }
    
    protected void captureAndAttachScreenshot(WebDriver driver){
    	String screenshotPath = saveScreenshotType(driver).getAbsolutePath();
        if (!screenshotPath.equalsIgnoreCase(ERROR_RESPONSE)) {
            addScreenCaptureFromPath(screenshotPath);
            TestContext.getInstance().testdata().put("fw.screenshotAbsolutePath", screenshotPath);
        }
    }
    
    protected File saveScreenshotType(WebDriver driver) {
        String screenshotPath = null;
        String defaultReportPath = System.getProperty("user.dir") + File.separator + "target" + File.separator + "allure-results" + File.separator;
        String reportPath = Property.getVariable("reportPath");
        screenshotPath = (reportPath == null ? defaultReportPath : reportPath) + "screenshots" + File.separator;           

        // Save the Screenshot
        return Screenshot.saveScreenshot(Screenshot.grabScreenshot(driver), screenshotPath);
    }  
    
    public void uploadToRepository(String path, String artifactLocator) throws Exception {
    	File fileToUpload = new File(path);
    	//default to src/test/resources/testdata folder if only a file name is provided
        if (!fileToUpload.isAbsolute()) {
            fileToUpload = new File(Paths.get(TESTDATAPATH + path).toString());
        }
        
        if (!fileToUpload.exists()) {
        	String errorMsg = String.format("File does not exist at path: %s", fileToUpload);
            log.error(errorMsg);
            Reporter.addStepLog("ERROR", errorMsg);
            return;
        }
    	String securityToken = Property.getVariable("cukes.perfectoSecurityToken");
    	String proxyHost = String.valueOf(props.getString("perfecto.proxyHost"));
        int proxyPort = Integer.parseInt(props.getString("perfecto.proxyPort"));
        HttpHost hostProxy = new HttpHost(proxyHost, proxyPort, "http");
    	HttpClient httpClient = HttpClientBuilder.create().setProxy(hostProxy).build();
    	URIBuilder taskUriBuilder = new URIBuilder("https://citi.app.perfectomobile.com/repository/api/v1/artifacts");    	
    	HttpPost httppost = new HttpPost(taskUriBuilder.build());
    	httppost.setHeader("Perfecto-Authorization", securityToken);
    	
    	MultipartEntityBuilder mpEntity = MultipartEntityBuilder.create();
    	File packagedFile = new File(path);
    	ContentBody inputStream = new FileBody(packagedFile, ContentType.APPLICATION_OCTET_STREAM);
    	
    	String requestPartStr = String.format("{'artifactLocator':'%s','override': 'true'}", artifactLocator);
    	
    	ContentBody requestPart = new StringBody(requestPartStr, ContentType.APPLICATION_JSON);
    	mpEntity.addPart("inputStream", inputStream);
    	mpEntity.addPart("requestPart", requestPart);
    	httppost.setEntity(mpEntity.build());
    	HttpResponse response = httpClient.execute(httppost);
    	    	
    	if(response.getStatusLine().getStatusCode() == 200) {
    		log.info("File has been uploaded to the Repository.");
    	} else {
    		log.error("Error occured while uploading to the Repository.");
    		throw new Exception("Error occured while uploading to the Repository: " + response.getStatusLine().getStatusCode() + " : " + EntityUtils.toString(response.getEntity()));    		
    	}    	
    }
    
    public void uploadFromRepositoryToDevice(String repositoryPath, String devicePath) {
    	JavascriptExecutor js = (JavascriptExecutor) getMobileDriver();
    	Map<String, Object> params = new HashMap<>();
    	params.put("handsetFile", devicePath);
    	params.put("repositoryFile", repositoryPath);
    	js.executeScript("mobile:media:put", params);
    	log.info("File has been uploaded to the Mobile Device.");
    }
    
    public void scrollWithPercentageOnMobileDevice(String start, String end, WebDriver driver) {
    	JavascriptExecutor js = (JavascriptExecutor) driver;
    	Map<String, Object> params = new HashMap<>();
    	params.put("start", start);
        params.put("end", end);
        params.put("duration", "2");
        Object res = js.executeScript("mobile:touch:swipe", params);
    } 
        
}