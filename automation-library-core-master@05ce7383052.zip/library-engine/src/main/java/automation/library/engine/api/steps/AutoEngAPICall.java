package automation.library.engine.api.steps;

import automation.library.api.Constants;
import automation.library.common.TestContext;
import automation.library.engine.api.BaseAPISteps;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

import java.io.IOException;
import java.util.Map;
import java.util.StringTokenizer;

import static automation.library.engine.core.objectmatcher.ObjectFinder.invokePOMethod;

public class AutoEngAPICall extends BaseAPISteps {

    public static final String FEATURE_NAME = "featureName";

    @Given("^the user sends request to the \"([^\"]*)\" API$")
    public void theUserSendsRequestToTheAPI(String featureName) {
        featureName = getAPIObject(featureName);
        Map<String, Object> args = getAPICallParamList("ALL");
        args.put(FEATURE_NAME, featureName);

        callAPIWithoutTag(featureName, args);
    }

    @Given("^the user sends request to the \"([^\"]*)\" API with parameters \"([^\"]*)\"$")
    public void theUserSendsRequestToTheAPIWithParams(String featureName,
                                                      String paramList) {
        featureName = getAPIObject(featureName);
        Map<String, Object> args = getAPICallParamList(paramList);
        args.put(FEATURE_NAME, featureName);

        callAPIWithoutTag(featureName, args);
    }

    @Given("^the user sends request to the \"([^\"]*)\" API with tag \"([^\"]*)\"$")
    public void theUserSendsRequestToTheAPIWithTag(String featureName, String tagName) {
        featureName = getAPIObject(featureName);
        Map<String, Object> args = getAPICallParamList("ALL");
        args.put(FEATURE_NAME, featureName);
        args.put("tagName", tagName);

        callAPIWithTag(featureName, args);
    }

    @Given("the user calls list of APIs \"([^\"]*)\"$")
    public void theUserCallsMultipleAPI(String featureNameList) {
        StringTokenizer stringTokenizer = new StringTokenizer(featureNameList, "|");
        Map<String, Object> args = TestContext.getInstance().testdata();

        while (stringTokenizer.hasMoreTokens()) {
            Map<String, Object> result = runAPIFeatureFile(String.format("classpath:%s/services/%s.feature", Constants.APIOBJECTSFOLDER, stringTokenizer.nextToken()), args);
            TestContext.getInstance().testdataPut(stringTokenizer.nextToken(), result);
        }
    }

    @When("^replace parameter values in the \"([^\"]*)\" API Request XML file and save to the \"([^\"]*)\" new XML file$")
    public void theUserCleansesTheXMLRequest(String xmlTemplate, String xmlTarget) throws IOException {
        replaceParamsInXMLFile(xmlTemplate, xmlTarget);
    }

    @Given("^the user sends \"([^\"]*)\" request to the \"([^\"]*)\" mq with payload \"([^\"]*)\"$")
    public void theUserSendsRequestToTheMQ(String syncParam, String queueName, String payLoadFile) {
        queueName = parseValue(queueName);
        syncParam = parseValue(syncParam);
        callMQ(syncParam, queueName, payLoadFile);
    }

    @When("^the user perform the API process defined in the \"([^\"]*)\"$")
    public void processAlert(String apiObject) throws InstantiationException,
                                                      IllegalAccessException {
        invokePOMethod(apiObject, "baseMethod");
    }

}
