package automation.library.engine.desktop.steps;

import automation.library.engine.desktop.BaseDesktopSteps;
import automation.library.leanft.exec.DesktopContext;
import com.hp.lft.sdk.GeneralLeanFtException;
import io.cucumber.java.en.When;

public class AutoEngDesktopSelect extends BaseDesktopSteps {

    private static final String SELECTED_VALUE = "Selected value: \"%s\"";

    @When("^the user selects value \"([^\"]*)\" from the \"([^\"]*)\" comboBox on the \"([^\"]*)\" desktop window$")
    public void theUserSelectsFromTheComboBoxOnTheDesktopWindow(String value, String fieldName, String windowName) throws GeneralLeanFtException {
        DesktopContext.getInstance().setCurrentLeanFTWindow(getDesktopWindow(windowName));
        value = parseValue(value);
        getDesktopComboBox(fieldName, windowName).select(value);
        logStepMessage(String.format(SELECTED_VALUE, value));
    }

    @When("^the user selects valueIndex \"([^\"]*)\" from the \"([^\"]*)\" comboBox on the \"([^\"]*)\" desktop window$")
    public void theUserSelectsFromTheValueIndexComboBoxOnTheDesktopWindow(String valueIndex, String fieldName, String windowName) throws GeneralLeanFtException {
        DesktopContext.getInstance().setCurrentLeanFTWindow(getDesktopWindow(windowName));
        valueIndex = parseValue(valueIndex);
        getDesktopComboBox(fieldName, windowName).select(Integer.parseInt(valueIndex));
        logStepMessage(String.format(SELECTED_VALUE, valueIndex));
    }


    @When("^the user selects value \"([^\"]*)\" from the \"([^\"]*)\" tabs on the \"([^\"]*)\" desktop window$")
    public void theUserSelectsFromTheTabOnTheDesktopWindow(String value, String fieldName, String windowName) throws GeneralLeanFtException {
        DesktopContext.getInstance().setCurrentLeanFTWindow(getDesktopWindow(windowName));
        value = parseValue(value);
        getDesktopTabControl(fieldName, windowName).select(value);
        logStepMessage(String.format(SELECTED_VALUE, value));
    }

    @When("^the user selects value \"([^\"]*)\" from the \"([^\"]*)\" toolbar on the \"([^\"]*)\" desktop window$")
    public void theUserSelectsFromTheToolBarOnTheDesktopWindow(String value, String fieldName, String windowName) throws GeneralLeanFtException {
        DesktopContext.getInstance().setCurrentLeanFTWindow(getDesktopWindow(windowName));
        value = parseValue(value);
        getDesktopToolBar(fieldName, windowName).select(value);
        logStepMessage(String.format(SELECTED_VALUE, value));
    }

    @When("^the user selects value \"([^\"]*)\" from the \"([^\"]*)\" listview on the \"([^\"]*)\" desktop window$")
    public void theUserSelectsFromTheListViewOnTheDesktopWindow(String value, String fieldName, String windowName) throws GeneralLeanFtException {
        DesktopContext.getInstance().setCurrentLeanFTWindow(getDesktopWindow(windowName));
        value = parseValue(value);
        getDesktopListView(fieldName, windowName).select(value);
        logStepMessage(String.format(SELECTED_VALUE, value));
    }
    @When("^the user selects value by index \"([^\"]*)\" from the \"([^\"]*)\" listview on the \"([^\"]*)\" desktop window$")
    public void theUserSelectsByIndexFromTheListViewOnTheDesktopWindow(String value, String fieldName, String windowName) throws GeneralLeanFtException {
        DesktopContext.getInstance().setCurrentLeanFTWindow(getDesktopWindow(windowName));
        int Intvalue = Integer.parseInt(value);
        getDesktopListView(fieldName, windowName).selectByIndex(Intvalue);
        logStepMessage(String.format(SELECTED_VALUE, value));
    }
    @When("^the user activates value \"([^\"]*)\" from the \"([^\"]*)\" listview on the \"([^\"]*)\" desktop window$")
    public void theUserActivatesValueFromTheListViewOnTheDesktopWindow(String value, String fieldName, String windowName) throws GeneralLeanFtException {
        DesktopContext.getInstance().setCurrentLeanFTWindow(getDesktopWindow(windowName));
        value = parseValue(value);
        getDesktopListView(fieldName, windowName).activateItem(value);
        logStepMessage(String.format(SELECTED_VALUE, value));
    }
    @When("^the user selects row value \"([^\"]*)\" for column value  \"([^\"]*)\" from the \"([^\"]*)\" listview on the \"([^\"]*)\" desktop window$")
    public void theUserSelectsRowColFromTheListViewOnTheDesktopWindow(String rowVal, String colValue, String fieldName, String windowName) throws GeneralLeanFtException {
        DesktopContext.getInstance().setCurrentLeanFTWindow(getDesktopWindow(windowName));
        rowVal = parseValue(rowVal);
        getDesktopListView(fieldName, windowName).selectColRow(colValue, rowVal);
        logStepMessage(String.format(SELECTED_VALUE, rowVal));

    }

    @When("^the user selects value \"([^\"]*)\" from the \"([^\"]*)\" listbox on the \"([^\"]*)\" desktop window$")
    public void theUserSelectsFromTheListBoxOnTheDesktopWindow(String value, String fieldName, String windowName) throws GeneralLeanFtException {
        DesktopContext.getInstance().setCurrentLeanFTWindow(getDesktopWindow(windowName));
        value = parseValue(value);
        getDesktopWebListBox(fieldName, windowName).select(value);
        logStepMessage(String.format(SELECTED_VALUE, value));
    }

    @When("^the user selects the \"([^\"]*)\" value from the \"([^\"]*)\" radio button at the \"([^\"]*)\" desktop window$")
    public void theUserSelectsValueFromWebRadioButtonAtTheDesktopWenRadio(String value, String fieldName, String windowName) throws GeneralLeanFtException {
        DesktopContext.getInstance().setCurrentLeanFTWindow(getDesktopWindow(windowName));
        value = parseValue(value);
        getDesktopRadioButton(fieldName, windowName).select(value);
    }

    @When("^the user selects the \"([^\"]*)\" index from the \"([^\"]*)\" radio button at the \"([^\"]*)\" desktop window$")
    public void theUserSelectsIndexFromWebRadioButtonAtTheDesktopWenRadio(int index, String fieldName, String windowName) throws GeneralLeanFtException {
        DesktopContext.getInstance().setCurrentLeanFTWindow(getDesktopWindow(windowName));
        getDesktopRadioButton(fieldName, windowName).select(index);
    }

    @When("^the user selects the matching cell in the \"([^\"]*)\" column where \"([^\"]*)\" column contains row value \"([^\"]*)\" from the \"([^\"]*)\" table at the \"([^\"]*)\" desktop window$")
    public void theUserSelectsOnTheMatchingCellInTheColumnContainingAndWhereTheColumnContainsFromTheTableAtTheDesktopWindow(int secondColumn,
                                                                                                                            int firstColumn,
                                                                                                                            String firstRow,
                                                                                                                            String tableName,
                                                                                                                            String windowName) throws GeneralLeanFtException {
        DesktopContext.getInstance().setCurrentLeanFTWindow(getDesktopWindow(windowName));
        String val=  getDesktopTable(tableName, windowName).selectMatchingRow(secondColumn,firstColumn,firstRow);
        logStepMessage(String.format(SELECTED_VALUE, val));

    }

}
