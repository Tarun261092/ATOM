package automation.library.engine.pdf.steps;

import automation.library.common.PDFHelper;
import automation.library.common.TestContext;
import automation.library.engine.pdf.BasePDFSteps;
import io.cucumber.java.en.Given;
import org.apache.pdfbox.pdmodel.PDDocument;

import static automation.library.engine.core.AutoEngConstants.PDF;

public class AutoEngPDFOpen extends BasePDFSteps {
    @Given("^the pdf at path \"([^\"]*)\" is opened$")
    public void thePDFIsOpened(String pathToFile) {
        TestContext.getInstance().setActiveWindowType(PDF);
        pathToFile = parseValue(pathToFile);
        TestContext.getInstance().testdataPut("fw.filePath", pathToFile);
        PDDocument document = PDFHelper.getDoc(pathToFile);
        if (document != null) {
            TestContext.getInstance().testdataPut(ACTIVE_PDF, document);
            TestContext.getInstance().testdata().put(CURRENT_PAGE_PDF, 0);

        } else {
            throw new IllegalArgumentException(String.format("Could not find PDF at path: %s", pathToFile));
        }
    }

    @Given("^the active pdf is closed$")
    public void thePDFisClosed() throws IllegalAccessException {
        PDFHelper.closePDFDoc(getActivePDF());
        TestContext.getInstance().testdata().remove(ACTIVE_PDF);
    }

}
