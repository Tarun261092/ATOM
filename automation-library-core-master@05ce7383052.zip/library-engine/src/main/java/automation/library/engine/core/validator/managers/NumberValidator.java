package automation.library.engine.core.validator.managers;

import automation.library.common.TestContext;
import automation.library.engine.core.validator.FailureFlag;
import automation.library.engine.core.validator.ValidatorManager;

import static automation.library.engine.core.validator.FailureFlag.*;
import static org.assertj.core.api.Assertions.*;

public class NumberValidator extends ValidatorManager {
    private FailureFlag onFailureFlag;

    public NumberValidator(String onFailureFlag) {
        this.onFailureFlag = valueOfLabel(onFailureFlag);
    }

    @Override
    protected void assertEquals(Object actual, Object expected, String assertMsg) {
        if(onFailureFlag == HARD_STOP_ON_FAILURE) {
            assertThat(Double.parseDouble(actual.toString())).as(assertMsg)
                                                             .isEqualTo(Double.parseDouble(expected.toString()),
                                                             withPrecision(2d));
        } else {
            TestContext.getInstance().sa()
                       .assertThat(Double.parseDouble(actual.toString())).as(assertMsg).isEqualTo(Double.parseDouble(expected.toString()),
                                                                                                  withPrecision(2d));
        }
    }

    @Override
    protected void assertEqualsIgnoreCase(Object actual, Object expected, String assertMsg) {
        throw new UnsupportedOperationException("EqualIgnoreCase assertion not available for Compare_Numbers");
    }

    @Override
    protected void assertNotEquals(Object actual, Object expected, String assertMsg) {
        if(onFailureFlag == HARD_STOP_ON_FAILURE) {
            assertThat(Double.parseDouble(actual.toString())).as(assertMsg).isNotEqualTo(Double.parseDouble(expected.toString()));
        } else {
            TestContext.getInstance().sa()
                       .assertThat(Double.parseDouble(actual.toString())).as(assertMsg).isNotEqualTo(Double.parseDouble(expected.toString()));
        }

    }

    @Override
    protected void assertLessThan(Object actual, Object expected, String assertMsg) {
        if(onFailureFlag == HARD_STOP_ON_FAILURE) {
            assertThat(Double.parseDouble(actual.toString())).as(assertMsg).isLessThan(Double.parseDouble(expected.toString()));
        } else {
            TestContext.getInstance().sa()
                       .assertThat(Double.parseDouble(actual.toString())).as(assertMsg).isLessThan(Double.parseDouble(expected.toString()));
        }
    }

    @Override
    protected void assertLessThanOrEqual(Object actual, Object expected, String assertMsg) {
        if(onFailureFlag == HARD_STOP_ON_FAILURE) {
            assertThat(Double.parseDouble(actual.toString())).as(assertMsg).isLessThanOrEqualTo(Double.parseDouble(expected.toString()));
        } else {
            TestContext.getInstance().sa()
                       .assertThat(Double.parseDouble(actual.toString())).as(assertMsg).isLessThanOrEqualTo(Double.parseDouble(expected.toString()));
        }
    }

    @Override
    protected void assertGreaterThan(Object actual, Object expected, String assertMsg) {
        if(onFailureFlag == HARD_STOP_ON_FAILURE) {
            assertThat(Double.parseDouble(actual.toString())).as(assertMsg).isGreaterThan(Double.parseDouble(expected.toString()));
        } else {
            TestContext.getInstance().sa()
                       .assertThat(Double.parseDouble(actual.toString())).as(assertMsg).isGreaterThan(Double.parseDouble(expected.toString()));
        }
    }

    @Override
    protected void assertGreaterThanOrEqual(Object actual, Object expected, String assertMsg) {
        if(onFailureFlag == HARD_STOP_ON_FAILURE) {
            assertThat(Double.parseDouble(actual.toString())).as(assertMsg).isGreaterThanOrEqualTo(Double.parseDouble(expected.toString()));
        } else {
            TestContext.getInstance().sa()
                       .assertThat(Double.parseDouble(actual.toString())).as(assertMsg).isGreaterThanOrEqualTo(Double.parseDouble(expected.toString()));
        }
    }

    @Override
    protected void assertContains(Object actual, Object expected, String assertMsg) {
        throw new UnsupportedOperationException("Contains comparison not supported for Compare_Numbers");
    }

    @Override
    protected void assertDoesNotContain(Object actual, Object expected, String assertMsg) {
        throw new UnsupportedOperationException("Does Not Contain assertion not available for Compare_Numbers.");
    }

}
