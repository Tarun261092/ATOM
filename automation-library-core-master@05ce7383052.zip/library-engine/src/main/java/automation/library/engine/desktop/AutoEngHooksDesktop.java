package automation.library.engine.desktop;

import automation.library.common.Property;
import automation.library.common.TestContext;
import automation.library.leanft.core.Constants;
import automation.library.leanft.exec.DesktopContext;
import io.cucumber.core.api.Scenario;
import io.cucumber.java8.En;
import org.apache.commons.configuration2.PropertiesConfiguration;

import static automation.library.engine.core.AutoEngConstants.DESKTOP;

public class AutoEngHooksDesktop implements En {

    public AutoEngHooksDesktop() {
        Before(40, (Scenario scenario) -> {
            setLeanFTRuntimeProperties();
        });

        After(40, (Scenario scenario) -> {
            if (TestContext.getInstance().getActiveWindowType() != null &&
                TestContext.getInstance().getActiveWindowType().equalsIgnoreCase(DESKTOP)) {
                DesktopContext.getInstance().quitAut();
                DesktopContext.removeInstance();
            }

        });
    }

    private void setLeanFTRuntimeProperties() {
        PropertiesConfiguration props = Property.getProperties(Constants.LEANFTRUNTIMEPATH);

        if (props != null) {
            String defaultFindRetries = props.getString("defaultFindRetries") == null ? "3" : props.getString("defaultFindRetries");
            System.setProperty(Constants.DEFAULT_RETRIES, defaultFindRetries);

            String screenRefindDelay = props.getString("screenRefindDelay") == null ? "1000" : props.getString("screenRefindDelay");
            System.setProperty("fw.screenRefindDelay", screenRefindDelay);

            DesktopContext.getInstance().setKeepTEOpen(Boolean.parseBoolean(props.getString("keepTEOpenOnFailure")));

            String screenshotOnValidations = props.getString("screenshotOnValidation");
            String screenshotOnFailure = props.getString("screenshotOnFailure");
            String screenshotOnEveryStep = props.getString("screenshotOnEveryStep");
            String trimMFTextOnRetrieval = props.getString("trimMFTextOnRetrieval");

            if (screenshotOnValidations != null) {
                System.setProperty("fw.screenshotOnValidation", screenshotOnValidations);
            }
            if (screenshotOnFailure != null) {
                System.setProperty("fw.screenshotOnFailure", screenshotOnFailure);
            }
            if (screenshotOnEveryStep != null) {
                System.setProperty("fw.screenshotOnEveryStep", screenshotOnEveryStep);
            }
            if (trimMFTextOnRetrieval != null) {
                System.setProperty("fw.trimMFTextOnRetrieval", trimMFTextOnRetrieval);
            }
        }
    }
}
