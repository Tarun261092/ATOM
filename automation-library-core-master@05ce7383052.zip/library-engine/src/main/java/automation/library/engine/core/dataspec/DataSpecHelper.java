package automation.library.engine.core.dataspec;

import automation.library.common.ExcelHelper;
import automation.library.common.FileHelper;
import automation.library.common.Property;
import automation.library.common.TestContext;
import automation.library.cucumber.core.Constants;
import automation.library.tdaas.core.dataspec.common.CommonUtils;
import automation.library.tdaas.core.dataspec.common.DataSpecException;
import automation.library.tdaas.core.dataspec.tdaas.DataRetrievalClient;
import automation.library.tdaas.core.dataspec.tdaas.QueryClient;
import automation.library.tlm.TlmContext;
import com.google.gson.JsonSyntaxException;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.JsonPathException;
import com.jayway.jsonpath.ReadContext;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.*;
import java.util.stream.Collectors;

public class DataSpecHelper {
    private static final String QUERY_NAME = "queryName";
    private static final String REQUEST_ID = "requestId";
    private static final String ERROR_RESPONSE = "-1";
    private List<Map<String, Object>> dataResultList = new ArrayList<>();
    private ReadContext jsonFile = null;
    private String rootAttribute = null;
    private boolean dataRetrievedWithRequestId = false;

    private final Logger log = LogManager.getLogger(DataSpecHelper.class);

    public List<Map<String, Object>> processDataSpec(String testName) {
        String errorMsg = "Unable to load data for this test. Skipping data load.";

        try {
            jsonFile = readJsonFile(testName);
            setRootAttribute();
            addTDaaSDataToResultList();

            if (!dataRetrievedWithRequestId) {
                addQueryDataToResultList();
            }

            addStaticDataToResultList();
        } catch (DataSpecException e) {
            errorMsg = errorMsg + " " +  e.getMessage();
        }

        addExternalFlatFileData(testName);

        if (dataResultList.isEmpty()) {
            log.warn(errorMsg);
            return Collections.emptyList();
        } else {
            return dataResultList;
        }
    }

    private void setRootAttribute() {
        try {
            jsonFile.read("$.TDaaS", Map.class);
            rootAttribute = "TDaaS";
        } catch (JsonPathException e) {
            try {
                jsonFile.read("$.DataAutomation", Map.class);
                rootAttribute = "DataAutomation";
            } catch (JsonPathException e2) {
                log.warn(e2.getMessage());
                throw new DataSpecException("Unable to find a matching root attribute in the " +
                                            "JSON data spec for retrieval");
            }
        }
    }

    private ReadContext readJsonFile(String testName) {
        final String jsonDataSpecName = String.format("%s.json", testName);
        String MultiJSONFlag = Property.getProperty(Constants.ALMPROPERTIESPATH, "enableMultipleJSON");
        String pathToDataSpec = "";
        if(MultiJSONFlag!=null)
        {
        	String FullPath = Constants.FEATUREFILEPATH+"/"+ Property.getProperty(Constants.ALMPROPERTIESPATH, "enableMultipleJSON");
        	pathToDataSpec = FileHelper.findFileInPath(FullPath, jsonDataSpecName);
        	log.info("************Mulitple JSON Flag is enabled*********");
        	log.info("Reading JSON file from :"+pathToDataSpec+"");
        }
        else
        {
        	pathToDataSpec = FileHelper.findFileInPath(Constants.FEATUREFILEPATH, jsonDataSpecName);
        	log.info("Reading JSON file from :"+pathToDataSpec+"");
        }
        if (pathToDataSpec != null) {
            try {
                return JsonPath.parse(new FileInputStream(new File(pathToDataSpec)));
            } catch (FileNotFoundException | NullPointerException | JsonSyntaxException e) {
                log.error(e.getMessage(), e);
                throw new DataSpecException(e.getMessage());
            }
        } else {
            throw new DataSpecException(String.format("Data spec was not found: '%s'", jsonDataSpecName));
        }
    }

    private void addQueryDataToResultList() {
        Map<String, Object> sqlContent = jsonFile.read(getTDaaSJsonPath(getSQLAttribute()), Map.class);

        if (sqlContent != null &&
            sqlContent.containsKey(QUERY_NAME) &&
            !sqlContent.get(QUERY_NAME).toString().isEmpty()) {
            QueryClient queryClient = new QueryClient(jsonFile.read(getTDaaSJsonPath("sharedAttributes"), Map.class),
                                                      CommonUtils.getTDaaSClient());

            List<Map<String, Object>> resultSet = queryClient.runTDaaSQuery(sqlContent.get(QUERY_NAME).toString(),
                                                                            getParamList(sqlContent));

            dataResultList.addAll(resultSet);
        }

    }

    private void addTDaaSDataToResultList() {
        Map<String, Object> apiContent = jsonFile.read(getTDaaSJsonPath(getSQLAttribute()), Map.class);

        if (apiContent != null) {
            if (apiContent.containsKey("dataConsumed")) {
                TestContext.getInstance().testdataPut("fw.dataConsumed", apiContent.get("dataConsumed"));
            }

            if (apiContent.containsKey(REQUEST_ID) && !apiContent.get(REQUEST_ID).toString().isEmpty()) {
                List<String> requestIds = getRequestIds(apiContent);

                DataRetrievalClient dataRetrievalClient = new DataRetrievalClient(CommonUtils.getTDaaSClient());
                List<Map<String, Object>> resultSet = dataRetrievalClient.getDataForRequestId(requestIds);

                if (!resultSet.isEmpty()) {
                    dataRetrievedWithRequestId = true;
                    dataResultList.addAll(resultSet);
                }
            }
        }

    }

    private List<String> getRequestIds(Map<String, Object> apiContent) {
        List<String> requestIds = new ArrayList<>();

        try {
            if (TlmContext.getInstance().updateTlmFlag() &&
                TlmContext.getInstance().getTlmManager().retrieveRequestIDFromTestInstance()) {
                String requestId = TlmContext.getInstance().getTlmManager().getRequestIdFromTool(getTestIdFromJson());
                if (!requestId.equalsIgnoreCase(ERROR_RESPONSE)) {
                    requestIds.add(requestId);
                } else {
                    requestIds = (List) apiContent.get(REQUEST_ID);
                }
            }
        } catch (ClassCastException e) {
            log.error(e.getMessage());
        }

        return requestIds;
    }

    private String getTestIdFromJson() {
        Map<String, String> sharedAttributes = jsonFile.read(getTDaaSJsonPath("sharedAttributes"), Map.class);
        return sharedAttributes.get("test_id");
    }

    private String getSQLAttribute() {
        try {
            jsonFile.read(getTDaaSJsonPath("sql"), Map.class);
            return "sql";
        } catch (JsonPathException e) {
            try {
                jsonFile.read(getTDaaSJsonPath("api"), Map.class);
                return "api";
            } catch (JsonPathException e2) {
                log.warn(e2.getMessage());
                return "";
            }
        }
    }

    private Map<String, Object> getParamList(Map<String, Object> sqlContent) {
        return sqlContent.entrySet()
                         .stream()
                         .filter(entry -> entry.getKey().matches(".*(?i)(param)(?i).*"))
                         .collect(Collectors.toMap(Map.Entry::getKey,
                                                   entry -> parseJsonPathVal(entry.getValue().toString())));


    }

    private void addStaticDataToResultList() {
        Map<String, Object> staticData = jsonFile.read(getTDaaSJsonPath("staticData"), Map.class);

        if (staticData != null) {
            Map<String, Object> staticDataFiltered = staticData.entrySet()
                                                               .stream()
                                                               .filter(entry -> !entry.getValue().toString().isEmpty())
                                                               .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));

            if (!dataResultList.isEmpty()) {
                dataResultList.forEach(dataRow -> staticDataFiltered.forEach(dataRow::put));
            } else
                dataResultList.add(staticDataFiltered);
        }
    }

    private String getTDaaSJsonPath(String jsonPathAddition) {
        StringJoiner jsonPath = new StringJoiner(".");

        jsonPath.add("$");
        jsonPath.add(rootAttribute);
        jsonPath.add(jsonPathAddition);

        return jsonPath.toString();
    }

    private String parseJsonPathVal(String valToParse) {
        if (valToParse.matches("^\\$\\..*")) {
            try {
                if (valToParse.matches(".*\\.\\..*")) {
                    List<String> actualVal = jsonFile.read(valToParse, List.class);
                    return actualVal.get(0);
                } else {
                    return jsonFile.read(valToParse, String.class);
                }
            } catch (JsonPathException e) {
                log.error("Invalid JSON Path: {} Returning actual value.", valToParse);
                return valToParse;
            } catch (ClassCastException e) {
                log.error("JSON Path type mismatch. Check for array references {}", valToParse);
                return valToParse;
            }
        } else {
            return valToParse;
        }
    }

    private void addExternalFlatFileData(String testName) {
        String fileName = testName + ".xlsx";
        String pathToFlatFile = FileHelper.findFileInPath(Constants.TESTDATAPATH, fileName);

        if (pathToFlatFile != null) {
            List<Map<String, Object>> fileDataResultList = ExcelHelper.getExcelDataAsMapWithoutIndex(pathToFlatFile,
                                                                                                     Property.getVariable("cukes.env"));

            if (!dataResultList.isEmpty()) {
                List<Map<String, Object>> tempDataResultList = new ArrayList<>();
                mergeExcelToDataSet(fileDataResultList, tempDataResultList);

                dataResultList = new ArrayList<>(tempDataResultList);
            } else {
                dataResultList = new ArrayList<>(fileDataResultList);
            }
        }
    }

    private void mergeExcelToDataSet(List<Map<String, Object>> fileDataResultList,
                                     List<Map<String, Object>> tempDataResultList) {
        //Merge data sets
        for (int dataListCtr = 0; dataListCtr < dataResultList.size(); dataListCtr++) {
            Map<String, Object> dataResultMapEntry = dataResultList.get(dataListCtr);
            if (fileDataResultList.size() > dataListCtr) {
                Map<String, Object> excelMapEntry = fileDataResultList.get(dataListCtr);

                excelMapEntry.forEach(
                        (key, value) -> dataResultMapEntry.merge(key, value,
                                                                 (dataMapVal, excelMapVal) -> dataMapVal.toString()
                                                                                                        .equalsIgnoreCase(excelMapVal.toString()) ? dataMapVal : excelMapVal));
            }

            tempDataResultList.add(dataResultMapEntry);
        }
    }

    public Map<String, Object> processPreBatchDataSpec(String flow) {
        String preBatchDataFilePath = TlmContext.getInstance().getTlmManager().getDataTable(flow);

        try {
            ReadContext priorJsonFile = JsonPath.parse(new FileInputStream(new File(preBatchDataFilePath)));
            Map<String, Object> preBatchDataResultList = priorJsonFile.read("lastRun", Map.class);

            if (preBatchDataResultList != null && !preBatchDataResultList.isEmpty()) {
                List<Map<String, Object>> dataTableList = priorJsonFile.read("$..priorData[*]", List.class);
                dataTableList.add(preBatchDataResultList);
                TestContext.getInstance().testdataPut("priorData", dataTableList);
                return preBatchDataResultList;
            } else {
                log.warn("Data spec and/or data file not found this test. Skipping prior test data load.");
            }
        } catch (FileNotFoundException | NullPointerException | JsonSyntaxException | ClassCastException e) {
            log.error("Unable to load prior data. {}", e::getMessage);
        }

        return Collections.emptyMap();
    }
}
