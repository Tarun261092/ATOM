package automation.library.engine.desktop.steps;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

import org.apache.commons.lang3.StringUtils;

import com.hp.lft.sdk.GeneralLeanFtException; 

import automation.library.engine.core.objectmatcher.ObjectNotFoundException;
import automation.library.engine.desktop.BaseDesktopSteps;
import automation.library.leanft.core.Constants;
import automation.library.leanft.core.desktop.web.WebDesktopBrowserWindow;
import automation.library.leanft.exec.DesktopContext;
import automation.library.reporting.Reporter;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;


public class AutoEngDesktopClick extends BaseDesktopSteps {
	private WebDesktopBrowserWindow parentWindow;

    @And("^the user clicks the \"([^\"]*)\" button at the \"([^\"]*)\" desktop window$")
    public void theUserClicksOnButtonAtTheDesktopWindow(String fieldName, String windowName) throws GeneralLeanFtException {
        DesktopContext.getInstance().setCurrentLeanFTWindow(getDesktopWindow(windowName));
        getDesktopButton(fieldName, windowName).click();
    }

    @And("^the user clicks the \"([^\"]*)\" label at the \"([^\"]*)\" desktop window$")
    public void theUserClicksOnButtonAtTheDesktopLabel(String fieldName, String windowName) throws GeneralLeanFtException {
        DesktopContext.getInstance().setCurrentLeanFTWindow(getDesktopWindow(windowName));
        getDesktopLabel(fieldName, windowName).click();
    }

    @And("^the user clicks on \"([^\"]*)\" ui object at the \"([^\"]*)\" desktop window$")
    public void theUserClicksAtTheDesktopUIObject(String fieldName, String windowName) throws GeneralLeanFtException {
        DesktopContext.getInstance().setCurrentLeanFTWindow(getDesktopWindow(windowName));
        getDesktopUiObject(fieldName, windowName).click();
    }

    @When("^the user clicks the \"([^\"]*)\" checkbox at the \"([^\"]*)\" desktop window$")
    public void theUserClicksAtTheDesktopCheckBox(String fieldName, String windowName) throws GeneralLeanFtException {
        DesktopContext.getInstance().setCurrentLeanFTWindow(getDesktopWindow(windowName));
        getDesktopCheckbox(fieldName, windowName).click();
    }

    @When("^the user clicks the \"([^\"]*)\" radio button at the \"([^\"]*)\" desktop window$")
    public void theUserClicksAtTheDesktopRadio(String fieldName, String windowName) throws GeneralLeanFtException {
        DesktopContext.getInstance().setCurrentLeanFTWindow(getDesktopWindow(windowName));
        getDesktopRadioButton(fieldName, windowName).click();
    }

    @And("^the user double clicks on \"([^\"]*)\" label at the \"([^\"]*)\" desktop window$")
    public void theUserDoubleClicksOnButtonAtTheDesktopWindow(String fieldName, String windowName) throws GeneralLeanFtException {
        DesktopContext.getInstance().setCurrentLeanFTWindow(getDesktopWindow(windowName));
        getDesktopButton(fieldName, windowName).doubleClick();
    }

    @And("^the user clicks the \"([^\"]*)\" button at the \"([^\"]*)\" desktop dialog window$")
    public void theUserClicksOnButtonAtTheDesktopDialogWindow(String fieldName, String windowName) throws GeneralLeanFtException {
        DesktopContext.getInstance().setCurrentLeanFTDialog(getDesktopDialog(windowName));
        getDesktopButton(fieldName, windowName).click();
    }

    @When("^the user doubleclicks value \"([^\"]*)\" from the \"([^\"]*)\" listview on the \"([^\"]*)\" desktop window$")
    public void theUserDoubleClicksFromTheListViewOnTheDesktopWindow(String value, String fieldName, String windowName) throws GeneralLeanFtException {
        DesktopContext.getInstance().setCurrentLeanFTWindow(getDesktopWindow(windowName));
        value = parseValue(value);
        getDesktopListView(fieldName, windowName).doubleClick(value);
    }

    @And("^the user clicks on \"([^\"]*)\" image at the \"([^\"]*)\" desktop window$")
    public void theUserClicksOnImageAtTheDesktopWindow(String imageName, String windowName) throws GeneralLeanFtException, IOException {
        String imagePath = System.getProperty("user.dir") + "/src/test/resources/" + "config/leanft/images/" + imageName + ".bmp";
        DesktopContext.getInstance().setCurrentLeanFTWindow(getDesktopWindow(windowName));
        getDesktopWindow(windowName).clickImage(imagePath, 1);
    }

    @And("^the user clicks the \"([^\"]*)\" web element at the \"([^\"]*)\" desktop window$")
    public void theUserClicksOnWebElementAtTheDesktopWindow(String fieldName, String windowName) throws GeneralLeanFtException {
        DesktopContext.getInstance().setCurrentLeanFTWindow(getDesktopWindow(windowName));
        getDesktopWebElement(fieldName, windowName).click();
    }

    @And("^the user double clicks the \"([^\"]*)\" web element at the \"([^\"]*)\" desktop window$")
    public void theUserDoubleClicksOnWebElementAtTheDesktopWindow(String fieldName, String windowName) throws GeneralLeanFtException {
        DesktopContext.getInstance().setCurrentLeanFTWindow(getDesktopWindow(windowName));
        getDesktopWebElement(fieldName, windowName).doubleClick();
    }

    @And("^the user clicks the \"([^\"]*)\" web link at the \"([^\"]*)\" desktop window$")
    public void theUserClicksOnWebLinkAtTheDesktopWindow(String fieldName, String windowName) throws GeneralLeanFtException {
        DesktopContext.getInstance().setCurrentLeanFTWindow(getDesktopWindow(windowName));
        getDesktopWebLink(fieldName, windowName).click();
    }

    @And("^the user clicks the cell at row \"([^\"]*)\" and column \"([^\"]*)\" of the \"([^\"]*)\" table at the \"([^\"]*)\" window$")
    public void theUserClicksOnCellAtTheDesktopWindow(String rownum, String colnum,String table, String window) throws GeneralLeanFtException {
        DesktopContext.getInstance().setCurrentLeanFTWindow(getDesktopWindow(window));
        getDesktopTable(table, window).clickCell(Integer.valueOf(rownum),Integer.valueOf(colnum));
    }

    @And("^the user clicks the \"([^\"]*)\" web image at the \"([^\"]*)\" desktop window$")
    public void theUserClicksOnWebImageAtTheDesktopWindow(String fieldName, String windowName) throws GeneralLeanFtException {
        DesktopContext.getInstance().setCurrentLeanFTWindow(getDesktopWindow(windowName));
        getDesktopWebImage(fieldName, windowName).click();
    }

    @And("^the user double clicks the \"([^\"]*)\" web image at the \"([^\"]*)\" desktop window$")
    public void theUserDoubleClicksOnWebImageAtTheDesktopWindow(String fieldName, String windowName) throws GeneralLeanFtException {
        DesktopContext.getInstance().setCurrentLeanFTWindow(getDesktopWindow(windowName));
        getDesktopWebImage(fieldName, windowName).doubleClick();
    }

    @And("^the user clicks the \"([^\"]*)\" textbox at the \"([^\"]*)\" desktop window$")
    public void theUserClicksOnWebTextBoxAtTheDesktopWindow(String fieldName, String windowName) throws GeneralLeanFtException {
        DesktopContext.getInstance().setCurrentLeanFTWindow(getDesktopWindow(windowName));
        getDesktopEditField(fieldName, windowName).click();
    }

    @And("^the user clicks the \"([^\"]*)\" listbox at the \"([^\"]*)\" desktop window$")
    public void theUserClicksOnWebListBoxAtTheDesktopWindow(String fieldName, String windowName) throws GeneralLeanFtException {
        DesktopContext.getInstance().setCurrentLeanFTWindow(getDesktopWindow(windowName));
        getDesktopWebListBox(fieldName, windowName).click();
    }
    
    @And("^the user encounters a conditional window clicks the \"([^\"]*)\" \"([^\"]*)\" at the \"([^\"]*)\" web desktop window$")
	public void theUserClicksOnConditionalButtonAtTheDesktopWindow(String fieldName, String elementType, String windowName) throws GeneralLeanFtException, FileNotFoundException {
		boolean focused = false;
		String browserType = "";
		String pageTitle = "";
		String wndwName = "";
		String PageobjectsFile = Constants.PAGEOBJECTJAVAPATH + windowName + ".java";
		File file_element = new File(PageobjectsFile);
		try(Scanner in = new Scanner(file_element);){
		while (in.hasNext()) {
			String line = in.nextLine();
			if (line.contains("return new WebDesktopBrowserWindow")) {
				wndwName = (StringUtils.substringBetween(line, "WebDesktopBrowserWindow", ");")).trim();
				pageTitle = StringUtils.substringBeforeLast(wndwName, ",");
				browserType = StringUtils.substringAfterLast(wndwName, ",");
				pageTitle = pageTitle.replaceAll("\"", "");
				pageTitle = pageTitle.replace("(", "");
				browserType = browserType.replaceAll("\"", "").trim();
			}
		}
		}catch(Exception e) {
			
		}
		try {
			this.parentWindow = new WebDesktopBrowserWindow(pageTitle, browserType);
			String pWindow = this.parentWindow.getWindow().getTitle();
			if (pWindow.equalsIgnoreCase(pageTitle)) {
				DesktopContext.getInstance().setCurrentLeanFTWindow(getDesktopWindow(windowName));
				focused = getDesktopObject(fieldName, windowName).exists() == null;
				if (!focused) {
					switch (elementType.toUpperCase()) {
					case "WEBBUTTON":
						getDesktopButton(fieldName, windowName).click();
						break;
					case "WEBELEMENT":
						getDesktopWebElement(fieldName, windowName).click();
						break;
					default:
						throw new ObjectNotFoundException("Please Enter a valid elementType : \""
								+ elementType.toUpperCase() + "\" is not valid");
					}
				}
			}
		} catch (Exception e) {
		}
	}
    
    @Then("^the user clicks on the \"([^\"]*)\" checkbox if the checkbox is not checked at the \"([^\"]*)\" desktop window$")
	public void theUserValidatesTheCheckboxIsCheckedAndClickAtTheDesktopWindow(String fieldName, String windowName)
			throws GeneralLeanFtException {
		DesktopContext.getInstance().setCurrentLeanFTWindow(getDesktopWindow(windowName));
		boolean checkBoxSelected = getDesktopCheckbox(fieldName, windowName).isChecked();
		final String compareDescription = String.format("Expected %s to be checked at the %s desktop window", fieldName,
				windowName);
		Reporter.addStepLog(compareDescription);
		if (!checkBoxSelected) {
			getDesktopCheckbox(fieldName, windowName).click();
		}
	}

}
