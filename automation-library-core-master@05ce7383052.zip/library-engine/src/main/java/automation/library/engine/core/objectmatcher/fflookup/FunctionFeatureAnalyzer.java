package automation.library.engine.core.objectmatcher.fflookup;

import automation.library.common.FileHelper;
import automation.library.common.Property;
import automation.library.db.exec.DBContext;
import automation.library.engine.core.parser.FeatureFileParser;

import org.apache.commons.configuration2.PropertiesConfiguration;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import static automation.library.common.StringHelper.removeSpecialChars;
import static automation.library.common.similarity.SimilarityHelper.getSimilarityScore;
import static automation.library.cucumber.core.Constants.RUNTIMEPATH;

public class FunctionFeatureAnalyzer {
    private static final double EXACT_THRESHOLD = 1;
    private static final double ABOVE_THRESHOLD = 0.85;
    protected final Logger log = LogManager.getLogger(FunctionFeatureAnalyzer.class);
    private String functionMatchName = null;
    private String subFeatureMatchName = null;
    private List<TagRating> functionMatches;
    private List<TagRating> subFeatureMatches;
    final List<FunctionFeature> functionFeatureList = new ArrayList<>();
    private static final String BANAMEX = "BANAMEX";
    private static final String NAQE = "NAQE";
    private static final String AE_PROPERTIES = "AE.properties";
    private static final String NAQE_SQLSERVER = "NAQE_SQLServer";
    private static final String BANAMEX_SQLSERVER = "BANAMEX_SQLServer";

    private class TagRating {
        private String tagName;
        private double similarityScore;

        public TagRating(String tagName, double tagScore) {
            this.tagName = tagName;
            this.similarityScore = tagScore;
        }

        public String getTagName() {
            return tagName;
        }

        public double getSimilarityScore() {
            return similarityScore;
        }
    }

    public FunctionFeatureAnalyzer() {
        connectToAEDB();
        getFunctionFeatureList();
    }

    public String getFunctionMatchName() {
        return functionMatchName;
    }

    public String getSubFeatureMatchName() {
        return subFeatureMatchName;
    }

    public String getFunctionMatches() {
        if (functionMatches != null) {
            return functionMatches.stream().map(TagRating::getTagName).collect(Collectors.joining(System.lineSeparator()));
        } else {
            return "";
        }
    }

    public String getSubFeatureMatches() {
        if (subFeatureMatches != null) {
            return subFeatureMatches.stream().map(TagRating::getTagName).collect(Collectors.joining(System.lineSeparator()));
        } else {
            return "";
        }
    }

    public boolean searchForMatchingFunction(List<String> fullListOfTags) {
        final List<TagRating> functionTags = compareAndRateTags(fullListOfTags,
                                                                functionFeatureList.stream()
                                                                                   .map(FunctionFeature::getFunction)
                                                                                   .collect(Collectors.toList()));

        if (!functionTags.isEmpty()) {
            TagRating topMatch = functionTags.get(0);

            if (topMatch.getSimilarityScore() >= EXACT_THRESHOLD) {
                functionMatchName = topMatch.tagName;
                return true;
            } else {
                functionMatches = new ArrayList<>(functionTags);
            }
        }

        return false;
    }

    public boolean matchBothFunctionAndSubFeature(List<String> fullListOfTags,
                                                  String matchingFunction) {
        final List<String> subFeatureForFunction = functionFeatureList.stream()
                                                                      .filter(entry -> entry.getFunction().equalsIgnoreCase(matchingFunction))
                                                                      .map(FunctionFeature::getSubFeature)
                                                                      .collect(Collectors.toList());

        final List<TagRating> subFeatureTags = compareAndRateTags(fullListOfTags, subFeatureForFunction);

        if (!subFeatureTags.isEmpty()) {
            TagRating topMatch = subFeatureTags.get(0);

            if (topMatch.getSimilarityScore() >= EXACT_THRESHOLD) {
                subFeatureMatchName = topMatch.tagName;
                return true;
            } else {
                subFeatureMatches = new ArrayList<>(subFeatureTags);
            }
        } else {
            subFeatureMatches = subFeatureForFunction.stream()
                                                     .distinct()
                                                     .sorted()
                                                     .map(entry -> new TagRating(entry, 0.0))
                                                     .collect(Collectors.toList());
        }

        return false;
    }

    private List<TagRating> compareAndRateTags(List<String> fullListOfTags,
                                               List<String> functionOrSubFeatureList) {
        List<TagRating> functionTags = new ArrayList<>();

        for (String tag : fullListOfTags) {
            List<TagRating> matchingTags = functionOrSubFeatureList.stream()
                                                                   .map(functionOrSubFeature -> new TagRating(functionOrSubFeature,
                                                                                                              getSimilarityScore(functionOrSubFeature, removeSpecialChars(tag))))
                                                                   .filter(ratedTag -> ratedTag.getSimilarityScore() >= ABOVE_THRESHOLD)
                                                                   .collect(Collectors.toList());
            if (!matchingTags.isEmpty()) {
                functionTags.addAll(matchingTags);
                functionTags.sort(Comparator.comparing(TagRating::getSimilarityScore).reversed());
            }
        }

        if (!functionTags.isEmpty()) {
            return functionTags.stream().filter(distinctByKey(tag -> tag.tagName)).collect(Collectors.toList());
        } else {
            return Collections.emptyList();
        }
    }

    private void connectToAEDB() {
    	PropertiesConfiguration props = Property.getProperties(RUNTIMEPATH);
        String ffFlag = props.getString("FunctionFeatureFlag");
        String dbConnectionString = "";
        
        if(ffFlag == null || ffFlag.isEmpty() || !ffFlag.equalsIgnoreCase(BANAMEX)) {
        	DBContext.getInstance().setAppName(NAQE);
        	dbConnectionString = getPropertyFromAEResources(AE_PROPERTIES,NAQE_SQLSERVER);
        }else if (ffFlag.equalsIgnoreCase(BANAMEX)){
        	DBContext.getInstance().setAppName(BANAMEX);
        	dbConnectionString = getPropertyFromAEResources(AE_PROPERTIES,BANAMEX_SQLSERVER);
        }
        
        DBContext.getInstance().setDatabaseType("SQLServer");
        DBContext.getInstance().setDatabaseURL(dbConnectionString);
        DBContext.getInstance().createConnection();
    }

    public void closeDBConnection() {
        DBContext.getInstance().closeConnection();
    }

    private String getPropertyFromAEResources(String fileName, String property) {
        final String fullPathToFile = String.format("%s/%s", "ff-lookup", fileName);
        try {
            Properties propFile = new Properties();
            propFile.load(FeatureFileParser.class.getClassLoader().getResourceAsStream(fullPathToFile));
            return propFile.getProperty(property);
        } catch (IOException e) {
            log.error(e);
            return null;
        }
    }

    private void getFunctionFeatureList() {
        final String fullPathToFile = String.format("%s/%s", "ff-lookup", "FFQuery.sql");

        try {
            final String queryString = FileHelper.getFileAsString((FeatureFileParser.class.getClassLoader().getResourceAsStream(fullPathToFile)), "\n");
            List<Map<String, Object>> queryResult = DBContext.getInstance().executeQuery(queryString);

            for (Map<String, Object> resultRow : queryResult) {
                FunctionFeature functionFeature = new FunctionFeature();
                functionFeature.setFunction(removeSpecialChars(String.valueOf(resultRow.get("FF_FUNCTION"))));
                functionFeature.setSubFeature(removeSpecialChars(String.valueOf(resultRow.get("FF_FEATURE"))));
                functionFeatureList.add(functionFeature);
            }

            log.info("Number of rows returned: {} rows", functionFeatureList.size());
        } catch (IOException e) {
            log.error(e.getMessage());
        }
    }

    private static <T> Predicate<T> distinctByKey(Function<? super T, ?> keyExtractor) {
        Map<Object, Boolean> seen = new ConcurrentHashMap<>();
        return t -> seen.putIfAbsent(keyExtractor.apply(t), Boolean.TRUE) == null;
    }
}
