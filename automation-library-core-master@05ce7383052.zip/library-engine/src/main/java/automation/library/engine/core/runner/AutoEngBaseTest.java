package automation.library.engine.core.runner;

import automation.library.cucumber.selenium.BaseTest;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(
        plugin = {"automation.library.engine.core.runner.AutoEngineFormatter",
                  "io.qameta.allure.cucumber4jvm.AllureCucumber4Jvm",
                  "json:target/cucumber-reports/runReport.json"},
        features = {"classpath:features"}
)
public class AutoEngBaseTest extends BaseTest {

}
