package automation.library.engine.api;

import automation.library.api.kafka.KafkaHandler;
import automation.library.common.TestContext;
import automation.library.engine.core.objectmatcher.fetch.FetchFlatFileObjects;
import io.cucumber.core.api.Scenario;
import io.cucumber.java8.En;

import static automation.library.engine.api.BaseAPISteps.TOPIC_KEY;

public class APIHooks implements En {

    public APIHooks() {
        Before(35, (Scenario scenario) -> {
            TestContext.getInstance().setOfAPI().addAll(FetchFlatFileObjects.populateListOfAPIObjects());
        });

        After(35, (Scenario scenario) -> {
            if(TestContext.getInstance().testdataGet(TOPIC_KEY) != null) {
                KafkaHandler kafkaHandler = TestContext.getInstance().testdataToClass(TOPIC_KEY, KafkaHandler.class);
                kafkaHandler.shutDown();
            }
        });
    }

}
