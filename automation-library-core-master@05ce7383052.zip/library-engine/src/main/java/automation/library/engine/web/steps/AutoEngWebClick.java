package automation.library.engine.web.steps;

import automation.library.engine.web.BaseWebSteps;
import automation.library.reporting.Reporter;
import automation.library.selenium.core.Element;
import io.cucumber.java.en.And;
import io.cucumber.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NotFoundException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

public class AutoEngWebClick extends BaseWebSteps {
    private static final String CLICKED_VALUE = "Clicked value: \"%s\"";
    private static final String CLICKING_ELEMENT = "Clicking element: {}";
    private static final String OUTER_HTML = "outerHTML";
    private static final String STATUS_FAIL = "FAIL";
    @When("^the user clicks the \"([^\"]*)\" element at the \"([^\"]*)\" page$")
    public void theUserClicksTheElementAtThePage(String objectName,
                                                 String pageName) {
        getObject(objectName, pageName).click();
    }

    @When("^the user doubleclicks the \"([^\"]*)\" element at the \"([^\"]*)\" page$")
    public void theUserDoubleclicksTheElementAtThePage(String objectName,
                                                       String pageName) {
        getObject(objectName, pageName).doubleClick();
    }

    @When("^the user rightclicks the \"([^\"]*)\" element at the \"([^\"]*)\" page$")
    public void theUserRightclicksTheElementAtThePage(String objectName,
                                                      String pageName) {
        getObject(objectName, pageName).rightClick();
    }

    @When("^the user clicks on \"([^\"]*)\" on the \"([^\"]*)\" checkbox at the \"([^\"]*)\" page$")
    public void theUserClicksOnOnTheCheckboxAtThePage(String valueToClick,
                                                      String objectName,
                                                      String pageName) {

        valueToClick = parseValue(valueToClick);
        List<Element> checkbox = getObjects(objectName, pageName);

        for (Element checkboxItem : checkbox) {
            if (checkboxItem.findMatchingCheckboxValToClick(valueToClick)) {
                checkboxItem.click();
                logStepMessage(String.format(CLICKED_VALUE, valueToClick));
            }
        }
    }

    @When("^the user clicks the header of column \"([^\"]*)\" from the \"([^\"]*)\" table on the \"([^\"]*)\" page$")
    public void theUserClicksTheHeaderOfColumnFromTheTableOnThePage(String colNum,
                                                                    String tableName,
                                                                    String pageName) {
        getObject(tableName, pageName).getHeadCellElement(0, Integer.parseInt(colNum)).click();
    }

    @When("^the user clicks on the cell at row \"([^\"]*)\" and column \"([^\"]*)\" from the \"([^\"]*)\" table at the \"([^\"]*)\" page$")
    public void theUserClicksOnTheCellAtRowAndColumnFromTheTableAtThePage(String rowNum,
                                                                          String colNum,
                                                                          String tableName,
                                                                          String pageName) {
        getObject(tableName, pageName).getDataCellElement(Integer.parseInt(rowNum), Integer.parseInt(colNum)).click();
    }

    @When("^the user clicks on row \"([^\"]*)\" from the \"([^\"]*)\" table at the \"([^\"]*)\" page$")
    public void theUserClicksOnRowFromTheTableOnThePage(String rowNum,
                                                        String tableName,
                                                        String pageName) {
        getObject(tableName, pageName).getRow(Integer.parseInt(rowNum)).click();
    }

    @When("^the user clicks \"([^\"]*)\" element on the \"([^\"]*)\" page if the \"([^\"]*)\" meets \"([^\"]*)\"$")
    public void theUserClicksElementOnThePageIfTheMeets(String objectName,
                                                        String pageName,
                                                        String secondObjectName,
                                                        String expectedCondition) {

        switch (expectedCondition.toUpperCase()) {
            case "CLICKABLE":
                if (getObject(secondObjectName, pageName).clickable() != null)
                    getObject(objectName, pageName).click();
                break;
            case "VISIBLE":
                if (getObject(secondObjectName, pageName).visible() != null)
                    getObject(objectName, pageName).click();
                break;
            case "HIDDEN":
                if (getObject(secondObjectName, pageName).invisible() != null)
                    getObject(objectName, pageName).click();
                break;
            case "DISPLAYED":
                if (getObject(secondObjectName, pageName).displayed() != null)
                    getObject(objectName, pageName).click();
                break;
            case "ENABLED":
                if (getObject(secondObjectName, pageName).enabled() != null)
                    getObject(objectName, pageName).click();
                break;
            case "DISABLED":
                if (getObject(secondObjectName, pageName).disabled() != null)
                    getObject(objectName, pageName).click();
                break;
            default:
                log.warn("Expected condition not found: {}. Options are CLICKABLE | VISIBLE | HIDDEN | DISPLAYED | ENABLED | DISABLED", expectedCondition);
        }
    }

    @When("^the user clicks on the cell at row \"([^\"]*)\"  from the \"([^\"]*)\" table at the \"([^\"]*)\" page$")
    public void theUserClicksOnTheCellAtRowFromTheTableAtThePage(String rowNum,
                                                                 String tableName,
                                                                 String pageName) {
        getObject(tableName, pageName).getRow(Integer.parseInt(rowNum)).click();
    }

    @When("^the user clicks on the cell at row with \"([^\"]*)\" \"([^\"]*)\"  and column with \"([^\"]*)\" \"([^\"]*)\"  from the \"([^\"]*)\" table at the \"([^\"]*)\" page$")
    public void theUserClicksOnTheCellAtRowWithAndColumnWithFromTheTableAtThePage(String rowIdentifier,
                                                                                  String rowVal,
                                                                                  String colIdentifier,
                                                                                  String colVal,
                                                                                  String tableName,
                                                                                  String pageName) {
        rowVal = parseValue(rowVal);
        colVal = parseValue(colVal);

        Element table = getObject(tableName, pageName);
        if (table.getMatchingRows(rowIdentifier, rowVal).size() == 1 && table.getMatchingColumns(colIdentifier, colVal).size() == 1) {
            table.getDataCellElement(table.getMatchingRows(rowIdentifier, rowVal).iterator().next(), table.getMatchingColumns(colIdentifier, colVal).iterator().next()).click();
        } else {
            log.warn("Could not find uniue row with {} having {} and {} having {}", rowIdentifier, rowVal, colIdentifier, colVal);
        }
    }

    @And("^the user clicks on \"([^\"]*)\" on the \"([^\"]*)\" radiobutton at the \"([^\"]*)\" page$")
    public void theUserClicksOnOnTheRadiobuttonAtThePage(String rdoBtnVal,
                                                         String objectName,
                                                         String pageName) {
        rdoBtnVal = parseValue(rdoBtnVal);

        final List<Element> radios = getObjects(objectName, pageName);
        for (Element radio : radios) {
            if (radio.getText().equalsIgnoreCase(rdoBtnVal)) {
                radio.click();
                logStepMessage(String.format(CLICKED_VALUE, rdoBtnVal));
            }
        }
    }

    @When("^the user clicks on the matching cell in the \"([^\"]*)\" column containing \"([^\"]*)\" from the \"([^\"]*)\" table at the \"([^\"]*)\" page$")
    public void theUserClicksOnTheMatchingCellInTheColumnContainsFromTheTableAtThePage(String firstColName,
                                                                                       String firstColValue,
                                                                                       String tableName,
                                                                                       String pageName) {

        Element tableCellToClick = findMatchingTableCell(firstColName, parseValue(firstColValue),
                                                         getObject(tableName, pageName));

        if (tableCellToClick != null && tableCellToClick.element() != null) {
            log.debug(CLICKING_ELEMENT, tableCellToClick.getAttribute(OUTER_HTML));
            tableCellToClick.click();
			tableCellToClick.unhighlight();
        } else
            log.warn("Could not find unique row with {} having {}", firstColName, firstColValue);

    }

    @When("^the user clicks on the matching cell in the \"([^\"]*)\" column containing \"([^\"]*)\" and where the \"([^\"]*)\" column contains \"([^\"]*)\" from the \"([^\"]*)\" table at the \"([^\"]*)\" page$")
    public void theUserClicksOnTheMatchingCellInTheColumnContainingAndWhereTheColumnContainsFromTheTableAtThePage(String firstColName,
                                                                                                                  String firstColValue,
                                                                                                                  String secondColName,
                                                                                                                  String secondColValue,
                                                                                                                  String tableName,
                                                                                                                  String pageName) {
        Element tableCellToClick = findMatchingTableCell(firstColName, parseValue(firstColValue),
                                                         secondColName, parseValue(secondColValue),
                                                         getObject(tableName, pageName));

        if (tableCellToClick != null && tableCellToClick.element() != null) {
            log.debug(CLICKING_ELEMENT, tableCellToClick.getAttribute(OUTER_HTML));
            tableCellToClick.click();
			tableCellToClick.unhighlight();
        } else
            log.warn("Could not find unique row with {} having {} and {} having {}", firstColName, firstColValue, secondColName, secondColValue);

    }

    @When("^the user clicks on the matching cell in the \"([^\"]*)\" column containing \"([^\"]*)\" where the \"([^\"]*)\" column contains \"([^\"]*)\" and the \"([^\"]*)\" column contains \"([^\"]*)\" from the \"([^\"]*)\" table at the \"([^\"]*)\" page$")
    public void theUserClicksOnTheMatchingCellInTheColumnContainingWhereTheColumnContainsAndTheColumnContainsFromTheTableAtThePage(
            String firstColName,
            String firstColValue,
            String secondColName,
            String secondColValue,
            String thirdColName,
            String thirdColValue,
            String tableName,
            String pageName) {

        Element tableCellToClick = findMatchingTableCell(firstColName, parseValue(firstColValue),
                                                         secondColName, parseValue(secondColValue),
                                                         thirdColName, parseValue(thirdColValue),
                                                         getObject(tableName, pageName));

        if (tableCellToClick != null && tableCellToClick.element() != null) {
            log.debug(CLICKING_ELEMENT, tableCellToClick.getAttribute(OUTER_HTML));
            tableCellToClick.click();
			tableCellToClick.unhighlight();
        } else
            log.warn("Could not find unique row with {} having {} where {} is {} and {} is {}",
                     firstColName, firstColValue, secondColName, secondColValue, thirdColName, thirdColValue);

    }

    @When("^the user clicks on the cell link having unique rowVal \"([^\"]*)\" at columnHeader \"([^\"]*)\" from the \"([^\"]*)\" table at the \"([^\"]*)\" page$")
    public void theUserClicksOnTheCellLinkHavingUniqueRowValAtColumnHeaderFromTheTableAtThePage(String rowValue,
                                                                                                String colHeader,
                                                                                                String tableName,
                                                                                                String pageName) {
        rowValue = parseValue(rowValue);
        getObject(tableName, pageName).findMatchingAnchorLinkCellinTable(rowValue, colHeader).click();
    }

    @When("^the user clicks on the cell link in the \"([^\"]*)\" column containing \"([^\"]*)\" and where the \"([^\"]*)\" column contains \"([^\"]*)\" from the \"([^\"]*)\" table at the \"([^\"]*)\" page$")
    public void theUserClicksOnTheCellLinkInTheColumnContainingAndWhereTheColumnContainsFromTheTableAtThePage(String firstColName,
                                                                                                              String firstColValue,
                                                                                                              String secondColName,
                                                                                                              String secondColValue,
                                                                                                              String tableName,
                                                                                                              String pageName) {
        Element tableCellToClick = findMatchingTableCell(firstColName, parseValue(firstColValue),
                secondColName, parseValue(secondColValue),
                getObject(tableName, pageName));

        if (tableCellToClick != null && tableCellToClick.element() != null) {
            log.debug(CLICKING_ELEMENT, tableCellToClick.getAttribute(OUTER_HTML));
            tableCellToClick.findElement(By.tagName("a")).click();
        } else
            log.warn("Could not find unique row with {} having {} and {} having {}", firstColName, firstColValue, secondColName, secondColValue);
    }

    @When("the user clicks all matching \"([^\"]*)\" elements on the \"([^\"]*)\" page")
    public void theUserClicksAllMatchingElementsOnThePage(String objectName,
                                                          String pageName) {
        List<Element> listOfObjects = getObjects(objectName, pageName);

        listOfObjects.forEach(Element::click);
    }

    @When("^the user clicks the \"([^\"]*)\" button on the matching cell where the \"([^\"]*)\" column contains \"([^\"]*)\" from the \"([^\"]*)\" table at the \"([^\"]*)\" page$")
    public void theUserSelectsTheRadioButtonInTheMatchingCellWhereTheColumnContainsFromTheTableAtThePage(String buttoText,
                                                                                                         String firstColName,
                                                                                                         String firstColValue,
                                                                                                         String tableName,
                                                                                                         String pageName) {

        Element matchingRowCell = findMatchingTableCell(firstColName, parseValue(firstColValue),
                                                        getObject(tableName, pageName));

        if (matchingRowCell != null && matchingRowCell.element() != null) {
            Element buttonToClick = matchingRowCell.findButtonInTableRow(buttoText);

            if (buttonToClick != null) {
                buttonToClick.click();
            } else {
                throw new NotFoundException("Unable to find a matching button in this table row");
            }
        } else
            log.warn("Could not find unique row with {} having {}", firstColName, firstColValue);
    }

    @When("^the user clicks on the \"([^\"]*)\" element until the \"([^\"]*)\" element value matches \"([^\"]*)\" on the page \"([^\"]*)\"$")
    public void theUserClicksOnTheElementUntilTheElementValueMatchesOnThePage(String elementToClick,
                                                                              String objectName,
                                                                              String expectedValue,
                                                                              String pageName) {
        expectedValue = parseValue(expectedValue);
        Element eleToClick = getObject(elementToClick, pageName);
        Element matchingEle = getObject(objectName, pageName);
        if (matchingEle != null && matchingEle.element() != null) {
            if (eleToClick != null && eleToClick.element() != null) {
                while (!matchingEle.getText().equalsIgnoreCase(expectedValue)) {
                    eleToClick.click();
                }
            } else {
                log.warn("Matching Element to be clicked not found: {}", eleToClick);
            }
        } else {
            log.warn("Element to be matched not found: {}", matchingEle);
        }
    }

    @When("^the user clicks the cell of column \"([^\"]*)\" of the \"([^\"]*)\" table on the \"([^\"]*)\" page where the \"([^\"]*)\" column has a row containing \"([^\"]*)\"$")
    public void theUserClicksTheCellOfColumnOfTheTableOnThePageWhereTheColumnHasARowContaining(String firstColNum,
                                                                                               String tableName,
                                                                                               String pageName,
                                                                                               String secondColName,
                                                                                               String secondColValue) {

        theUserScrollsAndClicksTheCellOfColumnOfTheTableOnThePageWhereTheColumnHasARowContaining(null, firstColNum, tableName, pageName, secondColName, secondColValue);
    }

    @When("^the user scrolls to \"([^\"]*)\" and then click on cell of column \"([^\"]*)\" of the \"([^\"]*)\" table on the \"([^\"]*)\" page where the \"([^\"]*)\" column has a row containing \"([^\"]*)\"$")
    public void theUserScrollsAndClicksTheCellOfColumnOfTheTableOnThePageWhereTheColumnHasARowContaining(String objectName,
                                                                                                         String firstColNum,
                                                                                                         String tableName,
                                                                                                         String pageName,
                                                                                                         String secondColName,
                                                                                                         String secondColValue) {

        Element table = getObject(tableName, pageName);
        int matchingRowNumber = table.getMatchingRowNumber(secondColName, parseValue(secondColValue));
        if (matchingRowNumber != -1) {
            if (objectName != null) {
                getObject(objectName, pageName).scroll();
            }
            table.getDataCellElement(matchingRowNumber, Integer.parseInt(firstColNum)).scroll().click();

        } else
            log.warn("Could not find row with {} having {}", secondColName, secondColValue);
    }

    @When("^the user clicks the \"([^\"]*)\" element and closes the pop up at the \"([^\"]*)\" page$")
    public void theUserClicksTheElementAndClosesPopUpAtThePage(String objectName,
                                                               String pageName) {
        getObject(objectName, pageName).click();
    }

    @When("^the user clicks the \"([^\"]*)\" element until the \"([^\"]*)\" column has a row containing \"([^\"]*)\" in the \"([^\"]*)\" table on the \"([^\"]*)\" page$")
    public void theUserClicksElementUntilTableRowFound(String objectName,
                                                       String colName,
                                                       String valToFind,
                                                       String tableName,
                                                       String pageName) {

        Element table = getObject(tableName, pageName);
        int matchingRowNumber;
        int retryNum = 0;
        int maxRetries = 10;

        do {
            matchingRowNumber = table.getMatchingRowNumber(colName, parseValue(valToFind));
            if (matchingRowNumber == -1) {
                getObject(objectName, pageName).clickable().click();
                retryNum++;
            }
        } while (matchingRowNumber == -1 && retryNum < maxRetries);

    }
    
    @When("^the user clicks the unread mail subject \"([^\"]*)\"$")
    public void theUserClicksTheMailSubjectElementAtThePage(String mailSubject) throws InterruptedException {   	
    	String mailsubject=parseValue(mailSubject);
    	String color="color";
    	boolean found=false;
    	WebElement dbl=null;
    	getPO().waitPageToLoad();
    	for(int i=1;i<=20;i++)
    	{   	
    		Thread.sleep(10000);
    		try
    		{
    			getDriver().findElement(By.id("O365_MainLink_Settings")).click();   		
    			getDriver().findElement(By.xpath("//span[contains(text(),'Refresh')]")).click();
    			Thread.sleep(2000);
    		}catch(Exception e)
    		{
    			Reporter.addStepLog("FAIL", "Mailbox didn't open.Intermittent issue");
    			assertThat("MailBox didn't open").isEqualTo("MailBox opened");
    		}
    		try
    		{
    			color=getDriver().findElement(By.xpath("(//*[contains(text(),'"+mailsubject+"')])[1]")).getCssValue("color");
    		}catch(Exception e)
    		{
    			
    		}
    		if(color.equals("rgba(0, 120, 215, 1)"))
    		{
    			dbl = getDriver().findElement(By.xpath("(//*[contains(text(),'"+mailsubject+"')])[1]"));
    			JavascriptExecutor js = (JavascriptExecutor)getDriver();
    			js.executeScript("arguments[0].scrollIntoView();",dbl );
    			try
    			{
    				/*action.doubleClick(dbl).build().perform();
	    			ArrayList<String> tabs2 = new ArrayList<String> (getDriver().getWindowHandles());
	    			int size=tabs2.size();
	    	   	 	getDriver().switchTo().window(tabs2.get(size-1));
	    	   	 	getDriver().close();
	    	   	 	getDriver().switchTo().window(tabs2.get(size-2));*/
    				Actions action1 = new Actions(getDriver());
    				action1.contextClick(dbl).build().perform();
    				WebDriverWait wait = new WebDriverWait(getDriver(), 10);
    				WebElement element = wait.until(
    				        ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Mark as read') and @autoid='_fce_9']")));   		
    				getDriver().findElement(By.xpath("//span[contains(text(),'Mark as read') and @autoid='_fce_9']")).click();
    			}catch(Exception e)
    			{
    				Actions action1 = new Actions(getDriver());
    				action1.contextClick(dbl).build().perform();
    				getDriver().findElement(By.xpath("//span[contains(text(),'Mark as read') and @autoid='_fce_9']")).click();
    			}
    	   	 	found=true;
    			break;
    		}   		
    	}
    	if(!found)
    	{
    		Reporter.addStepLog("FAIL", mailsubject+"-->email not recieved");
    		assertThat("Email not recieved").isEqualTo("Email received");
    	}
    	
    }
    
 	@When("^the user encounters a new pop-up clicks \"([^\"]*)\" on the \"([^\"]*)\" page$")
 	public void theUserEncountersANewPopUpClicksOnThePage(String objectName, String pageName) {
 		Element ele = getObjectAllowNull(objectName, pageName);
 		if (ele.element() != null) {
 			ele.click();
 		} else {
 			log.info("Matching Element to be clicked not present: {}", objectName);
 		}
 	}

 	@When("^the user encounters a new pop-up clicks on \"([^\"]*)\" on the \"([^\"]*)\" radiobutton at the \"([^\"]*)\" page$")
 	public void theUserEntersIntoTheTextboxAtThePage(String value, String objectName, String pageName) {
 		value = parseValue(value);
 		final List<Element> values = getObjectsAllowNull(objectName, pageName);
 		if (values != null) {
 			for (Element val : values) {
 				if (val.getText().equalsIgnoreCase(value)) {
 					val.click();
 					logStepMessage(String.format("Clicked value: \"%s\"", value));
 				}
 			}
 		}
 	}
 	
 	@When("^the element \"([^\"]*)\" exists on the \"([^\"]*)\" page click else skip$")
	public void theUserClicksOnAConditionalElementAtThePage(String objectName, String pageName) {
 		theUserEncountersANewPopUpClicksOnThePage(objectName, pageName);
	}

	@When("^the radiobutton \"([^\"]*)\" exists at the \"([^\"]*)\" page click on \"([^\"]*)\" else skip$")
	public void theUserClicksIntoConditionalRadioButtonAtThePage(String objectName, String pageName, String value) {
		theUserEntersIntoTheTextboxAtThePage(value, objectName, pageName);
	}
  
	@When("^the user clicks the element with the text \"([^\"]*)\" on the current page$")
	public void theUserClicksTheElementWithTheText(String elementText) throws InterruptedException {   

		elementText = parseValue(elementText);
		String xpath = "//*[contains(text(),'"+ elementText + "')]";
		
		try {
			WebDriverWait wait = new WebDriverWait(getDriver(), 10);
			WebElement element = wait.until(
			        ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath))); 
			element=getDriver().findElement(By.xpath(xpath));
			JavascriptExecutor js = (JavascriptExecutor)getDriver();
			js.executeScript("arguments[0].scrollIntoView();",element );
			getDriver().findElement(By.xpath(xpath)).click();
		} catch(Exception e) {
	        Reporter.addStepLog(STATUS_FAIL, "Could not locate element with text " + elementText);
	        assertThat(false).isTrue();
		}
	}

}
