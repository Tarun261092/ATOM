package automation.library.engine.core.steps;

import automation.library.api.Constants;
import automation.library.api.test.utils.ReadExcel;
import automation.library.common.FileHelper;
import automation.library.common.TestContext;
import automation.library.engine.core.BaseStepsEngine;
import io.cucumber.java.en.When;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

import static org.assertj.core.api.Assertions.assertThat;
import automation.library.common.ExcelHelper;
import automation.library.reporting.Reporter;
import io.cucumber.java.en.Then;
import org.apache.commons.io.FilenameUtils;

public class AutoEngStore extends BaseStepsEngine {
	
    @When("^store the concatenated value of \"([^\"]*)\" into the data dictionary with key \"([^\"]*)\"$")
    public void storeConcatenatedValue(String valsToConcat,
                                       String dictionaryKey) {
        storeConcatenatedValueWithDelimeter(valsToConcat, " ", dictionaryKey);
    }

    @When("^store the concatenated value of \"([^\"]*)\" with delimiter \"([^\"]*)\" into the data dictionary with key \"([^\"]*)\"$")
    public void storeConcatenatedValueWithDelimeter(String valsToConcat,
                                                    String joinDelimiter,
                                                    String dictionaryKey) {
        dictionaryKey = parseDictionaryKey(dictionaryKey);
        String combinedString = getConcatenatedVal(valsToConcat, "\\|", joinDelimiter);
        TestContext.getInstance().testdataPut(dictionaryKey, combinedString);
        logStepMessage(String.format(STORED_VALUE, combinedString, dictionaryKey));
    }

    @When("^store substring \"([^\"]*)\" of the data dictionary value at \"([^\"]*)\" into the data dictionary with key \"([^\"]*)\"$")
    public void storeSubstringVal(String substringPattern,
                                  String dictionaryKeyToSubstring,
                                  String dictionaryKeyToStore) {
        dictionaryKeyToSubstring = parseDictionaryKey(dictionaryKeyToSubstring);
        dictionaryKeyToStore = parseDictionaryKey(dictionaryKeyToStore);
        Object dictionaryValToSubstring = TestContext.getInstance().testdataGet(dictionaryKeyToSubstring);

        if (dictionaryValToSubstring != null) {
            String subStringVal = getSubstringVal(TestContext.getInstance().testdataGet(dictionaryKeyToSubstring).toString(),
                    substringPattern);
            TestContext.getInstance().testdataPut(dictionaryKeyToStore, subStringVal);
            logStepMessage(String.format(STORED_VALUE, subStringVal, dictionaryKeyToStore));
        } else {
            log.warn("Value not found at dictionary key: {}. Skipping substring.", dictionaryKeyToSubstring);
        }
    }

    @When("^store the length of the data dictionary value at \"([^\"]*)\" into the data dictionary with key \"([^\"]*)\"$")
    public void storeLengthOfDictionaryKeyValueIntoTheDataDictionaryWithKey(String value,
                                                                            String dictionaryKey) {

        dictionaryKey = parseDictionaryKey(dictionaryKey);
        value = parseValue(value);
        int length = value.length();
        TestContext.getInstance().testdataPut(dictionaryKey, length);
        logStepMessage(String.format(STORED_VALUE, length, dictionaryKey));
    }

    @When("^store xmlValue present in the attribute \"([^\"]*)\" of the data dictionary value at \"([^\"]*)\" into the data dictionary with key \"([^\"]*)\"$")
    public void storeXMLValuePresentInTheAttributeOfTheDataDictionaryValueAtIntoTheDataDictionaryWithKey(String attributeName,
                                                                                                         String storedDictionaryKey,
                                                                                                         String dictionaryKeyToStore) throws IOException, SAXException, ParserConfigurationException {
        storedDictionaryKey = parseDictionaryKey(storedDictionaryKey);
        dictionaryKeyToStore = parseDictionaryKey(dictionaryKeyToStore);
        String valToStore = getXMLAttributeVal(TestContext.getInstance().testdataGet(storedDictionaryKey).toString(), attributeName);
        TestContext.getInstance().testdataPut(dictionaryKeyToStore, valToStore);
        logStepMessage(String.format(STORED_VALUE, attributeName, dictionaryKeyToStore));
    }

    @When("^store xmlValue present in the attribute \"([^\"]*)\" with index \"([^\"]*)\" of the data dictionary value at \"([^\"]*)\" into the data dictionary with key \"([^\"]*)\"$")
    public void storeXMLValuePresentInTheAttributeOfTheDataDictionaryValueAtIntoTheDataDictionaryWithKey(String attributeName, int index,
                                                                                                         String storedDictionaryKey,
                                                                                                         String dictionaryKeyToStore) throws IOException, SAXException, ParserConfigurationException {
        storedDictionaryKey = parseDictionaryKey(storedDictionaryKey);
        dictionaryKeyToStore = parseDictionaryKey(dictionaryKeyToStore);
        String valToStore = getXMLAttributeValByIndex(TestContext.getInstance().testdataGet(storedDictionaryKey).toString(), attributeName, index);
        TestContext.getInstance().testdataPut(dictionaryKeyToStore, valToStore);
        logStepMessage(String.format(STORED_VALUE, attributeName, dictionaryKeyToStore));
    }

    @When("^store all xmlValues for the attribute \"([^\"]*)\" of the data dictionary value at \"([^\"]*)\" in list \"([^\"]*)\"$") 
    public void storeAllxmlValuesForTheAttributeOfTheDataDictionaryValueAtInList(String attributeName, String storedDictionaryKey, String List) throws ParserConfigurationException, IOException, SAXException {
    	int count = 0;
    	String valToStore;
    	List<String> l = new ArrayList<String>();
    	for(int index=0;index<2;index++) {
        	try {
        		valToStore = getXMLAttributeValByIndex(TestContext.getInstance().testdataGet(storedDictionaryKey).toString(), attributeName, index);
        		l.add(valToStore);
        	} catch (Exception e) {
        		break;
        	}
    		count++;
        }
    	log.info("List = {}, Count = {}", l, count);
    	TestContext.getInstance().testdataPut(List, l);
    	logStepMessage(String.format(STORED_VALUE, attributeName, List));
    }

    @When("^the user loads user credential into the data dictionary at key \"([^\"]*)\"$")
    public void theUserLoadsUserCredIntoDataDictionary(String dictionaryKey) {
        dictionaryKey = parseDictionaryKey(dictionaryKey);
        String valToStore = parseUser(dictionaryKey);
        TestContext.getInstance().testdataPut(dictionaryKey, valToStore);
    }

    @When("^the user loads secure credential into the data dictionary at key \"([^\"]*)\"$")
    public void theUserLoadsSecureCredIntoDataDictionary(String dictionaryKey) {

        dictionaryKey = parseDictionaryKey(dictionaryKey);
        String valToStore = parseSecureText(dictionaryKey);
        TestContext.getInstance().testdataPut(dictionaryKey, valToStore);
    }

    @When("^user loads the text of the file \"([^\"]*)\" into the data dictionary with key \"([^\"]*)\"$")
    public void userLoadsTheTextOfTheFileIntoTheDataDictionaryWithKey(String textFile, String dictionaryKey) throws IOException {

        dictionaryKey = parseValue(dictionaryKey);
        textFile = parseValue(textFile);

        String textFileAsString = getPathToTextFile(textFile);
        TestContext.getInstance().testdataPut("fw.filePath", textFileAsString);
        if(textFileAsString != null) {
            String textContent = getTextFromFile(textFileAsString);
            if (!textContent.isEmpty())
                TestContext.getInstance().testdataPut(dictionaryKey, textContent);
            else
                log.warn("Content in file is empty: {}", textFile);
        }
        else{
            String xmlFileAsString = FileHelper.findFileInPath(Constants.MQPAYLOADPATH, textFile);
            if(xmlFileAsString != null) {
                String textContent = getTextFromFile(xmlFileAsString);
                if (!textContent.isEmpty())
                    TestContext.getInstance().testdataPut(dictionaryKey, textContent);
                else
                    log.warn("Content in file is empty: {}", textFile);
            }

        }

    }

    @When("^store value of matching column where column header is \"([^\"]*)\" and row number is \"([^\"]*)\" in the sheet \"([^\"]*)\" for the excel \"([^\"]*)\" into the data dictionary with \"([^\"]*)\"$")
    public void storeValueOfMatchingColumnWhereColumnHeaderIsAndRowNumberIsInTheSheetForTheExcelIntoTheDataDictionaryKey(String columnName,
                                                                                                                         String rowNumber,
                                                                                                                         String sheetName,
                                                                                                                         String fileName,
                                                                                                                         String dictionaryKey) throws IOException {
        String valToStore = "";
        try {
            rowNumber = parseValue(rowNumber);
            columnName = parseValue(columnName);
            sheetName = parseValue(sheetName);
            fileName = parseValue(fileName);
            dictionaryKey = parseValue(dictionaryKey);
            valToStore = ReadExcel.getCellValue(Integer.parseInt(rowNumber), ReadExcel.getPathToExcel(fileName), sheetName, columnName);
            TestContext.getInstance().testdataPut(dictionaryKey, valToStore);
            logStepMessage(String.format(STORED_VALUE, valToStore, dictionaryKey));

        } catch (Exception e) {
            log.warn(e.getMessage());
        }
    }

    @When("^store value of the matching cell in the column \"([^\"]*)\" where the column header \"([^\"]*)\" contains unique value \"([^\"]*)\" in the sheet \"([^\"]*)\" for the excel \"([^\"]*)\" into the data dictionary with key \"([^\"]*)\"$")
    public void storeValueOfMatchingColumnInTheColumnWhereColumnHeaderIsAndRowNumberIsInTheSheetForTheExcelIntoTheDataDictionaryKey(String columnName,
                                                                                                                                    String columnHeader,
                                                                                                                                    String columnValue,
                                                                                                                                    String sheetName,
                                                                                                                                    String fileName,
                                                                                                                                    String dictionaryKey) throws IOException {
        int rowNumber=-1;
        String valToStore="";
        try {
            columnHeader = parseValue(columnHeader);
            columnValue = parseValue(columnValue);
            columnName = parseValue(columnName);
            sheetName = parseValue(sheetName);
            fileName = parseValue(fileName);
            dictionaryKey = parseValue(dictionaryKey);
            rowNumber = ReadExcel.getRowNumber(columnHeader,columnValue, ReadExcel.getPathToExcel(fileName), sheetName, columnName);
            valToStore = ReadExcel.getCellValue(rowNumber, ReadExcel.getPathToExcel(fileName), sheetName, columnName);
            TestContext.getInstance().testdataPut(dictionaryKey, valToStore);
            logStepMessage(String.format(STORED_VALUE, valToStore, dictionaryKey));

        } catch (Exception e) {
            log.warn(e.getMessage());
        }
    }

    @When("^the user splits the data dictionary value at \"([^\"]*)\" by matching the pattern \"([^\"]*)\" and store the value at index \"([^\"]*)\" into the data dictionary with key \"([^\"]*)\"$")
    public void storeTextByMatchingPatternAtIndex(String dictionaryKey,
                                                  String pattern,
                                                  int index,
                                                  String dictionaryKeyToStore) {

        dictionaryKey = parseValue(dictionaryKey);
        pattern = parseValue(pattern);
        index = Integer.parseInt(String.valueOf(index));
        dictionaryKeyToStore = parseDictionaryKey(dictionaryKeyToStore);
        try {
            List<String> val = Arrays.asList(dictionaryKey.split(pattern));
            String subStringVal = null;

            if (val.size() > 1) {
                subStringVal = val.get(index);
            } else log.warn("Pattern {} not found in data dictionary {}", pattern, dictionaryKey);

            TestContext.getInstance().testdataPut(dictionaryKeyToStore, subStringVal);
            logStepMessage(String.format(STORED_VALUE, subStringVal, dictionaryKeyToStore));

        } catch (Exception e) {
            log.warn(e.getMessage());
        }
    }
    
    @When("^the user searches row with \"([^\"]*)\" and stores the column values \"([^\"]*)\" from the excel \"([^\"]*)\" sheet \"([^\"]*)\" into data dictionary with key \"([^\"]*)\"$")
    public void theuserstorescolumnvaluesofrowindictionary(String expectedRowValue,String expectedColumnValue,String FileName,String SheetName,String keys) throws FileNotFoundException
    {
    	
    	String RowValue=parseValue(expectedRowValue);
    	String fileName=parseValue(FileName);
    	String sheet=parseValue(SheetName);
    	String inputsheetPath;
		String inputSheetName;
		String actualInputLocation;
		String RowNumber= "RowNumber";
		if(fileName.contains("\\")||fileName.contains("/")){
			inputsheetPath=fileName;
    		System.out.println(inputsheetPath);
    		inputSheetName = FilenameUtils.getBaseName(fileName)+"."+FilenameUtils.getExtension(fileName);
    		System.out.println(inputSheetName);
    		actualInputLocation = fileName;
    	}
    	else {
    		inputsheetPath = Constants.TESTDATAPATH;
    		System.out.println(inputsheetPath);
    		inputSheetName = fileName;
    		System.out.println(inputSheetName);
    		actualInputLocation = inputsheetPath+"\\"+ inputSheetName;
    	}
    	List<String> Column=new ArrayList<String>();
    	List<String> ActualValue=new ArrayList<String>();
    	if(!expectedColumnValue.contains(("|"))) {
    		Pattern p1 = Pattern.compile("#\\((.*)\\)");
            Matcher m1 = p1.matcher(expectedRowValue);
            String keyColHeader =null;
            //previously failing here because # wasn't present for the scenario based testing
            if (m1.matches()) {
                 keyColHeader = m1.group(1);
            }else {//changes made for the scenario outline
            	RowValue = "outlinescenario";
            	keyColHeader=expectedRowValue;
            }
                try {
                	int rowNumber=-1;
                	String valToStore="";
                	rowNumber = ReadExcel.getRowNumberForExcel(keyColHeader,RowValue, ReadExcel.getPathToExcel(inputsheetPath, inputSheetName), sheet);
                	valToStore = ReadExcel.getCellValueForExcel(rowNumber, ReadExcel.getPathToExcel(inputsheetPath, inputSheetName), sheet, parseValue(expectedColumnValue)).toString();
                	System.out.println(keys+"="+valToStore);
                	TestContext.getInstance().testdataPut(keys, valToStore);
                	TestContext.getInstance().testdataPut(RowNumber, rowNumber);
                } catch (Exception e) {
                    log.warn(e.getMessage());
                }
            
           
        }
    	else {
    		List<String> expectedColumnLists = Arrays.asList(expectedColumnValue.split("\\|"));
        	List<String> keyList=Arrays.asList(keys.split("\\|"));
        	
        	for(String expectedColumnList : expectedColumnLists)
        	{
        		log.debug(expectedColumnList);
        		
                String valToRetrieve = parseValue(expectedColumnList);
                Column.add(valToRetrieve);

        		//ColumnValues.add("("+valToRetrieve+" : "+parseValue(expectedColumnList.trim())+")");
            }
        	String tempPath = FileHelper.findFileInPath(inputsheetPath, inputSheetName);
            if (tempPath != null) {
            	if(!fileName.isEmpty() ) {
            		File inputFile = new File(actualInputLocation);
            		String fileExtString = inputFile.getName().substring(inputFile.getName().lastIndexOf(".") + 1);
            		String outputFilePath = new Date().getTime()+"OutputData_"+fileExtString;
            		File outPutFile = new File(outputFilePath);
            		if(outPutFile.exists()) {
            			outPutFile.delete();
            		}
            			
            	int count=0;
            	int count1=0;
            	Map<String, HashMap<String, Object>> exceldata=ExcelHelper.getExcelDataAsHashMapwithPrimaryColumnAsKey(inputFile, sheet,Column,expectedRowValue,RowValue,outPutFile,false,true);
            	HashMap<String, Object> primeKey=exceldata.get(RowValue);
            	
            	if(primeKey!=null)
            	{
            		
            	
            		for(String col : Column)
                	{
            			count++;
            			String value ="";
            			if (primeKey.get(col)!= null)
            			{
            				value=primeKey.get(col).toString().trim();
            			}
            			
            			for(String key:keyList)
            			{
            				count1++;
            				if(count==count1)
            				{
            					System.out.println(key+"="+value);
            					TestContext.getInstance().testdataPut(key, value);
            				}
            			}
            			count1=0;
                		ActualValue.add("("+col +" : "+value+")");
                	  		
                	}
            	}
            	else {
            		Reporter.addStepLog("FAIL", "Primary Key not found in excel");
            		assertThat("Not Found").isEqualTo("Primary Key");
            	}	
            	if(outPutFile.exists()) {
        			outPutFile.delete();
        			try {
        				if(expectedRowValue.contains("#(")) {
        					//expectedRowValue=expectedRowValue.substring(expectedRowValue.indexOf("#(")+2, expectedRowValue.indexOf(")"));
        					expectedRowValue=expectedRowValue.substring(expectedRowValue.indexOf("#(")+2, expectedRowValue.lastIndexOf(")"));
        				}
        				else {
        					RowValue = RowValue.concat("outlinescenario");
        				}
        				int rowNumber=-1;
                    	// getRowNumber1 rowNumber = ReadExcel.getRowNumber(expectedRowValue,RowValue, ReadExcel.getPathToExcel(inputsheetPath, inputSheetName), sheet);
        				rowNumber = ReadExcel.getRowNumberForExcel(expectedRowValue,RowValue, ReadExcel.getPathToExcel(inputsheetPath, inputSheetName), sheet);
                    	TestContext.getInstance().testdataPut(RowNumber, rowNumber);
                    } catch (Exception e) {
                        log.warn(e.getMessage());
                    }
        			
        		}	
              } 
            }
            else {
        		Reporter.addStepLog("FAIL", "Input excel sheet Not Found");
        		assertThat("Not Found").isEqualTo("Input Excel");
        		}
    }

}
    /* Stores the Column Header Values based on Header row number to a Data Dictionary where excel download to the local machine and has multiple versions*/
    
    @When("^the user stores the column values from the excel path \"([^\"]*)\" partialFileName \"([^\"]*)\" at sheet \"([^\"]*)\" at rownumber \"([^\"]*)\" into data dictionary with key \"([^\"]*)\"$")
    public void theuserstorescolumnvaluesofhdrindictionary(String excelFilepath,String partialFileName, String sheetName,String hdrrownum, String keys) throws FileNotFoundException
    {
    
    	try{
    		sheetName = parseValue(sheetName);
    		hdrrownum = parseValue(hdrrownum);
    		int rownumber = Integer.parseInt(hdrrownum);
    		partialFileName = parseValue(partialFileName);
    		excelFilepath = parseValue(excelFilepath);
    		String getfilename = FileHelper.getLatestFileWithNamefromDir(excelFilepath, partialFileName);
    	   	String newFileName = excelFilepath+getfilename;             
            List<String> actualvalue = ExcelHelper.getHdrDataAsArrayList(newFileName, sheetName, rownumber);
            TestContext.getInstance().testdataPut(keys, actualvalue);

         } catch (Exception e) {
             log.warn(e.getMessage());
         }
    
    
    }
    
    /* Stores the Column Header Drop down Values to a Data Dictionary where excel download to the local machine and has multiple instances*/
    
    @When("^the user stores the list values of matching column where column header is \"([^\"]*)\" and row number is \"([^\"]*)\" from the excel path \"([^\"]*)\" partialFileName \"([^\"]*)\" sheet \"([^\"]*)\" into data dictionary with key \"([^\"]*)\"$")
    public void theuserstoreslistValuesofColumnindictionary(String columnName,String rowNumber,String path,String partialFileName, String sheetName,String dictionaryKey) throws FileNotFoundException
    {
    	    	 
    	 rowNumber = parseValue(rowNumber);
         columnName = parseValue(columnName);
         sheetName = parseValue(sheetName);
         path = parseValue(path);
         partialFileName = parseValue(partialFileName);
         dictionaryKey = parseValue(dictionaryKey);
         String fileName = FileHelper.getLatestFileWithNamefromDir(path, partialFileName);
         if(fileName==null) {
        	 Reporter.addStepLog("FAIL", "Input excel sheet Not Found");
        	 assertThat("Not Found").isEqualTo("Input Excel");
         }
         else {
         String[] valToStore = ExcelHelper.getCellListValues(Integer.parseInt(rowNumber),path+fileName, sheetName, columnName);         
         TestContext.getInstance().testdataPut(dictionaryKey, Arrays.asList(valToStore));
         }
    }
    
    @When("^the user searches row with primaryKey \"([^\"]*)\" and secondaryKey \"([^\"]*)\" and stores the column values \"([^\"]*)\" from the excel \"([^\"]*)\" sheet \"([^\"]*)\" into data dictionary with key \"([^\"]*)\"$")
    public void theuserstorescolumnvaluesofrowindictionaryforprimaryandseconadrykey(String primeKeyHdr, String secondKeyHdr, String expectedColumnValue,String FileName,String SheetName,String keys) throws FileNotFoundException
    {
    	
    	String primeKeyValue=parseValue(primeKeyHdr);
		String secondKeyValue=parseValue(secondKeyHdr);
    	String fileName=parseValue(FileName);
    	String sheet=parseValue(SheetName);
    	String inputsheetPath;
		String inputSheetName;
		String actualInputLocation;
		String RowNumber= "RowNumber";
		int rowNumber=0;
    	if(fileName.contains("\\")||fileName.contains("/")){
    		inputsheetPath=fileName;
    		inputSheetName = FilenameUtils.getBaseName(fileName)+"."+FilenameUtils.getExtension(fileName);
    		System.out.println(inputSheetName);
    		actualInputLocation = fileName;
    	}
    	else {
    		inputsheetPath = Constants.TESTDATAPATH;
    		System.out.println(inputsheetPath);
    		inputSheetName = fileName;
    		System.out.println(inputSheetName);
    		actualInputLocation = inputsheetPath+"\\"+ inputSheetName;
    	}
    	List<String> Column=new ArrayList<String>();
    	List<String> ActualValue=new ArrayList<String>();
    	
    	if(primeKeyHdr!=null && primeKeyHdr.contains("#(")) {
    		primeKeyHdr = primeKeyHdr.substring(primeKeyHdr.indexOf("#(")+2, primeKeyHdr.indexOf(")"));
    	 }
    	 if(secondKeyHdr!=null && secondKeyHdr.contains("#(")) {
    		 secondKeyHdr = secondKeyHdr.substring(secondKeyHdr.indexOf("#(")+2, secondKeyHdr.indexOf(")"));
    	 }
    	 try {
         	rowNumber = ReadExcel.getRowNumber(primeKeyHdr,primeKeyValue,secondKeyHdr,secondKeyValue,ReadExcel.getPathToExcel(inputsheetPath, inputSheetName), sheet);
         	TestContext.getInstance().testdataPut(RowNumber, rowNumber);
         } catch (Exception e) {
             log.warn(e.getMessage());
         }
    	if(!expectedColumnValue.contains(("|"))) {
    		try {
            	String valToStore="";
                valToStore = ReadExcel.getCellValue(rowNumber, ReadExcel.getPathToExcel(inputsheetPath, inputSheetName), sheet, parseValue(expectedColumnValue));
                System.out.println(keys+"="+valToStore);
                TestContext.getInstance().testdataPut(keys, valToStore);
                } catch (Exception e) {
                    log.warn(e.getMessage());
                }
		}
    	else {
    		List<String> expectedColumnLists = Arrays.asList(expectedColumnValue.split("\\|"));
        	List<String> keyList=Arrays.asList(keys.split("\\|"));
        	
        	for(String expectedColumnList : expectedColumnLists)
        	{
        		log.debug(expectedColumnList);

        		String valToRetrieve = parseValue(expectedColumnList);
                Column.add(valToRetrieve);
            }
        	
        	String tempPath = FileHelper.findFileInPath(inputsheetPath, inputSheetName);
            if (tempPath != null) {
            	if(!fileName.isEmpty() ) {
            		File inputFile = new File(actualInputLocation);
            		String fileExtString = inputFile.getName().substring(inputFile.getName().lastIndexOf(".") + 1);
            		String outputFilePath = new Date().getTime()+"OutputData_"+fileExtString;
            		File outPutFile = new File(outputFilePath);
            		if(outPutFile.exists()) {
            			outPutFile.delete();
            		}
            			
            	int count=0;
            	int count1=0;
            	Map<String, HashMap<String, Object>> exceldata=ExcelHelper.getExcelDataAsHashMapwithPrimaryAndSecondaryColumnAsKey(inputFile, sheet,Column,primeKeyHdr,primeKeyValue,secondKeyHdr, secondKeyValue,outPutFile,false,true);
            	HashMap<String, Object> primeKey=exceldata.get(primeKeyValue);
            	
            	if(primeKey!=null)
            	{
            		for(String col : Column)
                	{
            			count++;
            			String value ="";
            			if (primeKey.get(col)!= null)
            			{
            				value=primeKey.get(col).toString().trim();
            			}
            			
            			for(String key:keyList)
            			{
            				count1++;
            				if(count==count1)
            				{
            					System.out.println(key+"="+value);
            					TestContext.getInstance().testdataPut(key, value);
            				}
            			}
            			count1=0;
                		ActualValue.add("("+col +" : "+value+")");
                	  		
                	}
            	}
            	else {
            		Reporter.addStepLog("FAIL", "Primary or Secondary Key not found in excel");
            		assertThat("Not Found").isEqualTo("Primary or Secondary Key");
            		//System.out.println("Row not found");
            	}	
            	if(outPutFile.exists()) {
        			outPutFile.delete();
        		}
            } 
           }
               
        	else {
        		Reporter.addStepLog("FAIL", "Input excel sheet Not Found");
        		assertThat("Not Found").isEqualTo("Input Excel");
        		//System.out.println("Excel not found");
        		}
   }

}
  //To Store Column header value into a Data Dictionary from CSV file for the given 2 Column Header Values
    
    @When("^store value of column header \"([^\"]*)\" which matches primary column header \"([^\"]*)\" with value \"([^\"]*)\" and secondary column header \"([^\"]*)\" with value \"([^\"]*)\" in sheet \"([^\"]*)\" from csv path \"([^\"]*)\" with partalFileName \"([^\"]*)\" into dataDictionary with key \"([^\"]*)\"$")  
    public void StoresTheValueFromCsvToDataDictionaryKeyWithTwoColumnHeaderValues(String columnName,
  																			String clmFilter1,String clmValue1,
  																			String clmFilter2,String clmValue2,
  																			String sheetName,
  																			String path,
  																			String partialFileoutName,
  																			String dictionaryKey) throws IOException {
	  sheetName = parseValue(sheetName); 
	  path = parseValue(path);
	  partialFileoutName = parseValue(partialFileoutName); 
	  dictionaryKey = parseValue(dictionaryKey);
	  
	  String fileName = FileHelper.getLatestFileWithNamefromDir(path,partialFileoutName); 
	  
	  if(fileName==null) { 
		  Reporter.addStepLog("FAIL","Input excel sheet Not Found");
	  assertThat("Not Found").isEqualTo("Input Excel"); } else { 
		  String valToStore = ExcelHelper.getCellValuecsvTwoFilters(path+fileName, sheetName, columnName,clmFilter1,clmValue1,clmFilter2,clmValue2);
		  
		 TestContext.getInstance().testdataPut(dictionaryKey, valToStore);
		  logStepMessage(String.format(STORED_VALUE, valToStore, dictionaryKey));
		   
	  }
	 
	  }
	  
  //To Store Column header value into a Data Dictionary from CSV file for the given 3 Column Header Values
    
    @When("^store value of column header \"([^\"]*)\" which matches primary column header \"([^\"]*)\" with value \"([^\"]*)\" and secondary column header \"([^\"]*)\" with value \"([^\"]*)\" and third column header \"([^\"]*)\" with value \"([^\"]*)\" in sheet \"([^\"]*)\" from csv path \"([^\"]*)\" with partalFileName \"([^\"]*)\" into dataDictionary with key \"([^\"]*)\"$")  
    public void StoresTheValueFromCsvToDataDictionaryKeyWithThreeColumnHeaderValues(String columnName,
    																			String clmFilter1,String clmValue1,
    																			String clmFilter2,String clmValue2,
    																			String clmFilter3,String clmValue3,
    																			String sheetName,
    																			String path,
    																			String partialFileoutName,
    																			String dictionaryKey) throws IOException {
	  sheetName = parseValue(sheetName); 
	  path = parseValue(path);
	  partialFileoutName = parseValue(partialFileoutName); 
	  dictionaryKey = parseValue(dictionaryKey);
	  
	  String fileName = FileHelper.getLatestFileWithNamefromDir(path,partialFileoutName); 
	  
	  if(fileName==null) { 
		  Reporter.addStepLog("FAIL","Input excel sheet Not Found");
	  assertThat("Not Found").isEqualTo("Input Excel"); } else { 
		  String valToStore = ExcelHelper.getCellValuecsvThreeFilters(path+fileName, sheetName, columnName,clmFilter1,clmValue1,clmFilter2,clmValue2,clmFilter3,clmValue3);
		  
		 TestContext.getInstance().testdataPut(dictionaryKey, valToStore);
		  logStepMessage(String.format(STORED_VALUE, valToStore, dictionaryKey));
		   
	  }
	 
	  }
    
    //Stores specific XML file into Data Dictionary(using filters), when multiple XML's are present within the same file.

    @When("^the user stores the xml values from data dictionary value with key \"([^\"]*)\" containing \"([^\"]*)\" to data dictionary value with key \"([^\"]*)\"$")
    public void theuservalidatesxmlvaluesofdictionary(String dataDictionaryVal,String fieldName, String trgtDataDictionary) throws FileNotFoundException
    {

    	try{
    		
    		dataDictionaryVal = parseDictionaryKey(dataDictionaryVal);
    		trgtDataDictionary = parseDictionaryKey(trgtDataDictionary);
    		dataDictionaryVal = String.valueOf(TestContext.getInstance().testdataGet(dataDictionaryVal));
    		fieldName = parseValue(fieldName);
    		String separator = "(?=<\\?xml version=\"1.0\" encoding=\"UTF-8\"\\?>)";
    		String[] xmls = dataDictionaryVal.split(separator);
    		for (String xml : xmls) {
    			if(xml.contains(fieldName)) {
    				
    			System.out.println(xml);
    		    TestContext.getInstance().testdataPut(trgtDataDictionary, xml);
    			  logStepMessage(String.format(STORED_VALUE, xml, trgtDataDictionary));
   
    			break;
    			}}
    	}
    		
          catch (Exception e) {
             log.warn(e.getMessage());
         }
    }    
    
    
}
