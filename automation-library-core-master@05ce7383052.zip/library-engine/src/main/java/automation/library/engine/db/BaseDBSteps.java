package automation.library.engine.db;

import automation.library.common.FileHelper;
import automation.library.common.Property;
import automation.library.common.TestContext;
import automation.library.db.core.Constants;
import automation.library.db.exec.DBContext;
import automation.library.engine.core.BaseStepsEngine;
import automation.library.engine.core.validator.AssertHelper;
import automation.library.engine.core.validator.ComparisonOperator;
import automation.library.engine.core.validator.ComparisonType;
import automation.library.reporting.Reporter;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static automation.library.cucumber.core.Constants.ENVIRONMENTPATH;
import static automation.library.engine.core.AutoEngConstants.DB;
import static automation.library.engine.core.objectmatcher.ObjectFinder.getMatchingDBQuery;

public class BaseDBSteps extends BaseStepsEngine {
    private static final String PROPS_FILE_PATH = ENVIRONMENTPATH + Property.getVariable(ENV_PROP) + PROPERTIES_EXT;
    private static final String STATUS_FAIL = "FAIL";
    private static final String UNDERSCOREDELIMITER = "_";
    private static final String ERROR_RESPONSE = "-1";
    protected static final String VALIDATION_TAG = "VALIDATION.";
    protected static final String QUERY_RESULT = "fw.queryResult";

    //For formatting
    private static final String QUERY_RESULT_LOG_FORMAT = "%-1s %-40s %-1s %-40s %-1s";
    private static final String QUERY_RESULT_LOG_DIVIDER = "----------------------------------------";
    private static final String QUERY_RESULT_LOG_COLUMN_SEPARATOR = "|";
    private static final String QUERY_RESULT_LOG_COLUMN_SEPARATOR_BEGIN = "\n" + QUERY_RESULT_LOG_COLUMN_SEPARATOR;

    public BaseDBSteps() {
        //Base class
    }

    protected void createConnection(String appNameDbType) {
        TestContext.getInstance().setActiveWindowType(DB);

        if (appNameDbType != null && appNameDbType.matches("^[a-zA-Z0-9]+?_{1}[a-zA-Z0-9]+?$")) {
            String dbConnectionString = Property.getProperty(PROPS_FILE_PATH, appNameDbType);

            if (dbConnectionString != null) {
                DBContext.getInstance().setAppName(appNameDbType.split(UNDERSCOREDELIMITER)[0]);
                DBContext.getInstance().setDatabaseType(appNameDbType.split(UNDERSCOREDELIMITER)[1]);
                DBContext.getInstance().setDatabaseURL(dbConnectionString);

                DBContext.getInstance().createConnection();

                FileHelper.loadDataParametersFromPropsFile(PROPS_FILE_PATH, "db");
            } else {
                throw new IllegalArgumentException(String.format("Did not find a connection string for '%s' DB in the properties file: %s",
                                                                 appNameDbType,
                                                                 PROPS_FILE_PATH));
            }
        } else {
            throw new IllegalArgumentException(String.format("AppName and DBType is not in required format in properties file: %s", PROPS_FILE_PATH));
        }
    }

    protected void closeActiveConnection() {
        DBContext.getInstance().closeConnection();
    }

    protected String getDBObject(String queryName) {
        String queryFileName = getMatchingDBQuery(queryName).getFlatFileObjectName();

        if (queryFileName != null) {
            return queryFileName;
        } else {
            try {
                throw new FileNotFoundException("The \"" + queryFileName + "\" is not found in the DBObject directory");
            } catch (FileNotFoundException e) {
                log.error(e.getMessage());
            }
        }
        return null;
    }

    protected void callDBQuery(String queryName) throws Exception {
        try {
            List<Map<String, Object>> result = runDBQueryFile(getPathToQuery(queryName));
            TestContext.getInstance().testdataPut(QUERY_RESULT, result);
            logQueryResult(result, queryName);
        } catch (Exception e) {
            Reporter.addStepLog(STATUS_FAIL,
                                "Step Failed: " + queryName + " execution is failed. See error message" + e.getMessage());
            throw e;
        }
    }

    private Map<String, Object> prepResultSetForReport(Map<String, Object> resultSet) {
        return resultSet.entrySet()
                        .stream()
                        .map(entry -> {
                            if (entry.getValue() == null)
                                entry.setValue("null");
                            return entry;
                        }).collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));

    }

    private String getPathToQuery(String queryName) {
        if(DBContext.getInstance().getSQLConnection() != null) {
            queryName = queryName + ".sql";
        } else {
            queryName = queryName + ".json";
        }

        return FileHelper.findFileInPath(Constants.DBOBJECTSPATH, queryName);
    }

    private List<Map<String, Object>> runDBQueryFile(String path) throws IOException {
        String query = FileHelper.getFileAsString(path, "\n");
        query = replaceParameterVals(query);
        log.info(query);
        return DBContext.getInstance().executeQuery(query);
    }

    protected void storeQueryResults(String queryResultKey) {
        List<Map<String, Object>> result = (List<Map<String, Object>>) TestContext.getInstance().testdataGet(QUERY_RESULT);
        if (result != null && !result.isEmpty()) {
            TestContext.getInstance().testdataPut(queryResultKey, result);
        } else {
            String errMsg = "The query result did not have any records";
            log.warn(errMsg);
            Reporter.addStepLog("FAIL", errMsg);
        }
    }

    protected Object getActualValueFromDBResult(List<Map<String, Object>> result, String columnName, int index) {

        if (result != null && !result.isEmpty() && columnName != null) {
            columnName = columnName.toUpperCase();

            if (index > 0 && index <= result.size()) {
                return convertNullToString(String.valueOf(result.get(index - 1).get(columnName)));
            } else if (index == 0) {
                return convertNullToString(String.valueOf(result.get(0).get(columnName)));
            } else {
                throw new IllegalArgumentException(String.format("Invalid index provided to the DB query result set: %s", index));
            }
        } else {
            String errMsg = "The query result is empty";
            log.warn(errMsg);
            Reporter.addStepLog("FAIL", errMsg);
            return ERROR_RESPONSE;
        }

    }

    protected void storeColumnValueFromQueryResults(String index, String columnName, String dictionaryKey) {
        Object valToStore = getActualValueFromDBResult(TestContext.getInstance().testdataToClass(QUERY_RESULT, List.class),
                                                       columnName,
                                                       Integer.parseInt(index));

        TestContext.getInstance().testdataPut(dictionaryKey, valToStore);
        logStepMessage(String.format(STORED_VALUE, valToStore, dictionaryKey));
    }

    protected void validateBlankValsFromDB(String colNameToValidate,
                                           List<Map<String, Object>> queryResultToValidate,
                                           List<String> expectedBlankVals,
                                           String validationID,
                                           String onFailureFlag) {

        List<String> actualValFromDB = new ArrayList<>();

        Object colValFromDB = getActualValueFromDBResult(queryResultToValidate, colNameToValidate, 1);

        if (colValFromDB != null && !colValFromDB.toString().equalsIgnoreCase(ERROR_RESPONSE)) {
            actualValFromDB.add(colNameToValidate);
            actualValFromDB.add(convertNullToString(colValFromDB.toString().trim()));

            AssertHelper validator = new AssertHelper(ComparisonType.COMPARE_LISTS, ComparisonOperator.CONTAINS, onFailureFlag);
            TestContext.getInstance().testdataPut(VALIDATION_TAG + validationID, validator.getResultMessage(String.join(" | ", actualValFromDB),
                                                                                                            String.join(" | ", expectedBlankVals)));
            validator.performValidation(actualValFromDB, expectedBlankVals, validationID, "DB column blank value check");
            actualValFromDB.clear();
        } else {
            logStepMessage(String.format("The %s column was not found in the result set. Skipping validation.", colNameToValidate));
        }
    }

    private String convertNullToString(String colValFromDB) {
        return colValFromDB == null ? "null" : colValFromDB;
    }

    private void logQueryResult(List<Map<String, Object>> queryResult, String queryName) throws Exception {
    	if (!queryResult.isEmpty()) {
            Map<String, Object> firstResultRow = prepResultSetForReport(queryResult.get(0));
            if(firstResultRow.containsKey("Exception")) {
            	log.error(firstResultRow.get("Exception"));
            	throw new Exception(firstResultRow.get("Exception").toString());
            }
            else
            	log.debug(getQueryResultAsFormattedTable(firstResultRow, queryName));
            Reporter.addDataTable("Query Output Data Table", prepResultSetForReport(firstResultRow));
        } 
        else{
            log.warn("No query results returned. Skipping logging step.");
        }

    }

    private String getQueryResultAsFormattedTable(Map<String, Object> resultRow, String queryName) {
        StringBuilder queryResultRow = new StringBuilder();

        queryResultRow.append(String.format("%n%nFirst row of the %s query result:", queryName));
        queryResultRow.append(getDataTableRow(QUERY_RESULT_LOG_DIVIDER, QUERY_RESULT_LOG_DIVIDER));
        queryResultRow.append(getDataTableRow("DB Column Name", "DB Column Value"));
        queryResultRow.append(getDataTableRow(QUERY_RESULT_LOG_DIVIDER, QUERY_RESULT_LOG_DIVIDER));

        resultRow.entrySet()
                 .stream()
                 .sorted(Map.Entry.comparingByKey())
                 .forEach(entry -> queryResultRow.append(getDataTableRow(entry.getKey(), entry.getValue().toString())));

        queryResultRow.append(getDataTableRow(QUERY_RESULT_LOG_DIVIDER, QUERY_RESULT_LOG_DIVIDER));
        queryResultRow.append("\n");
        return queryResultRow.toString();
    }

    private static String getDataTableRow(String key, String value) {
        return String.format(QUERY_RESULT_LOG_FORMAT,
                             QUERY_RESULT_LOG_COLUMN_SEPARATOR_BEGIN,
                             key,
                             QUERY_RESULT_LOG_COLUMN_SEPARATOR,
                             value,
                             QUERY_RESULT_LOG_COLUMN_SEPARATOR);
    }
}