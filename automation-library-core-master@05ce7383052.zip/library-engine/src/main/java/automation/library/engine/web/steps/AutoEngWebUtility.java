package automation.library.engine.web.steps;

import automation.library.common.FileHelper;
import automation.library.common.PDFHelper;
import automation.library.common.TestContext;
import automation.library.engine.core.validator.AssertHelper;
import automation.library.engine.core.validator.ComparisonOperator;
import automation.library.engine.core.validator.ComparisonType;
import automation.library.engine.web.BaseWebSteps;
import automation.library.reporting.Reporter;
import automation.library.selenium.core.Constants;
import automation.library.selenium.core.Element;
import automation.library.selenium.exec.driver.factory.DriverContext;
import automation.library.selenium.util.FileDownloadHelper;
import io.cucumber.java.en.When;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.impl.client.DefaultHttpClient;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.LocalFileDetector;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.BufferedInputStream;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.URISyntaxException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import javax.imageio.*;
import java.net.URL;

import static org.assertj.core.api.Assertions.assertThat;

import static automation.library.cucumber.core.Constants.TESTDATAPATH;
import static automation.library.engine.core.objectmatcher.ObjectFinder.invokePOMethod;

public class AutoEngWebUtility extends BaseWebSteps {
	@When("^the user closes the current browser$")
	public void theUserClosesTheCurrentBrowser() {
		DriverContext.getInstance().quit();
	}

	@When("^the user takes a screenshot \"([^\"]*)\"$")
	public void theUserTakesAScreenshot(String screenshotType) {
		saveScreenshotType(screenshotType);
	}

	@When("^the user switches to frame \"([^\"]*)\"$")
	public void theUserSwitchesToFrame(String frameName) {
		frameName = parseValue(frameName);        
		try {
			getPO().switchFrame(frameName, 3);
		} catch (NoSuchFrameException | TimeoutException ex) {
			try {
				getPO().switchFrame(By.xpath("//frame[@title=" + "'" + frameName + "'" + "] | //iFrame[@title=" + "'" + frameName + "'" + "]"));
			} catch (InvalidSelectorException | TimeoutException ex2) {
				getPO().switchFrame(By.xpath(frameName));
			}
		}                      
	}

	@When("^the user switches to frame with title \"([^\"]*)\"$")
	public void theUserSwitchesToFrameXpath(String frameName) {
		frameName = parseValue(frameName);
		getPO().switchFrame(By.xpath("//frame[@title=" + "'" + frameName + "'" + "] | //iFrame[@title=" + "'" + frameName + "'" + "]"), 3);
	}

	@When("^the user switches to frame with xPath \"([^\"]*)\"$")
	public void theUserSwitchesToFrameTitle(String frameName) {
		frameName = parseValue(frameName);
		getPO().switchFrame(By.xpath(frameName), 3);
	}

	@When("^the user switches to the \"([^\"]*)\" frame element at the \"([^\"]*)\" page$")
	public void theUserSwitchesToFrameElement(String frameName,
			String pageName) {
		getPO().switchFrame(getObject(frameName, pageName));
	}

	@When("^the user switches to the default window content$")
	public void theUserSwitchesToTheDefaultWindowContent() {
		getPO().switchToDefaultContent();
	}

	@When("^the user switches to window \"([^\"]*)\"$")
	public void theUserSwitchesToWindow(String windowName) {
		switchToNamedWindow(windowName, "EXACT", 5);
	}

	@When("^the user switches to window that contains \"([^\"]*)\"$")
	public void theUserSwitchesToWindowContains(String windowName) {
		switchToNamedWindow(windowName, "PARTIAL", 5);
	}

	@When("^the user switches to the next window$")
	public void theUserSwitchesToNextWindow() throws InterruptedException {
		switchToNextWindow(5);
	}

	@When("^the user switches to the last open window$")
	public void theUserSwitchesToLastOpenWindow() throws InterruptedException {
		TestContext.getInstance().popWindowHandle();

		try {
			getDriver().switchTo().window(TestContext.getInstance().peekLastWindowHandle());
		} catch (NoSuchWindowException e) {
			long windowSwitchDelay = Integer.parseInt(System.getProperty("fw.windowSwitchDelay"));
			log.debug("Last window not found. Waiting {}ms and trying again.", windowSwitchDelay);
			Thread.sleep(windowSwitchDelay);
			getDriver().switchTo().window(TestContext.getInstance().peekLastWindowHandle());
		}
	}

	@When("^the user closes the current window in focus$")
	public void theUserClosesTheCurrentWindowInFocus() {
		getDriver().switchTo().window(getDriver().getWindowHandle()).close();
		TestContext.getInstance().popWindowHandle();
	}

	@When("^the user closes the system dialog pop-up$")
	public void theUserClosesTheSystemDialogPopUp() {
		try {
			getWait().until(ExpectedConditions.alertIsPresent());
			getDriver().switchTo().alert().dismiss();
		} catch (NoAlertPresentException ex) {
			log.warn(ex.getMessage());
		}
	}

	@When("^the user saves a file as \"([^\"]*)\" in location \"([^\"]*)\" with type \"([^\"]*)\" on a file download dialog$")
	public void theUserSavesAFileAsInLocationWithTypeOnAFileDownloadDialog(String fileName,
			String filePath,
			String fileType) {
		new File(filePath + fileName + fileType);
	}

	@When("^the user chooses \"([^\"]*)\" in the system dialog pop-up$")
	public void theUserChoosesInTheSystemDialogPopUp(String dialogOption) {
		try {
			getWait().until(ExpectedConditions.alertIsPresent());
			if (dialogOption.equalsIgnoreCase("OK")) getDriver().switchTo().alert().accept();
			else getDriver().switchTo().alert().dismiss();
		} catch (NoAlertPresentException ex) {
			log.warn(ex.getMessage());
		}
	}

	@When("^the user waits for the page to load$")
	public void theUserWaitsForThePageToLoad() {
		getPO().waitPageToLoad();
	}

	@When("^the user waits for the \"([^\"]*)\" element to be \"([^\"]*)\" on the \"([^\"]*)\" page$")
	public void theUserWaitsForTheElementToBeOnThePage(String objectName,
			String expectedCondition,
			String pageName) {
		theUserWaitsForTheElementToBeContainOnThePage(objectName, expectedCondition, null, pageName);
	}

	@When("^the user waits for the \"([^\"]*)\" element to \"([^\"]*)\" text \"([^\"]*)\" on the \"([^\"]*)\" page$")
	public void theUserWaitsForTheElementToBeContainOnThePage(String objectName,
			String expectedCondition,
			String text,
			String pageName) {
		switch (expectedCondition.toUpperCase()) {
		case "VISIBLE":
			getObject(objectName, pageName).visible();
			break;
		case "HIDDEN":
			getObject(objectName, pageName).invisible();
			break;
		case "DISPLAYED":
			getObject(objectName, pageName).displayed();
			break;
		case "CLICKABLE":
			getObject(objectName, pageName).clickable();
			break;
		case "ENABLED":
			getObject(objectName, pageName).enabled();
			break;
		case "DISABLED":
			getObject(objectName, pageName).disabled();
			break;
		case "NOT EMPTY":
			getObject(objectName, pageName).notEmpty();
			break;
		case "EMPTY":
			getObject(objectName, pageName).empty();
			break;
		case "CONTAINSTEXT":
			text = parseValue(text);
			if (text != null) {
				String data = getObject(objectName, pageName).element().getText();
				if(data.contains(text)) {
					TestContext.getInstance().testdataPut("Logs", data);
					break;
				}
			} else {
				log.warn("Expected text not found for ContainsText condition");
			}
			break;
		default:
			log.warn("Expected condition not found: {}. Options are CLICKABLE | VISIBLE | HIDDEN | DISPLAYED | ENABLED | DISABLED | NOT EMPTY | EMPTY",
					expectedCondition);
		}
	}

	@When("^the user hovers over the \"([^\"]*)\" element at the \"([^\"]*)\" page$")
	public void theUserHoversOverTheElementAtThePage(String objectName,
			String pageName) {
		getObject(objectName, pageName).hover();
	}

	@When("^the user refreshes the page$")
	public void theUserRefreshesThePage() {
		getDriver().navigate().refresh();
	}

	@When("^the user maximizes the current window$")
	public void theUserMaximizesTheWindow() {
		getDriver().manage().window().maximize();
	}

	//New TS. Before file upload, it will replace values from Data Dictionary (txt)...
	@When("^the user uploads the file at \"([^\"]*)\" with data dictionary replacements using the \"([^\"]*)\" element at the \"([^\"]*)\" page$")
	public void theUserUploadsAFile(String filePath,
			String objectName,
			String pageName) throws IOException {

		File fileToUpload = new File(filePath);

		//default to src/test/resources/testdata folder if only a file name is provided
		if (!fileToUpload.isAbsolute()) {
			fileToUpload = new File(Paths.get(TESTDATAPATH + filePath).toString());
		}

		if (fileToUpload.exists()) {
			final String pathToFile = fileToUpload.toPath().toAbsolutePath().toString();
			final String fileContents = replaceParameterVals(FileHelper.getFileAsString(pathToFile, "\n"));
			Path tmpFileToUpload = FileHelper.writeTempFile(FileHelper.getFileNameWithoutExtension(pathToFile),
					FileHelper.getFileNameExtension(pathToFile),
					fileContents);
          	if(DriverContext.getInstance().getTechStack().get("seleniumServer").equalsIgnoreCase("grid"))
            {
				((RemoteWebDriver) getDriver()).setFileDetector(new LocalFileDetector());
            }
			getObject(objectName, pageName).sendKeys(tmpFileToUpload.toAbsolutePath().toString());
		} else {
			String errorMsg = String.format("File does not exist at path: %s", fileToUpload);
			log.error(errorMsg);
			Reporter.addStepLog("ERROR", errorMsg);
		}
	}

	//Old TS but changed definition to upload file directly...
	@When("^the user uploads the file at \"([^\"]*)\" using the \"([^\"]*)\" element at the \"([^\"]*)\" page$")
	public void theUserUploadsAnExcelFile(String filePath,
			String objectName,
			String pageName) throws IOException {

		File fileToUpload = new File(filePath);

		//default to src/test/resources/testdata folder if only a file name is provided
		if (!fileToUpload.isAbsolute()) {
			fileToUpload = new File(Paths.get(TESTDATAPATH + filePath).toString());
		}

		if (fileToUpload.exists()) {
			final String pathToFile = fileToUpload.toPath().toAbsolutePath().toString();  
			if(DriverContext.getInstance().getTechStack().get("seleniumServer").equalsIgnoreCase("grid"))
            {
				((RemoteWebDriver) getDriver()).setFileDetector(new LocalFileDetector());
            }
			getObject(objectName, pageName).sendKeys(pathToFile);
		} else {
			String errorMsg = String.format("File does not exist at path: %s", fileToUpload);
			log.error(errorMsg);
			Reporter.addStepLog("ERROR", errorMsg);
		}
	}

	@When("^the user drags the \"([^\"]*)\" element and drops it on the \"([^\"]*)\" element at the \"([^\"]*)\" page$")
	public void theUserDragsAndDrops(String objectName1,
			String objectName2,
			String pageName) {

		getObject(objectName2, pageName).dragAndDrop(getObject(objectName1, pageName));
	}

	@When("^the user downloads a file from the \"([^\"]*)\" link element at the \"([^\"]*)\" page and saves full path to data dictionary key \"([^\"]*)\"$")
	public void theUserDownloadsTheFile(String objectName,
			String pageName,
			String dictionaryKey) throws URISyntaxException {

		String pathToCurCerts = setTrustStoreBasedOnEnv();

		FileDownloadHelper downloadHelper = new FileDownloadHelper(getDriver());
		Element downloadLink = getObject(objectName, pageName);
		downloadHelper.setURISpecifiedInAnchorElement(downloadLink);
		File downloadedFile = downloadHelper.downloadFile("");

		if (downloadedFile != null && downloadedFile.exists()) {
			TestContext.getInstance().testdataPut(parseDictionaryKey(dictionaryKey), downloadedFile.getAbsolutePath());
			logStepMessage(String.format("Saved file to: %s", downloadedFile.getAbsolutePath()));
		} else {
			logStepMessage("Unable to download file.");
		}

		setTrustStore(pathToCurCerts);

	}

	@When("^the user downloads a \"([^\"]*)\" file at the current page URL and saves full path to data dictionary key \"([^\"]*)\"$")
	public void theUserDownloadsTheFileWithExtensionAtURL(String fileExtension,
			String dictionaryKey) throws URISyntaxException {
		String pathToCurCerts = setTrustStoreBasedOnEnv();

		FileDownloadHelper downloadHelper = new FileDownloadHelper(getDriver());
		downloadHelper.setURIToCurrentBrowserURL();
		File downloadedFile = downloadHelper.downloadFile(fileExtension);

		if (downloadedFile != null && downloadedFile.exists()) {
			TestContext.getInstance().testdataPut(parseDictionaryKey(dictionaryKey), downloadedFile.getAbsolutePath());
			logStepMessage(String.format("Saved file to: %s", downloadedFile.getAbsolutePath()));
		} else {
			logStepMessage("Unable to download file.");
		}

		setTrustStore(pathToCurCerts);
	}

	@When("^the user downloads a file at the current page URL and saves full path to data dictionary key \"([^\"]*)\"$")
	public void theUserDownloadsTheFileAtURL(String dictionaryKey) throws URISyntaxException {
		theUserDownloadsTheFileWithExtensionAtURL("pdf", dictionaryKey);
	}

	@When("^the user scroll to the page until the object \"([^\"]*)\" is visible at the page \"([^\"]*)\"$")
	public void theUserScrollsToElementInThePage(String objectName, String pageName) {
		getObject(objectName, pageName).scroll();
	}

	@When("^the user scrolls until the row containing \"([^\"]*)\" in the column \"([^\"]*)\" found in the \"([^\"]*)\" table at the \"([^\"]*)\" page$")
	public void theUserScrollsInThePage(String rowVal, String colName, String tableName, String pageName) {
		while (getObject(tableName, pageName).findMatchingCellinTable(parseValue(rowVal), colName)==null){
			getObject(tableName, pageName).findElement(By.tagName("tbody")).hover().scroll();
		}
	}

	@When("^the user responds to challenge questions on the \"([^\"]*)\" page$")
	public void userRespondsToChallengeQuestions(String pageName) throws InstantiationException,
	IllegalAccessException {
		invokePOMethod(pageName, "userRespondsToChallenge");
	}

	@When("^the user performs the \"([^\"]*)\" process at the \"([^\"]*)\" page$")
	public void processAlert(String methodName, String pageName) throws InstantiationException,
	IllegalAccessException {

		invokePOMethod(pageName, "basePOMethod");
	}

	@When("^the user sets the \"([^\"]*)\" cookie to a new value of \"([^\"]*)\"$")
	public void setCookieToNewValue(String cookieName, String newCookieValue) {
		Cookie matchingCookie = getDriver().manage().getCookieNamed(parseValue(cookieName));

		if (matchingCookie != null) {
			getDriver().manage().deleteCookie(matchingCookie);

			getDriver().manage().addCookie(new Cookie.Builder(matchingCookie.getName(), parseValue(newCookieValue))
					.domain(matchingCookie.getDomain())
					.expiresOn(matchingCookie.getExpiry())
					.isSecure(matchingCookie.isSecure())
					.isHttpOnly(matchingCookie.isHttpOnly())
					.path(matchingCookie.getPath())
					.build());
		} else {
			log.warn("Cookie with name {} was not found.", () -> parseValue(cookieName));
		}
	}

	@When("^the user logs in to the webmail using username \"([^\"]*)\" and password in secure text \"([^\"]*)\"$")
	public void userlogsintothewebmail(String username, String password) {
		getPO().waitPageToLoad();
		username=parseUser(username);
		String Username="NAM\\"+username;
		password=parseSecureText(password);
		try
		{
			getDriver().findElement(By.name("username")).sendKeys(Username);
			getDriver().findElement(By.id("password")).sendKeys(password);
			getDriver().findElement(By.xpath("//span[contains(text(),'sign in')]")).click();
		}catch(Exception e)
		{
			Reporter.addStepLog("FAIL", "Mail Page Error.Intermittent issue");
			assertThat("Webmail login screen not appeared").isEqualTo("Webmail login screen appeared");
		}
	}

	@When("^the user closes the current last window and go back to previous window$")
	public void theUserClosesTheCurrentLastWindow() {
		ArrayList<String> tabs2 = new ArrayList<String> (getDriver().getWindowHandles());
		int size=tabs2.size();
		getDriver().close();
		getDriver().switchTo().window(tabs2.get(size-2));
	}

	@When("^User draws on the canvas \"([^\"]*)\" element at the \"([^\"]*)\" page$")
	public void userdrawsoncanvas(String Objectname,String Pagename)
	{
		getObject(Objectname, Pagename).canvasSignature();   	
	}

	@When("^the user waits until docusign process gets completed$")
	public void userRefreshesUntilEthanFinishesDocusignStuff() throws InterruptedException {
		getPO().waitPageToLoad();
		WebElement completed = null;
		WebElement refresh = null;
		while (refresh == null) {
			try{
				refresh = getDriver().findElement(By.xpath("//span[contains(text(),'Refresh')]//parent::button"));
			} catch(Exception e) {

			}
		}

		do {
			refresh.click();
			Thread.sleep(10000);

			System.out.println(getDriver().findElements(By.xpath("//span[contains(text(),'completed')]")).size());
			System.out.println(getDriver().findElements(By.xpath("//span[contains(text(),'COMPLETED')]")).size());
			log.info("completed: " + getDriver().findElements(By.xpath("//span[contains(text(),'completed')]")).size());
			log.info("COMPLETED: " + getDriver().findElements(By.xpath("//span[contains(text(),'COMPLETED')]")).size());
		} while(getDriver().findElements(By.xpath("//span[contains(text(),'completed')]")).size()== 0 && getDriver().findElements(By.xpath("//span[contains(text(),'COMPLETED')]")).size()== 0);


	}

	@When("^the user goes \"([^\"]*)\" in the browser$")
	public void theUserGoesInTheBrowser(String action) throws InterruptedException {
		action = action.toLowerCase();
		log.debug("performing selenium driver operation:{}", action);
		switch (action) {
		case "back":
			getDriver().navigate().back();
			break;
		case "forward":
			getDriver().navigate().forward();
			break;
		default:
			throw new UnsupportedOperationException("Did not provide a valid action: " + action);
		}
	}

	@When("^the user encounters a new pop-up switch to the frame with xpath \"([^\"]*)\" on the \"([^\"]*)\" page$")
	public void theUserSwitchesToPopUpFrame(String frameName, String pageName) {
		Element ele = getObjectAllowNull(frameName, pageName);
		if (ele.element() != null) {
			getPO().switchFrame(ele);			
		} else {
			log.info("Already switched to frame or frame does not exist: {}", frameName);
		}
	}

	@When("^the user switches execution to \"([^\"]*)\"$")
	public void theUserSwitchesToDriver(String driverName) {
		driverName = parseValue(driverName).toLowerCase();
		switch (driverName) {
		case "mobile":
			System.setProperty("fw.mobileWebAutomation", "true");
			log.info("The execution switched to MOBILE Successfully.");
			break;
		case "web":
			System.setProperty("fw.mobileWebAutomation", "false");
			log.info("The execution switched to WEB Successfully.");
			break;
		default:
			throw new UnsupportedOperationException("Inappropriate driver name provided: " + driverName + " - Options are 'mobile', 'web'");
		}
	}

	@When("^the user clicks the \"([^\"]*)\" element every \"([^\"]*)\" seconds until the \"([^\"]*)\" element is reachable on the \"([^\"]*)\" page with a maximum of \"([^\"]*)\" clicks$")
	public void userClicksElementEveryFewSecondsUntilOtherElementIsrReachable(String clickElement, String sleepTimer, String searchElement, String pageObject, String attemptsString) throws InterruptedException  {

		final String BASEPATH = System.getProperty("user.dir") + "/src/test/resources/";
		final String PageobjectsPath=System.getProperty("user.dir") + "/src/test/java/pageobjects/";

		String PageobjectsFile = PageobjectsPath + pageObject +".java";    
		String xpath = "";

		int sleepTime = 5000;
		int attempts = 10;

		try {
			sleepTime = Integer.parseInt(sleepTimer)*1000;
		}catch(Exception e){}

		try {
			attempts = Integer.parseInt(attemptsString);
		}catch(Exception e){}

		try {
			File file_element = new File(PageobjectsFile);             
			try(Scanner in = new Scanner(file_element);){
				while(in.hasNext()){
					String line=in.nextLine();
					if(line.contains("private By")) { 
						String element="";
						try{

							element=(StringUtils.substringBetween(line, "private By", "=")).trim();
							if(element.equals(searchElement)) {

								xpath=(StringUtils.substringBetween(line, "(\"", "\")")).trim();
								System.out.println("Element Name: "+(StringUtils.substringBetween(line, "private By", "=")).trim() +"      "+xpath);

							}
						}catch(Exception e) {

						}
					}

				}
			}

		}catch(Exception e) {

		}


		boolean foundSearchElement = false;
		for (int i = 0; i < attempts && !foundSearchElement; i++) {

			getObject(clickElement, pageObject).click();

			Thread.sleep(sleepTime);

			System.out.println("Searching for xpath '" +xpath+ "'");
			List<WebElement> elements = getDriver().findElements(By.xpath(xpath));
			System.out.println("Found " + elements.size() + " elements");
			if (elements.size() != 0) {
				foundSearchElement = true;
				log.info("Element \"" + searchElement + "\" was located on the \"" + pageObject + "\" page after " + (i+1) + " clicks");
			}
			Thread.sleep(5000);

		}

		if (foundSearchElement == false) {
			log.error("Element \"" + searchElement + "\" was not found on the \"" + pageObject + "\" page after " + attempts + " clicks");
			throw new NotFoundException("Element \"" + searchElement + "\" was not found on the \"" + pageObject + "\" page after " + attempts + " clicks");
		}
	}
	@When("^the user waits for \"([^\"]*)\" seconds$")
	public void waitForSomeSeconds(String sleepTimer) throws InterruptedException {
		int sleepTime = 10000;
		try {
			sleepTime = Integer.parseInt(sleepTimer)*1000;
		}catch(Exception e) {

		}
		Thread.sleep(sleepTime);


	}
	@When("^the user uploads the file named \"([^\"]*)\" in the downloads directory with data dictionary replacements using the \"([^\"]*)\" element at the \"([^\"]*)\" page$")
	public void theUserUploadsADownloadedFile(String fileName,
			String objectName,
			String pageName) throws IOException {


		File fileToUpload = new File(Paths.get(Constants.DOWNLOADPATH + parseValue(fileName)).toString());


		if (fileToUpload.exists()) {
			final String pathToFile = fileToUpload.toPath().toAbsolutePath().toString();  
			getObject(objectName, pageName).sendKeys(pathToFile);
		} else {
			String errorMsg = String.format("File does not exist at path: %s", fileToUpload);
			log.error(errorMsg);
			Reporter.addStepLog("ERROR", errorMsg);
		}
	}

	@When("^the user uploads the file in excel path \"([^\"]*)\" with partialFileName \"([^\"]*)\" using the \"([^\"]*)\" element at the \"([^\"]*)\" page$")
	public void theUserUploadsLatestVersionOfExcelFile(String excelFilepath,String partialFileName,
			String objectName,
			String pageName) throws IOException {


		partialFileName = parseValue(partialFileName);
		excelFilepath = parseValue(excelFilepath);
		String getfilename = FileHelper.getLatestFileWithNamefromDir(excelFilepath, partialFileName);
		String newFileName = excelFilepath+getfilename; 

		File fileToUpload = new File(newFileName);

		if (fileToUpload.exists()) {
			final String pathToFile = fileToUpload.toPath().toAbsolutePath().toString();  

			getObject(objectName, pageName).sendKeys(pathToFile);
		} else {
			String errorMsg = String.format("File does not exist at path: %s", fileToUpload);
			log.error(errorMsg);
			Reporter.addStepLog("ERROR", errorMsg);
		}
	}


	@When("^the user drags and drops element from \"([^\"]*)\" to \"([^\"]*)\" element at the \"([^\"]*)\" page$")
	public void theUserDragsAndDropsElement(String objectName1,
			String objectName2,
			String pageName) {
		final String BASEPATH = System.getProperty("user.dir") + "/src/test/resources/";
		final String PageobjectsPath=System.getProperty("user.dir") + "/src/test/java/pageobjects/";

		String PageobjectsFile = PageobjectsPath + pageName +".java";    
		String From = "";
		String To = "";


		File file_element = new File(PageobjectsFile);    
		try (Scanner in = new Scanner(file_element);){
			while(in.hasNext()){
				String line=in.nextLine();
				if(line.contains("private By")) { 
					String element="";
					try{

						element=(StringUtils.substringBetween(line, "private By", "=")).trim();
						if(element.equals(objectName1)) {

							From=(StringUtils.substringBetween(line, "(\"", "\")")).trim();
							System.out.println("Element Name: "+(StringUtils.substringBetween(line, "private By", "=")).trim() +"      "+From);

						}
						if(element.equals(objectName2)) {

							To=(StringUtils.substringBetween(line, "(\"", "\")")).trim();
							System.out.println("Element Name: "+(StringUtils.substringBetween(line, "private By", "=")).trim() +"      "+To);

						}
					}catch(Exception e) {

					}
				}

			}

		}catch(Exception e) {

		}            
		WebElement from=getDriver().findElement(By.xpath(From));
		WebElement to=getDriver().findElement(By.xpath(To));
		Actions builder = new Actions(getDriver());
		Action dragdrop= builder                       
				.clickAndHold(from)
				.moveToElement(to)
				.release(to)
				.build();                       
		dragdrop.perform();        
	}
	@When("^the user waits for the matching cell in the \"([^\"]*)\" column containing \"([^\"]*)\" from the \"([^\"]*)\" table at the \"([^\"]*)\" page to be visible$")
	public void theUserWaitsForTheMatchingCellInTheColumnContainsFromTheTableAtThePage(String firstColName,
			String firstColValue,
			String tableName,
			String pageName) {
		
		
		Element tableCellToHighlight = findMatchingTableCell(firstColName, parseValue(firstColValue),
				getObject(tableName, pageName).visible(3));

		if (tableCellToHighlight != null && tableCellToHighlight.element() != null) {

			tableCellToHighlight.highlight();

		} else
			log.warn("Could not find unique row with {} having {}", firstColName, firstColValue);

	}
	
	
}
