package automation.library.engine.pdf;

import automation.library.common.PDFHelper;
import automation.library.common.TestContext;
import automation.library.engine.core.BaseStepsEngine;
import automation.library.reporting.Reporter;
import org.apache.pdfbox.pdmodel.PDDocument;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class BasePDFSteps extends BaseStepsEngine {
    protected static final String VALIDATION_TAG = "VALIDATION.";
    protected static final String STATUS_FAIL = "FAIL";
    protected static final String VALIDATION_FAILED = "Validation Failed: ";
    protected static final String ACTIVE_PDF = "fw.activePDF";
    protected static final String CURRENT_PAGE_PDF = "fw.PDFCurrentPageNumber";
    protected static final String PGNUM_START_PDF= "fw.PDFPageNumStart";
    protected static final String PGNUM_END_PDF = "fw.PDFPageNumEnd";

    protected String searchPDFForPattern(String textToFind, String textToSearch) {
        if(Boolean.parseBoolean(System.getProperty("fw.ignoreWhitespaceOnPDFCompare"))) {
            textToSearch = removeNewLinesAndOtherWhiteSpace(textToSearch);
        }

        Pattern p = Pattern.compile(getPDFRegEx(textToFind));
        Matcher m = p.matcher(textToSearch);
        List<String> matches = new ArrayList<>();
        int numMatches = 0;

        while (m.find()) {
            matches.add(m.group(1) + m.group(2));
            numMatches++;
        }

        matches.add(String.format("Number of matches found: %s.", numMatches));
        return String.join("\n", matches);
    }

    protected String searchPDFForPatternDynamic(String textToFind1, String textToSearch, String textToFind2) {
        if(Boolean.parseBoolean(System.getProperty("fw.ignoreWhitespaceOnPDFCompare"))) {
            textToSearch = removeNewLinesAndOtherWhiteSpace(textToSearch);
        }
        Reporter.addStepLog(String.format("Looking in the table for \"%s\" and \"%s\" in the same row", textToFind1, textToFind2));

        Pattern p = Pattern.compile(getPDFPatternRegEx(textToFind1,textToFind2));

        Matcher m = p.matcher(textToSearch);
        List<String> matches = new ArrayList<>();

        if (m.find()) {
            matches.add(m.group(1)+m.group(2)+m.group(3));
        } else {
            return null;
        }
        return String.join("", matches);
    }


    private String getPDFRegEx(String textToFind) {
        String numCharacters = System.getProperty("fw.numLeadingCharactersforPDFCompare");
        String pattern = String.format("(\\S{0,%s}\\s*)(%s)", numCharacters, Pattern.quote(textToFind));

        if(Boolean.parseBoolean(System.getProperty("fw.ignoreCaseOnPDFCompare"))) {
            pattern = "(?i)" + pattern;
        }

        return pattern;
    }

    private String getPDFPatternRegEx(String textToFind1, String textToFind2) {
    	String pattern = String.format("(%s)(.*)(%s)",Pattern.quote(textToFind1), Pattern.quote(textToFind2));
        if(Boolean.parseBoolean(System.getProperty("fw.ignoreCaseOnPDFCompare"))) {
            pattern = "(?i)" + pattern;
        }

        return pattern;
    }

    private String removeNewLinesAndOtherWhiteSpace(String textToModify) {
        return String.join(" ", Arrays.asList(textToModify.split("\\s+")));
    }

    protected void addPDFScreenshots(PDDocument document) {
        List<File> pdfDocAsList = PDFHelper.takeScreenshotOfFullDoc(document, Reporter.getScreenshotPath());
        for(File screenshot : pdfDocAsList) {
            if(screenshot.exists()) {
                Reporter.addScreenCaptureFromPath(screenshot.getAbsolutePath());
            }
        }
    }

    protected void addPDFScreenshotOfPage(PDDocument document, int pageNum) {
        File screenshotOfPage = PDFHelper.takeScreenshotOfPage(document, Reporter.getScreenshotPath(), pageNum);
        if (screenshotOfPage.exists()) {
            Reporter.addScreenCaptureFromPath(screenshotOfPage.getAbsolutePath());
        }
    }

    protected void addPDFScreenshotOfPages(PDDocument document, int pageNumStart, int pageNumEnd) {
        for(int i=pageNumStart; i <= pageNumEnd; i++) {
            addPDFScreenshotOfPage(document, i);
        }
    }

    protected PDDocument getActivePDF() throws IllegalAccessException {
        PDDocument document = TestContext.getInstance().testdataToClass(ACTIVE_PDF, PDDocument.class);

        if(document != null) {
            return document;
        } else {
            throw new IllegalAccessException("No PDFs are active. Please open a PDF.");
        }
    }
    
protected String validateLogoAndImageInPDF(String pathToFile, PDDocument pdfDoc,String downloaddir,String opType, String pdfTemplateName,List<String> boldTextToFind,List<String> italicTextToFind, String strImageSrc) throws IOException {
		
    	return PDFHelper.getImageValidationFromPDFContent(pathToFile, pdfDoc,downloaddir,opType,pdfTemplateName,boldTextToFind,italicTextToFind,strImageSrc);
        
    }
}
