package automation.library.engine.api.steps;

import automation.library.common.TestContext;
import automation.library.engine.api.BaseAPISteps;
import automation.library.engine.core.validator.ComparisonOperator;
import io.cucumber.java.en.And;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class AutoEngAPIStoreValue extends BaseAPISteps {

    @And("^store \"([^\"]*)\" within parent attribute \"([^\"]*)\" from the API response into the data dictionary with key \"([^\"]*)\"$")
    public void theUserStoresFromAPIResponseWithParentIntoTheDataDictionaryWithKey(String attributeName,
                                                                                   String parentAttributeName,
                                                                                   String dictionaryKey) {

        theUserStoresFromAPIPayloadWithParent(attributeName,
                                              parentAttributeName,
                                              RESPONSE_KEY,
                                              dictionaryKey);

    }

    @And("^store \"([^\"]*)\" from the API response into the data dictionary with key \"([^\"]*)\"$")
    public void theUserStoresFromAPIResponseIntoTheDataDictionaryWithKey(String attributeName,
                                                                         String dictionaryKey) {
        theUserStoresFromAPIResponseWithParentIntoTheDataDictionaryWithKey(attributeName,
                                                                           ROOT_ATTRIBUTE,
                                                                           dictionaryKey);
    }


    @And("^store \"([^\"]*)\" within parent attribute \"([^\"]*)\" from the API response where \"([^\"]*)\" is equal to \"([^\"]*)\" into the data dictionary with key \"([^\"]*)\"$")
    public void theUserStoresFromAPIResponseWithFilter(String attributeName,
                                                       String parentAttributeName,
                                                       String attribToSearchBy,
                                                       String valToSearchBy,
                                                       String dictionaryKey) {

        theUserStoresFromAPIPayloadWithFilter(attributeName,
                                              parentAttributeName,
                                              RESPONSE_KEY,
                                              attribToSearchBy,
                                              ComparisonOperator.EQ.label,
                                              valToSearchBy,
                                              dictionaryKey);
    }


    @And("^store \"([^\"]*)\" from the API response where \"([^\"]*)\" is equal to \"([^\"]*)\" into the data dictionary with key \"([^\"]*)\"$")
    public void theUserStoresFromAPIResponseWithFilterNoParent(String attributeName,
                                                               String attribToSearchBy,
                                                               String valToSearchBy,
                                                               String dictionaryKey) {

        theUserStoresFromAPIResponseWithFilter(attributeName,
                                               ROOT_ATTRIBUTE,
                                               attribToSearchBy,
                                               valToSearchBy,
                                               dictionaryKey);
    }

    @And("^store \"([^\"]*)\" within parent attribute \"([^\"]*)\" from the API response where \"([^\"]*)\" is \"([^\"]*)\" \"([^\"]*)\" into the data dictionary with key \"([^\"]*)\"$")
    public void theUserStoresFromAPIResponseWithFilterAndCompareOp(String attributeName,
                                                                   String parentAttributeName,
                                                                   String attribToSearchBy,
                                                                   String comparisonOperator,
                                                                   String valToSearchBy,
                                                                   String dictionaryKey) {

        theUserStoresFromAPIPayloadWithFilter(attributeName,
                                              parentAttributeName,
                                              RESPONSE_KEY,
                                              attribToSearchBy,
                                              comparisonOperator,
                                              valToSearchBy,
                                              dictionaryKey);
    }

    @And("^store \"([^\"]*)\" from the API response where \"([^\"]*)\" is \"([^\"]*)\" \"([^\"]*)\" into the data dictionary with key \"([^\"]*)\"$")
    public void theUserStoresFromAPIResponseWithFilterAndCompareOpNoParent(String attributeName,
                                                                           String attribToSearchBy,
                                                                           String comparisonOperator,
                                                                           String valToSearchBy,
                                                                           String dictionaryKey) {

        theUserStoresFromAPIResponseWithFilterAndCompareOp(attributeName,
                                                           ROOT_ATTRIBUTE,
                                                           attribToSearchBy,
                                                           comparisonOperator,
                                                           valToSearchBy,
                                                           dictionaryKey);
    }

    @And("^store \"([^\"]*)\" within parent attribute \"([^\"]*)\" from the API response where \"([^\"]*)\" is equal to \"([^\"]*)\" and \"([^\"]*)\" is equal to \"([^\"]*)\" into the data dictionary with key \"([^\"]*)\"$")
    public void theUserStoresFromAPIResponseWithTwoFilters(String attributeName,
                                                           String parentAttributeName,
                                                           String attribToSearchBy1,
                                                           String valToSearchBy1,
                                                           String attribToSearchBy2,
                                                           String valToSearchBy2,
                                                           String dictionaryKey) {

        theUserStoresFromAPIResponseWithTwoFiltersAndCompareOp(attributeName,
                                                               parentAttributeName,
                                                               attribToSearchBy1,
                                                               ComparisonOperator.EQ.label,
                                                               valToSearchBy1,
                                                               attribToSearchBy2,
                                                               ComparisonOperator.EQ.label,
                                                               valToSearchBy2,
                                                               dictionaryKey);
    }

    @And("^store \"([^\"]*)\" from the API response where \"([^\"]*)\" is equal to \"([^\"]*)\" and \"([^\"]*)\" is equal to \"([^\"]*)\" into the data dictionary with key \"([^\"]*)\"$")
    public void theUserStoresFromAPIResponseWithTwoFiltersNoParent(String attributeName,
                                                                   String attribToSearchBy1,
                                                                   String valToSearchBy1,
                                                                   String attribToSearchBy2,
                                                                   String valToSearchBy2,
                                                                   String dictionaryKey) {

        theUserStoresFromAPIResponseWithTwoFilters(attributeName,
                                                   ROOT_ATTRIBUTE,
                                                   attribToSearchBy1,
                                                   valToSearchBy1,
                                                   attribToSearchBy2,
                                                   valToSearchBy2,
                                                   dictionaryKey);
    }

    @And("^store \"([^\"]*)\" within parent attribute \"([^\"]*)\" from the API response where \"([^\"]*)\" is \"([^\"]*)\" \"([^\"]*)\" and \"([^\"]*)\" is \"([^\"]*)\" \"([^\"]*)\" into the data dictionary with key \"([^\"]*)\"$")
    public void theUserStoresFromAPIResponseWithTwoFiltersAndCompareOp(String attributeName,
                                                                       String parentAttributeName,
                                                                       String attribToSearchBy1,
                                                                       String comparisonOperator1,
                                                                       String valToSearchBy1,
                                                                       String attribToSearchBy2,
                                                                       String comparisonOperator2,
                                                                       String valToSearchBy2,
                                                                       String dictionaryKey) {

        dictionaryKey = parseDictionaryKey(dictionaryKey);
        Map<String, Object> args = new HashMap<>(TestContext.getInstance().testdata());
        args.put(PARENT_ATTRIBUTE_NAME, parentAttributeName);
        args.put(ATTRIBUTE_NAME, attributeName);
        args.put(RESPONSE, TestContext.getInstance().testdataGet(RESPONSE_KEY));
        args.put("attribToSearchBy1", attribToSearchBy1);
        args.put(COMPARISON_OP + "1", comparisonOperator1);
        args.put("valToSearchBy1", parseValue(valToSearchBy1));
        args.put("attribToSearchBy2", attribToSearchBy2);
        args.put(COMPARISON_OP + "2", comparisonOperator2);
        args.put("valToSearchBy2", parseValue(valToSearchBy2));

        final String featureToRun = getStorageFeature(parentAttributeName, StoreType.FILTERBYTWO);

        storeAPIResponse(featureToRun, args, attributeName, dictionaryKey);
    }

    @And("^store \"([^\"]*)\" from the API response where \"([^\"]*)\" is \"([^\"]*)\" \"([^\"]*)\" and \"([^\"]*)\" is \"([^\"]*)\" \"([^\"]*)\" into the data dictionary with key \"([^\"]*)\"$")
    public void theUserStoresFromAPIResponseWithTwoFiltersAndCompareOpNoParent(String attributeName,
                                                                               String attribToSearchBy1,
                                                                               String comparisonOperator1,
                                                                               String valToSearchBy1,
                                                                               String attribToSearchBy2,
                                                                               String comparisonOperator2,
                                                                               String valToSearchBy2,
                                                                               String dictionaryKey) {

        theUserStoresFromAPIResponseWithTwoFiltersAndCompareOp(attributeName,
                                                               ROOT_ATTRIBUTE,
                                                               attribToSearchBy1,
                                                               comparisonOperator1,
                                                               valToSearchBy1,
                                                               attribToSearchBy2,
                                                               comparisonOperator2,
                                                               valToSearchBy2,
                                                               dictionaryKey);
    }

    @And("^store \"([^\"]*)\" at index \"([^\"]*)\" within parent attribute \"([^\"]*)\" from the API response into the data dictionary with key \"([^\"]*)\"$")
    public void theUserStoresFromAPIResponseAtIndex(String attributeName,
                                                    String arrayIndex,
                                                    String parentAttributeName,
                                                    String dictionaryKey) {

        theUserStoresFromJSONPayloadWithIndexAtParent(attributeName,
                                                      arrayIndex,
                                                      parentAttributeName,
                                                      RESPONSE_KEY,
                                                      dictionaryKey);
    }

    @And("^store \"([^\"]*)\" at index \"([^\"]*)\" from the API response into the data dictionary with key \"([^\"]*)\"$")
    public void theUserStoresFromAPIResponseAtIndexNoParent(String attributeName,
                                                            String arrayIndex,
                                                            String dictionaryKey) {

        theUserStoresFromAPIResponseAtIndex(attributeName,
                                            arrayIndex,
                                            ROOT_ATTRIBUTE,
                                            dictionaryKey);
    }

    @And("^store \"([^\"]*)\" as full array within parent attribute \"([^\"]*)\" from the API response into the data dictionary with key \"([^\"]*)\"$")
    public void theUserStoresFromAPIResponseFullArray(String attributeName,
                                                      String parentAttributeName,
                                                      String dictionaryKey) {

        dictionaryKey = parseDictionaryKey(dictionaryKey);
        Map<String, Object> args = new HashMap<>(TestContext.getInstance().testdata());
        args.put(PARENT_ATTRIBUTE_NAME, parentAttributeName);
        args.put(ATTRIBUTE_NAME, attributeName);
        args.put(RESPONSE, TestContext.getInstance().testdataGet(RESPONSE_KEY));

        final String featureToRun = getStorageFeature(parentAttributeName, StoreType.FULLARRAY);

        storeAPIResponse(featureToRun, args, attributeName, dictionaryKey);
    }

    @And("^store \"([^\"]*)\" as full array from the API response into the data dictionary with key \"([^\"]*)\"$")
    public void theUserStoresFromAPIResponseFullArrayNoParent(String attributeName,
                                                              String dictionaryKey) {

        theUserStoresFromAPIResponseFullArray(attributeName,
                                              ROOT_ATTRIBUTE,
                                              dictionaryKey);
    }

    @And("^store full API response body into the data dictionary with key \"([^\"]*)\"$")
    public void theUserStoresFullAPIResponseBody(String dictionaryKey) {

        dictionaryKey = parseDictionaryKey(dictionaryKey);
        TestContext.getInstance().testdataPut(dictionaryKey,
                                              TestContext.getInstance().testdataGet(RESPONSE_KEY));
        logStepMessage(String.format("Stored full API response body to key: %s", dictionaryKey));

    }
    @And("^store \"([^\"]*)\" from the API response headers into the data dictionary with key \"([^\"]*)\"$")
    public void theUserStoresRawValueAPIResponseBody(String attributeName,
                                                     String dictionaryKey) {

        attributeName = parseDictionaryKey(attributeName);
        dictionaryKey = parseDictionaryKey(dictionaryKey);
        Map<String, Object> args = new HashMap<>(TestContext.getInstance().testdata());
        args.put(ATTRIBUTE_NAME, attributeName);
        args.put(RESPONSE,TestContext.getInstance().testdataGet(RESPONSE_HEADER_KEY));

        final String featureToRun = getStorageFeature(ROOT_ATTRIBUTE, StoreType.SINGLE);
        storeAPIResponse(featureToRun, args, attributeName, dictionaryKey);


    }
    @And("^store \"([^\"]*)\" within parent attribute \"([^\"]*)\" from the JSON payload at dictionary key \"([^\"]*)\" into the data dictionary with key \"([^\"]*)\"$")
    public void theUserStoresFromAPIPayloadWithParent(String attributeName,
                                                      String parentAttributeName,
                                                      String payloadDictionaryKey,
                                                      String dictionaryKey) {
        dictionaryKey = parseDictionaryKey(dictionaryKey);
        Map<String, Object> args = new HashMap<>(TestContext.getInstance().testdata());
        args.put(PARENT_ATTRIBUTE_NAME, parentAttributeName);
        args.put(ATTRIBUTE_NAME, attributeName);
        args.put(RESPONSE, TestContext.getInstance().testdataGet(parseDictionaryKey(payloadDictionaryKey)));

        final String featureToRun = getStorageFeature(parentAttributeName, StoreType.SINGLE);

        storeAPIResponse(featureToRun, args, attributeName, dictionaryKey);

    }

    @And("^store \"([^\"]*)\" from the JSON payload at dictionary key \"([^\"]*)\" into the data dictionary with key \"([^\"]*)\"$")
    public void theUserStoresFromAPIPayload(String attributeName,
                                            String payloadDictionaryKey,
                                            String dictionaryKey) {

        theUserStoresFromAPIPayloadWithParent(attributeName,
                                              ROOT_ATTRIBUTE,
                                              payloadDictionaryKey,
                                              dictionaryKey);
    }

    @And("^store \"([^\"]*)\" within parent attribute \"([^\"]*)\" from the JSON payload at dictionary key \"([^\"]*)\" where \"([^\"]*)\" is \"([^\"]*)\" \"([^\"]*)\" into the data dictionary with key \"([^\"]*)\"$")
    public void theUserStoresFromAPIPayloadWithFilter(String attributeName,
                                                      String parentAttributeName,
                                                      String payloadDictionaryKey,
                                                      String attribToSearchBy,
                                                      String comparisonOperator,
                                                      String valToSearchBy,
                                                      String dictionaryKey) {

        dictionaryKey = parseDictionaryKey(dictionaryKey);
        Map<String, Object> args = new HashMap<>(TestContext.getInstance().testdata());
        args.put(PARENT_ATTRIBUTE_NAME, parentAttributeName);
        args.put(ATTRIBUTE_NAME, attributeName);
        args.put(RESPONSE, TestContext.getInstance().testdataGet(parseDictionaryKey(payloadDictionaryKey)));
        args.put(COMPARISON_OP, comparisonOperator);


        args.put("attribToSearchBy", attribToSearchBy);
        args.put("valToSearchBy", parseValue(valToSearchBy));

        final String featureToRun = getStorageFeature(parentAttributeName, StoreType.FILTERBY);

        storeAPIResponse(featureToRun, args, attributeName, dictionaryKey);
    }

    @And("^store \"([^\"]*)\" from the JSON payload at dictionary key \"([^\"]*)\" where \"([^\"]*)\" is \"([^\"]*)\" \"([^\"]*)\" into the data dictionary with key \"([^\"]*)\"$")
    public void theUserStoresFromAPIPaylaodWithFilterNoParent(String attributeName,
                                                              String payloadDictionaryKey,
                                                              String attribToSearchBy,
                                                              String comparisonOperator,
                                                              String valToSearchBy,
                                                              String dictionaryKey) {

        theUserStoresFromAPIPayloadWithFilter(attributeName,
                                              ROOT_ATTRIBUTE,
                                              payloadDictionaryKey,
                                              attribToSearchBy,
                                              comparisonOperator,
                                              valToSearchBy,
                                              dictionaryKey);
    }

    @And("^store \"([^\"]*)\" at index \"([^\"]*)\" within parent attribute \"([^\"]*)\" from the JSON payload at dictionary key \"([^\"]*)\" into the data dictionary with key \"([^\"]*)\"$")
    public void theUserStoresFromJSONPayloadWithIndexAtParent(String attributeName,
                                                              String arrayIndex,
                                                              String parentAttributeName,
                                                              String payloadDictionaryKey,
                                                              String dictionaryKey) {
        dictionaryKey = parseDictionaryKey(dictionaryKey);
        Map<String, Object> args = new HashMap<>(TestContext.getInstance().testdata());
        args.put(PARENT_ATTRIBUTE_NAME, parentAttributeName);
        args.put(ATTRIBUTE_NAME, attributeName);
        args.put(RESPONSE, TestContext.getInstance().testdataGet(parseDictionaryKey(payloadDictionaryKey)));

        if (arrayIndex.equalsIgnoreCase("LAST")) {
            final String featureToRun = getStorageFeature(parentAttributeName, StoreType.ATLAST);
            storeAPIResponse(featureToRun, args, attributeName, dictionaryKey);
        }
        else
        {
            args.put("arrayIndex", Integer.parseInt(parseValue(arrayIndex)));
            final String featureToRun = getStorageFeature(parentAttributeName, StoreType.ATINDEX);
            storeAPIResponse(featureToRun, args, attributeName, dictionaryKey);
        }
    }

    @And("^store \"([^\"]*)\" at index \"([^\"]*)\" from the JSON payload at dictionary key \"([^\"]*)\" into the data dictionary with key \"([^\"]*)\"$")
    public void theUserStoresFromJSONPayloadWithIndex(String attributeName,
                                                              String arrayIndex,
                                                              String payloadDictionaryKey,
                                                              String dictionaryKey) {
        theUserStoresFromJSONPayloadWithIndexAtParent(attributeName,
                                                      arrayIndex,
                                                      ROOT_ATTRIBUTE,
                                                      payloadDictionaryKey,
                                                      dictionaryKey);
    }
    
    @And("^store full API response XML body into the data dictionary with key \"([^\"]*)\"$")
    public void theUserStoresFullAPIResponseXMLBody(String dictionaryKey) {

        dictionaryKey = parseDictionaryKey(dictionaryKey);
        TestContext.getInstance().testdataPut(dictionaryKey,
                                              TestContext.getInstance().testdataGet(RESPONSE_XML_KEY));
        logStepMessage(String.format("Stored full API response body to key: %s", dictionaryKey));

    }
    
    @And("^format API response XML body into proper standards with XML tag \"([^\"]*)\" and XML attribute \"([^\"]*)\"$")
    public void theUserFormatsResponseXMLBodyIntoProperStandards(String tagToReplace, String xmlAttributeName) throws ParserConfigurationException, IOException, SAXException, TransformerException {

        String responseXML = (String) TestContext.getInstance().testdataGet(RESPONSE_XML_KEY);
        responseXML = transformXMLWithProperStandards(responseXML,tagToReplace ,xmlAttributeName);
        TestContext.getInstance().testdataPut(RESPONSE_XML_KEY,responseXML);
    }
    
    @And("^store \"([^\"]*)\" within parent attribute \"([^\"]*)\" from the API response xml into the data dictionary with key \"([^\"]*)\"$")
    public void theUserStoresFromAPIResponseXMLWithParentIntoTheDataDictionaryWithKey(String attributeName,
                                                                                   String parentAttributeName,
                                                                                   String dictionaryKey) {

    	theUserStoresFromAPIXMLPayloadWithParent(attributeName,
                                              parentAttributeName,
                                              RESPONSE_XML_KEY,
                                              dictionaryKey);

    }

    @And("^store \"([^\"]*)\" from the API response XML into the data dictionary with key \"([^\"]*)\"$")
    public void theUserStoresFromAPIResponseXMLIntoTheDataDictionaryWithKey(String attributeName,
                                                                         String dictionaryKey) {
        theUserStoresFromAPIResponseXMLWithParentIntoTheDataDictionaryWithKey(attributeName,
                                                                           ROOT_ATTRIBUTE,
                                                                           dictionaryKey);
    }
    
    @And("^store \"([^\"]*)\" within parent attribute \"([^\"]*)\" from the XML payload at dictionary key \"([^\"]*)\" into the data dictionary with key \"([^\"]*)\"$")
    public void theUserStoresFromAPIXMLPayloadWithParent(String attributeName,
                                                      String parentAttributeName,
                                                      String payloadDictionaryKey,
                                                      String dictionaryKey) {
        dictionaryKey = parseDictionaryKey(dictionaryKey);
        Map<String, Object> args = new HashMap<>(TestContext.getInstance().testdata());
        args.put(PARENT_ATTRIBUTE_NAME, parentAttributeName);
        args.put(ATTRIBUTE_NAME, attributeName);
        args.put(RESPONSE_XML, TestContext.getInstance().testdataGet(parseDictionaryKey(payloadDictionaryKey)));
        args.put(RESPONSE, TestContext.getInstance().testdataGet(RESPONSE_KEY));
        
        final String featureToRun = getXMLStorageFeature(parentAttributeName, StoreType.SINGLE);

        storeAPIResponse(featureToRun, args, attributeName, dictionaryKey);
    }

    @And("^store \"([^\"]*)\" from the XML payload at dictionary key \"([^\"]*)\" into the data dictionary with key \"([^\"]*)\"$")
    public void theUserStoresFromAPIXMLPayload(String attributeName,
                                               String payloadDictionaryKey,
                                               String dictionaryKey) {
        theUserStoresFromAPIXMLPayloadWithParent(attributeName, ROOT_ATTRIBUTE, payloadDictionaryKey, dictionaryKey);
    }

    @And("^store last index of attribute \"([^\"]*)\" from the JSON payload at dictionary key \"([^\"]*)\" into the data dictionary with key \"([^\"]*)\"$")
    public void theUserStoresFromJSONPayloadWithIndexAtParent(String attributeName,
                                                              String payloadDictionaryKey,
                                                              String dictionaryKey) {
        dictionaryKey = parseDictionaryKey(dictionaryKey);
        Map<String, Object> args = new HashMap<>(TestContext.getInstance().testdata());
        args.put(ATTRIBUTE_NAME, attributeName);
        args.put(RESPONSE, TestContext.getInstance().testdataGet(parseDictionaryKey(payloadDictionaryKey)));

        final String featureToRun = getStorageFeature(ROOT_ATTRIBUTE, StoreType.LASTCOUNT);
        storeAPIResponse(featureToRun, args, attributeName, dictionaryKey);

    }
    @And("^store array of \"([^\"]*)\" within parent attribute \"([^\"]*)\" from the JSON payload at dictionary key \"([^\"]*)\" into the data dictionary with key \"([^\"]*)\"$")
    public void theUserStoresArrayFromAPIPayloadWithParent(String attributeName,
                                                           String parentAttributeName,
                                                           String payloadDictionaryKey,
                                                           String dictionaryKey) {
        dictionaryKey = parseDictionaryKey(dictionaryKey);
        Map<String, Object> args = new HashMap<>(TestContext.getInstance().testdata());
        args.put(PARENT_ATTRIBUTE_NAME, parentAttributeName);
        args.put(ATTRIBUTE_NAME, attributeName);
        args.put(RESPONSE, TestContext.getInstance().testdataGet(parseDictionaryKey(payloadDictionaryKey)));

        final String featureToRun = getStorageFeature(parentAttributeName, StoreType.FULLARRAY);

        storeAPIResponse(featureToRun, args, attributeName, dictionaryKey);

    }

    @And("^store API response status code into the data dictionary with key \"([^\"]*)\"$")
    public void theUserStoresTheAPIResponseStatusCode(String dictionaryKey) {

        String actualStatus = TestContext.getInstance().testdataGet(RESPONSE_STATUS_KEY).toString();
        dictionaryKey = parseDictionaryKey(dictionaryKey);
        TestContext.getInstance().testdataPut(dictionaryKey, actualStatus);
    }

    @And("^store \"([^\"]*)\" from the API response xml where \"([^\"]*)\" is \"([^\"]*)\" \"([^\"]*)\" into the data dictionary with key \"([^\"]*)\"$")
    public void theUserStoresFromAPIResponseXmlWithFilterAndCompareOpNoParent(String attributeName,
                                                                              String attribToSearchBy,
                                                                              String comparisonOperator,
                                                                              String valToSearchBy,
                                                                              String dictionaryKey) {

        theUserStoresFromAPIResponseXmlWithFilterAndCompareOp(attributeName,
                                                                ROOT_ATTRIBUTE,
                                                                attribToSearchBy,
                                                                comparisonOperator,
                                                                valToSearchBy,
                                                                dictionaryKey);
    }

    @And("^store \"([^\"]*)\" within parent attribute \"([^\"]*)\" from the API response xml where \"([^\"]*)\" is \"([^\"]*)\" \"([^\"]*)\" into the data dictionary with key \"([^\"]*)\"$")
    public void theUserStoresFromAPIResponseXmlWithFilterAndCompareOp(String attributeName,
                                                                      String parentAttributeName,
                                                                      String attribToSearchBy,
                                                                      String comparisonOperator,
                                                                      String valToSearchBy,
                                                                      String dictionaryKey) {

        theUserStoresFromAPIXmlPayloadWithFilter(attributeName,
                                                parentAttributeName,
                                                RESPONSE_XML_KEY,
                                                attribToSearchBy,
                                                comparisonOperator,
                                                valToSearchBy,
                                                dictionaryKey);
    }

    @And("^store \"([^\"]*)\" within parent attribute \"([^\"]*)\" from the XML payload at dictionary key \"([^\"]*)\" where \"([^\"]*)\" is \"([^\"]*)\" \"([^\"]*)\" into the data dictionary with key \"([^\"]*)\"$")
    public void theUserStoresFromAPIXmlPayloadWithFilter(String attributeName,
                                                         String parentAttributeName,
                                                         String payloadDictionaryKey,
                                                         String attribToSearchBy,
                                                         String comparisonOperator,
                                                         String valToSearchBy,
                                                         String dictionaryKey) {

        dictionaryKey = parseDictionaryKey(dictionaryKey);
        Map<String, Object> args = new HashMap<>(TestContext.getInstance().testdata());
        args.put(PARENT_ATTRIBUTE_NAME, parentAttributeName);
        args.put(ATTRIBUTE_NAME, attributeName);
        args.put(RESPONSE_XML, TestContext.getInstance().testdataGet(parseDictionaryKey(payloadDictionaryKey)));
        args.put(RESPONSE, TestContext.getInstance().testdataGet(RESPONSE_KEY));
        args.put(COMPARISON_OP, comparisonOperator);
        args.put("attribToSearchBy", attribToSearchBy);
        args.put("valToSearchBy", parseValue(valToSearchBy));

        final String featureToRun = getXMLStorageFeature(parentAttributeName, StoreType.FILTERBY);

        storeAPIResponse(featureToRun, args, attributeName, dictionaryKey);
    }


}
