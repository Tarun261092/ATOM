package automation.library.engine.ivr.steps;

import automation.library.common.TestContext;
import automation.library.cyara.core.CyaraContext;
import automation.library.engine.ivr.BaseIVRSteps;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

public class AutoEngIVRLaunch extends BaseIVRSteps {
    @Given("^the user launches an IVR test with name \"([^\"]*)\"$")
    public void theIVRTestIsLaunched(String testName) {
        launchIVRTest(testName);
    }

    @When("^the user waits for the current IVR test to complete$")
    public void theUserWaitsForTheIVRTestToComplete() {
        final Map<String, String> currentlyRunningTest = (Map) TestContext.getInstance().testdataGet(CYARA_TEST_INFO);

        if (currentlyRunningTest != null) {
            Map<String, Object> testResultObject = CyaraContext.getInstance().waitForTestToComplete(currentlyRunningTest.get("testCaseId"),
                                                                                                    currentlyRunningTest.get("ticketNum"));

            if(!testResultObject.isEmpty()) {
                logAndReportJSON("IVR Test Result", testResultObject);
                final Map<String, Object> testResult = (Map) testResultObject.get("testResult");
                logStepMessage("Test result detail text: " + testResult.get("detail"));

                //confirm that test did not fail or abort
                assertThat(testResult.get("result").toString()).isNotEqualToIgnoringCase("Failed");
                assertThat(testResult.get("result").toString()).isNotEqualToIgnoringCase("Aborted");
            }
        } else {
            log.error("No IVR test is currently running");
        }
    }

    @When("^the user checks that the campaign \"([^\"]*)\" is running$")
    public void theUserChecksForARunningCampaign(String campaignName) {
        Map<String, String> currentlyRunningCampaign = launchIVRCampaign(campaignName);

        logAndReportJSON("Current Campaign Details", currentlyRunningCampaign);
    }

    @When("^the user aborts the currently running IVR test$")
    public void theUserAbortsTheIVRTest() {
        final Map<String, String> currentlyRunningTest = (Map) TestContext.getInstance().testdataGet(CYARA_TEST_INFO);

        if (currentlyRunningTest != null) {
            Map<String, Object> testResultObject = CyaraContext.getInstance().abortCurrentTest(currentlyRunningTest.get("testCaseId"),
                                                                                               currentlyRunningTest.get("ticketNum"));

            if(!testResultObject.isEmpty()) {
                logAndReportJSON("IVR Test Result", testResultObject);
            }
        } else {
            log.error("No IVR test is currently running");
        }
    }
}