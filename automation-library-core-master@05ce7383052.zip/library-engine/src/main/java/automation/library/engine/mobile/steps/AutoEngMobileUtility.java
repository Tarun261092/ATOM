package automation.library.engine.mobile.steps;

import automation.library.engine.mobile.BaseMobileSteps;
import io.cucumber.java.en.When;

public class AutoEngMobileUtility extends BaseMobileSteps {
    
    @When("^the user scrolls from \"([^\"]*)\" to \"([^\"]*)\" on mobile device$")
    public void theUserScrollsFromToOnMobileDevice(String start, String end) throws Exception {
    	scrollWithPercentageOnMobileDevice(start, end, getMobileDriver());
    }
      
}
