package automation.library.engine.core.parser;

import automation.library.engine.core.BaseStepsEngine;
import com.google.common.reflect.ClassPath;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.util.*;
import java.util.stream.Collectors;

import static java.util.stream.Collectors.toList;

public class StepDefParser {
    protected Logger log = LogManager.getLogger(StepDefParser.class);
    private Map<String, List<String>> annotationsMap;

    public StepDefParser() {
        this.annotationsMap = buildAnnotationsMap();
    }

    public Map<String, List<String>> getAnnotationsMap() {
        return annotationsMap;
    }

    private Map<String, List<String>> buildAnnotationsMap() {
        return buildMapOfDeclaredMethods().entrySet()
                                          .stream()
                                          .collect(Collectors.toMap(Map.Entry::getKey,
                                                                    stepDef -> buildFullStepDefString(stepDef.getValue())));
    }

    protected List<String> getListOfStepDefs() {
        return annotationsMap.values().stream().flatMap(List::stream).collect(toList());
    }

    private List<String> buildFullStepDefString(List<Method> methodListMerged) {
        List<String> annotationList = new ArrayList<>();

        methodListMerged.forEach(method -> {
            Annotation[] annotations = method.getDeclaredAnnotations();
            for (Annotation annotation : annotations) {

                switch (annotation.annotationType().getName()) {
                    case "cucumber.api.java.en.Given":
                    case "io.cucumber.java.en.Given":
                        annotationList.add(((Given) annotation).value());
                        break;
                    case "cucumber.api.java.en.When":
                    case "io.cucumber.java.en.When":
                        annotationList.add(((When) annotation).value());
                        break;
                    case "cucumber.api.java.en.Then":
                    case "io.cucumber.java.en.Then":
                        annotationList.add(((Then) annotation).value());
                        break;
                    case "cucumber.api.java.en.And":
                    case "io.cucumber.java.en.And":
                        annotationList.add(((And) annotation).value());
                        break;
                    default:
                        break;
                }
            }
        });

        return annotationList;
    }

    private Map<String, List<Method>> buildMapOfDeclaredMethods() {
        Map<String, List<Method>> declaredMethods = new HashMap<>();
        try {
            getStepDefinitionClasses("automation.library.engine.web.steps").forEach(clazz -> declaredMethods.put(clazz.getSimpleName(), Arrays.asList(clazz.getDeclaredMethods())));
            getStepDefinitionClasses("automation.library.engine.mainframe.steps").forEach(clazz -> declaredMethods.put(clazz.getSimpleName(), Arrays.asList(clazz.getDeclaredMethods())));
            getStepDefinitionClasses("automation.library.engine.api.steps").forEach(clazz -> declaredMethods.put(clazz.getSimpleName(), Arrays.asList(clazz.getDeclaredMethods())));
            getStepDefinitionClasses("automation.library.engine.db.steps").forEach(clazz -> declaredMethods.put(clazz.getSimpleName(), Arrays.asList(clazz.getDeclaredMethods())));
            getStepDefinitionClasses("automation.library.engine.desktop.steps").forEach(clazz -> declaredMethods.put(clazz.getSimpleName(), Arrays.asList(clazz.getDeclaredMethods())));
            getStepDefinitionClasses("automation.library.engine.ivr.steps").forEach(clazz -> declaredMethods.put(clazz.getSimpleName(), Arrays.asList(clazz.getDeclaredMethods())));
            getStepDefinitionClasses("automation.library.engine.mobile.steps").forEach(clazz -> declaredMethods.put(clazz.getSimpleName(), Arrays.asList(clazz.getDeclaredMethods())));
            getStepDefinitionClasses("automation.library.engine.pdf.steps").forEach(clazz -> declaredMethods.put(clazz.getSimpleName(), Arrays.asList(clazz.getDeclaredMethods())));
            getStepDefinitionClasses("automation.library.engine.core.steps").forEach(clazz -> declaredMethods.put(clazz.getSimpleName(), Arrays.asList(clazz.getDeclaredMethods())));
        } catch (IOException e) {
            log.error(e.getMessage(), e);
        }
        return declaredMethods;
    }

    private List<Class<? extends BaseStepsEngine>> getStepDefinitionClasses(String packageName) throws IOException {
        List<Class<? extends BaseStepsEngine>> classes = new ArrayList<>();
        final ClassLoader loader = Thread.currentThread().getContextClassLoader();
        ClassPath.from(loader).getTopLevelClasses(packageName).forEach(info -> classes.add((Class<? extends BaseStepsEngine>) info.load()));
        return classes;
    }

}
