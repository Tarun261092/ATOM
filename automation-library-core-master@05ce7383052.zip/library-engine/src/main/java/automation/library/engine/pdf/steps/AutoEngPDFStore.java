package automation.library.engine.pdf.steps;

import automation.library.common.PDFHelper;
import automation.library.common.TestContext;
import automation.library.engine.pdf.BasePDFSteps;
import io.cucumber.java.en.Then;
import org.apache.pdfbox.pdmodel.PDDocument;

public class AutoEngPDFStore extends BasePDFSteps {

    @Then("^the user store the content of the currently active pdf into the data dictionary with key \"([^\"]*)\"$")
    public void storethePDFContent(String dictionaryKey) throws IllegalAccessException {

        PDDocument document = getActivePDF();
        String pdfDocumentText = PDFHelper.getPDFText(document);
        dictionaryKey = parseDictionaryKey(dictionaryKey);

        TestContext.getInstance().testdata().put(CURRENT_PAGE_PDF, 0);

        TestContext.getInstance().testdataPut(dictionaryKey, pdfDocumentText);
        logStepMessage(String.format(STORED_VALUE, pdfDocumentText, dictionaryKey));
    }

    @Then("^the user store the content of the currently active pdf from page \"([^\"]*)\" for number of pages \"([^\"]*)\" into the data dictionary with key \"([^\"]*)\"$")
    public void storePDFContainsTextBetweenPages(String pageNumStart,
                                                 String pageNumbr,
                                                 String dictionaryKey) throws IllegalAccessException {
        PDDocument document = getActivePDF();

        pageNumStart = parseValue(pageNumStart);
        pageNumbr = parseValue(pageNumbr);
        int pageNumEnd = Integer.parseInt(pageNumStart) + Integer.parseInt(pageNumbr) - 1;
        String pdfDocumentText = PDFHelper.getPDFText(document, Integer.parseInt(pageNumStart), pageNumEnd);
        TestContext.getInstance().testdata().put(CURRENT_PAGE_PDF, 0);

        TestContext.getInstance().testdataPut(dictionaryKey, pdfDocumentText);
        logStepMessage(String.format(STORED_VALUE, pdfDocumentText, dictionaryKey));
    }

    @Then("^the user store the page number of the currently active pdf which contains value \"([^\"]*)\" into the data dictionary with key \"([^\"]*)\"$")
    public void storePDFPageNumberContainingValueIntoDataDictionary(String textToFind,
                                                                    String dictionaryKey) throws IllegalAccessException {
        PDDocument document = getActivePDF();
        textToFind = parseValue(textToFind);

        int pdfPageNum = PDFHelper.getPDFPageNumber(document, textToFind);

        TestContext.getInstance().testdata().put(CURRENT_PAGE_PDF, 0);

        TestContext.getInstance().testdataPut(dictionaryKey, pdfPageNum);
        logStepMessage(String.format(STORED_VALUE, pdfPageNum, dictionaryKey));
    }

    @Then("^the user store the currently active pdf on page \"([^\"]*)\" into the data dictionary with key \"([^\"]*)\"$")
    public void storethePDFContainsTextOnPageStoreInDictionaryKey(String pageNumStart,
                                                                  String dictionaryKey) throws IllegalAccessException {

        PDDocument document = getActivePDF();
        pageNumStart = parseValue(pageNumStart);

        TestContext.getInstance().testdata().put(CURRENT_PAGE_PDF, 0);

        String pdfDocumentText = PDFHelper.getPDFText(document, Integer.parseInt(pageNumStart), Integer.parseInt(pageNumStart));

        TestContext.getInstance().testdataPut(dictionaryKey, pdfDocumentText);
        logStepMessage(String.format(STORED_VALUE, pdfDocumentText, dictionaryKey));
    }


}
