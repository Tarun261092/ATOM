package automation.library.engine.core.runner;

import automation.library.engine.core.parser.FeatureFileTestUploader;
import org.testng.annotations.Test;

public class TlmUploadUtilityRunner {

    @Test
    public void tlmTestUpload() {
        new FeatureFileTestUploader().uploadTestsInFeatureFile();
    }
}