package automation.library.engine.core.validator.managers;

import automation.library.common.TestContext;
import automation.library.engine.core.validator.FailureFlag;
import automation.library.engine.core.validator.ValidatorManager;

import static automation.library.common.DateHelper.formatAsDate;
import static automation.library.engine.core.validator.FailureFlag.HARD_STOP_ON_FAILURE;
import static automation.library.engine.core.validator.FailureFlag.valueOfLabel;
import static org.assertj.core.api.Assertions.assertThat;

public class DateValidator extends ValidatorManager {
    private FailureFlag onFailureFlag;

    public DateValidator(String onFailureFlag) {
        this.onFailureFlag = valueOfLabel(onFailureFlag);
    }

    @Override
    protected void assertEquals(Object actual, Object expected, String assertMsg) {
        if(onFailureFlag == HARD_STOP_ON_FAILURE) {
            assertThat(formatAsDate(actual)).as(assertMsg).isEqualTo(formatAsDate(expected));
        } else {
            TestContext.getInstance().sa()
                       .assertThat(formatAsDate(actual)).as(assertMsg).isEqualTo(formatAsDate(expected));
        }
    }

    @Override
    protected void assertEqualsIgnoreCase(Object actual, Object expected, String assertMsg) {
        throw new UnsupportedOperationException("Equal Ignore Case assertion not available for Compare_Dates.");
    }

    @Override
    protected void assertNotEquals(Object actual, Object expected, String assertMsg) {
        if(onFailureFlag == HARD_STOP_ON_FAILURE) {
            assertThat(formatAsDate(actual)).as(assertMsg).isNotEqualTo(formatAsDate(expected));
        } else {
            TestContext.getInstance().sa()
                       .assertThat(formatAsDate(actual)).as(assertMsg).isNotEqualTo(formatAsDate(expected));
        }
    }

    @Override
    protected void assertLessThan(Object actual, Object expected, String assertMsg) {
        if(onFailureFlag == HARD_STOP_ON_FAILURE) {
            assertThat(formatAsDate(actual)).as(assertMsg).isBefore(formatAsDate(expected));
        } else {
            TestContext.getInstance().sa()
                       .assertThat(formatAsDate(actual)).as(assertMsg).isBefore(formatAsDate(expected));
        }
    }

    @Override
    protected void assertLessThanOrEqual(Object actual, Object expected, String assertMsg) {
        if(onFailureFlag == HARD_STOP_ON_FAILURE) {
            assertThat(formatAsDate(actual)).as(assertMsg).isBeforeOrEqualTo(formatAsDate(expected));
        } else {
            TestContext.getInstance().sa()
                       .assertThat(formatAsDate(actual)).as(assertMsg).isBeforeOrEqualTo(formatAsDate(expected));
        }
    }

    @Override
    protected void assertGreaterThan(Object actual, Object expected, String assertMsg) {
        if(onFailureFlag == HARD_STOP_ON_FAILURE) {
            assertThat(formatAsDate(actual)).as(assertMsg).isAfter(formatAsDate(expected));
        } else {
            TestContext.getInstance().sa()
                       .assertThat(formatAsDate(actual)).as(assertMsg).isAfter(formatAsDate(expected));
        }
    }

    @Override
    protected void assertGreaterThanOrEqual(Object actual, Object expected, String assertMsg) {
        if(onFailureFlag == HARD_STOP_ON_FAILURE) {
            assertThat(formatAsDate(actual)).as(assertMsg).isAfterOrEqualTo(formatAsDate(expected));
        } else {
            TestContext.getInstance().sa()
                       .assertThat(formatAsDate(actual)).as(assertMsg).isAfterOrEqualTo(formatAsDate(expected));
        }
    }

    @Override
    protected void assertContains(Object actual, Object expected, String assertMsg) {
        throw new UnsupportedOperationException("Contains assertion not available for Compare_Dates.");
    }

    @Override
    protected void assertDoesNotContain(Object actual, Object expected, String assertMsg) {
        throw new UnsupportedOperationException("Does Not Contain assertion not available for Compare_Dates.");
    }
}
