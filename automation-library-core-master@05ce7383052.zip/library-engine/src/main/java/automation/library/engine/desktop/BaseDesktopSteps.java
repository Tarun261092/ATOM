package automation.library.engine.desktop;

import automation.library.common.TestContext;
import automation.library.engine.core.BaseStepsEngine;
import automation.library.engine.core.objectmatcher.ObjectNotFoundException;
import automation.library.leanft.core.Constants;
import automation.library.leanft.core.desktop.*;
import automation.library.leanft.core.desktop.stdwin.*;
import automation.library.leanft.core.desktop.web.*;
import automation.library.leanft.core.desktop.winforms.*;
import automation.library.leanft.exec.DesktopContext;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.stream.JsonReader;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.Keyboard;

import java.awt.*;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import static automation.library.engine.core.AutoEngConstants.DESKTOP;
import static automation.library.engine.core.objectmatcher.ObjectFinder.getMatchingElement;
 
public class BaseDesktopSteps extends BaseStepsEngine {
    protected static final String LIST_DELIMITER = " | ";
    public static final String EMB_TRAN_TYPE = "EMB TRAN TYPE";
    public static final String NA = "NA";
    public static final String FE = "FE";
    private static final String FIELD_NOT_FOUND_PATTERN = "The \"%s\" field was not found in the page object: \"%s\"";

    protected void launchApplication(String appName) {
        TestContext.getInstance().setActiveWindowType(DESKTOP);
        DesktopContext.getInstance().setDesktopContextWithLaunchInfo(appName);
        DesktopContext.getInstance().getAut(appName);
    }

    protected void launchApplication(String pageTitle, String browser) {
        TestContext.getInstance().setActiveWindowType(DESKTOP);
        DesktopContext.getInstance().getExistingBrowser(pageTitle, browser);
    }


    protected void closeApplication(String appName) {
        DesktopContext.getInstance().quitAut(appName);
    }

    /**
     * Generic method to find object
     *
     * @param fieldName
     * @param windowName
     */
    protected DesktopButton getDesktopButton(String fieldName, String windowName) {
        Object ele = getMatchingElement(fieldName, windowName);
        DesktopClass instanceName = DesktopClass.get(ele.getClass().getSimpleName());

        switch (instanceName) {
            case DESKTOP_SW_BUTTON:
                return (SWDesktopButton) ele;
            case DESKTOP_WF_BUTTON:
                return (WFDesktopButton) ele;
            case DESKTOP_WEB_BUTTON:
                return (DesktopWebButton) ele;
            default:
                throw new ObjectNotFoundException(String.format(FIELD_NOT_FOUND_PATTERN, fieldName, windowName));
        }
    }

    /**
     * Generic method to find object
     *
     * @param fieldName
     * @param windowName
     */
    protected DesktopEditField getDesktopEditField(String fieldName, String windowName) {
        Object ele = getMatchingElement(fieldName, windowName);
        DesktopClass instanceName = DesktopClass.get(ele.getClass().getSimpleName());

        switch (instanceName) {
            case DESKTOP_WF_EDIT_FIELD:
                return (WFDesktopEditField) ele;
            case DESKTOP_SW_EDITFIELD:
                return (SWDesktopEditField) ele;
            case DESKTOP_WEB_EDIT_FIELD:
                return (DesktopWebEditField) ele;
            default:
                throw new ObjectNotFoundException(String.format(FIELD_NOT_FOUND_PATTERN, fieldName, windowName));
        }
    }


    /**
     * Generic method to find object
     *
     * @param fieldName
     * @param windowName
     */
    protected DesktopComboBox getDesktopComboBox(String fieldName, String windowName) {
        Object ele = getMatchingElement(fieldName, windowName);
        DesktopClass instanceName = DesktopClass.get(ele.getClass().getSimpleName());

        switch (instanceName) {
            case DESKTOP_WF_COMBOBOX:
                return (WFDesktopComboBox) ele;
            case DESKTOP_SW_COMBOBOX:
                return (SWDesktopComboBox) ele;
            default:
                throw new ObjectNotFoundException(String.format(FIELD_NOT_FOUND_PATTERN, fieldName, windowName));
        }
    }


    /**
     * Generic method to find object
     *
     * @param fieldName
     * @param windowName
     */
    protected DesktopTable getDesktopTable(String fieldName, String windowName) {
        Object ele = getMatchingElement(fieldName, windowName);
        DesktopClass instanceName = DesktopClass.get(ele.getClass().getSimpleName());

        switch (instanceName) {
            case DESKTOP_WF_TABLE:
                return (WFDesktopTable) ele;
            case DESKTOP_WEB_TABLE:
                return (DesktopWebTable) ele;
            default:
                throw new ObjectNotFoundException(String.format(FIELD_NOT_FOUND_PATTERN, fieldName, windowName));
        }
    }

    /**
     * Generic method to find object
     *
     * @param fieldName
     * @param windowName
     */
    protected DesktopTabControl getDesktopTabControl(String fieldName, String windowName) {
        Object ele = getMatchingElement(fieldName, windowName);
        DesktopClass instanceName = DesktopClass.get(ele.getClass().getSimpleName());

        switch (instanceName) {
            case DESKTOP_WF_TABCONTROL:
                return (WFDesktopTabControl) ele;
            case DESKTOP_SW_TABCONTROL:
                return (SWDesktopTabControl) ele;
            default:
                throw new ObjectNotFoundException(String.format(FIELD_NOT_FOUND_PATTERN, fieldName, windowName));
        }
    }

    /**
     * Generic method to find object
     *
     * @param fieldName
     * @param windowName
     */
    protected DesktopLabel getDesktopLabel(String fieldName, String windowName) {
        Object ele = getMatchingElement(fieldName, windowName);
        DesktopClass instanceName = DesktopClass.get(ele.getClass().getSimpleName());

        switch (instanceName) {
            case DESKTOP_WF_LABEL:
                return (WFDesktopLabel) ele;
            case DESKTOP_SW_LABEL:
                return (SWDesktopLabel) ele;
            default:
                throw new ObjectNotFoundException(String.format(FIELD_NOT_FOUND_PATTERN, fieldName, windowName));
        }
    }
    protected DesktopToolBar getDesktopToolBar(String fieldName, String windowName) {
        Object ele = getMatchingElement(fieldName, windowName);
        DesktopClass instanceName = DesktopClass.get(ele.getClass().getSimpleName());

        switch (instanceName) {
            case DESKTOP_WF_TOOLBAR:
                return (WFDesktopToolBar) ele;
            default:
                throw new ObjectNotFoundException(String.format(FIELD_NOT_FOUND_PATTERN, fieldName, windowName));
        }
    }

    /**
     * Generic method to find object
     *
     * @param fieldName
     * @param windowName
     */
    protected DesktopUiObject getDesktopUiObject(String fieldName, String windowName) {
        Object ele = getMatchingElement(fieldName, windowName);
        DesktopClass instanceName = DesktopClass.get(ele.getClass().getSimpleName());

        switch (instanceName) {
            case DESKTOP_WF_UIOBJECT:
                return (WFDesktopUIObject) ele;
            case DESKTOP_SW_UIOBJECT:
                return (SWDesktopUIObject) ele;
            default:
                throw new ObjectNotFoundException(String.format(FIELD_NOT_FOUND_PATTERN, fieldName, windowName));
        }
    }
    /**
     * Generic method to find object
     *
     * @param fieldName
     * @param windowName
     */
    protected DesktopRadioButton getDesktopRadioButton(String fieldName, String windowName) {
        Object ele = getMatchingElement(fieldName, windowName);
        DesktopClass instanceName = DesktopClass.get(ele.getClass().getSimpleName());

        switch (instanceName) {
            case DESKTOP_WF_RADIOBUTTON:
                return (WFDesktopRadioButton) ele;
            case DESKTOP_SW_RADIOBUTTON:
                return (SWDesktopRadioButton) ele;
            case DESKTOP_WEB_RADIO_GROUP:
                return (DesktopWebRadioGroup) ele;
            default:
                throw new ObjectNotFoundException(String.format(FIELD_NOT_FOUND_PATTERN, fieldName, windowName));
        }
    }
    /**
     * Generic method to find object
     *
     * @param fieldName
     * @param windowName
     */
    protected DesktopCheckbox getDesktopCheckbox(String fieldName, String windowName) {
        Object ele = getMatchingElement(fieldName, windowName);
        DesktopClass instanceName = DesktopClass.get(ele.getClass().getSimpleName());

        switch (instanceName) {
            case DESKTOP_WF_CHECKBOX:
                return (WFDesktopCheckbox) ele;
            case DESKTOP_SW_CHECKBOX:
                return (SWDesktopCheckbox) ele;
            case DESKTOP_WEB_CHECKBOX:
                return (DesktopWebCheckbox) ele;
            default:
                throw new ObjectNotFoundException(String.format(FIELD_NOT_FOUND_PATTERN, fieldName, windowName));
        }
    }

    /**
     * Generic method to find object
     *
     * @param fieldName
     * @param windowName
     */
    protected DesktopEditor getDesktopEditor(String fieldName, String windowName) {
        Object ele = getMatchingElement(fieldName, windowName);
        DesktopClass instanceName = DesktopClass.get(ele.getClass().getSimpleName());

        switch (instanceName) {
            case DESKTOP_WF_EDITOR:
                return (WFDesktopEditor) ele;
            case DESKTOP_SW_EDITOR:
                return (SWDesktopEditor) ele;
            default:
                throw new ObjectNotFoundException(String.format(FIELD_NOT_FOUND_PATTERN, fieldName, windowName));
        }
    }
    /**
     * Generic method to find object
     *
     * @param fieldName
     * @param windowName
     */
    protected DesktopListView getDesktopListView(String fieldName, String windowName) {
        Object ele = getMatchingElement(fieldName, windowName);
        DesktopClass instanceName = DesktopClass.get(ele.getClass().getSimpleName());

        switch (instanceName) {
            case DESKTOP_WF_LISTVIEW:
                return (WFDesktopListView) ele;
            default:
                throw new ObjectNotFoundException(String.format(FIELD_NOT_FOUND_PATTERN, fieldName, windowName));
        }
    }

    protected DesktopWindow getDesktopWindow(String windowName) {
        Object ele = getMatchingElement("window", windowName);
        DesktopClass instanceName = DesktopClass.get(ele.getClass().getSimpleName());

        switch (instanceName) {
            case DESKTOP_WF_WINDOW:
                return (WFDesktopWindow) ele;
            case DESKTOP_SW_WINDOW:
                return (SWDesktopWindow) ele;
            case DESKTOP_WEB_WINDOW:
                return (WebDesktopBrowserWindow) ele;
            default:
                throw new ObjectNotFoundException("The 'window' was not found in the page object: : \"" + windowName + "\"");
        }
    }

    protected DesktopWeb getDesktopWebElement(String fieldName, String windowName) {
        Object ele = getMatchingElement(fieldName, windowName);
        DesktopClass instanceName = DesktopClass.get(ele.getClass().getSimpleName());

        switch (instanceName) {
            case DESKTOP_WEB_ELEMENT:
                return (DesktopWebElement) ele;
            default:
                throw new ObjectNotFoundException(String.format(FIELD_NOT_FOUND_PATTERN, fieldName, windowName));
        }
    }

    protected DesktopWeb getDesktopWebListBox(String fieldName, String windowName) {
        Object ele = getMatchingElement(fieldName, windowName);
        DesktopClass instanceName = DesktopClass.get(ele.getClass().getSimpleName());

        switch (instanceName) {
            case DESKTOP_WEB_LIST_BOX:
                return (DesktopWebListBox) ele;
            default:
                throw new ObjectNotFoundException(String.format(FIELD_NOT_FOUND_PATTERN, fieldName, windowName));
        }
    }

    protected DesktopWeb getDesktopWebLink(String fieldName, String windowName) {
        Object ele = getMatchingElement(fieldName, windowName);
        DesktopClass instanceName = DesktopClass.get(ele.getClass().getSimpleName());

        switch (instanceName) {
            case DESKTOP_WEB_LINK:
                return (DesktopWebLink) ele;
            default:
                throw new ObjectNotFoundException(String.format(FIELD_NOT_FOUND_PATTERN, fieldName, windowName));
        }
    }

    protected DesktopImage getDesktopWebImage(String fieldName, String windowName) {
        Object ele = getMatchingElement(fieldName, windowName);
        DesktopClass instanceName = DesktopClass.get(ele.getClass().getSimpleName());

        switch (instanceName) {
            case DESKTOP_WEB_IMAGE:
                return (DesktopWebImage) ele;
            default:
                throw new ObjectNotFoundException(String.format(FIELD_NOT_FOUND_PATTERN, fieldName, windowName));
        }
    }

    protected DesktopStatic getDesktopStatic(String fieldName, String windowName) {
        Object ele = getMatchingElement(fieldName, windowName);
        DesktopClass instanceName = DesktopClass.get(ele.getClass().getSimpleName());

        switch (instanceName) {
            case DESKTOP_SW_STATIC:
                return (SWDesktopStatic) ele;
            case DESKTOP_WF_STATIC:
                return (WFDesktopStatic) ele;
            default:
                throw new ObjectNotFoundException(String.format(FIELD_NOT_FOUND_PATTERN, fieldName, windowName));
        }
    }

    protected DesktopObject getDesktopObject(String fieldName,String windowName) {
        Object ele = getMatchingElement(fieldName, windowName);
        DesktopClass instanceName = DesktopClass.get(ele.getClass().getSimpleName());

        switch (instanceName) {
            case DESKTOP_WF_UIOBJECT:
                return (WFDesktopUIObject) ele;
            case DESKTOP_SW_CHECKBOX:
                return (SWDesktopCheckbox) ele;
            case DESKTOP_SW_UIOBJECT:
                return (SWDesktopUIObject) ele;
            case DESKTOP_SW_LABEL:
                return (SWDesktopLabel) ele;
            case DESKTOP_SW_TABCONTROL:
                return (SWDesktopTabControl) ele;
            case DESKTOP_SW_COMBOBOX:
                return (SWDesktopComboBox) ele;
            case DESKTOP_WF_CHECKBOX:
                return (WFDesktopCheckbox) ele;
            case DESKTOP_WF_EDIT_FIELD:
                return (WFDesktopEditField) ele;
            case DESKTOP_WF_TABCONTROL:
                return (WFDesktopTabControl) ele;
            case DESKTOP_WF_BUTTON:
                return (WFDesktopButton) ele;
            case DESKTOP_SW_BUTTON:
                return (SWDesktopButton) ele;
            case DESKTOP_SW_EDITFIELD:
                return (SWDesktopEditField) ele;
            case DESKTOP_WF_LABEL:
                return (WFDesktopLabel) ele;
            case DESKTOP_WF_COMBOBOX:
                return (WFDesktopComboBox) ele;
            case DESKTOP_WF_RADIOBUTTON:
                return (WFDesktopRadioButton) ele;
            case DESKTOP_SW_RADIOBUTTON:
                return (SWDesktopRadioButton) ele;
            case DESKTOP_WF_TOOLBAR:
                return (WFDesktopToolBar) ele;
            case DESKTOP_WF_LISTVIEW:
                return (WFDesktopListView) ele;
            case DESKTOP_WF_EDITOR:
                return (WFDesktopEditor) ele;
            case DESKTOP_SW_EDITOR:
                return (SWDesktopEditor) ele;
            case DESKTOP_WEB_LINK:
                return (DesktopWebLink) ele;
            case DESKTOP_WEB_LIST_BOX:
                return (DesktopWebListBox) ele;
            case DESKTOP_WEB_ELEMENT:
                return (DesktopWebElement) ele;
            case DESKTOP_WEB_RADIO_GROUP:
                return (DesktopWebRadioGroup) ele;
            case DESKTOP_WEB_EDIT_FIELD:
                return (DesktopWebEditField) ele;
            case DESKTOP_WEB_BUTTON:
                return (DesktopWebButton) ele;
            case DESKTOP_WEB_CHECKBOX:
                return (DesktopCheckbox) ele;
            case DESKTOP_WEB_IMAGE:
                return (DesktopWebImage) ele;
            case DESKTOP_SW_STATIC:
                return (SWDesktopStatic) ele;
            case DESKTOP_WF_STATIC:
                return (WFDesktopStatic) ele;
            default:
                throw new ObjectNotFoundException("The 'window' was not found in the page object: : \"" + windowName + "\"");
        }
    }

    protected String getMnemonicKey(String key) {
        Gson gson = new Gson();
        try {
            JsonReader reader = new JsonReader(new FileReader(Constants.KEYBOARDMAINFRAMEJSON));
            JsonObject jsonObject = gson.fromJson(reader, JsonObject.class);
            key = jsonObject.get(key.toUpperCase()).getAsString();
        } catch (FileNotFoundException e) {
            log.error(e.getMessage());
        }
        return key;
    }

    /**
     * Captures clipboard
     * @return
     */
    protected String copyClipboardToVar() {
        Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
        String valToStore = "";

        try {
            valToStore = (String) clipboard.getData(DataFlavor.stringFlavor);
        } catch(UnsupportedFlavorException | IOException e) {
            log.error(e.getMessage());
        }
        return valToStore;
    }

    protected String getValueFromField(String fieldName, String windowName) throws GeneralLeanFtException {
        DesktopEditField field = getDesktopEditField(fieldName, windowName);

        String actualVal = null;

        if (field.exists() != null) {
            actualVal = field.getText().trim();
        } else {
            actualVal = field.getText();
        }
        return actualVal;
    }


    protected void pressKeyboardKey(Keyboard.Keys keyToPress) throws GeneralLeanFtException {
        if (DesktopContext.getInstance().runOnGrid()) {
            DesktopContext.getInstance()
                     .getEnv()
                     .getKeyboard()
                     .pressKey(keyToPress);
        } else {
            Keyboard.pressKey(keyToPress);
        }
    }

    protected DesktopDialog getDesktopDialog(String dialogName) {
        Object ele = getMatchingElement("dialog", dialogName);
        DesktopClass instanceName = DesktopClass.get(ele.getClass().getSimpleName());

        switch (instanceName) {
            case DESKTOP_WF_DIALOG:
                return (WFDesktopDialog) ele;
            case DESKTOP_SW_DIALOG:
                return (SWDesktopDialog) ele;
            default:
                throw new ObjectNotFoundException("The 'dialog window' was not found in the page object: : \"" + dialogName + "\"");
        }
    }
    
    protected void WaitfortheElementVisible(String title,String browserType,String elementType,String xpath) throws GeneralLeanFtException
    {
    	switch(elementType.toUpperCase())
    	{
    	case "WEBELEMENT":
    		DesktopWebElement webelement = new DesktopWebElement();
    		webelement.checkVisiblityOfElement(title, browserType, xpath);
    		break;
    	case "WEBBUTTON":
    		DesktopWebButton webButton = new DesktopWebButton();
    		webButton.checkVisiblityOfButton(title, browserType, xpath);
    		break;
    	case "WEBCHECKBOX":
    		DesktopWebCheckbox webCheckbox = new DesktopWebCheckbox();
    		webCheckbox.checkVisiblityOfCheckbox(title, browserType, xpath);
    		break;
    	case "WEBIMAGE":
    		DesktopWebImage webImage = new DesktopWebImage();
    		webImage.checkVisiblityOfImage(title, browserType, xpath);
    		break;
    	case "WEBLINK":
    		DesktopWebLink webLink = new DesktopWebLink();
    		webLink.checkVisiblityOfLink(title, browserType, xpath);
    		break;
    	case "WEBEDITFIELD":
    		DesktopWebEditField webEditField = new DesktopWebEditField();
    		webEditField.checkVisiblityOfEditField(title, browserType, xpath);
    		break;
    	case "WEBLISTBOX":
    		DesktopWebListBox webListBox = new DesktopWebListBox();
    		webListBox.checkVisiblityOfListBox(title, browserType, xpath);
    		break;
    	case "WEBRADIOGROUP":
    		DesktopWebRadioGroup webRadioGroup = new DesktopWebRadioGroup();
    		webRadioGroup.checkVisiblityOfRadioGroup(title, browserType, xpath);
    		break;
    	case "WEBTABLE":
    		DesktopWebTable webTable = new DesktopWebTable();
    		webTable.checkVisiblityOfWebTable(title, browserType, xpath);
    		break;
    	default:
            throw new ObjectNotFoundException("Please Enter a valid elementType : \"" + elementType.toUpperCase() + "\" is not valid");
    	}
    }
    
    protected void WaitfortheElementVisibleInFrame(String title,String browserType,String elementType,String frameName,String xpath) throws GeneralLeanFtException
    {
    	switch(elementType.toUpperCase())
    	{
    	case "WEBELEMENT":
    		DesktopWebElement webelement = new DesktopWebElement();
    		webelement.checkVisiblityOfElementInFrame(title, browserType, frameName, xpath);
    		break;
    	case "WEBBUTTON":
    		DesktopWebButton webButton = new DesktopWebButton();
    		webButton.checkVisiblityOfButtonInFrame(title, browserType, frameName, xpath);
    		break;
    	case "WEBCHECKBOX":
    		DesktopWebCheckbox webCheckbox = new DesktopWebCheckbox();
    		webCheckbox.checkVisiblityOfCheckboxInFrame(title, browserType, frameName, xpath);
    		break;
    	case "WEBIMAGE":
    		DesktopWebImage webImage = new DesktopWebImage();
    		webImage.checkVisiblityOfImageInFrame(title, browserType, frameName, xpath);
    		break;
    	case "WEBLINK":
    		DesktopWebLink webLink = new DesktopWebLink();
    		webLink.checkVisiblityOfLinkInFrame(title, browserType, frameName, xpath);
    		break;
    	case "WEBEDITFIELD":
    		DesktopWebEditField webEditField = new DesktopWebEditField();
    		webEditField.checkVisiblityOfEditFieldInFrame(title, browserType, frameName, xpath);
    		break;
    	case "WEBLISTBOX":
    		DesktopWebListBox webListBox = new DesktopWebListBox();
    		webListBox.checkVisiblityOfListBoxInFrame(title, browserType, frameName, xpath);
    		break;
    	case "WEBRADIOGROUP":
    		DesktopWebRadioGroup webRadioGroup = new DesktopWebRadioGroup();
    		webRadioGroup.checkVisiblityOfRadioGroupInFrame(title, browserType, frameName, xpath);
    		break;
    	case "WEBTABLE":
    		DesktopWebTable webTable = new DesktopWebTable();
    		webTable.checkVisiblityOfWebTableInFrame(title, browserType, frameName, xpath);
    		break;
    	default:
            throw new ObjectNotFoundException("Please Enter a valid elementType : \"" + elementType.toUpperCase() + "\" is not valid");
    	}
    }

}