package automation.library.engine.ivr;

import automation.library.common.TestContext;
import automation.library.cyara.core.CyaraContext;
import automation.library.engine.core.BaseStepsEngine;

import java.util.Map;

public class BaseIVRSteps extends BaseStepsEngine {
    protected static final String ERROR_RESPONSE = "-1";
    protected static final String CYARA_TEST_INFO = "fw.cyaraTestInfo";

    protected void launchIVRTest(String testName) {
        TestContext.getInstance().setActiveWindowType("IVR");
        final Map<String, String> currentlyRunningTest = CyaraContext.getInstance().launchTest(testName);

        if(!currentlyRunningTest.isEmpty()) {
            TestContext.getInstance().testdataPut(CYARA_TEST_INFO, currentlyRunningTest);
            TestContext.getInstance().testdataPut("fw.cyaraRunning", "true");
            logStepMessage(String.format("Cyara ticket number of running test: %s", currentlyRunningTest.get("ticketNum")));
        } else {
            throw new IllegalArgumentException("Unable to launch test with name:" + testName);
        }
    }

    protected Map<String, String> launchIVRCampaign(String campaignName) {
        TestContext.getInstance().setActiveWindowType("IVR");
        final Map<String, String> currentlyRunningCampaign = CyaraContext.getInstance().checkForRunningCampaign(campaignName);

        if(!currentlyRunningCampaign.isEmpty()) {
            logStepMessage(String.format("Cyara campaign status of running campaign: %s", currentlyRunningCampaign.get("status")));
            TestContext.getInstance().testdataPut("fw.cyaraOBRunning", "true");
            return currentlyRunningCampaign;
        } else {
            throw new IllegalArgumentException("Unable to launch campaign with name:" + campaignName);
        }
    }
}