package automation.library.engine.api.steps;

import automation.library.common.TestContext;
import automation.library.engine.api.BaseAPISteps;
import io.cucumber.java.en.When;

import java.util.HashMap;
import java.util.Map;

public class AutoEngAPIRemove extends BaseAPISteps {

    @When("^remove \"([^\"]*)\" in the API response at key \"([^\"]*)\"$")
    public void theUserRemovesAttributeInPayload(String attributeName,
                                                 String dictionaryKey) {

        theUserRemovesAttributeInPayload(attributeName,
                                         ROOT_ATTRIBUTE, dictionaryKey);
    }

    @When("^remove \"([^\"]*)\" within parent attribute \"([^\"]*)\" in the API response at key \"([^\"]*)\"$")
    public void theUserRemovesAttributeInPayload(String attributeName,
                                                 String parentAttributeName,
                                                 String dictionaryKey) {
        dictionaryKey = parseDictionaryKey(dictionaryKey);
        Map<String, Object> args = new HashMap<>();
        args.put(ATTRIBUTE_NAME, attributeName);
        args.put(PARENT_ATTRIBUTE_NAME, parentAttributeName);
        args.put(RESPONSE, TestContext.getInstance().testdataGet(dictionaryKey));
        final String featureToRun = getRemoveFeature(args.get("parentAttributeName").toString());

        removeAPIAttribute(featureToRun, args, attributeName, dictionaryKey);
    }
}