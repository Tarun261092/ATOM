package automation.library.engine.core.validator.managers;

import automation.library.common.TestContext;
import automation.library.engine.core.validator.FailureFlag;
import automation.library.engine.core.validator.ValidatorManager;

import java.util.List;

import static automation.library.engine.core.validator.FailureFlag.HARD_STOP_ON_FAILURE;
import static automation.library.engine.core.validator.FailureFlag.valueOfLabel;
import static org.assertj.core.api.Assertions.assertThat;

public class ListValidator extends ValidatorManager {
    private FailureFlag onFailureFlag;

    public ListValidator(String onFailureFlag) {
        this.onFailureFlag = valueOfLabel(onFailureFlag);
    }

    @Override
    protected void assertEquals(Object actual, Object expected, String assertMsg) {
        if (onFailureFlag == HARD_STOP_ON_FAILURE) {
            assertThat((List)actual).as(assertMsg).hasSameElementsAs((List)expected);
        } else {
            TestContext.getInstance().sa().assertThat((List) actual).as(assertMsg).hasSameElementsAs((List)expected);
        }
    }

    @Override
    protected void assertEqualsIgnoreCase(Object actual, Object expected, String assertMsg) {
        throw new UnsupportedOperationException("EqualIgnoreCase assertion not available for Compare_Lists");
    }

    @Override
    protected void assertNotEquals(Object actual, Object expected, String assertMsg) {
        if (onFailureFlag == HARD_STOP_ON_FAILURE) {
            assertThat((List) actual).as(assertMsg).isNotSameAs(expected);
        } else {
            TestContext.getInstance().sa().assertThat((List) actual).as(assertMsg).isNotSameAs(expected);
        }
    }

    @Override
    protected void assertLessThan(Object actual, Object expected, String assertMsg) {
        throw new UnsupportedOperationException("assertLessThan is not supported for Compare_Lists");
    }

    @Override
    protected void assertLessThanOrEqual(Object actual, Object expected, String assertMsg) {
        throw new UnsupportedOperationException("assertLessThanOrEqual is not supported for Compare_Lists");
    }

    @Override
    protected void assertGreaterThan(Object actual, Object expected, String assertMsg) {
        throw new UnsupportedOperationException("assertGreaterThan is not supported for Compare_Lists");
    }

    @Override
    protected void assertGreaterThanOrEqual(Object actual, Object expected, String assertMsg) {
        throw new UnsupportedOperationException("assertGreaterThanOrEqual is not supported for Compare_Lists");
    }

    @Override
    protected void assertContains(Object actual, Object expected, String assertMsg) {
        if (onFailureFlag == HARD_STOP_ON_FAILURE) {
            assertThat((List)actual).as(assertMsg).containsAnyElementsOf((List)expected);
        } else {
            TestContext.getInstance().sa().assertThat((List) actual).as(assertMsg).containsAnyElementsOf((List)expected);
        }
    }

    @Override
    protected void assertDoesNotContain(Object actual, Object expected, String assertMsg) {
        if (onFailureFlag == HARD_STOP_ON_FAILURE) {
            assertThat((List) actual).as(assertMsg).doesNotContainAnyElementsOf((List)expected);
        } else {
            TestContext.getInstance().sa().assertThat((List) actual).as(assertMsg).doesNotContainAnyElementsOf((List)expected);
        }
    }

}