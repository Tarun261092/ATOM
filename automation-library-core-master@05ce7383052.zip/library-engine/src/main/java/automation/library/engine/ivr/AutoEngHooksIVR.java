package automation.library.engine.ivr;

import automation.library.common.TestContext;
import automation.library.cyara.core.CyaraContext;
import io.cucumber.core.api.Scenario;
import io.cucumber.java8.En;

import static automation.library.cyara.core.CyaraConstants.CYARA_LAUNCHED;
import static automation.library.engine.core.AutoEngConstants.IVR;

public class AutoEngHooksIVR implements En {
    public AutoEngHooksIVR() {
        After(50, (Scenario scenario) -> {
            if (TestContext.getInstance().getActiveWindowType() != null &&
                (TestContext.getInstance().getActiveWindowType().equalsIgnoreCase(IVR) ||
                 Boolean.parseBoolean(String.valueOf(TestContext.getInstance().testdataGet(CYARA_LAUNCHED))))) {
                CyaraContext.removeInstance();
            }
        });
    }
}
