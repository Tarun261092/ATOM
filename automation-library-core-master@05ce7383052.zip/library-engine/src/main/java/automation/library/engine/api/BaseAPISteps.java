package automation.library.engine.api;

import automation.library.api.Constants;
import automation.library.api.kafka.KafkaHandler;
import automation.library.api.test.utils.JSONFormatter;
import automation.library.common.FileHelper;
import automation.library.common.Property;
import automation.library.common.TestContext;
import automation.library.engine.core.BaseStepsEngine;
import automation.library.engine.core.validator.AssertHelper;
import automation.library.engine.core.validator.ComparisonOperator;
import automation.library.engine.core.validator.ComparisonType;
import automation.library.reporting.Reporter;
import com.google.gson.Gson;
import com.google.gson.JsonIOException;
import com.google.gson.JsonSyntaxException;
import com.intuit.karate.Runner;
import com.intuit.karate.exception.KarateException;
import com.jayway.jsonpath.InvalidPathException;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.ReadContext;
import org.apache.commons.configuration2.PropertiesConfiguration;
import org.testng.reporters.Files;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.*;
import java.nio.file.Paths;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static automation.library.api.Constants.KAFKA_PROPS_PATH;
import static automation.library.api.Constants.KAFKA_TOPICS_FILE;
import static automation.library.cucumber.core.Constants.MQENVIRONMENTPATH;
import static automation.library.cucumber.core.Constants.RUNTIMEPATH;
import static automation.library.engine.core.AutoEngConstants.API;
import static automation.library.engine.core.objectmatcher.ObjectFinder.getMatchingAPIFeature;
import static org.assertj.core.api.Assertions.assertThat;

public class BaseAPISteps extends BaseStepsEngine {
    private static final String STATUS_FAIL = "FAIL";
    protected static final String ROOT_ATTRIBUTE = "root";
    protected static final String VALIDATION_TAG = "VALIDATION.";
    protected static final String RESPONSE_KEY = "fw.lastAPIResponse";
    protected static final String RESPONSE = "response";
    protected static final String RESPONSE_STATUS_KEY = "fw.responseStatus";
    protected static final String COMPARISON_OP = "comparisonOperator";
    private static final String RESPONSE_STATUS = "responseStatus";
    protected static final String PARENT_ATTRIBUTE_NAME = "parentAttributeName";
    protected static final String ATTRIBUTE_NAME = "attributeName";
    protected static final String ATTRIBUTE_VALUE = "attributeValue";
    private static final String CLASSPATH_API_FEATURE_FILES = "classpath:%s%s";
    private static final String REQUEST_URI = "requestURI";
    private static final String REQUEST_HEADERS = "requestHeaders";
    private static final String REQUEST_BODY = "requestBody";
    protected static final String RESPONSE_XML = "responseAsXml";
    protected static final String RESPONSE_XML_KEY = "responseXMLKey";
    private static final String WITH_PARENT = "WithParent";
    private static final String PARENT_FEATURE_PATTERN = "%s%s.feature";
    private static final String FEATURE_PATTERN = "%s.feature";
    protected static final String RESPONSE_HEADER_KEY = "fw.responseHeaders";
    protected static final String RESPONSE_HEADER = "responseHeaders";
    protected static final String TOPIC_KEY = "fw.activeKafkaTopic";
    protected static final String HARD_STOP_ON_FAILURE = "HardStopOnFailure";
    protected static final String FW_KAFKA_HEADER_MAP = "fw.kafkaHeaderMap";
    protected static final String QUEUE_NAME = "queueName";
    protected static final String VALUE_TO_STORE = "valToStore";

    protected static final String MQ_RESP = "fw.respMsg";

    protected enum StoreType {
        SINGLE, ATINDEX, ATLAST, LASTCOUNT, FILTERBY, FILTERBYTWO, FULLARRAY;
    }

    public Map runAPIFeatureFile(String path, Map<String, Object> args) {
        return Runner.runFeature(path, args, true);
    }

    protected String getAPIObject(String featurename) {
        String featureFileName = getMatchingAPIFeature(featurename).getFlatFileObjectName();

        if (featureFileName != null) {
            return featureFileName;
        } else {
            try {
                throw new FileNotFoundException("The \"" + featurename + "\" is not found in the APIObject directory");
            } catch (FileNotFoundException e) {
                log.error(e.getMessage());
            }
        }
        return null;
    }

    protected String getStorageFeature(String parentAttributeName, StoreType storeType) {
        String baseFeatureName = "";

        switch (storeType) {
            case ATINDEX:
                baseFeatureName = "storeAttributeAtIndex";
                break;
            case ATLAST:
                baseFeatureName = "storeAttributeAtLastIndex";
                break;
            case LASTCOUNT:
                baseFeatureName = "storeAttributeLastCount";
                break;
            case FILTERBY:
                baseFeatureName = "storeAttributeSearchBy";
                break;
            case FILTERBYTWO:
                baseFeatureName = "storeAttributeSearchByTwo";
                break;
            case FULLARRAY:
                baseFeatureName = "storeAttributeFullArray";
                break;
            case SINGLE:
            default:
                baseFeatureName = "storeAttribute";
                break;
        }

        if (parentAttributeName.equalsIgnoreCase((ROOT_ATTRIBUTE))) {
            return String.format(FEATURE_PATTERN, baseFeatureName);
        } else {
            return String.format(PARENT_FEATURE_PATTERN, baseFeatureName, WITH_PARENT);
        }
    }


    protected String getSetFeature(String parentAttributeName, StoreType storeType) {
        String baseFeatureName = "";

        switch (storeType) {
            case ATINDEX:
                baseFeatureName = "setAttributeAtIndex";
                break;
            case SINGLE:
            default:
                baseFeatureName = "setAttribute";
                break;
        }

        if (parentAttributeName.equalsIgnoreCase((ROOT_ATTRIBUTE))) {
            return String.format(FEATURE_PATTERN, baseFeatureName);
        } else {
            return String.format(PARENT_FEATURE_PATTERN, baseFeatureName, WITH_PARENT);
        }
    }

    protected String getRemoveFeature(String parentAttributeName) {
        String baseFeatureName = "removeAttribute";

        if (parentAttributeName.equalsIgnoreCase((ROOT_ATTRIBUTE))) {
            return String.format(FEATURE_PATTERN, baseFeatureName);
        } else {
            return String.format(PARENT_FEATURE_PATTERN, baseFeatureName, WITH_PARENT);
        }
    }

    private void logRequestResponseData(Map<String, Object> result) {
        Map<String, Object> reportInfo = getReportInfo(result);

        logAndReportText("API Request URI: %s", reportInfo.get(REQUEST_URI));
        logAndReportDataTable("API Request Headers", reportInfo.get(REQUEST_HEADERS));
        logAndReportJSON("API Request Body", reportInfo.get(REQUEST_BODY));
        Reporter.addStepLog(String.format("Response Code: %s", result.get(RESPONSE_STATUS)));
        logAndReportJSON("API Response", result.get(RESPONSE));

        if (result.get(RESPONSE_XML) != null) {
            logAndReportText("API Response XML: %s", result.get(RESPONSE_XML));
        }
    }

    private Map<String, Object> getReportInfo(Map<String, Object> result) {
        if (result.get("reportInfo") != null) {
            return (HashMap) result.get("reportInfo");
        } else {
            Map<String, Object> reportInfo = new HashMap<>();
            reportInfo.put(REQUEST_URI, result.get(REQUEST_URI));
            reportInfo.put(REQUEST_HEADERS, result.get(REQUEST_HEADERS));
            reportInfo.put(REQUEST_BODY, result.get(REQUEST_BODY));
            return reportInfo;
        }
    }

    private void logAndReportText(String textToLog, Object attributeToLog) {
        if (attributeToLog != null && !attributeToLog.toString().isEmpty()) {
            log.debug(() -> String.format(textToLog, attributeToLog.toString()));
            Reporter.addStepLog(String.format(textToLog, attributeToLog.toString()));
        }
    }

    private void logAndReportDataTable(String tableTitle, Object attributeToLog) {
        if (attributeToLog != null) {
            log.debug(attributeToLog);
            Reporter.addDataTable(tableTitle, (Map) attributeToLog);
        }
    }


    protected String retrieveValueFromAPIResponse(String payloadKeyName, String parentAttributeName, String attributeName) {
        Map<String, Object> args = new HashMap<>(TestContext.getInstance().testdata());
        args.put(PARENT_ATTRIBUTE_NAME, parentAttributeName);
        args.put(ATTRIBUTE_NAME, attributeName);
        args.put(RESPONSE, TestContext.getInstance().testdataGet(payloadKeyName));

        final String featureToRun = getStorageFeature(parentAttributeName, StoreType.SINGLE);

        try {
            Map<String, Object> result = runAPIFeatureFile(String.format(CLASSPATH_API_FEATURE_FILES,
                                                                         Constants.STOREUTILSPATH,
                                                                         featureToRun),
                                                           args);
            return String.valueOf(result.get(VALUE_TO_STORE));
        } catch (KarateException ke) {
            Reporter.addStepLog(STATUS_FAIL, ke.getMessage());
            log.error(ke.getMessage());
            throw ke;
        }
    }


    protected void validateAPIResponse(String payloadKeyName,
                                       String attributeName,
                                       String parentAttributeName,
                                       String comparisonOperator,
                                       String expectedValue,
                                       String validationID,
                                       String onFailureFlag) {
        Object expectedVal = parseValueToObject(expectedValue);
        String actualValue = retrieveValueFromAPIResponse(payloadKeyName, parentAttributeName, attributeName);

        Map<String, Object> argsToAdd = new HashMap<>();
        argsToAdd.put(PARENT_ATTRIBUTE_NAME, parentAttributeName);
        argsToAdd.put(ATTRIBUTE_NAME, attributeName);
        argsToAdd.put("attributeVal", expectedVal);
        argsToAdd.put(RESPONSE, TestContext.getInstance().testdataGet(payloadKeyName));
        TestContext.getInstance().testdataPut("fw.argList", argsToAdd);

        AssertHelper validator = new AssertHelper(ComparisonType.COMPARE_API_RESPONSE,
                                                  ComparisonOperator.valueOfLabel(comparisonOperator),
                                                  onFailureFlag);
        validator.performValidation(actualValue, expectedVal, validationID, "API response validation");
    }

    private void storeReturnedValue(String attributeName, String dictionaryKey, Object result) {
        if (result != null && !result.toString().isEmpty()) {
            TestContext.getInstance().testdata().put(dictionaryKey, result);
            logStepMessage(String.format("Stored attribute --> { %s : \"%s\" }", attributeName, result));
        } else {
            String errMsg = String.format("the '%s' attribute was not found in response", attributeName);
            log.warn(errMsg);
            Reporter.addStepLog("FAIL", errMsg);
        }
    }

    private String getPathToFeature(String featureName) {
        String tempPath = FileHelper.findFileInPath(Constants.APIOBJECTSPATH, featureName + ".feature");
        if (tempPath != null) {
            return tempPath.split(Constants.APIOBJECTSFOLDER)[1];
        } else
            return null;
    }

    private String getPathToXML(String featureName) {
        return FileHelper.findFileInPath(Constants.APIOBJECTSPATH, featureName + ".xml");
    }

    private String getPathToMQPayLoad(String payload) {
        return FileHelper.findFileInPath(Constants.MQPAYLOADPATH, payload + ".xml");
    }

    private void callAPI(String pathToFeature, Map<String, Object> args) {
        try {
            TestContext.getInstance().setActiveWindowType(API);
            Map<String, Object> result = runAPIFeatureFile(pathToFeature, args);
            TestContext.getInstance().testdataPut(RESPONSE_KEY, result.get(RESPONSE));
            TestContext.getInstance().testdataPut(RESPONSE_STATUS_KEY, result.get(RESPONSE_STATUS));
            if (result.get(RESPONSE_XML) != null) {
                TestContext.getInstance().testdataPut(RESPONSE_XML_KEY, result.get(RESPONSE_XML));
            }
            TestContext.getInstance().testdataPut(RESPONSE_HEADER_KEY, result.get(RESPONSE_HEADER));
            logRequestResponseData(result);
        } catch (KarateException ke) {
            Reporter.addStepLog(STATUS_FAIL, "Step Failed: " + args.get("featureName") + " execution is failed. See error message" + ke.getMessage());
            throw ke;
        }
    }

    protected void callAPIWithoutTag(String featureName, Map<String, Object> args) {
        callAPI(String.format(CLASSPATH_API_FEATURE_FILES, Constants.APIOBJECTSFOLDER, getPathToFeature(featureName)),
                args);
    }

    protected void callMQ(String syncParam, String queueName, String payloadFile) {
        Map<String, Object> args = new HashMap<>(TestContext.getInstance().testdata());
        args.put(QUEUE_NAME, queueName);
        args.put("pathToPayload", String.format("file:%s", getPathToMQPayLoad(payloadFile)));
        PropertiesConfiguration mqPropsEnv = Property.getProperties(MQENVIRONMENTPATH + Property.getVariable(MQ_ENV_PROP) + PROPERTIES_EXT);

        if (mqPropsEnv != null) {
            for (Iterator<String> it = mqPropsEnv.getKeys(); it.hasNext(); ) {
                String key = it.next();
                args.put(key, mqPropsEnv.getString(key));
            }
        }
        if (syncParam.equalsIgnoreCase("sync")) {
            final String featureToRun = String.format(FEATURE_PATTERN, "syncMQ");
            runAPIFeatureFile(String.format(CLASSPATH_API_FEATURE_FILES,
                                            Constants.MQUTILSPATH,
                                            featureToRun), args);
        } else {
            final String featureToRun = String.format(FEATURE_PATTERN, "asyncMQ");
            runAPIFeatureFile(String.format(CLASSPATH_API_FEATURE_FILES,
                                            Constants.MQUTILSPATH,
                                            featureToRun), args);
        }
    }

    protected void callAPIWithTag(String featureName, Map<String, Object> args) {
        String pathToFeature = getPathToFeature(featureName);

        if (pathToFeature != null) {
            args.put("fullPathToFeature", String.format(CLASSPATH_API_FEATURE_FILES, Constants.APIOBJECTSFOLDER, pathToFeature));
            args.put("pathToFeature", String.format(CLASSPATH_API_FEATURE_FILES, Constants.APIOBJECTSFOLDER, pathToFeature.split(featureName + ".feature")[0]));
        } else {
            log.warn("Unable to get path to feature.");
        }

        callAPI(String.format(CLASSPATH_API_FEATURE_FILES, Constants.CALLUTILSPATH, "callAPI.feature"), args);
    }

    protected Map<String, Object> getAPICallParamList(String paramList) {
        List<String> listOfParams = Arrays.asList(paramList.split("\\|"));

        if (!listOfParams.isEmpty() && listOfParams.get(0).equalsIgnoreCase("ALL")) {
            return new HashMap<>(TestContext.getInstance().testdata());
        } else {
            return listOfParams.stream()
                               .map(String::trim)
                               .collect(Collectors.toMap(this::parseDictionaryKey, this::parseValueToObject));
        }
    }

    protected void storeAPIResponse(String featureName,
                                    Map<String, Object> args,
                                    String attributeName,
                                    String dictionaryKey) {
        try {
            Map<String, Object> result = runAPIFeatureFile(String.format(CLASSPATH_API_FEATURE_FILES, Constants.STOREUTILSPATH, featureName), args);
            storeReturnedValue(attributeName, dictionaryKey, result.get(VALUE_TO_STORE));
        } catch (KarateException ke) {
            Reporter.addStepLog(STATUS_FAIL, ke.getMessage());
            log.error(ke.getMessage());
            throw ke;
        }
    }

    protected void setAPIAttribute(String featureName,
                                   Map<String, Object> args,
                                   String attributeName,
                                   String dictionaryKey) {
        try {
            Map<String, Object> result = runAPIFeatureFile(String.format(CLASSPATH_API_FEATURE_FILES, Constants.SETUTILSPATH, featureName), args);
            TestContext.getInstance().testdataPut(dictionaryKey, result.get("updatedJson"));
            logStepMessage(String.format("Set %s attribute to %s.", attributeName, result.get("replacedVal")));
        } catch (KarateException ke) {
            Reporter.addStepLog(STATUS_FAIL, ke.getMessage());
            log.error(ke.getMessage());
            throw ke;
        }
    }

    protected void removeAPIAttribute(String featureName,
                                      Map<String, Object> args,
                                      String attributeName,
                                      String dictionaryKey) {
        try {
            Map<String, Object> result = runAPIFeatureFile(String.format(CLASSPATH_API_FEATURE_FILES, Constants.REMOVEUTILSPATH, featureName), args);
            TestContext.getInstance().testdataPut(dictionaryKey, result.get("updatedJson"));
            logStepMessage(String.format("Removed attribute %s.", attributeName));
        } catch (KarateException ke) {
            Reporter.addStepLog(STATUS_FAIL, ke.getMessage());
            log.error(ke.getMessage());
            throw ke;
        }
    }

    protected String getXMLStorageFeature(String parentAttributeName, StoreType storeType) {
        String baseFeatureName = "";

        switch (storeType) {            
            case FILTERBY:
                baseFeatureName = "storeXMLAttributeSearchBy";
                break;
            case SINGLE:
            default:
                baseFeatureName = "storeXMLAttribute";
                break;
        }

        if (parentAttributeName.equalsIgnoreCase((ROOT_ATTRIBUTE))) {
            return String.format(FEATURE_PATTERN, baseFeatureName);
        } else {
            return String.format(PARENT_FEATURE_PATTERN, baseFeatureName, WITH_PARENT);
        }
    }

    protected void replaceParamsInXMLFile(String xmlTemplateFile, String xmlTarget) throws IOException {
        final String pathToXmlTemplate = getPathToXML(xmlTemplateFile);
        String templateXMLAsString = FileHelper.getFileAsString(pathToXmlTemplate, "\n");

        if (templateXMLAsString != null) {
            templateXMLAsString = replaceParameterVals(templateXMLAsString);
            PropertiesConfiguration props = Property.getProperties(RUNTIMEPATH);
            boolean val = Boolean.parseBoolean(props.getString("ignoreTagsXML"));
            String fetchedVal = props.getString("ignoreTagInformation");
            if (val) {
                List<String> list = props.getList("ignoreTagInformation").stream().map(token -> (String) token).collect(Collectors.toList());
                for (String token : list) {
                    if (fetchedVal != null && !fetchedVal.isEmpty()) {
                        Pattern p = Pattern.compile("<" + token + ">" + "(\\S+)" + "</" + token + ">");
                        Matcher m = p.matcher(templateXMLAsString);
                        if (!m.find()) {
                            TestContext.getInstance().testdataPut(xmlTarget, templateXMLAsString);
                        }
                    }
                }
            } else {
                TestContext.getInstance().testdataPut(xmlTarget, templateXMLAsString);
            }
            final String newFileName = Paths.get(String.format("%s/%s.xml",
                                                               Paths.get(pathToXmlTemplate).getParent().toString(),
                                                               xmlTarget))
                                            .toAbsolutePath()
                                            .toString();
            Files.writeFile(templateXMLAsString, new File(newFileName));
        }
    }

    protected String transformXMLWithProperStandards(String responseXML,
                                                     String tagToReplace,
                                                     String xmlAttributeName) throws TransformerException,
                                                                                     ParserConfigurationException,
                                                                                     SAXException,
                                                                                     IOException {

        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance("com.sun.org.apache.xerces.internal.jaxp.DocumentBuilderFactoryImpl", null);
        factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
        factory.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, "");
        factory.setAttribute(XMLConstants.ACCESS_EXTERNAL_SCHEMA, "");

        DocumentBuilder builder = factory.newDocumentBuilder();
        Document doc = builder.parse(new InputSource(new StringReader(responseXML)));
        NodeList nodes = doc.getElementsByTagName(tagToReplace);

        for (int temp = 0; temp < nodes.getLength(); temp++) {
            String newNodeName = nodes.item(temp).getAttributes().getNamedItem(xmlAttributeName).getNodeValue();
            doc.renameNode(nodes.item(temp), null, newNodeName);
            nodes.item(temp).getAttributes().removeNamedItem(xmlAttributeName);
        }

        TransformerFactory tf = TransformerFactory.newInstance("com.sun.org.apache.xalan.internal.xsltc.trax.TransformerFactoryImpl", null);
        tf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
        tf.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, "");
        tf.setAttribute(XMLConstants.ACCESS_EXTERNAL_STYLESHEET, "");

        Transformer transformer = tf.newTransformer();
        transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
        StringWriter writer = new StringWriter();
        transformer.transform(new DOMSource(doc), new StreamResult(writer));
        return writer.getBuffer().toString();
    }

    protected Map<String, String> getKafkaTopicMap() {
        try (FileReader kafkaReader = new FileReader(Paths.get(KAFKA_TOPICS_FILE).toFile())) {
            return new Gson().fromJson(kafkaReader, Map.class);
        } catch (IOException | JsonSyntaxException | JsonIOException e) {
            log.error(e.getMessage());
        }
        return Collections.emptyMap();
    }

    protected KafkaHandler getActiveKafkaHandler() {
        KafkaHandler kafkaHandler = TestContext.getInstance().testdataToClass(TOPIC_KEY, KafkaHandler.class);

        if (kafkaHandler != null) {
            return kafkaHandler;
        } else {
            throw new IllegalArgumentException("Unable to find active topic. Please subscribe first");
        }
    }

    protected KafkaHandler getNewOrActiveKafkaHandler(String scenarioName) {
        KafkaHandler kafkaHandler = TestContext.getInstance().testdataToClass(TOPIC_KEY, KafkaHandler.class);

        if (kafkaHandler == null) {
            return new KafkaHandler(scenarioName);
        } else {
            return kafkaHandler;
        }
    }

    protected String getActualKafkaTopicName(String topicNameLogical) {
        final Map<String, String> kafkaTopics = getKafkaTopicMap();
        final String topicNameActual = kafkaTopics.get(parseValue(topicNameLogical));

        if (topicNameActual != null) {
            return topicNameActual;
        } else {
            throw new IllegalArgumentException("Unable to find topic in list. Please provide the topic name in: " +
                                               KAFKA_TOPICS_FILE);
        }
    }

    protected Object getKafkaPayload(String msgTemplateName) throws IOException {
        final String pathToKakfaTemplateFile = Paths.get(String.format("%smessageTemplates/%s.json",
                                                                       KAFKA_PROPS_PATH,
                                                                       msgTemplateName))
                                                    .toAbsolutePath()
                                                    .toString();

        if (new File(pathToKakfaTemplateFile).exists()) {
            final String jsonPayload = replaceParameterVals(FileHelper.getFileAsString(pathToKakfaTemplateFile, "\n"));
            return new Gson().fromJson(jsonPayload, Object.class);
        } else {
            throw new IllegalArgumentException("Unable to find payload template at path: " + pathToKakfaTemplateFile);
        }
    }

    protected boolean jsonHasMatchingAttribute(Object payload,
                                               String attributeName,
                                               String attributeValue,
                                               String comparisonText,
                                               String attributeName2,
                                               String attributeValue2,
                                               String comparisonText2) {
        String comparisonOperator = getComparisonOperator(comparisonText);

        try {
            ReadContext ctx = JsonPath.parse(payload);
            String jsonPathToUse;

            if (attributeName2 != null) {
                String comparisonOperator2 = getComparisonOperator(comparisonText2);
                jsonPathToUse = getJsonPath(ctx, attributeName, attributeValue, comparisonOperator,
                                            attributeName2, attributeValue2, comparisonOperator2);
            } else {
                jsonPathToUse = getJsonPath(ctx, attributeName, attributeValue, comparisonOperator);
            }

            if (jsonPathToUse != null) {
                final List<Object> listOfMatches = ctx.read(jsonPathToUse);
                return !listOfMatches.isEmpty();
            }
        } catch (InvalidPathException e) {
            log.error(e.getMessage());
        }

        return false;
    }

    private String getJsonPath(ReadContext ctx, String attributeName, String attributeValue, String comparisonOperator) {
        final List<Object> attributeTypeInPayload = ctx.read("$.." + attributeName);

        if (!attributeTypeInPayload.isEmpty()) {
            final String attribValToCompare = getAttributeValType(attributeTypeInPayload.get(0), attributeValue);
            return String.format("$..[?(@.%s%s%s)]", attributeName, comparisonOperator, attribValToCompare);
        }

        return null;
    }

    private String getJsonPath(ReadContext ctx,
                               String attributeName,
                               String attributeValue,
                               String comparisonOperator,
                               String attributeName2,
                               String attributeValue2,
                               String comparisonOperator2) {

        final List<Object> attributeTypeInPayload = ctx.read("$.." + attributeName);
        final List<Object> attributeTypeInPayload2 = ctx.read("$.." + attributeName2);

        if (!attributeTypeInPayload.isEmpty() && !attributeTypeInPayload2.isEmpty()) {
            final String attribValToCompare = getAttributeValType(attributeTypeInPayload.get(0), attributeValue);
            final String attribValToCompare2 = getAttributeValType(attributeTypeInPayload2.get(0), attributeValue2);

            return String.format("$..[?(@.%s%s%s && @.%s%s%s)]",
                                 attributeName, comparisonOperator, attribValToCompare,
                                 attributeName2, comparisonOperator2, attribValToCompare2);
        }

        return null;
    }


    private String getAttributeValType(Object attributeType, String attributeValue) {
        if (attributeType instanceof String) {
            return String.format("'%s'", attributeValue);
        } else {
            return String.valueOf(attributeValue);
        }
    }

    private String getComparisonOperator(String comparisonText) {
        switch (comparisonText.toLowerCase()) {
            case "equal to":
                return "==";

            case "not equal to":
                return "!=";

            case "greater than":
                return ">";

            case "greater than or equal to":
                return ">=";

            case "less than":
                return "<";

            case "less than or equal to":
                return "<=";

            default:
                log.warn("Unsupported comparison operator:  {}. Defaulting to equals.", comparisonText);
                return "==";
        }
    }

    protected void validateJsonSchema(String payloadKeyName,
                                      String schemaName,
                                      String validationID,
                                      String onFailureFlag) {
        TestContext.getInstance().setActiveWindowType(API);
        String fullPathToSchema = FileHelper.findFileInPath(Constants.APIOBJECTSPATH, schemaName + ".json");

        if (fullPathToSchema != null) {
            String classPathToSchema = fullPathToSchema.split(Constants.APIOBJECTSFOLDER)[1];

            Map<String, Object> args = new HashMap<>();
            args.put(RESPONSE, TestContext.getInstance().testdataGet(payloadKeyName));
            args.put("pathToSchema", String.format(CLASSPATH_API_FEATURE_FILES, Constants.APIOBJECTSFOLDER, classPathToSchema));

            try {
                Map<String, Object> result = runAPIFeatureFile("classpath:services/validate/validateJsonSchema.feature", args);
                Reporter.addTextLogContent("Response Payload Validated", JSONFormatter.formatJSON(result.get(RESPONSE)));
                TestContext.getInstance().testdata().put(VALIDATION_TAG + validationID, "Schema validation passed");
            } catch (KarateException ke) {
                Reporter.addTextLogContent("Karate assertion message", ke.getMessage());
                TestContext.getInstance().testdata().put(VALIDATION_TAG + validationID, "Schema validation failed");

                if (onFailureFlag.equalsIgnoreCase(HARD_STOP_ON_FAILURE)) {
                    assertThat(ke).doesNotThrowAnyException();
                } else {
                    TestContext.getInstance().sa().assertThat(ke).doesNotThrowAnyException();
                }
            }

        } else
            log.error("Did not find schema");
    }

    protected Map<String, Object> getKafkaHeaders(String headerObject) {
        if (headerObject != null && parseValueToObject(headerObject) != null) {
            try {
                return (Map) parseValueToObject(headerObject);
            } catch (ClassCastException e) {
                log.error("Did not find header object at key: {}", headerObject);
            }
        } else {
            return getKafkaHeaderObject();
        }

        return new HashMap<>();
    }

    protected Map<String, Object> getKafkaHeaderObject() {
        Object kafkaHeaders = TestContext.getInstance().testdataGet(FW_KAFKA_HEADER_MAP);

        if (kafkaHeaders != null) {
            return (Map) kafkaHeaders;
        } else {
            return new HashMap<>();
        }
    }


}