package automation.library.engine.web.steps;

import automation.library.common.Property;
import automation.library.common.TestContext;
import automation.library.engine.web.BaseWebSteps;
import automation.library.selenium.core.Constants;
import automation.library.selenium.core.Element;
import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.LinkedListMultimap;
import com.google.common.collect.ListMultimap;
import io.cucumber.java.en.When;
import org.openqa.selenium.Cookie;

import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class AutoEngWebStoreValue extends BaseWebSteps {

    @When("^store tooltip value of the \"([^\"]*)\" element at the \"([^\"]*)\" page into the data dictionary with key \"([^\"]*)\"$")
    public void storeTooltipValueOfTheElementAtThePageIntoTheDataDictionaryWithKey(String objectName,
                                                                                   String pageName,
                                                                                   String dictionaryKey) {
        dictionaryKey = parseDictionaryKey(dictionaryKey);
        String valToStore = getObject(objectName, pageName).getAttribute("title");
        TestContext.getInstance().testdataPut(dictionaryKey, valToStore);
        logStepMessage(String.format(STORED_VALUE, valToStore, dictionaryKey));
    }

    @When("^store the displayed text of the \"([^\"]*)\" element at the \"([^\"]*)\" page into the data dictionary with key \"([^\"]*)\"$")
    public void storeTheDisplayedTextOfTheElementAtThePageIntoTheDataDictionaryWithKey(String objectName,
                                                                                       String pageName,
                                                                                       String dictionaryKey) {
        dictionaryKey = parseDictionaryKey(dictionaryKey);
        String valToStore = getTextFromElement(getObject(objectName, pageName)).trim();
        TestContext.getInstance().testdataPut(dictionaryKey, valToStore);
        logStepMessage(String.format(STORED_VALUE, valToStore, dictionaryKey));
    }

    @When("^store the value of the \"([^\"]*)\" element at the \"([^\"]*)\" page into the data dictionary with key \"([^\"]*)\"$")
    public void storeTheValueOfTheElementAtThePageIntoTheDataDictionaryWithKey(String objectName,
                                                                               String pageName,
                                                                               String dictionaryKey) {
        dictionaryKey = parseDictionaryKey(dictionaryKey);
        String valToStore = getObject(objectName, pageName).getValue();
        TestContext.getInstance().testdataPut(dictionaryKey, valToStore);
        logStepMessage(String.format(STORED_VALUE, valToStore, dictionaryKey));
    }

    @When("^store text of all elements that match the pattern of \"([^\"]*)\" element present at \"([^\"]*)\" page into the data dictionary with key \"([^\"]*)\"$")
    public void storeTextByMatchingThePatternOfAllElementsPresentAtPage(String objectName,
                                                                        String pageName,
                                                                        String dictionaryKeyToStore) {

        dictionaryKeyToStore = parseDictionaryKey(dictionaryKeyToStore);
        List<Element> els = getObjects(objectName, pageName);
        List<String> valToStore = new ArrayList<>();
        for (Element el : els) {
            valToStore.add(el.getText());
        }
        TestContext.getInstance().testdataPut(dictionaryKeyToStore, valToStore);
        logStepMessage(String.format(STORED_VALUE, valToStore, dictionaryKeyToStore));
    }

    @When("^store list values from the \"([^\"]*)\" dropdown at the \"([^\"]*)\" page into the data dictionary with key \"([^\"]*)\"$")
    public void storeListValuesFromTheDropdownAtTheIntoTheDataDictionaryWithKey(String objectName,
                                                                                String pageName,
                                                                                String dictionaryKey) {
        dictionaryKey = parseDictionaryKey(dictionaryKey);
        List<String> valToStore = getObject(objectName, pageName).getDropdownOptionValues();
        TestContext.getInstance().testdataPut(dictionaryKey, valToStore);
        logStepMessage(String.format(STORED_VALUE, valToStore, dictionaryKey));
    }

    @When("^store list values from the \"([^\"]*)\" combobox at the \"([^\"]*)\" page into the data dictionary with key \"([^\"]*)\"$")
    public void storeListValuesFromTheComboboxAtTheIntoTheDataDictionaryWithKey(String objectName,
                                                                                String pageName,
                                                                                String dictionaryKey) {
        dictionaryKey = parseDictionaryKey(dictionaryKey);
        String valToStore = getObject(objectName, pageName).element().getText();
        TestContext.getInstance().testdataPut(dictionaryKey, valToStore);
        logStepMessage(String.format(STORED_VALUE, valToStore, dictionaryKey));
    }

    @When("^store the current page URL into the data dictionary with key \"([^\"]*)\"$")
    public void storeTheCurrentPageURLIntoTheDataDictionaryWithKey(String dictionaryKey) {
        dictionaryKey = parseDictionaryKey(dictionaryKey);
        String valToStore = getDriver().getCurrentUrl();
        TestContext.getInstance().testdataPut(dictionaryKey, valToStore);
        logStepMessage(String.format(STORED_VALUE, valToStore, dictionaryKey));
    }

    @When("^store value from row \"([^\"]*)\" and column \"([^\"]*)\" from the \"([^\"]*)\" table at the \"([^\"]*)\" page into the data dictionary with key \"([^\"]*)\"$")
    public void storeValueFromRowAndColumnFromTheTableAtThePageIntoTheDataDictionaryWithKey(String rowNum,
                                                                                            String colNum,
                                                                                            String tableName,
                                                                                            String pageName,
                                                                                            String dictionaryKey) {
        dictionaryKey = parseDictionaryKey(dictionaryKey);
        String valToStore = getObject(tableName, pageName).getDataCellElement(Integer.parseInt(rowNum),
                                                                              Integer.parseInt(colNum)).getText();
        TestContext.getInstance().testdataPut(dictionaryKey, valToStore);
        logStepMessage(String.format(STORED_VALUE, valToStore, dictionaryKey));
    }

    @When("^store the value of the phone \"([^\"]*)\" element and \"([^\"]*)\" element at the \"([^\"]*)\" page into the data dictionary with key \"([^\"]*)\"$")
    public void storeTheValueOfThePhoneElementAndElementAtThePageIntoTheDataDictionaryWithKey(String countryCodeEle,
                                                                                              String phoneNumEle,
                                                                                              String pageName,
                                                                                              String dictionaryKey) {
        dictionaryKey = parseDictionaryKey(dictionaryKey);
        String countryCode = getObject(countryCodeEle, pageName).getValue();
        String phoneNum = getObject(phoneNumEle, pageName).getValue();
        String valToStore = countryCode.concat(phoneNum);
        TestContext.getInstance().testdataPut(dictionaryKey, valToStore);
        logStepMessage(String.format(STORED_VALUE, valToStore, dictionaryKey));
    }

    @When("^store the current system time into the data dictionary with key \"([^\"]*)\" as timezone \"([^\"]*)\"$")
    public void storeTheCurrentSystemTimeIntoTheDataDictionaryWithKeyAsTimezone(String dictionaryKey,
                                                                                String timezone) {

        dictionaryKey = parseDictionaryKey(dictionaryKey);

        DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("MM/dd/yyyy hh:mma").withLocale(Locale.ENGLISH);
        ZonedDateTime zonedDateTime = Instant.now().atZone(ZoneId.of(timezone));
        String valToStore = dateFormat.format(zonedDateTime);

        TestContext.getInstance().testdataPut(dictionaryKey, valToStore);
        logStepMessage(String.format(STORED_VALUE, valToStore, dictionaryKey));
    }

    @When("^store the current system date and time into the data dictionary with key \"([^\"]*)\" and \"([^\"]*)\" timezone \"([^\"]*)\"$")
    public void storeTheCurrentSystemDateAndTimeIntoTheDataDictionaryWithKeyAndTimezone(String dateDictionaryKey,
                                                                                        String timeDictionaryKey,
                                                                                        String timezone) {
        dateDictionaryKey = parseDictionaryKey(dateDictionaryKey);
        timeDictionaryKey = parseDictionaryKey(timeDictionaryKey);

        DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("MM/dd/yyyy").withLocale(Locale.ENGLISH);
        DateTimeFormatter timeFormat = DateTimeFormatter.ofPattern("hh:mma").withLocale(Locale.ENGLISH);

        ZonedDateTime zonedDateTime = Instant.now().atZone(ZoneId.of(timezone));

        String valToStore = dateFormat.format(zonedDateTime);
        TestContext.getInstance().testdataPut(dateDictionaryKey, valToStore);
        logStepMessage(String.format(STORED_VALUE, valToStore, dateDictionaryKey));

        valToStore = timeFormat.format(zonedDateTime);
        TestContext.getInstance().testdataPut(timeDictionaryKey, timeFormat.format(zonedDateTime));
        logStepMessage(String.format(STORED_VALUE, valToStore, timeDictionaryKey));
    }

    @When("^store text of the cell having unique rowVal \"([^\"]*)\" and columnHeader \"([^\"]*)\" from the \"([^\"]*)\" table at the \"([^\"]*)\" page into the data dictionary with key \"([^\"]*)\"$")
    public void storeTextOfTheCellHavingUniqueRowValAndColumnHeaderFromTheTableAtThePageIntoTheDataDictionaryWithKey(String rowValue,
                                                                                                                     String colHeader,
                                                                                                                     String tableName,
                                                                                                                     String pageName,
                                                                                                                     String dictionaryKey) {
        dictionaryKey = parseDictionaryKey(dictionaryKey);
        String valToStore = getObject(tableName, pageName).findMatchingCellinTable(rowValue,
                                                                                   colHeader).getText();

        TestContext.getInstance().testdataPut(dictionaryKey, valToStore);
        logStepMessage(String.format(STORED_VALUE, valToStore, dictionaryKey));
    }

    @When("^store text of the matching cell in the column \"([^\"]*)\" where the column \"([^\"]*)\" contains unique value \"([^\"]*)\" in the \"([^\"]*)\" table at the \"([^\"]*)\" page into the data dictionary with key \"([^\"]*)\"$")
    public void storeTextOfTheMatchingCellInTheColumnWhereTheColumnContainsUniqueInTheTableAtThePageIntoTheDataDictionaryWithKey(String colHeader1,
                                                                                                                                 String colHeader2,
                                                                                                                                 String colValue2,
                                                                                                                                 String tableName,
                                                                                                                                 String pageName,
                                                                                                                                 String dictionaryKey) {
        dictionaryKey = parseDictionaryKey(dictionaryKey);
        colValue2 = parseValue(colValue2);
        colHeader1 = parseValue(colHeader1);
        colHeader2 = parseValue(colHeader2);

        String valToStore = getObject(tableName, pageName).findMatchingCellValueinTableForGivenColumnHeaderAndValue(colValue2,
                                                                                                                    colHeader2,
                                                                                                                    colHeader1).getText();
        TestContext.getInstance().testdataPut(dictionaryKey, valToStore);
        logStepMessage(String.format(STORED_VALUE, valToStore, dictionaryKey));
    }

    @When("^store the concatenated string of \"([^\"]*)\" and the \"([^\"]*)\" element value at the \"([^\"]*)\" page into the data dictionary with key \"([^\"]*)\"$")
    public void storeConcatenatedValueandElementValue(String valsToConcat,
                                                      String objectName,
                                                      String pageName,
                                                      String dictionaryKey) {
        dictionaryKey = parseDictionaryKey(dictionaryKey);
        valsToConcat = String.join("|", valsToConcat, getTextFromElement(getObject(objectName, pageName)));
        String combinedString = getConcatenatedVal(valsToConcat, "\\|", " ");

        TestContext.getInstance().testdataPut(dictionaryKey, combinedString);
        logStepMessage(String.format(STORED_VALUE, combinedString, dictionaryKey));
    }

    @When("^store text from the corresponding cell in all rows of the \"([^\"]*)\" column in the \"([^\"]*)\" table at the \"([^\"]*)\" page into the data dictionary with key \"([^\"]*)\"$")
    public void storeTextOfAllTheCellInTheColumnInTheTableAtThePageIntoTheDataDictionaryWithKey(String colHeader,
                                                                                                String tableName, String pageName, String dictionaryKey) {
        dictionaryKey = parseDictionaryKey(dictionaryKey);
        List<String> valToStore = getObject(tableName, pageName).getRowValuesForGivenColumn(colHeader);
        TestContext.getInstance().testdataPut(dictionaryKey, valToStore);
        logStepMessage(String.format(STORED_VALUE, valToStore, dictionaryKey));
    }

    @When("^stores list of values from column \"([^\"]*)\" and \"([^\"]*)\" where the \"([^\"]*)\" column contains \"([^\"]*)\" and \"([^\"]*)\" column contains \"([^\"]*)\" from the \"([^\"]*)\" table at the \"([^\"]*)\" page into the data dictionary with key \"([^\"]*)\"$")
    public void storeTextOfTheMatchingCellInTheColumnWhereTheColumnContainsUniqueInTheTableAtThePageIntoTheDataDictionaryWithKey(String colHeader1,
                                                                                                                                 String colHeader2,
                                                                                                                                 String colHeader3,
                                                                                                                                 String colValue3,
                                                                                                                                 String colHeader4,
                                                                                                                                 String colValue4,
                                                                                                                                 String tableName,
                                                                                                                                 String pageName,
                                                                                                                                 String dictionaryKey) {
        colValue3 = parseValue(colValue3);
        colValue4 = parseValue(colValue4);
        dictionaryKey = parseDictionaryKey(dictionaryKey);

        int rowNumber = getObject(tableName, pageName).getMatchingRowNumber(colHeader3, colValue3, colHeader4, colValue4);
        List<String> colName1 = getObject(tableName, pageName).getTopNineSubRowValuesForGivenColumn(colHeader1, rowNumber);
        List<String> colName2 = getObject(tableName, pageName).getTopNineSubRowValuesForGivenColumn(colHeader2, rowNumber);
        ListMultimap<String, String> map = ArrayListMultimap.create();
        for (int i = 0; i < colName1.size(); i++) {
            map.put(colName1.get(i), colName2.get(i));
        }
        TestContext.getInstance().testdataPut(dictionaryKey, map);
        logStepMessage(String.format(STORED_VALUE, map, dictionaryKey));
    }

    @When("^store text by matching the pattern \"([^\"]*)\" at index \"([^\"]*)\" where text starting with \"([^\"]*)\" and ending with \"([^\"]*)\" into the data dictionary with key \"([^\"]*)\"$")
	public void storeTextByMatchingPatternWithTheIndexStartingWithAndEndingWith(String pattern,
			int index,                                                                                         
			String startText,
			String endText,
			String dictionaryKeyToStore) {

		pattern = parseValue(pattern);
		dictionaryKeyToStore = parseDictionaryKey(dictionaryKeyToStore);
		String fullVal = TestContext.getInstance().testdataGet("Logs").toString();
		List<String> val = Arrays.asList(fullVal.split(pattern));
		String fullValue = null;
		String subStringVal = null;

		fullValue = val.get(index);

		if (fullValue.contains(startText) && fullValue.contains(endText) ) {
			subStringVal = getSubstringVal(fullValue, fullValue.indexOf(parseValue(startText)) + "-" + (fullValue.indexOf(parseValue(endText)) + parseValue(endText).length()));

		} else {
			log.warn("Not a valid pattern to substring. Returning blank value");
		}

		TestContext.getInstance().testdataPut(dictionaryKeyToStore, subStringVal);
		logStepMessage(String.format(STORED_VALUE, subStringVal, dictionaryKeyToStore));
	}

    @When("^store text by matching the pattern \"([^\"]*)\" of \"([^\"]*)\" element present at \"([^\"]*)\" page into the data dictionary with key \"([^\"]*)\"$")
    public void storeTextByMatchingThePatternOfElementPresentAtPage(String pattern,
                                                                    String objectName,
                                                                    String pageName,
                                                                    String dictionaryKeyToStore) {

        pattern = parseValue(pattern);
        dictionaryKeyToStore = parseDictionaryKey(dictionaryKeyToStore);
        String fullVal = getObject(objectName, pageName).element().getText();
        List<String> val = Arrays.asList(fullVal.split(pattern));
        String fullValue = val.get(0);
        TestContext.getInstance().testdataPut(dictionaryKeyToStore, fullValue);
        logStepMessage(String.format(STORED_VALUE, fullValue, dictionaryKeyToStore));
    }

    @When("^store text of field \"([^\"]*)\" and \"([^\"]*)\" from the \"([^\"]*)\" table at the \"([^\"]*)\" page into the data dictionary with key \"([^\"]*)\"$")
    public void storeTextAndFromColumnFromTableAtThePage(String firstText,
                                                         String secondText,
                                                         String tableName,
                                                         String pageName,
                                                         String dictionaryKeyToStore) throws InterruptedException {

        dictionaryKeyToStore = parseDictionaryKey(dictionaryKeyToStore);
        Element tableElement = getObject(tableName, pageName);
        List<Element> buttonToClick = tableElement.findExpandButtonInTable();
        List<Element> tableRowText = tableElement.findTableColumnPattern();
        List<Element> tableColText = tableElement.findTableColumnPatternText(firstText, secondText);
        List<String> finalList = new ArrayList<>();
        String accountType = null;
        String accountNumber = null;
        for (int i = 0; i < buttonToClick.size(); i++) {
            String accNumb = null;
            accountType = tableRowText.get(i).getText();
            buttonToClick.get(i).click();
            for (Element tableEle : tableColText) {
                Thread.sleep(Property.getProperties(Constants.SELENIUMRUNTIMEPATH).getInt("elementVisisbleDelay", 0));
                if (tableEle.getText() != null && tableEle.element().isDisplayed()) {
                    accountNumber = tableEle.getText();
                    accNumb = accountNumber.substring(accountNumber.length() - 4);
                }
            }
            if (accNumb != null) {
                finalList.add(accountType + " - " + accNumb);
            }
        }
        TestContext.getInstance().testdataPut(dictionaryKeyToStore, finalList);
        logStepMessage(String.format(STORED_VALUE, finalList, dictionaryKeyToStore));
    }

    @When("^store the amount from the \"([^\"]*)\" element at the \"([^\"]*)\" page into the data dictionary with key \"([^\"]*)\"$")
    public void storeAmountOfTheElementAtThePageIntoTheDataDictionaryWithKey(String objectName,
                                                                             String pageName,
                                                                             String dictionaryKey) {
        dictionaryKey = parseDictionaryKey(dictionaryKey);
        String amount = getDollarAmountFromString(getTextFromElement(getObject(objectName, pageName)));
        TestContext.getInstance().testdataPut(dictionaryKey, amount);
        logStepMessage(String.format(STORED_VALUE, amount, dictionaryKey));
    }

    @When("^split the text with pattern \"([^\"]*)\" and store value of column \"([^\"]*)\" where row contains \"([^\"]*)\" from the data dictionary \"([^\"]*)\" into the data dictionary with key \"([^\"]*)\"$")
    public void storeValueOfColumnWhereRowContainsFromTheDataDictionaryIntoTheDataDictionaryKey(String pattern,
                                                                                                String columnIndex,
                                                                                                String value,
                                                                                                String text,
                                                                                                String dictionaryKey) {
        dictionaryKey = parseValue(dictionaryKey);
        value = parseValue(value);
        int index = Integer.parseInt(parseValue(columnIndex));
        text = String.valueOf(TestContext.getInstance().testdataGet(parseDictionaryKey(text)));
        String valueToStore = getValueFromText(text, pattern, value, index);
        TestContext.getInstance().testdataPut(dictionaryKey, valueToStore);
        logStepMessage(String.format(STORED_VALUE, valueToStore, dictionaryKey));
    }


    @When("^the user stores the value of the \"([^\"]*)\" cookie to the data dictionary with key \"([^\"]*)\"$")
    public void storeCookieValue(String cookieName, String dictionaryKey) {
        Cookie matchingCookie = getDriver().manage().getCookieNamed(parseValue(cookieName));
        dictionaryKey = parseValue(dictionaryKey);

        if (matchingCookie != null) {
            final String valueToStore = matchingCookie.getValue();
            TestContext.getInstance().testdataPut(dictionaryKey, valueToStore);
            logStepMessage(String.format(STORED_VALUE, valueToStore, dictionaryKey));
        } else {
            log.warn("Cookie with name {} was not found.", () -> parseValue(cookieName));
        }
    }
    
    @When("^stores list of values from column \"([^\"]*)\" into the data dictionary with key \"([^\"]*)\" and column \"([^\"]*)\" into the data dictionary with key \"([^\"]*)\" where the \"([^\"]*)\" column contains \"([^\"]*)\" and \"([^\"]*)\" column contains \"([^\"]*)\" from the \"([^\"]*)\" table at the \"([^\"]*)\" page$")
    public void storeListOfValuesInTheColumn1WithDictionaryKey1AndColumn2WithDictionaryKey2ContainsColumn3AndColumn4InTheTableAtThePage(String colHeader1,
                                                                                                                                        String dictionaryKey1,
                                                                                                                                        String colHeader2,
                                                                                                                                        String dictionaryKey2,
                                                                                                                                        String colHeader3,
                                                                                                                                        String colValue3,
                                                                                                                                        String colHeader4,
                                                                                                                                        String colValue4,
                                                                                                                                        String tableName,
                                                                                                                                        String pageName) {
        colValue3 = parseValue(colValue3);
        colValue4 = parseValue(colValue4);
        dictionaryKey1 = parseDictionaryKey(dictionaryKey1);
        dictionaryKey2 = parseDictionaryKey(dictionaryKey2);

        int rowNumber = getObject(tableName, pageName).getMatchingRowNumber(colHeader3, colValue3, colHeader4, colValue4);
        List<String> colName1 = getObject(tableName, pageName).getTopNineSubRowValuesForGivenColumn(colHeader1, rowNumber);
        List<String> colName2 = getObject(tableName, pageName).getTopNineSubRowValuesForGivenColumn(colHeader2, rowNumber);
        ListMultimap<String, String> map = LinkedListMultimap.create();
        for (int i = 0; i < colName1.size(); i++) {
            map.put(colName1.get(i), colName2.get(i));
        }
        Set keySet = map.keySet();
        Iterator keyIterator = keySet.iterator();
        while (keyIterator.hasNext() ) {
            String key = (String) keyIterator.next();
            List values = map.get( key );
            TestContext.getInstance().testdataPut(dictionaryKey1, values);
            TestContext.getInstance().testdataPut(dictionaryKey2, values);
        }
        logStepMessage(String.format(STORED_VALUE, map.keys(), dictionaryKey1));
        logStepMessage(String.format(STORED_VALUE, map.values(), dictionaryKey2));
    }    

}
