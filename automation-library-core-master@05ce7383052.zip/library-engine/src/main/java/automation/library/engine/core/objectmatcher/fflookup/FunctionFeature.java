package automation.library.engine.core.objectmatcher.fflookup;

public class FunctionFeature {
    private String function;
    private String subFeature;

    public String getFunction() {
        return function;
    }
 
    public void setFunction(String function) {
        this.function = function;
    }
 
    public String getSubFeature() {
        return subFeature;
    }
 
    public void setSubFeature(String subFeature) {
        this.subFeature = subFeature;
    }
         
}