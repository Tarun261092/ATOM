package automation.library.engine.pdf.steps;

import automation.library.common.FileHelper;
import automation.library.common.PDFHelper;
import automation.library.common.TestContext;
import automation.library.engine.pdf.BasePDFSteps;
import automation.library.selenium.core.Constants;
import io.cucumber.java.en.When;
import io.qameta.allure.Allure;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.pdfbox.pdmodel.PDDocument;

public class AutoEngPDFUtility extends BasePDFSteps {
    @When("^the user takes a screenshot of the active pdf$")
    public void theUserTakesPDFScreenshot() throws IllegalAccessException {
        PDDocument document = getActivePDF();
        addPDFScreenshots(document);
    }
    
    
    @When("^the user adds the pdf with file path \"([^\"]*)\" to the allure report$")
	public void addPdfToAllureReportWithPath(String filePath) throws IOException {


		// Generate filePath
		filePath = parseValue(filePath);



		// Add PDF at filePath to Allure Report
		PDDocument document = PDFHelper.getDoc(filePath);
        addPDFScreenshots(document);
		if (document != null) {
			FileInputStream fileInputStream = new FileInputStream(filePath); 
			Allure.addAttachment("OutputPDF",null,fileInputStream,"pdf");
			TestContext.getInstance().testdataPut("fw.excelPath", filePath);
			TestContext.getInstance().testdataPut("fw.stepExcelPath", filePath);
			fileInputStream.close();
		} else {
			throw new IllegalArgumentException(String.format("Could not find PDF at path: %s", filePath));
		}

	}





	@When("^the user adds the latest pdf in the downloads directory to the allure report$")
	public void addLatestPdfToAllureReportFromDownloads() throws IOException {


		// Generate filePath
		String filePath = Constants.DOWNLOADPATH+"\\"+FileHelper.getLatestFilefromDir(Constants.DOWNLOADPATH)+"";


		// Add PDF at filePath to Allure Report
		PDDocument document = PDFHelper.getDoc(filePath);
        addPDFScreenshots(document);
		if (document != null) {
			FileInputStream fileInputStream = new FileInputStream(filePath); 
			Allure.addAttachment("OutputPDF",null,fileInputStream,"pdf");
			TestContext.getInstance().testdataPut("fw.excelPath", filePath);
			TestContext.getInstance().testdataPut("fw.stepExcelPath", filePath);
			fileInputStream.close();
		} else {
			throw new IllegalArgumentException(String.format("Could not find PDF at path: %s", filePath));
		}

	}

	@When("^the user adds the latest pdf in the \"([^\"]*)\" directory to the allure report$")
	public void addLatestPdfToAllureReportFromDirectory(String filePath) throws IOException {


		// Generate filePath
		filePath = parseValue(filePath);
		filePath = filePath+"\\"+FileHelper.getLatestFilefromDir(filePath);


		// Add PDF at filePath to Allure Report
		PDDocument document = PDFHelper.getDoc(filePath);
        addPDFScreenshots(document);
		if (document != null) {
			FileInputStream fileInputStream = new FileInputStream(filePath); 
			Allure.addAttachment("OutputPDF",null,fileInputStream,"pdf");

			TestContext.getInstance().testdataPut(ACTIVE_PDF, document);
			TestContext.getInstance().testdata().put(CURRENT_PAGE_PDF, -1);
		} else {
			throw new IllegalArgumentException(String.format("Could not find PDF at path: %s", filePath));
		}

	}
    
    
    
}
