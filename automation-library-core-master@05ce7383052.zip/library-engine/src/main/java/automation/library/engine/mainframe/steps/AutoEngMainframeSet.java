package automation.library.engine.mainframe.steps;

import automation.library.engine.mainframe.BaseMFSteps;
import automation.library.leanft.core.mainframe.LeanFTField;
import automation.library.leanft.core.mainframe.LeanFTTable;
import automation.library.leanft.exec.DesktopContext;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.te.Keys;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class AutoEngMainframeSet extends BaseMFSteps {

    private static final String BLANK = "BLANK";

    @When("^the user enters \"([^\"]*)\" into the \"([^\"]*)\" field on the \"([^\"]*)\" TE screen$")
    public void theUserEntersIntoTheFieldOnTheTEScreen(String value, String fieldName, String screenName) throws GeneralLeanFtException {
        DesktopContext.getInstance().setCurrentLeanFTScreen(getMainframeScreen(screenName));
        value = parseValue(value);
        fieldName = parseValue(fieldName);
        LeanFTField field = getMainframeObject(fieldName, screenName);
        field.setText(value);
        logStepMessage(String.format(ENTERED_VALUE, value));
    }

    @When("^the user enters \"([^\"]*)\" into the \"([^\"]*)\" field and presses enter on the \"([^\"]*)\" TE screen$")
    public void theUserEntersValueAndPressesEnter(String value, String fieldName, String screenName) throws GeneralLeanFtException {
        theUserEntersIntoTheFieldOnTheTEScreen(value, fieldName, screenName);
        getMainframeScreen(screenName).sendKeys(Keys.ENTER);
    }

    @Then("^the user clears the text in the \"([^\"]*)\" field on the \"([^\"]*)\" TE screen$")
    public void theUserClearsText(String fieldName, String screenName) throws GeneralLeanFtException {
        DesktopContext.getInstance().setCurrentLeanFTScreen(getMainframeScreen(screenName));
        LeanFTField field = getMainframeObject(fieldName, screenName);
        field.setText(" ");
        logStepMessage("Cleared text in the field.");
    }

    @When("^the user enters the user credential \"([^\"]*)\" into the \"([^\"]*)\" field on the \"([^\"]*)\" TE screen$")
    public void theUserEntersCredential(String value,
                                        String fieldName,
                                        String screenName) throws GeneralLeanFtException {
        DesktopContext.getInstance().setCurrentLeanFTScreen(getMainframeScreen(screenName));
        String valToEnter = parseUser(value);
        LeanFTField field = getMainframeObject(fieldName, screenName);
        field.setText(valToEnter);
    }

    @When("^the user enters the user credential \"([^\"]*)\" into the \"([^\"]*)\" field and presses enter on the \"([^\"]*)\" TE screen$")
    public void theUserEntersCredentialWithEnter(String value,
                                                 String fieldName,
                                                 String screenName) throws GeneralLeanFtException {
        theUserEntersCredential(value, fieldName, screenName);
        getMainframeScreen(screenName).sendKeys(Keys.ENTER);
    }

    @When("^the user enters the secure credential \"([^\"]*)\" into the \"([^\"]*)\" field on the \"([^\"]*)\" TE screen$")
    public void theUserEntersSecureCredential(String value,
                                              String fieldName,
                                              String screenName) throws GeneralLeanFtException {
        theUserEntersSecureTextIntoTheFieldOnTheTEScreen(value, fieldName, screenName);
    }

    @When("^the user enters the secure credential \"([^\"]*)\" into the \"([^\"]*)\" field and presses enter on the \"([^\"]*)\" TE screen$")
    public void theUserEntersSecureCredentialWithEtner(String value,
                                                       String fieldName,
                                                       String screenName) throws GeneralLeanFtException {
        theUserEntersSecureTextIntoTheFieldOnTheTEScreen(value, fieldName, screenName);
        getMainframeScreen(screenName).sendKeys(Keys.ENTER);
    }

    @Then("^the user enters secure text \"([^\"]*)\" into the \"([^\"]*)\" field on the \"([^\"]*)\" TE screen$")
    public void theUserEntersSecureTextIntoTheFieldOnTheTEScreen(String text, String fieldName, String screenName) throws GeneralLeanFtException {
        DesktopContext.getInstance().setCurrentLeanFTScreen(getMainframeScreen(screenName));
        text = parseSecureText(text);
        LeanFTField field = getMainframeObject(fieldName, screenName);
        field.setSecure(text);
    }

    @When("^the user sets cursor position at the \"([^\"]*)\" field on the \"([^\"]*)\" TE screen$")
    public void theUserSetsCursorPositionAtTheFieldOnTheTEScreen(String fieldName, String screenName) throws GeneralLeanFtException {
        DesktopContext.getInstance().setCurrentLeanFTScreen(getMainframeScreen(screenName));
        LeanFTField field = getMainframeObject(fieldName, screenName);
        field.setCursor();
    }

    @When("^the user sets cursor position at the matching cell in the \"([^\"]*)\" column where the \"([^\"]*)\" column contains \"([^\"]*)\" and \"([^\"]*)\" column contains \"([^\"]*)\" in the \"([^\"]*)\" table on the \"([^\"]*)\" TE screen$")
    public void theUserEntersIntoTheMatchingCellsAndPressEnter(String columnToRetrive,
                                                               String colToMatch1,
                                                               String valToMatch1,
                                                               String colToMatch2,
                                                               String valToMatch2,
                                                               String tableName,
                                                               String screenName) throws GeneralLeanFtException {

        DesktopContext.getInstance().setCurrentLeanFTScreen(getMainframeScreen(screenName));
        valToMatch1 = parseValue(valToMatch1);
        valToMatch2 = parseValue(valToMatch2);

        LeanFTTable table = getMainframeTable(tableName, screenName);
        table.setCursorInMatchingCell(columnToRetrive, colToMatch1, valToMatch1, colToMatch2, valToMatch2, BLANK);
    }


    @When("^the user sends keys \"([^\"]*)\" to the \"([^\"]*)\" TE screen$")
    public void theUserSendsKeysToTheTEScreen(String key, String screenName) throws GeneralLeanFtException {
        DesktopContext.getInstance().setCurrentLeanFTScreen(getMainframeScreen(screenName));
        getMainframeScreen(screenName).sendKeys(getMnemonicKey(key));
    }

    @When("^the user enters \"([^\"]*)\" on the \"([^\"]*)\" TE screen$")
    public void theUserEntersValueOnTheTEScreen(String value, String screenName) throws GeneralLeanFtException {
        DesktopContext.getInstance().setCurrentLeanFTScreen(getMainframeScreen(screenName));
        getMainframeScreen(screenName).sendKeys(parseValue(value));
    }

    @When("^the user enters \"([^\"]*)\" concatenated with \"([^\"]*)\" into the \"([^\"]*)\" field on the \"([^\"]*)\" TE screen$")
    public void theUserEntersConcatValIntoTheField(String value1,
                                                   String value2,
                                                   String fieldName,
                                                   String screenName) throws GeneralLeanFtException {
        DesktopContext.getInstance().setCurrentLeanFTScreen(getMainframeScreen(screenName));
        value1 = parseValue(value1);
        value2 = parseValue(value2);
        LeanFTField field = getMainframeObject(fieldName, screenName);
        field.setText(value1 + value2);
        logStepMessage(String.format(ENTERED_VALUE, value1 + value2));
    }

    @When("^the user enters \"([^\"]*)\" into the first blank row of the \"([^\"]*)\" column in the \"([^\"]*)\" table on the \"([^\"]*)\" TE screen$")
    public void theUserEntersIntoTheFirstBlankRow(String valToEnter,
                                                  String columnName,
                                                  String tableName,
                                                  String screenName) throws GeneralLeanFtException {
        DesktopContext.getInstance().setCurrentLeanFTScreen(getMainframeScreen(screenName));
        valToEnter = parseValue(valToEnter);

        LeanFTTable table = getMainframeTable(tableName, screenName);
        table.enterInFirstBlankRow(valToEnter, columnName);
    }

    @When("^the user enters \"([^\"]*)\" into the matching cell in the \"([^\"]*)\" column where the \"([^\"]*)\" column contains \"([^\"]*)\" in the \"([^\"]*)\" table((?: | and presses enter )?)on the \"([^\"]*)\" TE screen$")
    public void theUserEntersIntoTheMatchingCellAndPressEnter(String valToEnter,
                                                              String columnName,
                                                              String keyColumnName,
                                                              String valToMatch,
                                                              String tableName,
                                                              String option,
                                                              String screenName) throws GeneralLeanFtException {

        theUserEntersIntoTheMatchingCellContainsValueAndPressEnter(valToEnter,
                                                                   columnName,
                                                                   BLANK,
                                                                   keyColumnName,
                                                                   valToMatch,
                                                                   tableName,
                                                                   option,
                                                                   screenName);
    }

    @When("^the user enters \"([^\"]*)\" into the matching cell in the \"([^\"]*)\" column which contains \"([^\"]*)\" where the \"([^\"]*)\" column contains \"([^\"]*)\" in the \"([^\"]*)\" table((?: | and presses enter )?)on the \"([^\"]*)\" TE screen$")
    public void theUserEntersIntoTheMatchingCellContainsValueAndPressEnter(String valToEnter,
                                                                           String columnName,
                                                                           String columnValue,
                                                                           String keyColumnName,
                                                                           String valToMatch,
                                                                           String tableName,
                                                                           String option,
                                                                           String screenName) throws GeneralLeanFtException {
        DesktopContext.getInstance().setCurrentLeanFTScreen(getMainframeScreen(screenName));
        valToEnter = parseValue(valToEnter);
        valToMatch = parseValue(valToMatch);

        LeanFTTable table = getMainframeTable(tableName, screenName);
        // passing columnValue through TS
        table.enterTextInMatchingCell(valToEnter, columnName, keyColumnName, valToMatch, columnValue);
        if (option.contains("presses enter"))getMainframeScreen(screenName).sendKeys(Keys.ENTER);
    }

    @When("^the user enters \"([^\"]*)\" into the matching cell in \"([^\"]*)\" column((?: | and presses enter )?)where \"([^\"]*)\" column contains \"([^\"]*)\" and \"([^\"]*)\" column contains \"([^\"]*)\" and \"([^\"]*)\" column contains \"([^\"]*)\" and \"([^\"]*)\" column contains \"([^\"]*)\" in the \"([^\"]*)\" table on the \"([^\"]*)\" TE screen$")
    public void theUserEntersIntoTheMatchingCellAndPressEnter(String valToEnter,
                                                              String columnName,
                                                              String option,
                                                              String colNameToFind1,
                                                              String expectedVal1,
                                                              String colNameToFind2,
                                                              String expectedVal2,
                                                              String colNameToFind3,
                                                              String expectedVal3,
                                                              String keyColName,
                                                              String keyColVal,
                                                              String tableName,
                                                              String screenName) throws GeneralLeanFtException {
        DesktopContext.getInstance().setCurrentLeanFTScreen(getMainframeScreen(screenName));
        String expectedValue = String.join(LIST_DELIMITER, parseValue(expectedVal1), parseValue(expectedVal2), parseValue(expectedVal3));

        LeanFTTable table = getMainframeTable(tableName, screenName);
        String actualValue = table.checkForMatchInTable(keyColName, parseValue(keyColVal),
                                                        colNameToFind1, parseValue(expectedVal1),
                                                        colNameToFind2, parseValue(expectedVal2),
                                                        colNameToFind3, parseValue(expectedVal3));
        if (actualValue.equals(expectedValue)) {
            table.enterTextInMatchingCell(valToEnter, columnName, keyColName, parseValue(keyColVal), BLANK);
            if (option.contains("presses enter"))getMainframeScreen(screenName).sendKeys(Keys.ENTER);
        }

    }

    @When("^the user sets cursor position at the matching cell in the \"([^\"]*)\" column where the \"([^\"]*)\" column contains \"([^\"]*)\" in the \"([^\"]*)\" table on the \"([^\"]*)\" TE screen$")
    public void theUserEntersIntoTheMatchingCellAndPressEnter(String columnToRetrive,
                                                              String colToMatch,
                                                              String valToMatch,
                                                              String tableName,
                                                              String screenName) throws GeneralLeanFtException {

        DesktopContext.getInstance().setCurrentLeanFTScreen(getMainframeScreen(screenName));
        valToMatch = parseValue(valToMatch);

        LeanFTTable table = getMainframeTable(tableName, screenName);
        table.setCursorInMatchingCell(columnToRetrive, colToMatch, valToMatch, BLANK);
    }

}
