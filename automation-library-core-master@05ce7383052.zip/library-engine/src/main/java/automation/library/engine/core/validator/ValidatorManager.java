package automation.library.engine.core.validator;

public abstract class ValidatorManager {

    protected abstract void assertEquals(Object actual, Object expected, String assertMsg);

    protected abstract void assertEqualsIgnoreCase(Object actual, Object expected, String assertMsg);

    protected abstract void assertNotEquals(Object actual, Object expected, String assertMsg);

    protected abstract void assertLessThan(Object actual, Object expected, String assertMsg);

    protected abstract void assertLessThanOrEqual(Object actual, Object expected, String assertMsg);

    protected abstract void assertGreaterThan(Object actual, Object expected, String assertMsg);

    protected abstract void assertGreaterThanOrEqual(Object actual, Object expected, String assertMsg);

    protected abstract void assertContains(Object actual, Object expected, String assertMsg);

    protected abstract void assertDoesNotContain(Object actual, Object expected, String assertMsg);
}
