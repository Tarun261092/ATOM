package automation.library.engine.core.steps;
 
import automation.library.api.test.utils.ReadExcel;
import automation.library.common.ExcelHelper;
import automation.library.common.FileHelper;
import automation.library.common.JSONHelper;
import automation.library.common.TestContext;
import automation.library.common.ZipHelper;
import automation.library.engine.api.steps.*;
import automation.library.engine.core.BaseStepsEngine;
import automation.library.engine.core.runner.FDRDataConditionWriter;
import automation.library.engine.db.steps.*;
import automation.library.leanft.exec.DesktopContext;
import automation.library.reporting.Reporter;
import automation.library.selenium.core.Constants;
import automation.library.selenium.exec.driver.factory.DriverContext;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonSyntaxException;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.ReadContext;
import cucumber.api.PendingException;
import io.cucumber.java.en.When;

import java.io.*;
import java.text.NumberFormat;
import java.text.ParseException;
import java.time.format.DateTimeParseException;
import java.util.*;

import static automation.library.common.DataTableFormatter.getFilteredDataTableAsMap;
import static automation.library.cucumber.core.Constants.*;
import static org.junit.Assert.assertThat;
import static org.assertj.core.api.Assertions.assertThat;

public class AutoEngUtility extends BaseStepsEngine {
    @When("^flag test data as \"([^\"]*)\"$")
    public void flagTestDataAs(String testDataReusableFlag) {
        //TO-DO: implement based on final TDM solution
    }

    @When("^add log \"([^\"]*)\" \"([^\"]*)\"$")
    public void addLog(String logType, String logMessage) {
        switch (logType.toUpperCase()) {
            case "INFO":
                log.info(logMessage);
                break;
            case "WARNING":
                log.warn(logMessage);
                break;
            case "ERROR":
                log.error(logMessage);
                break;
            default:
                log.warn("Expected log type not found: {}. Options are INFO | WARNING | ERROR", logType);
        }
    }

    @When("^format data dictionary value at key \"([^\"]*)\" as \"([^\"]*)\"$")
    public void formatDataDictionaryValueAtKeyAs(String dictionaryKey,
                                                 String formatType) throws ParseException {
        formatDataDictionaryValueAtKeyToNewKey(dictionaryKey, formatType, dictionaryKey);
    }

    @When("^format data dictionary epoch date value at key \"([^\"]*)\" as \"([^\"]*)\" and store in new key \"([^\"]*)\"$")
    public void formatDataDictionaryValueAtKeyFromEpochAs(String oldDictionaryKey,
												            String formatType,
												            String newDictionaryKey) throws ParseException {
    	oldDictionaryKey = parseDictionaryKey(oldDictionaryKey);
        newDictionaryKey = parseDictionaryKey(newDictionaryKey);

        Object originalValue = TestContext.getInstance().testdataGet(oldDictionaryKey);
        if (originalValue != null) {
            String formattedValue = convertEpoch(originalValue.toString(), formatType);
            TestContext.getInstance().testdata().put(newDictionaryKey, formattedValue);
            logStepMessage(String.format("Formatted %s to new value of %s", originalValue, formattedValue));
        } else {
            log.warn("Did not find value at key: {}. Skipping format.", oldDictionaryKey);
        }
    }
    
    @When("^format data dictionary date value at key \"([^\"]*)\" in \"([^\"]*)\" as epoch date and store in new key \"([^\"]*)\"$")
    public void formatDataDictionaryValueAtKeyFromLocalAs(String oldDictionaryKey, String unit,
												            String newDictionaryKey) throws ParseException {
    	try {
    	oldDictionaryKey = parseDictionaryKey(oldDictionaryKey);
        newDictionaryKey = parseDictionaryKey(newDictionaryKey);

        Object originalValue = TestContext.getInstance().testdataGet(oldDictionaryKey);
        if (originalValue != null) {
        	String convertedValue = convertLocal(originalValue.toString(), unit);
            TestContext.getInstance().testdata().put(newDictionaryKey, convertedValue);
            logStepMessage(String.format("Formatted %s to new value of %s", originalValue, convertedValue));
        } else {
            log.warn("Did not find value at key: {}. Skipping format.", oldDictionaryKey);
        }} catch (DateTimeParseException e) {log.warn("Format should be YYYY-MM-DDTHH:mm:ss");}
    }
    
    @When("^the user stores random UUID into data dictionary key \"([^\"]*)\"$")
    public void theUserStoresRandomUUID(String dictionaryKey) {
        String uuid = UUID.randomUUID().toString().replace("-","");
        if (uuid != null) {
            TestContext.getInstance().testdataPut(parseDictionaryKey(dictionaryKey), uuid);
            logStepMessage(String.format("Saved UUID: %s", uuid));
        } else {
            logStepMessage("Unable to generate UUID.");
        }
    }

    @When("^format data dictionary value at key \"([^\"]*)\" as \"([^\"]*)\" and store in new key \"([^\"]*)\"$")
    public void formatDataDictionaryValueAtKeyToNewKey(String oldDictionaryKey,
                                                       String formatType,
                                                       String newDictionaryKey) throws ParseException {
        oldDictionaryKey = parseDictionaryKey(oldDictionaryKey);
        newDictionaryKey = parseDictionaryKey(newDictionaryKey);

        Object originalValue = TestContext.getInstance().testdataGet(oldDictionaryKey);
        if (originalValue != null) {
            String formattedValue = format(originalValue.toString(), formatType);
            TestContext.getInstance().testdata().put(newDictionaryKey, formattedValue);
            logStepMessage(String.format("Formatted %s to new value of %s", originalValue, formattedValue));
        } else {
            log.warn("Did not find value at key: {}. Skipping format.", oldDictionaryKey);
        }
    }

    @When("^split data dictionary value at key \"([^\"]*)\" with \"([^\"]*)\"$")
    public void splitDataDictionaryValueAtKeyWith(String dictionaryKey,
                                                  String delimiter) {
        dictionaryKey = parseDictionaryKey(dictionaryKey);
        final List<String> resultSet = Arrays.asList(split(String.valueOf(TestContext.getInstance().testdataGet(dictionaryKey)),
                                                           delimiter));

        if (!resultSet.isEmpty()) {
            TestContext.getInstance().testdataPut(dictionaryKey, resultSet.get(0));
            logStepMessage(String.format("Split by delimiter %s with result: %s", delimiter, resultSet.get(0)));
        }
    }

    @When("^split data dictionary value at key \"([^\"]*)\" with \"([^\"]*)\" and store full array to same key$")
    public void splitDataDictionaryValueAtKeyFullArray(String dictionaryKey,
                                                       String delimiter) {
        dictionaryKey = parseDictionaryKey(dictionaryKey);
        final List<String> resultSet = Arrays.asList(split(String.valueOf(TestContext.getInstance().testdataGet(dictionaryKey)),
                                                           delimiter));
        TestContext.getInstance().testdataPut(dictionaryKey, resultSet);
        logStepMessage(String.format("Split by delimiter %s with result: %s", delimiter, resultSet));
    }


    @When("^the user finds the latest \"([^\"]*)\" file from the default download directory and stores to data dictionary key \"([^\"]*)\"$")
    public void theUserFindsLastDownloadedFile(String extension,
                                               String dictionaryKey) {
        dictionaryKey = parseDictionaryKey(dictionaryKey);
        String pathToFile = FileHelper.findMostRecentFileByExtension(Constants.DOWNLOADPATH, extension);

        TestContext.getInstance().testdataPut(dictionaryKey, pathToFile);
        logStepMessage(String.format(STORED_VALUE, dictionaryKey, pathToFile));
    }

    @When("^load data from JSON file \"([^\"]*)\" into the data dictionary$")
    public void loadToDataDictionary(String fileName) throws IOException {
        String pathToDataJson = FileHelper.findFileInPath(TESTDATAPATH,
                                                          fileName + JSON);

        if (pathToDataJson != null) {
            Map<String, String> dataCriteria;
            Object jsonObject = JSONHelper.getDataPOJO(pathToDataJson, Object.class);

            if (jsonObject instanceof ArrayList) {
                log.info("Found array in JSON. Reading first array element only");
                dataCriteria = (Map) ((List) jsonObject).get(0);
            } else {
                dataCriteria = (Map) jsonObject;
            }

            dataCriteria.forEach((dataItem, val) -> TestContext.getInstance().testdataPut(dataItem, val));
        } else {
            log.warn("Did not find JSON file to load: {}", fileName);
        }
    }

    @When("^the user extracts value at index \"([^\"]*)\" from the JSON array at dictionary key \"([^\"]*)\" and stores into dictionary key \"([^\"]*)\"$")
    public void theUserExtractsValue(String index, String dictionaryKey, String newDictionaryKey) {
        List<String> listAtKey = getListFromDictionary(dictionaryKey);

        if (!listAtKey.isEmpty()) {
            final String valToStore = listAtKey.get(Integer.parseInt(parseValue(index)));
            newDictionaryKey = parseDictionaryKey(newDictionaryKey);
            TestContext.getInstance().testdataPut(newDictionaryKey, valToStore);
            logStepMessage(String.format(STORED_VALUE, valToStore, newDictionaryKey));
        }
    }

    @When("^the user extracts index from the JSON array at dictionary key \"([^\"]*)\" where value matches \"([^\"]*)\" and stores into dictionary key \"([^\"]*)\"$")
    public void theUserExtractsIndex(String dictionaryKey, String valToMatch, String newDictionaryKey) {
        List<String> listAtKey = getListFromDictionary(dictionaryKey);

        if (!listAtKey.isEmpty()) {
            int matchingIndex = listAtKey.indexOf(parseValue(valToMatch));

            if(matchingIndex != -1) {
                newDictionaryKey = parseDictionaryKey(newDictionaryKey);
                TestContext.getInstance().testdataPut(newDictionaryKey, matchingIndex);
                logStepMessage(String.format(STORED_VALUE, matchingIndex, newDictionaryKey));
            } else {
                logStepMessage(String.format("Did not find matching index for value: %s", valToMatch));
            }
        }
    }

    @When("^the user completes the rest of the test manually$")
    public void theUserFinishesTheTestManually() {
        DriverContext.getInstance().setKeepBrowserOpen(true);
        DesktopContext.getInstance().setKeepTEOpen(true);
        throw new PendingException("Complete rest of the test manually");
    }

    @When("^the user perform mathematical operation \"([^\"]*)\" on the value 1 \"([^\"]*)\" and value 2 \"([^\"]*)\" and store result into dictionary key \"([^\"]*)\"$")
    public void theUserPerformsMathematicalOperation(String operationPerf,
                                                     String value1,
                                                     String value2,
                                                     String dictonaryKey) {
        double calValue = 0.00;
        String calValueAsString = "";
        dictonaryKey = parseDictionaryKey(dictonaryKey);
        value1 = parseValue(value1);
        value2 = parseValue(value2);
        boolean isCalValueString = false;

        switch (operationPerf.toUpperCase()) {
            case "ADDITION":
                calValue = Double.parseDouble(value1) + Double.parseDouble(value2);
                break;
            case "SUBTRACTION":
                calValue = Double.parseDouble(value1) - Double.parseDouble(value2);
                break;
            case "DIVISION":
                calValue = Double.parseDouble(value1) / Double.parseDouble(value2);
                break;
            case "MULTIPLICATION":
                calValue = Double.parseDouble(value1) * Double.parseDouble(value2);
                break;
            case "POWER":
                calValue = Math.pow(Double.parseDouble(value1), Double.parseDouble(value2));
                break;
            case "PERCENTAGE":
                NumberFormat numberFormat = NumberFormat.getPercentInstance();
                numberFormat.setMaximumFractionDigits(2);
                calValueAsString = numberFormat.format(Double.parseDouble(value1) / Double.parseDouble(value2));
                isCalValueString = true;
                break;
            default:
                log.warn("Operation performed condition not found: {}. Options are ADDITION | SUBTRACTION | DIVISION | MULTIPLICATION | POWER | PERCENTAGE",
                         operationPerf);
        }
        if (!isCalValueString) {
            TestContext.getInstance().testdata().put(dictonaryKey, String.valueOf(calValue));
            logStepMessage(String.format("Result of mathematical operation %s is %s", operationPerf, calValue));
        } else {
            TestContext.getInstance().testdata().put(dictonaryKey, calValueAsString);
            logStepMessage(String.format("Result of mathematical operation %s is %s", operationPerf, calValueAsString));
        }
    }

    @When("generate data input files from the \"([^\"]*)\" tab in the conditioning sheet \"([^\"]*)\"")
    public void generateDataConditions(String tabName, String fileName) throws IOException {
        tabName = parseValue(tabName);
        fileName = parseValue(fileName);

        String pathToInputSheet = FileHelper.findFileInPath(TESTDATAPATH, fileName);
        List<Map<String, Object>> conditioningInputs = ExcelHelper.getExcelDataAsMapWithoutIndex(pathToInputSheet,
                                                                                                 tabName);
        new FDRDataConditionWriter().generateJSONFromDataConditions(conditioningInputs);
    }

    @When("^the user updates cell value with \"([^\"]*)\" at row number \"([^\"]*)\" for column Name \"([^\"]*)\" in the sheet \"([^\"]*)\" for the excel \"([^\"]*)\"$")
    public void theUserUpdatesCellValueWithRowNumberForColumnNameInTheSheet(String attributeName,
                                                                            String rowNumber,
                                                                            String columnName,
                                                                            String sheetName,
                                                                            String fileName) throws IOException {

        try {
            rowNumber = parseValue(rowNumber);
            columnName = parseValue(columnName);
            sheetName = parseValue(sheetName);
            fileName = parseValue(fileName);
            attributeName = parseValue(attributeName);
            ReadExcel.setCellValue(Integer.parseInt(rowNumber), ReadExcel.getPathToExcel(fileName), sheetName, columnName, attributeName);
        } catch (Exception e) {
            log.warn(e.getMessage());
        }
    }

    @When("^update dataSpec of scenario \"([^\"]*)\" with data dictionary keys$")
    public void updateDataspecOfScenarioWithDatadictionaryKeys(String fileName) {
        ReadContext jsonFile = null;
        LinkedHashMap<String, LinkedHashMap<String, HashMap<String, Object>>> staticDataResultList = new LinkedHashMap<>();
        String pathToDataJson = FileHelper.findFileInPath(TESTDATAPATH,
                                                          parseValue(fileName) + JSON);
        if (pathToDataJson != null) {
            try {
                jsonFile = JsonPath.parse(new FileInputStream(new File(pathToDataJson)));
            } catch (FileNotFoundException | JsonSyntaxException e) {
                log.error(e.getMessage(), e);
            }
            if (jsonFile != null) staticDataResultList = jsonFile.read("$");
            HashMap<String, Object> staticdata = staticDataResultList.get("TDaaS").get("staticData");
            staticdata.putAll(getFilteredDataTableAsMap());

            try (FileWriter jsonWriter = new FileWriter(pathToDataJson)) {
                new GsonBuilder().setPrettyPrinting()
                                 .setLenient()
                                 .create()
                                 .toJson(staticDataResultList.get("TDaaS").put("staticData", staticdata), jsonWriter);

            } catch (IOException e) {
                log.error(e.getMessage());
            }
        }
    }

    @When("^the user writes the value \"([^\"]*)\" for dictionary key \"([^\"]*)\" in json \"([^\"]*)\"$")
    public void writesTheValueForDictionaryKeyInJSON(String value, String dictionaryKey, String fileName) throws IOException {
        String pathToDataJson = FileHelper.findFileInPath(TESTDATAPATH,
                                                          fileName + JSON);
        ReadContext jsonFile = null;
        value = parseValue(value);

        if (pathToDataJson != null) {
            jsonFile = JsonPath.parse(new FileInputStream(new File(pathToDataJson)));
            ArrayList<Map<String, String>> valueMap = jsonFile.read("$");

            if (valueMap.get(0).containsKey(dictionaryKey)) {

                int keyCount = (int) valueMap.get(0).keySet().stream().filter(entry -> entry.startsWith(dictionaryKey)).count();

                for (int i = 1; i <= keyCount; i++) {
                    if (!valueMap.get(0).containsKey(dictionaryKey.concat(String.valueOf(i)))) {
                        valueMap.get(0).put(dictionaryKey.concat(String.valueOf(i)), valueMap.get(0).get(dictionaryKey));
                        valueMap.get(0).replace(dictionaryKey, value);
                    }
                }

            } else {
                valueMap.get(0).put(dictionaryKey, value);
            }

            try (FileWriter jsonWriter = new FileWriter(pathToDataJson)) {
                new GsonBuilder().setPrettyPrinting()
                                 .setLenient()
                                 .create()
                                 .toJson(valueMap, jsonWriter);
            } catch (IOException e) {
                log.error(e);
            }
            TestContext.getInstance().testdataPut(dictionaryKey, value);
        } else {
            log.warn("Did not find JSON file: {}", fileName);
        }
    }

    @When("^the user mask the value at key \"([^\"]*)\" as per \"([^\"]*)\" rule and store with new key \"([^\"]*)\"$")
    public void maskValueAndStoreIntoDataDictionary(String dictionayKey, String rule, String newDictionaryKey) {
        String fullEmail = parseValue(dictionayKey);
        newDictionaryKey = parseDictionaryKey(newDictionaryKey);
        String[] emailparts = fullEmail.split("@");
        if (rule.equalsIgnoreCase("OlympusEmailMasking")) {
            if (emailparts[0].split("").length == 1) {
                TestContext.getInstance().testdataPut(newDictionaryKey, fullEmail);
            } else if (emailparts[0].split("").length == 2 || emailparts[0].split("").length == 3) {
                String maskedEmail = fullEmail.replaceAll("(?<=.{1}).(?=.*@)", "*");
                TestContext.getInstance().testdataPut(newDictionaryKey, maskedEmail);
            } else if (emailparts[0].split("").length > 3) {
                String maskedEmail = fullEmail.replaceAll("(?<=.{1}).(?=.*.@)", "*");
                TestContext.getInstance().testdataPut(newDictionaryKey, maskedEmail);
            }
        }
    }

    @When("^the user updates the \"([^\"]*)\" position in the string at key \"([^\"]*)\" to \"([^\"]*)\"$")
    public void updatePositionInString(String position, String dictionayKey, String newValue) {
        dictionayKey = parseDictionaryKey(dictionayKey);
        StringBuilder fullString = new StringBuilder(String.valueOf(TestContext.getInstance().testdataGet(dictionayKey)));

        if (fullString.length() > 0) {
            switch (parseValue(position).toLowerCase()) {
                case "last":
                    fullString.setCharAt(fullString.length() - 1, newValue.charAt(0));
                    break;
                case "first":
                    fullString.setCharAt(0, newValue.charAt(0));
                    break;
                default:
                    int positionAsInt = Integer.parseInt(position);
                    if (positionAsInt > 0) {
                        fullString.setCharAt(positionAsInt - 1, newValue.charAt(0));
                    }
                    break;
            }

            TestContext.getInstance().testdataPut(dictionayKey, fullString);
            logStepMessage("Set value at key to :" + fullString);
        }

    }

    @When("^store value of the matching cell in the column \"([^\"]*)\" where column \"([^\"]*)\" contains value \"([^\"]*)\" and column \"([^\"]*)\" contains value \"([^\"]*)\" and column \"([^\"]*)\" contains value \"([^\"]*)\"in the sheet \"([^\"]*)\" for the excel \"([^\"]*)\" into the data dictionary with key \"([^\"]*)\"$")
    public void storeValueOfMatchingColumnInTheColumnWhereColumnHeader1IsColumnHeader2IsColumnHeader3IsAndRowNumberIsInTheSheetForTheExcelIntoTheDataDictionaryKey(
            String columnName,
            String columnHeader1,
            String columnValue1,
            String columnHeader2,
            String columnValue2,
            String columnHeader3,
            String columnValue3,
            String sheetName,
            String fileName,
            String dictionaryKey) throws IOException {
        int rowNumber=-1;
        String valToStore="";
        try {
            columnHeader1=parseValue(columnHeader1);
            columnValue1 = parseValue(columnValue1);
            columnHeader2=parseValue(columnHeader2);
            columnValue2 = parseValue(columnValue2);
            columnHeader3=parseValue(columnHeader3);
            columnValue3 = parseValue(columnValue3);
            columnName = parseValue(columnName);
            sheetName = parseValue(sheetName);
            fileName = parseValue(fileName);
            dictionaryKey = parseValue(dictionaryKey);
            rowNumber=ReadExcel.getRowNumber(columnHeader1,columnValue1, columnHeader2,columnValue2, columnHeader3,columnValue3,ReadExcel.getPathToExcel(fileName), sheetName);
            valToStore=ReadExcel.getCellValue(rowNumber, ReadExcel.getPathToExcel(fileName), sheetName, columnName);
            TestContext.getInstance().testdataPut(dictionaryKey, valToStore);
            logStepMessage(String.format(STORED_VALUE, valToStore, dictionaryKey));

        } catch (Exception e) {
            log.warn(e.getMessage());
        }
    }
    
    /* Writes Data to the excel when the excel download to the local machine which has multiple instances*/
    @When("^the user writes cell value with \"([^\"]*)\" at row number \"([^\"]*)\" for column Name \"([^\"]*)\" in the sheet \"([^\"]*)\" for the partialFileName \"([^\"]*)\" in excel path \"([^\"]*)\"$")
    public void theUserWritesCellValueWithRowNumberForColumnNameInTheSheet(String valueToBeEntered,
                                                                            String rowNumber,
                                                                            String columnName,
                                                                            String sheetName,
                                                                            String partialFileName, 
                                                                            String path) throws IOException {
    	String result="";
        try {
            rowNumber = parseValue(rowNumber);
            columnName = parseValue(columnName);
            sheetName = parseValue(sheetName);
            partialFileName = parseValue(partialFileName);
            path = parseValue(path);
            valueToBeEntered = parseValue(valueToBeEntered);
            String newFileName = FileHelper.getLatestFileWithNamefromDir(path, partialFileName);
            if(newFileName==null) {
           	 Reporter.addStepLog("FAIL", "Input excel sheet Not Found");
           	 assertThat("Not Found").isEqualTo("Input Excel");
            }
            else {
            	result = ExcelHelper.enterCellValue(Integer.parseInt(rowNumber), path+newFileName, sheetName, columnName, valueToBeEntered);
            	if(!result.equalsIgnoreCase("1"))
            		log.error(result);
            }
        } catch (Exception e) {
            log.warn(e.getMessage());
        }
    }
    
    /* Selects Drop down values in Excel  when the excel download to the local machine which has multiple instances*/
    @When("^the user selects cell value with \"([^\"]*)\" at row number \"([^\"]*)\" for column Name \"([^\"]*)\" in the sheet \"([^\"]*)\" for the partialFileName \"([^\"]*)\" in excel path \"([^\"]*)\"$")
    public void theUserSelectsCellValueWithRowNumberForColumnNameInTheSheet(String valueToBeSelected,
                                                                            String rowNumber,
                                                                            String columnName,
                                                                            String sheetName,
                                                                            String partialFileName, 
                                                                            String path) throws IOException {
    	String result="";
        try {
            rowNumber = parseValue(rowNumber);
            columnName = parseValue(columnName);
            sheetName = parseValue(sheetName);
            partialFileName = parseValue(partialFileName);
            path = parseValue(path);
            valueToBeSelected = parseValue(valueToBeSelected);
            String newFileName = FileHelper.getLatestFileWithNamefromDir(path, partialFileName);
            if(newFileName==null) {
           	 Reporter.addStepLog("FAIL", "Input excel sheet Not Found");
           	 assertThat("Not Found").isEqualTo("Input Excel");
            }
            else {
            	result = ExcelHelper.selectCellValue(Integer.parseInt(rowNumber), path+newFileName, sheetName, columnName, valueToBeSelected);
            	if(!result.equalsIgnoreCase("1"))
            		log.error(result);
            }
        } catch (Exception e) {
            log.warn(e.getMessage());
        }
    }
    
    @When("^the user opens \"([^\"]*)\" DB connections and executes the \"([^\"]*)\" query for \"([^\"]*)\" times until \"([^\"]*)\" is equal to \"([^\"]*)\" in \"([^\"]*)\" API response to fetch valid \"([^\"]*)\"$")
	public void fetchTestDataAccount(String appName, String sqlQuery, String maxCount, String attributeName, String expectedValue, String apiName, String accountNumber) {

		boolean statusCheck = true;
		int counter = 0;
		//TestContext.getInstance().testdataPut("dummyAccount", "0");
		try {
			AutoEngDBConnect autoEngDBConnect = new AutoEngDBConnect();
			autoEngDBConnect.connectToDatabase(appName);

			do {
				counter++;
				
				AutoEngDBCall autoEngDBCall = new AutoEngDBCall();
				try {
					autoEngDBCall.theUserExecutesTheQuery(sqlQuery);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				AutoEngDBStoreValue autoEngDBStoreValue = new AutoEngDBStoreValue();
				autoEngDBStoreValue.theUserStoresFromtheQueryResultIntoTheDataDictionaryWithKey("ACT_NO", accountNumber);
			
				AutoEngValidate autoEngValidate = new AutoEngValidate();
				autoEngValidate.theUserValidatesThatTheDataDictionaryValueOf("Compare_Strings", accountNumber, "Not Equal To", "null", "statusCheckValidation", "HardStopOnFailure");
				autoEngValidate.theUserValidatesThatTheDataDictionaryValueOf("Compare_Numbers", accountNumber, "Greater Than", "0", "statusCheckValidation", "HardStopOnFailure");
				
				AutoEngAPICall autoEngAPICall = new AutoEngAPICall();
				autoEngAPICall.theUserSendsRequestToTheAPI(apiName);
				
				AutoEngAPIStoreValue autoEngAPIStoreValue = new AutoEngAPIStoreValue();
				autoEngAPIStoreValue.theUserStoresFromAPIResponseIntoTheDataDictionaryWithKey(attributeName,
						"actualValue");
				
				String actualValue = TestContext.getInstance().testdataGet("actualValue").toString();

				if (actualValue.equalsIgnoreCase(expectedValue)) {
					statusCheck = false;
				}
				
				if (counter == Integer.parseInt(maxCount)) {
					autoEngValidate.theUserValidatesThatTheDataDictionaryValueOf("Compare_Strings", accountNumber, "Equal To", "Max count reached", "statusCheckValidation", "HardStopOnFailure");
				}
				
			} while (statusCheck);
			
			autoEngDBConnect.closeDBConnection(appName);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
    
/*Un-zip a file from source location and save it in specific location*/
    
    @When("^the user unzip file to downloads location$")
    public void theuserunzipfilefromsrclctiontodestinationlocation() {
    
    	try {
    		
    		String srcepath= FileHelper.findMostRecentFileByExtension(DOWNLOADS, "zip"); 
    		System.out.println("The scre path is" +srcepath);
    		ZipHelper.unzipit(srcepath, DOWNLOADS);
    				}
    	catch (Exception e) {
            log.warn(e.getMessage());
    	}
    	
    }
    
    /*Copy specific File from one directory to another*/
    
    @When("^the user copy file \"([^\"]*)\" to testData location$")
    		public void theusercopyfilefromsourcetotargetfolder(String fileName) {
    	
    	FileHelper.copyFileFromOneLocationToAnother(fileName,DOWNLOADS,TESTDATAPATH);
    }
    
    /*Copy Entire String to a text file*/
    
    @When("^the user copy string \"([^\"]*)\" to text file \"([^\"]*)\"$")
    public void theusercopystringtotxtfile(String text,String file) {
 	   text=parseValue(text);
 	   file=parseValue(file);
 	   File existingFile = new File(file);

 	   if (existingFile.exists() && existingFile.isFile()) {
 	       existingFile.delete();
 	     }

 	   BufferedWriter writer = null;
 	   try
 	   {
 	       writer = new BufferedWriter( new FileWriter( file));
 	       writer.write( text);

 	   }
 	   catch ( IOException e)
 	   {
 	   }
 	   finally
 	   {
 	       try
 	       {
 	           if ( writer != null)
 	           writer.close( );
 	       }
 	       catch ( IOException e)
 	       {
 	       }
 	   }
    } 

	@When("^the user iterates the JSON data \"([^\"]*)\" in the \"([^\"]*)\" JSON file \"([^\"]*)\" using delimiter \"([^\"]*)\"$")
	public void iterateDummyDataInJsonFileWithDelimiter(String jsonDataKey, String fileName, String iterateType, String delimiter) {

		//log.info("Beginning Test");

		//
		// Check if file is full filepath or single filename
		//

		fileName = parseValue(fileName);
		jsonDataKey = parseValue(jsonDataKey);

		File jsonFile = new File("");
		if (fileName.contains("\\") || fileName.contains("/")){
			jsonFile = new File(fileName);
		} else {
			jsonFile = new File(System.getProperty("user.dir") + "\\src\\test\\resources\\features\\" + fileName + ".json");
			if (!jsonFile.exists()) {

				String[] directories = (new File(System.getProperty("user.dir") + "\\src\\test\\resources\\features")).list(new FilenameFilter() {
					@Override
					public boolean accept(File current, String name) {
						return new File(current, name).isDirectory();
					}
				});
				boolean foundFile = false;

				for (int i = 0; i < directories.length && foundFile == false; i++) {
					jsonFile = new File(System.getProperty("user.dir") + "\\src\\test\\resources\\features\\" + directories[i] + "\\" + fileName + ".json");
					if (jsonFile.exists()) {
						foundFile = true;
					}
				}

				if (!jsonFile.exists()) {
					jsonFile = new File(System.getProperty("user.dir") + "\\src\\test\\resources\\testdata\\" + fileName + ".json");
					if (!jsonFile.exists()) {
						log.info("JSON File was not able to be located.  Please provide a full file path or place the JSON in the same foler as the feature file.  Current directory is: " + System.getProperty("user.dir"));
						return;
					}
				}
			}
		}
		//Prepare Json Data 
		ArrayList<String> jsonData =  new ArrayList<String>();


		// Check if File exists at all.


		// Read all data from the file.
		try (FileReader reader = new FileReader(jsonFile); BufferedReader bReader = new BufferedReader(reader);){
			String line;
			while ((line = bReader.readLine()) != null){
				//log.info("Reading Line: " + line);
				jsonData.add(line);
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		}




		// Find data and replace it 
		for (int i=0; i < jsonData.size(); i++) {
			String line = jsonData.get(i);
			if (line.split(":").length > 1 && line.split(":")[0].replace("\"", "").trim().equals(jsonDataKey)) {

				String hasComma = "";
				if(line.contains(",")) {
					hasComma = ",";
				}

				log.info("Discovered Line: " + line);
				String dataKey = line.split(":",2)[0];
				line = line.split(":",2)[1];
				line = line.replace("\"", "").replace(",", "");

				if (line.contains(delimiter)) {
					String storedValue = line.split(delimiter,2)[0];
					String iterator = line.split(delimiter,2)[1];
					String newIterator = "";


					if (iterateType.equals("numerically")) {
						newIterator = Integer.toString(Integer.parseInt(iterator) + 1).trim();
					}


					else if (iterateType.equals("alphabetically")) {

						boolean iterateNext = true;
						for (int j = iterator.length()-1; j >= 0; j--) {
							if (iterateNext) {
								iterateNext = false;
								newIterator = iterateChar(iterator.charAt(j)) + newIterator;
								if (iterator.charAt(j) == 'Z') {
									iterateNext = true;
								}
							} else {
								newIterator = iterator.charAt(j) + newIterator;
							}
						}

						if (iterator.replace("Z", "").equals("")) {
							newIterator = "a" + newIterator;
						}
					}  else {
						log.info("Iterator Type unknown:  Please use \"alphabetically\" or \"numerically\" as type");
						return;
					}

					String finalLine = dataKey + ":\"" + storedValue + delimiter + newIterator + "\"" + hasComma;
					log.info("Final Line Generated: " + finalLine);
					jsonData.set(i, finalLine);
				} else {
					String finalLine = "";
					if (iterateType.equals("numerically")) {
						finalLine = dataKey + ":\"" + line + delimiter + "1\"" + hasComma;
					} else {
						finalLine = dataKey + ":\"" + line + delimiter + "a\"" + hasComma;
					}

					jsonData.set(i, finalLine);
				}
			}
		}







		// Print data back into file.
		if (jsonData.size() > 0) {
			try (FileWriter writer = new FileWriter(jsonFile); BufferedWriter bWriter = new BufferedWriter(writer);){
				for (String line: jsonData) {
					//log.info("Writing Line: " + line);
					bWriter.write(line + "\n");
				}
			} catch(Exception e) {

			}
		}


		//log.info("Ending Test");

	}

	@When("^the user iterates the JSON data \"([^\"]*)\" in the \"([^\"]*)\" JSON file \"([^\"]*)\"$")
	public void iterateDummyDataInJsonFile(String jsonDataKey, String fileName, String iterateType) {

		//log.info("Beginning Test");

		//
		// Check if file is full filepath or single filename
		//

		fileName = parseValue(fileName);
		jsonDataKey = parseValue(jsonDataKey);

		File jsonFile = new File("");

		if (fileName.contains("\\") || fileName.contains("/")){
			jsonFile = new File(fileName);

		} else {
			jsonFile = new File(System.getProperty("user.dir") + "\\src\\test\\resources\\features\\" + fileName + ".json");
			if (!jsonFile.exists()) {

				String[] directories = (new File(System.getProperty("user.dir") + "\\src\\test\\resources\\features")).list(new FilenameFilter() {
					@Override
					public boolean accept(File current, String name) {
						return new File(current, name).isDirectory();
					}
				});
				boolean foundFile = false;

				for (int i = 0; i < directories.length && foundFile == false; i++) {
					jsonFile = new File(System.getProperty("user.dir") + "\\src\\test\\resources\\features\\" + directories[i] + "\\" + fileName + ".json");
					if (jsonFile.exists()) {
						foundFile = true;
					}
				}

				if (!jsonFile.exists()) {
					jsonFile = new File(System.getProperty("user.dir") + "\\src\\test\\resources\\testdata\\" + fileName + ".json");
					if (!jsonFile.exists()) {
						log.info("JSON File was not able to be located.  Please provide a full file path or place the JSON in the same foler as the feature file.  Current directory is: " + System.getProperty("user.dir"));
						return;
					}
				}
			}
		}

		//Prepare Json Data 
		ArrayList<String> jsonData =  new ArrayList<String>();


		// Check if File exists at all.


		// Read all data from the file.
		try (FileReader reader = new FileReader(jsonFile); BufferedReader bReader = new BufferedReader(reader);){
			String line;
			while ((line = bReader.readLine()) != null){
				//log.info("Reading Line: " + line);
				jsonData.add(line);
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		}




		// Find data and replace it 
		for (int i=0; i < jsonData.size(); i++) {
			String line = jsonData.get(i);
			if (line.split(":").length > 1 && line.split(":")[0].replace("\"", "").trim().equals(jsonDataKey)) {

				String hasComma = "";
				if(line.contains(",")) {
					hasComma = ",";
				}

				log.info("Discovered Line: " + line);
				String dataKey = line.split(":",2)[0];
				line = line.split(":",2)[1];
				line = line.replace("\"", "").replace(",", "");
				String newIterator = "";

				if (iterateType.equals("numerically")) {
					newIterator = Integer.toString(Integer.parseInt(line) + 1).trim();
				}


				else if (iterateType.equals("alphabetically")) {

					boolean iterateNext = true;
					for (int j = line.length()-1; j >= 0; j--) {
						if (iterateNext) {
							iterateNext = false;
							newIterator = iterateChar(line.charAt(j)) + newIterator;
							if (line.charAt(j) == 'Z') {
								iterateNext = true;
							}
						} else {
							newIterator = line.charAt(j) + newIterator;
						}
					}

					if (line.replace("Z", "").equals("")) {
						newIterator = "a" + newIterator;
					}
				}  else {
					log.info("Iterator Type unknown:  Please use \"alphabetically\" or \"numerically\" as type");
					return;
				}

				String finalLine = dataKey + ":\"" + newIterator + "\"" + hasComma;
				log.info("Final Line Generated: " + finalLine);
				jsonData.set(i, finalLine);


			}
		}

		// Print data back into file.
		if (jsonData.size() > 0) {
			try (FileWriter writer = new FileWriter(jsonFile); BufferedWriter bWriter = new BufferedWriter(writer);){
				for (String line: jsonData) {
					//log.info("Writing Line: " + line);
					bWriter.write(line + "\n");
				}
			} catch(Exception e) {

			}
		}


		//log.info("Ending Test");
	}

	@When("^the user iterates the Social Security number data \"([^\"]*)\" in the \"([^\"]*)\" JSON file \"([^\"]*)\" hyphen$")
	public void iterateDummyDataInJsonFileSSN(String jsonDataKey, String fileName, String hyphen) {

		//log.info("Beginning Test");

		//
		// Check if file is full filepath or single filename
		//

		String hyphenString = "";
		if (hyphen.toLowerCase().equals("with")) {
			hyphenString = "-";
		}

		fileName = parseValue(fileName);
		jsonDataKey = parseValue(jsonDataKey);


		File jsonFile = new File("");

		if (fileName.contains("\\") || fileName.contains("/")){
			jsonFile = new File(fileName);

		} else {
			jsonFile = new File(System.getProperty("user.dir") + "\\src\\test\\resources\\features\\" + fileName + ".json");
			if (!jsonFile.exists()) {

				String[] directories = (new File(System.getProperty("user.dir") + "\\src\\test\\resources\\features")).list(new FilenameFilter() {
					@Override
					public boolean accept(File current, String name) {
						return new File(current, name).isDirectory();
					}
				});
				boolean foundFile = false;

				for (int i = 0; i < directories.length && foundFile == false; i++) {
					jsonFile = new File(System.getProperty("user.dir") + "\\src\\test\\resources\\features\\" + directories[i] + "\\" + fileName + ".json");
					if (jsonFile.exists()) {
						foundFile = true;
					}
				}

				if (!jsonFile.exists()) {
					jsonFile = new File(System.getProperty("user.dir") + "\\src\\test\\resources\\testdata\\" + fileName + ".json");
					if (!jsonFile.exists()) {
						log.info("JSON File was not able to be located.  Please provide a full file path or place the JSON in the same foler as the feature file.  Current directory is: " + System.getProperty("user.dir"));
						return;
					}
				}
			}
		}


		//Prepare Json Data 
		ArrayList<String> jsonData =  new ArrayList<String>();


		// Check if File exists at all.


		// Read all data from the file.
		try (FileReader reader = new FileReader(jsonFile); BufferedReader bReader = new BufferedReader(reader);){
			String line;
			while ((line = bReader.readLine()) != null){
				//log.info("Reading Line: " + line);
				jsonData.add(line);
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		}




		// Find data and replace it 
		for (int i=0; i < jsonData.size(); i++) {
			String line = jsonData.get(i);
			if (line.split(":").length > 1 && line.split(":")[0].replace("\"", "").trim().equals(jsonDataKey)) {

				String hasComma = "";
				if(line.contains(",")) {
					hasComma = ",";
				}

				log.info("Discovered Line: " + line);
				String dataKey = line.split(":",2)[0];
				line = line.split(":",2)[1];
				line = line.replace("\"", "").replace(",", "");

				int SSN = Integer.parseInt(line.replace("-",""))+1;


				if ( SSN >= 900000000) {
					SSN = 0;
				}

				int SSN_1 = SSN / 1000000;
				int SSN_2 = (SSN % 1000000)/10000; 
				int SSN_3 = SSN % 10000; 

				System.out.println("SSN: " + SSN_1*100000 + "-" + SSN_2*1000 + "-" + SSN_3);

				if (SSN_1 == 666) {
					SSN_1++;
				} else if (SSN_1 < 100) {
					SSN_1 += 100;
				}

				if (SSN_2 == 0) {
					SSN_2++;
				}
				if (SSN_3 / 10 == 666 ) {
					SSN_3+= 10;
				}
				if (SSN_3 == 0 || SSN % 1000 == 666) {
					SSN_3++;
				}

				String String_1 = Integer.toString(SSN_1);
				String String_2 = Integer.toString(SSN_2);
				String String_3 = Integer.toString(SSN_3);

				if (SSN_1 < 10) {
					String_1 = "00".concat(String_1);
				} else if (SSN_1 < 100) {
					String_1 = "0".concat(String_1);
				}

				if (SSN_2 < 10) {
					String_2 = "0".concat(String_2);
				}

				if (SSN_3 < 10) {
					String_3 = "000".concat(String_3);
				} else if (SSN_3 < 100) {
					String_3 = "00".concat(String_3);
				} else if (SSN_3 < 1000) {
					String_3 = "0".concat(String_3);
				}


				String newIterator = String_1.concat(hyphenString).concat(String_2).concat(hyphenString).concat(String_3);

				String finalLine = dataKey + ":\"" + newIterator + "\"" + hasComma;
				log.info("Final Line Generated: " + finalLine);
				jsonData.set(i, finalLine);


			}
		}

		// Print data back into file.
		if (jsonData.size() > 0) {
			try (FileWriter writer = new FileWriter(jsonFile); BufferedWriter bWriter = new BufferedWriter(writer);){
				for (String line: jsonData) {
					//log.info("Writing Line: " + line);
					bWriter.write(line + "\n");
				}
			} catch(Exception e) {

			}
		}


		//log.info("Ending Test");
	}
	

	@When("^the user iterates the Phone Number data \"([^\"]*)\" in the \"([^\"]*)\" JSON file \"([^\"]*)\" hyphen$")
	public void iterateDummyDataInJsonFilePhone(String jsonDataKey, String fileName, String hyphen) {


		//
		// Check if file is full filepath or single filename
		//

		String hyphenString = "";
		if (hyphen.toLowerCase().equals("with")) {
			hyphenString = "-";
		}

		fileName = parseValue(fileName);
		jsonDataKey = parseValue(jsonDataKey);


		File jsonFile = new File("");

		if (fileName.contains("\\") || fileName.contains("/")){
			jsonFile = new File(fileName);

		} else {
			jsonFile = new File(System.getProperty("user.dir") + "\\src\\test\\resources\\features\\" + fileName + ".json");
			if (!jsonFile.exists()) {

				String[] directories = (new File(System.getProperty("user.dir") + "\\src\\test\\resources\\features")).list(new FilenameFilter() {
					@Override
					public boolean accept(File current, String name) {
						return new File(current, name).isDirectory();
					}
				});
				boolean foundFile = false;

				for (int i = 0; i < directories.length && foundFile == false; i++) {
					jsonFile = new File(System.getProperty("user.dir") + "\\src\\test\\resources\\features\\" + directories[i] + "\\" + fileName + ".json");
					if (jsonFile.exists()) {
						foundFile = true;
					}
				}

				if (!jsonFile.exists()) {
					jsonFile = new File(System.getProperty("user.dir") + "\\src\\test\\resources\\testdata\\" + fileName + ".json");
					if (!jsonFile.exists()) {
						log.info("JSON File was not able to be located.  Please provide a full file path or place the JSON in the same foler as the feature file.  Current directory is: " + System.getProperty("user.dir"));
						return;
					}
				}
			}
		}


		//Prepare Json Data 
		ArrayList<String> jsonData =  new ArrayList<String>();


		// Read all data from the file.
		try (FileReader reader = new FileReader(jsonFile); BufferedReader bReader = new BufferedReader(reader);){
			String line;
			while ((line = bReader.readLine()) != null){
				//log.info("Reading Line: " + line);
				jsonData.add(line);
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		}




		// Find data and replace it 
		for (int i=0; i < jsonData.size(); i++) {
			String line = jsonData.get(i);
			if (line.split("\"").length > 3 && line.split("\"")[1].trim().equals(jsonDataKey)) {
				String hasComma = "";
				if(line.contains(",")) {
					hasComma = ",";
				}

				log.info("Discovered Line: " + line);
				String dataKey = line.split(":",2)[0];
				line = line.split(":",2)[1];
				line = line.replace("\"", "").replace(",", "");

				long PhoneNum = Long.parseLong(line.replace("-","").replace("_",""))+1;
				
				long tendigit = 100000000 * 10;

				if ( PhoneNum >= tendigit*9 + 999999999 || PhoneNum < tendigit) {
					PhoneNum = tendigit;
				}

				log.info("Phone Number: " + PhoneNum);
				long Phone_1 = PhoneNum / 10000000;
				long Phone_2 = (PhoneNum % 10000000)/10000; 
				long Phone_3 = PhoneNum % 10000; 

				System.out.println("Phone Number Found: " + Phone_1 + "-" + Phone_2 + "-" + Phone_3);

				if (Phone_2 == 555) {
					Phone_2++;
				} else if (Phone_2 == 0) {
					Phone_2 += 100;
				}
				
				if (Phone_3 == 0) {
					Phone_3 += 1000;
				}
				
				String String_1 = Long.toString(Phone_1);
				String String_2 = Long.toString(Phone_2);
				String String_3 = Long.toString(Phone_3);

				if (Phone_2 < 10) {
					String_2 = "00".concat(String_1);
				} else if (Phone_2 < 100) {
					String_2 = "0".concat(String_1);
				}


				if (Phone_3 < 10) {
					String_3 = "000".concat(String_3);
				} else if (Phone_3 < 100) {
					String_3 = "00".concat(String_3);
				} else if (Phone_3 < 1000) {
					String_3 = "0".concat(String_3);
				}


				String newIterator = String_1.concat(hyphenString).concat(String_2).concat(hyphenString).concat(String_3);

				String finalLine = dataKey + ":\"" + newIterator + "\"" + hasComma;
				log.info("Final Line Generated: " + finalLine);
				jsonData.set(i, finalLine);


			}
		}

		// Print data back into file.
		if (jsonData.size() > 0) {
			try (FileWriter writer = new FileWriter(jsonFile); BufferedWriter bWriter = new BufferedWriter(writer);){
				for (String line: jsonData) {
					log.info("Writing Line: " + line);
					bWriter.write(line + "\n");
				}
			} catch(Exception e) {

			}
		}


		log.info("Ending Test Phone Number");
	}
	
	
	private char iterateChar(char theChar) {
		if (theChar == 'a') {return 'b';}
		if (theChar == 'b') {return 'c';}
		if (theChar == 'c') {return 'd';}
		if (theChar == 'd') {return 'e';}
		if (theChar == 'e') {return 'f';}
		if (theChar == 'f') {return 'g';}
		if (theChar == 'g') {return 'h';}
		if (theChar == 'h') {return 'i';}
		if (theChar == 'i') {return 'j';}
		if (theChar == 'j') {return 'k';}
		if (theChar == 'k') {return 'l';}
		if (theChar == 'l') {return 'm';}
		if (theChar == 'm') {return 'n';}
		if (theChar == 'n') {return 'o';}
		if (theChar == 'o') {return 'p';}
		if (theChar == 'p') {return 'q';}
		if (theChar == 'q') {return 'r';}
		if (theChar == 'r') {return 's';}
		if (theChar == 's') {return 't';}
		if (theChar == 't') {return 'u';}
		if (theChar == 'u') {return 'v';}
		if (theChar == 'v') {return 'W';}
		if (theChar == 'w') {return 'X';}
		if (theChar == 'x') {return 'Y';}
		if (theChar == 'y') {return 'Z';}
		if (theChar == 'z') {return 'A';}
		if (theChar == 'A') {return 'B';}
		if (theChar == 'B') {return 'C';}
		if (theChar == 'C') {return 'D';}
		if (theChar == 'D') {return 'E';}
		if (theChar == 'E') {return 'F';}
		if (theChar == 'F') {return 'G';}
		if (theChar == 'G') {return 'H';}
		if (theChar == 'H') {return 'I';}
		if (theChar == 'I') {return 'J';}
		if (theChar == 'J') {return 'K';}
		if (theChar == 'K') {return 'L';}
		if (theChar == 'L') {return 'M';}
		if (theChar == 'M') {return 'N';}
		if (theChar == 'N') {return 'O';}
		if (theChar == 'O') {return 'P';}
		if (theChar == 'P') {return 'Q';}
		if (theChar == 'Q') {return 'R';}
		if (theChar == 'R') {return 'S';}
		if (theChar == 'S') {return 'T';}
		if (theChar == 'T') {return 'U';}
		if (theChar == 'U') {return 'V';}
		if (theChar == 'V') {return 'W';}
		if (theChar == 'W') {return 'X';}
		if (theChar == 'X') {return 'Y';}
		if (theChar == 'Y') {return 'Z';}
		return 'a';
	}
}
