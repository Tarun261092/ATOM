package automation.library.engine.core.parser.maps;

public class ScenarioMap {
    private String scnKey;
    private String scnVal;
    private int lineNo;

    public String getScnKey() {
        return scnKey;
    }

    public void setScnKey(String scnKey) {
        this.scnKey = scnKey;
    }

    public String getScnVal() {
        return scnVal;
    }

    public void setScnVal(String scnVal) {
        this.scnVal = scnVal;
    }

    public int getLineNo() {
        return lineNo;
    }

    public void setLineNo(int lineno) {
        this.lineNo = lineno;
    }
}
