package automation.library.engine.core.runner;

import automation.library.common.Property;
import automation.library.cucumber.core.Constants;
import automation.library.engine.core.parser.FeatureFileParserUtil;
import com.google.gson.GsonBuilder;

import org.apache.commons.configuration2.PropertiesConfiguration;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.Map.Entry;

public class FDRDataConditionWriter extends FeatureFileParserUtil {
	protected final Logger logs = LogManager.getLogger(FDRDataConditionWriter.class);
	private static final String EMB_TRAN_TYPE = "EMB TRAN TYPE";
	private static final String NA = "NA";
	private static final String FE = "FE";
	private static final String AT = "AT";
	private static final String LS = "LS";
	private static final String DM = "DM";
	private static final String FLAG = "Flag";
	private static final String KEYWORD = "KeyWord";
	private static final String EXPDATE = "EXP DATE";
	private static final String CHDUPC = "CHD_UPC";
	private static final String CREDBURID = "CRED BUR ID";
	private static final String CASH_LINE = "CASH LINE";
	private static final String PL_CT = "PL CT";
	private static final String ADD_AUTH_USERS = "ADD AUTH USERS";
	private static final String STORE = "STORE";
	private static final String ROW_NUM = "ROW_NUM";

	protected List<String> jsonNameList = new ArrayList<>();
	Map<String, String> authUserMap = new HashMap<>();

	public FDRDataConditionWriter() {
		//Utility class
	}

	public void generateJSONFromDataConditions(Object mainCriteria,
			Object additionalCriteria,
			Object storeNumbers,
			Object embossingData,
			Map<String, LinkedHashMap<String, Object>> logicCriteria) {

		List<String> mainCriteriaList = Arrays.asList(mainCriteria.toString().split("\n"));
		List<String> addlCriteriaList = Arrays.asList(additionalCriteria.toString().split("\n"));
		List<String> existingAccountsList = null;

		String storeNumber = "";
		if (storeNumbers != null) {
			storeNumber = storeNumbers.toString().split("\n")[0];
		}

		if (embossingData != null ) {
			existingAccountsList = new LinkedList<>(Arrays.asList(embossingData.toString().split("\n")));
			int index = existingAccountsList.size() - 1;
			existingAccountsList.remove(index);
		}

		Map<String, String> criteriaMap = new HashMap<>();
		Map<String, String> addlCriteriaMap = new HashMap<>();
		List<Map<String, String>> criteriaListOfMaps = new ArrayList<>();
		List<Map<String, String>> addlCriteriaListOfMaps = new ArrayList<>();

		int jsonNumber = 0;

		for (String criteriaLine : mainCriteriaList) {
			criteriaLine = criteriaLine.replace("(", "").replace(")", "").toUpperCase().trim();

			if (isKeyValuePair(criteriaLine)) {
				writeKeyValPair(criteriaMap, criteriaLine, criteriaListOfMaps, storeNumber);
			} 
			else if (isFirstLine(criteriaLine)) {
				writeDataIntoMap(criteriaMap, criteriaLine);
			}
		}

		for (String criteriaLine : addlCriteriaList) {
			criteriaLine = criteriaLine.toUpperCase().trim();
			if (isKeyValuePairAlternate(criteriaLine)) {
				writeKeyValPairAlternate(addlCriteriaMap, criteriaLine, addlCriteriaListOfMaps);
			}
		}

		if (!criteriaMap.isEmpty() && !addlCriteriaMap.isEmpty()) {
			criteriaListOfMaps.add(criteriaMap);
			addlCriteriaListOfMaps.add(addlCriteriaMap);

			Map<String, String> dataConditionMap;
			Map<String, String> dataConditionMapFinal;

			for (Map<String, String> currentMap : criteriaListOfMaps) {
				jsonNameList.clear();
			
				if (currentMap.get(EMB_TRAN_TYPE).contains(NA)) {
					dataConditionMap = getUpdatedConditionsMap(addlCriteriaListOfMaps, currentMap, existingAccountsList);
					jsonNumber = createNumber(dataConditionMap, addlCriteriaListOfMaps);
					dataConditionMapFinal = getFormattedConditionsMap(dataConditionMap);
					updateFeatureFileForDataConditions(logicCriteria, dataConditionMapFinal, jsonNumber);
					updateFeatureFileForAddAuthUser(logicCriteria);
				} else if(currentMap.get(EMB_TRAN_TYPE).contains(FE) || currentMap.get(EMB_TRAN_TYPE).contains(AT) || currentMap.get(EMB_TRAN_TYPE).contains(LS) || currentMap.get(EMB_TRAN_TYPE).contains(DM)) {
					dataConditionMap = getUpdatedConditionsMap(addlCriteriaListOfMaps, currentMap, existingAccountsList);
					jsonNumber = createNumber(dataConditionMap, addlCriteriaListOfMaps);
					dataConditionMapFinal = getFormattedConditionsMap(dataConditionMap);
					updateFeatureFileForAddAuthUser(logicCriteria);
					updateFeatureFileForDataConditions(logicCriteria, dataConditionMapFinal, jsonNumber);
				} 
			}
		}
	}

	private List<String> updateJSONListForAuthUser(List<String> jsonNameList) {

		List<String> updatedJsonList = new ArrayList<>();
		
		String jsonName = jsonNameList.get(jsonNameList.size()-1);
		updatedJsonList.add(jsonName);
		
		return updatedJsonList;		
	}
	
	private void updateFeatureFileForDataConditions(Map<String, LinkedHashMap<String, Object>> logicCriteria, Map<String, String> dataConditionMapFinal, int jsonNumber) {
		
		Map<String, String> scenarioMap = getScenarioMap(logicCriteria, dataConditionMapFinal,false);

		if(!jsonNameList.isEmpty()) {
			try {
				reformFeatureFile(scenarioMap, jsonNameList, jsonNumber);
			} catch (IOException e) {
				e.getMessage();
			}
		}
	}
	
	private void updateFeatureFileForAddAuthUser(Map<String, LinkedHashMap<String, Object>> logicCriteria) {
		
		if(!authUserMap.isEmpty()) {
			
			Map<String, String> authscenarioMap = getScenarioMap(logicCriteria, authUserMap,true);
    		List<String> newJsonNameList = updateJSONListForAuthUser(jsonNameList);
			
			if(!newJsonNameList.isEmpty())
				try {
					reformFeatureFile(authscenarioMap, newJsonNameList, 1);
				} catch (IOException e) {
					e.getMessage();
				}
		}
	}

	private Map<String, String> getScenarioMap(Map<String, LinkedHashMap<String, Object>> logicCriteria, Map<String, String> currentMap, boolean isAuth) {
		Map<String, String> finalCriteriaMap = new LinkedHashMap<>();
		boolean flagForFE = false;
		String tempKey = "";
		String tempValue = "";

		if(currentMap.containsKey(EMB_TRAN_TYPE.concat(":").concat(NA))) {
			finalCriteriaMap.put("API CALL", "API call steps");
			finalCriteriaMap.put("Update Account Number in Sheet", "Update Account Number");
		}

		for (Map.Entry<String, String> innerCriteria : currentMap.entrySet()) {  	

			for (Entry<String, LinkedHashMap<String, Object>> entry : logicCriteria.entrySet()) {
				try {
					
					if (!isAuth && (entry.getValue().get(KEYWORD).toString().trim().equalsIgnoreCase(innerCriteria.getKey().trim()) ||
							innerCriteria.getKey().toUpperCase().trim().contains(entry.getValue().get(KEYWORD).toString().toUpperCase().trim())))					
					{
						String key = entry.getValue().get(KEYWORD).toString();
						String value = entry.getValue().get("Scenario Name").toString();

						//This if condition being added so that embossing always comes last in the finalCriteriaMap.
						if (key.contains(":FE") || key.contains(":AT") || key.contains(":LS") || key.contains(":DM")) {
							tempKey = key;
							tempValue = value;
							flagForFE = true;
						} else {
							finalCriteriaMap.put(key, value);
						}
						break;
					} else if (isAuth && entry.getValue().get(KEYWORD).toString().toUpperCase().trim().contains(innerCriteria.getKey().toUpperCase().trim())) {
							String key = entry.getValue().get(KEYWORD).toString();
							String value = entry.getValue().get("Scenario Name").toString();
							finalCriteriaMap.put(key, value);
							break;
					}
				} catch (Exception e) {
					e.getMessage();
				}
			}
		}
		if (flagForFE) {
			finalCriteriaMap.put(tempKey, tempValue);
		}
		return finalCriteriaMap;
	}

	private Map<String, String> getUpdatedConditionsMap(List<Map<String, String>> addlCriteriaListOfMaps,
			Map<String, String> currentMap,List<String> existingAccountsList) {

			StringBuilder fileName = new StringBuilder();

			List<Map<String, String>> criteriaList = new ArrayList<>();
			Map<String, String> conditionMap = new HashMap<>(currentMap);

		for (Entry<String, String> entry : currentMap.entrySet()) {
			if ((currentMap.get(EMB_TRAN_TYPE).contains(NA) && entry.getKey().contains(CHDUPC)) ||
					(currentMap.get(EMB_TRAN_TYPE).contains(FE) && entry.getKey().contains(CHDUPC)) ||
					(currentMap.get(EMB_TRAN_TYPE).contains(AT) && entry.getKey().contains(CHDUPC)) ||
					(currentMap.get(EMB_TRAN_TYPE).contains(LS) && entry.getKey().contains(CHDUPC)) ||
					(currentMap.get(EMB_TRAN_TYPE).contains(DM) && entry.getKey().contains(CHDUPC))) {
				getUPCDetails(entry, conditionMap);
			}

			if ((currentMap.get(EMB_TRAN_TYPE).contains(NA) && entry.getKey().contains(CREDBURID)) ||
					(currentMap.get(EMB_TRAN_TYPE).contains(FE) && entry.getKey().contains(CREDBURID)) ||
					(currentMap.get(EMB_TRAN_TYPE).contains(AT) && entry.getKey().contains(CREDBURID)) ||
					(currentMap.get(EMB_TRAN_TYPE).contains(LS) && entry.getKey().contains(CREDBURID)) ||
					(currentMap.get(EMB_TRAN_TYPE).contains(DM) && entry.getKey().contains(CREDBURID))) {
				getCreditScoreDetails(conditionMap);
			}
		}

		currentMap = conditionMap;

		for (Map<String, String> adlCurrent : addlCriteriaListOfMaps) {
			if ((currentMap.get(EMB_TRAN_TYPE).contains(NA) && adlCurrent.containsKey(NA) && adlCurrent.containsKey(EXPDATE)) ||
					(currentMap.get(EMB_TRAN_TYPE).contains(FE) && adlCurrent.containsKey(FE) && adlCurrent.containsKey(EXPDATE)) ||
					(currentMap.get(EMB_TRAN_TYPE).contains(AT) && adlCurrent.containsKey(AT) && adlCurrent.containsKey(EXPDATE)) ||
					(currentMap.get(EMB_TRAN_TYPE).contains(LS) && adlCurrent.containsKey(LS) && adlCurrent.containsKey(EXPDATE)) ||
					(currentMap.get(EMB_TRAN_TYPE).contains(DM) && adlCurrent.containsKey(DM) && adlCurrent.containsKey(EXPDATE))) {
				getExpDateDetails(adlCurrent, currentMap);
			}

			if (((currentMap.get(EMB_TRAN_TYPE).contains(NA) && adlCurrent.containsKey(NA)) ||
					(currentMap.get(EMB_TRAN_TYPE).contains(FE) && adlCurrent.containsKey(FE)) ||
					(currentMap.get(EMB_TRAN_TYPE).contains(AT) && adlCurrent.containsKey(AT)) ||
					(currentMap.get(EMB_TRAN_TYPE).contains(LS) && adlCurrent.containsKey(LS)) ||
					(currentMap.get(EMB_TRAN_TYPE).contains(DM) && adlCurrent.containsKey(DM))) &&
					adlCurrent.containsKey(CASH_LINE) && adlCurrent.get(CASH_LINE).equalsIgnoreCase("No")) {
				currentMap.put(CASH_LINE, "0000000000000");
				currentMap.put("AP_FIELD", "A");
			}

			if (currentMap.get(EMB_TRAN_TYPE).contains(NA) && adlCurrent.containsKey(NA) && adlCurrent.containsKey("NAME LENGTH")) {
				getNameDetails(adlCurrent, currentMap);
			}
			
			if (currentMap.get(EMB_TRAN_TYPE).contains(NA) && adlCurrent.containsKey(NA)) {
				List<Object> custNamesList;
				PropertiesConfiguration config = Property.getProperties(Constants.FDR_PROPERTIES_FILE_PATH);
				custNamesList = config.getList("CustNamesList");
				
				if(!custNamesList.isEmpty()) {
					String custName = custNamesList.get(new Random().nextInt(custNamesList.size())).toString().replace(" ", ",").toUpperCase().concat(String.valueOf(new Random().nextInt(10)));
					currentMap.put("PRMR_CUST_NM", custName);
				}
			}
			
			if (currentMap.get(EMB_TRAN_TYPE).contains(LS) && adlCurrent.containsKey(LS)) {
					currentMap.put("CURRENTDATE",LocalDate.now().format(DateTimeFormatter.ofPattern("MMddYY")));
			}
			
			if ((currentMap.get(EMB_TRAN_TYPE).contains(NA) && currentMap.containsKey(ADD_AUTH_USERS) && adlCurrent.containsKey(NA)) ||
					(currentMap.get(EMB_TRAN_TYPE).contains(FE) && currentMap.containsKey(ADD_AUTH_USERS) && adlCurrent.containsKey(FE)) ||
					(currentMap.get(EMB_TRAN_TYPE).contains(AT) && currentMap.containsKey(ADD_AUTH_USERS) && adlCurrent.containsKey(AT)) ||
					(currentMap.get(EMB_TRAN_TYPE).contains(LS) && currentMap.containsKey(ADD_AUTH_USERS) && adlCurrent.containsKey(LS)) ||
					(currentMap.get(EMB_TRAN_TYPE).contains(DM) && currentMap.containsKey(ADD_AUTH_USERS) && adlCurrent.containsKey(DM))) {
				authUserMap.clear();
				String newAuthUserKey= ADD_AUTH_USERS+":"+adlCurrent.get("AUTH USERS");
				authUserMap.put(newAuthUserKey, adlCurrent.get("AUTH USERS"));	
				currentMap.remove(ADD_AUTH_USERS);
			}

			if ((currentMap.get(EMB_TRAN_TYPE).contains(NA) && adlCurrent.containsKey(NA) && adlCurrent.containsKey(PL_CT)) ||
					(currentMap.get(EMB_TRAN_TYPE).contains(FE) && adlCurrent.containsKey(FE) && adlCurrent.containsKey(PL_CT)) ||
					(currentMap.get(EMB_TRAN_TYPE).contains(AT) && adlCurrent.containsKey(AT) && adlCurrent.containsKey(PL_CT)) ||
					(currentMap.get(EMB_TRAN_TYPE).contains(LS) && adlCurrent.containsKey(LS) && adlCurrent.containsKey(PL_CT)) ||
					(currentMap.get(EMB_TRAN_TYPE).contains(DM) && adlCurrent.containsKey(DM) && adlCurrent.containsKey(PL_CT))) {
				currentMap.put(PL_CT, adlCurrent.get(PL_CT));
			}
		}
		
		criteriaList.add(currentMap);

		if(currentMap.get(EMB_TRAN_TYPE).contains(FE)||currentMap.get(EMB_TRAN_TYPE).contains(AT)||currentMap.get(EMB_TRAN_TYPE).contains(LS)||currentMap.get(EMB_TRAN_TYPE).contains(DM)) {
			updateAccountToJSON(currentMap,existingAccountsList,criteriaList);
		}
		else{
			fileName.append(currentMap.get(ROW_NUM)+"_").append(currentMap.get(EMB_TRAN_TYPE));
			writeFileToJson(criteriaList, fileName);
		}

		return currentMap;
	}

	private void updateAccountToJSON(Map<String, String> currentMap, List<String> existingAccountsList, List<Map<String, String>> criteriaList) {
		Map<String,String> tempMap = new HashMap<>();
		String accountNumber="Account_Num";
		StringBuilder fileName = null;
		int count=1;
		try 
		{
			for(String list : existingAccountsList) {
				fileName= new StringBuilder();
				tempMap.put(accountNumber.concat(String.valueOf(count)), list);
				currentMap.put(accountNumber, list);

				if(existingAccountsList.indexOf(list) == (existingAccountsList.size()-1))
					currentMap.putAll(tempMap);

				fileName.append(currentMap.get(ROW_NUM)+"_").append(count);
				writeFileToJson(criteriaList, fileName.append(currentMap.get(EMB_TRAN_TYPE)));			
				count++;
			}
			currentMap.keySet().removeAll(tempMap.keySet());
		}catch(Exception e) {
			logs.debug("existing accounts list is empty for ROW Number: {}", currentMap.get(ROW_NUM));
		}	
	}

	private void getNameDetails(Map<String, String> adlCurrent, Map<String, String> currentMap) {

		String nameLengthValue = adlCurrent.get("NAME LENGTH");
		List<Object> namesList;
		PropertiesConfiguration config = Property.getProperties(Constants.FDR_PROPERTIES_FILE_PATH);

		if (nameLengthValue.equals("25")) {
			namesList = config.getList("TwentyFiveCharNamesList");
			String name = namesList.get(new Random().nextInt(namesList.size())).toString().replace(" ", ",").toUpperCase();
			currentMap.put("PRMR_CUST_NM", name);
		}
	}

	private void getCreditScoreDetails(Map<String, String> conditionMap) {
		conditionMap.put("CRED BUR FLAG", "1");
		conditionMap.put("CRED BUR SCORE", "700");
		conditionMap.put("CRED BUR DATE", LocalDate.now().format(DateTimeFormatter.ofPattern("YYMMdd")));
	}

	private void getExpDateDetails(Map<String, String> adlCurrent, Map<String, String> currentMap) {
		SimpleDateFormat parser = new SimpleDateFormat("MM/yyyy");
		SimpleDateFormat formatter = new SimpleDateFormat("MMyyyy");
		String expDateValue = adlCurrent.get(EXPDATE);

		try {
			if (expDateValue.startsWith("99")) {
				currentMap.put(EXPDATE, "999999");
			} else {
				currentMap.put(EXPDATE, formatter.format(parser.parse(expDateValue)));
			}
		} catch (Exception e) {
			log.error("Unable to parse Expiry Date:: {}", e.getMessage());
			currentMap.put(EXPDATE, "000000");
		}
	}

	private void getUPCDetails(Entry<String, String> entry, Map<String, String> conditionMap) {
		List<String> keysList = Arrays.asList(entry.getKey().split("CHD_UPC_"));
		conditionMap.put(CHDUPC, entry.getValue());
		conditionMap.put("CHD_UPC_INDEX", keysList.get(1).trim());
		conditionMap.remove("CHD_UPC_" + keysList.get(1).trim());
	}

	public void generateJSONFromDataConditions(List<Map<String, Object>> conditioningParams) throws IOException {
		Map<String, String> scenarioMap = new HashMap<>();
		StringBuilder fileName = null;
		int rowNumber = 1;
		int jsonNumber = 1;
		if (!conditioningParams.isEmpty()) {

			for (Map<String, Object> map : conditioningParams) {
				++rowNumber;
				if (!map.containsKey(FLAG) || map.get(FLAG).toString().trim().equalsIgnoreCase("Y")) {
					Map<String, String> criteriaMap = new HashMap<>();
					fileName = new StringBuilder();
					for (Map.Entry<String, Object> entry : map.entrySet()) {
						String value = checkForDouble(entry.getValue(), entry.getKey());
						criteriaMap.put(entry.getKey().trim(), value.trim());
					}
					List<Map<String, String>> criteriaList = new ArrayList<>();
					criteriaList.add(criteriaMap);
					writeFileToJson(criteriaList, fileName.append("RowNum_").append(rowNumber));
				}
			}
		}
		scenarioMap.put("1", System.getProperty("scenarioName"));
		reformFeatureFile(scenarioMap, jsonNameList, jsonNumber);
	}

	private String checkForDouble(Object value, String key) {
		String stringValue = "";
		try {

			if (value.getClass() == Double.class && !(key.equals("Transaction_Amount"))) {
				Double doubleValue = (double) value;
				stringValue = Long.toString(doubleValue.longValue());
			} else {
				stringValue = value.toString();
			}

		} catch (Exception e) {
			logs.error(e.getMessage());
		}
		return stringValue;
	}

	private Map<String, String> writeDataIntoMap(Map<String, String> criteriaMap, String criteriaLine) {
		final List<String> parametersList = Arrays.asList(criteriaLine.split("/"));
		String parameterOneValue = "";
		String parameterTwoValue = "";
		String parameterThreeValue = "";
		String sysPriAgentValue = "";

		if (parametersList != null && parametersList.size() > 2) {
			parameterOneValue = parametersList.get(0).trim().contains(",") ? parametersList.get(0).trim().split(",")[0]
					: parametersList.get(0).trim();
			parameterTwoValue = parametersList.get(1).trim().contains(",") ? parametersList.get(1).trim().split(",")[0]
					: parametersList.get(1).trim();
			parameterThreeValue = parametersList.get(2).trim().contains(",")
					? parametersList.get(2).trim().split(",")[0]
							: parametersList.get(2).trim();
		} else if (parametersList != null) {
			parameterOneValue = parametersList.get(0).trim().contains(",") ? parametersList.get(0).trim().split(",")[0]
					: parametersList.get(0).trim();
			parameterTwoValue = parametersList.get(1).trim().contains(",") ? parametersList.get(1).trim().split(",")[0]
					: parametersList.get(1).trim();
			parameterThreeValue = "0001";
		}

		criteriaMap.put("SYS_ID", parameterOneValue);
		criteriaMap.put("PRINT_ID", parameterTwoValue);
		criteriaMap.put("AGENT_ID", parameterThreeValue);

		sysPriAgentValue = String.join("",parameterOneValue,parameterTwoValue,parameterThreeValue);
		criteriaMap.put("SYSPRINAGENT", sysPriAgentValue);

		return criteriaMap;
	}

	private int createNumber(Map<String, String> currentMap, List<Map<String, String>> addlCriteriaListOfMaps) {
		int value = 0;
		for (Map<String, String> adlCurrent : addlCriteriaListOfMaps) {
			if (currentMap.get(EMB_TRAN_TYPE).contains(NA) && adlCurrent.containsKey(NA)) {
				return Integer.parseInt(adlCurrent.get(NA));
			} else if (currentMap.get(EMB_TRAN_TYPE).contains(FE) && adlCurrent.containsKey(FE)) {
                value = 1;
            } else if (currentMap.get(EMB_TRAN_TYPE).contains(AT) && adlCurrent.containsKey(AT)) {
                value = 1;
            } else if (currentMap.get(EMB_TRAN_TYPE).contains(LS) && adlCurrent.containsKey(LS)) {
            	 value = 1;
            } else if (currentMap.get(EMB_TRAN_TYPE).contains(DM) && adlCurrent.containsKey(DM)) {
            	 value = 1;
            }
		}
		return value;
	}

	private String writeKeyValPair(Map<String, String> criteriaMap, final String criteriaLine, List<Map<String, String>> criteriaListOfMaps, String storeNumber) {

		List<String> keywords = Arrays.asList(EMB_TRAN_TYPE, "CURR PRICING STRATEGY", "CHD-CB-ID", "SOURCE CODE",
				"AD CODE", "PREMIER FLAG", "*JNTSVCMA", "LANG CD", STORE, ADD_AUTH_USERS, "PLASTIC TYPE", CHDUPC, CREDBURID, PL_CT);
		List<String> keywordsList = new ArrayList<>();

		keywords.stream().map(String::trim).forEach(entry -> {
			if (criteriaLine.toUpperCase().indexOf(entry) >= 0)
				keywordsList.add(entry);
		});
		String value = "";

		if (keywordsList.size() > 1) {
			int index1 = criteriaLine.toUpperCase().indexOf(keywordsList.get(0));
			int index2 = criteriaLine.toUpperCase().indexOf(keywordsList.get(1));

			String val1 = "";
			String val2 = "";
			if (index2 > index1) {
				val1 = criteriaLine.substring(index1, index2).trim();
				val2 = criteriaLine.substring(index2).trim();
			} else {
				val1 = criteriaLine.substring(index2, index1).trim();
				val2 = criteriaLine.substring(index1).trim();
			}
			createMap(val1, criteriaListOfMaps, criteriaMap, storeNumber);
			value = createMap(val2, criteriaListOfMaps, criteriaMap, storeNumber);
		} else {
			value = createMap(criteriaLine, criteriaListOfMaps, criteriaMap, storeNumber);
		}
		return value;
	}

	private String createMap(String criteriaLine, List<Map<String, String>> criteriaListOfMaps, Map<String, String> criteriaMap, String storeNumber) {

		String key = "";
		String value = "";

		if (criteriaLine != null && criteriaLine.contains("=")) {
			final List<String> keyValPair = Arrays.asList(criteriaLine.split("="));

			key = keyValPair.get(0).trim();
			value = keyValPair.get(1).trim().replace(")", "");

			if (key.equalsIgnoreCase(EMB_TRAN_TYPE) && (criteriaMap.get(EMB_TRAN_TYPE) != null)) {
				criteriaListOfMaps.add(new HashMap<>(criteriaMap));
			}
			criteriaMap.put(key, value);

		} else if (criteriaLine != null && criteriaLine.toUpperCase().contains(STORE) && storeNumber != null) {
			criteriaMap.put(STORE, storeNumber);
		} else {
			criteriaMap.put(criteriaLine, "");
		}
		return key;
	}

	private String writeKeyValPairAlternate(Map<String, String> addlcriteriaMap, String criteriaLine, List<Map<String, String>> addlcriteriaListOfMaps) {
		final List<String> keyValPair = Arrays.asList(criteriaLine.split(":"));

		if (keyValPair.size() == 2) {
			String key = keyValPair.get(0).trim();
			final String value = keyValPair.get(1).trim().replace(")", "");
			boolean flag = false;

			if (key.equalsIgnoreCase(FE) || key.equalsIgnoreCase(AT) || key.equalsIgnoreCase(LS) || key.equalsIgnoreCase(DM)) {
				addlcriteriaListOfMaps.add(new HashMap<>(addlcriteriaMap));
				flag = true;
			}
			if (flag)
				addlcriteriaMap.remove(NA);

			addlcriteriaMap.put(key, value);
			return value;
		}

		return "";
	}

	private Map<String, String> getFormattedConditionsMap(Map<String, String> currentMap) {
		List<String> valuesList;
		Map<String, String> conditionMap = new LinkedHashMap<>();

		for (Entry<String, String> entry : currentMap.entrySet()) {
			String key = entry.getKey();
			String value = entry.getValue();

			if (value != null && value.contains(",")) {
				valuesList = Arrays.asList(value.split(","));

				for (String val : valuesList) {
					val = val.trim();
					String newKey = key + ":" + val;
					conditionMap.put(newKey, val);
				}
			} else {
				String newKey = key + ":" + value;
				conditionMap.put(newKey, value);
			}
		}
		return conditionMap;
	}

	private void writeFileToJson(List<Map<String, String>> criteriaMap, StringBuilder fileName) {
		final String fullFilePath = String.format("%s%s.json",
				automation.library.cucumber.core.Constants.TESTDATAPATH,
				fileName);


		try (FileWriter jsonWriter = new FileWriter(fullFilePath)) {
			new GsonBuilder().setPrettyPrinting()
			.setLenient()
			.create()
			.toJson(criteriaMap, jsonWriter);

			logs.debug("Data file written to: {}", fullFilePath);
			jsonNameList.add(fullFilePath.replace(automation.library.cucumber.core.Constants.TESTDATAPATH, "").replace(".json", ""));
		} catch (IOException e) {
			logs.error(e);
		}
	}

	private boolean isKeyValuePair(String criteriaLine) {
		return criteriaLine.contains("=") || criteriaLine.toUpperCase().contains(STORE) || criteriaLine.contains(ADD_AUTH_USERS);
	}

	private boolean isKeyValuePairAlternate(String criteriaLine) {
		return criteriaLine.contains(":");
	}

	private boolean isFirstLine(String criteriaLine) {
		return criteriaLine.contains("/");
	}
}
