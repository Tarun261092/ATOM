package automation.library.engine.core.runner;

import automation.library.ada.services.AXEReportBuilder;
import org.testng.annotations.Test;

import java.io.IOException;

public class ADAReportRunner {

    @Test
    public void dequeReportGeneration() throws IOException {
        AXEReportBuilder con = new AXEReportBuilder();
        con.dequeReportGeneration();
    }
}