package automation.library.engine.desktop.steps;

import automation.library.common.TestContext;
import automation.library.engine.core.validator.AssertHelper;
import automation.library.engine.core.validator.ComparisonOperator;
import automation.library.engine.core.validator.ComparisonType;
import automation.library.engine.desktop.BaseDesktopSteps;
import automation.library.leanft.exec.DesktopContext;
import automation.library.reporting.Reporter;
import com.hp.lft.sdk.GeneralLeanFtException;
import io.cucumber.java.en.Then;

import static org.assertj.core.api.Assertions.assertThat;

public class AutoEngDesktopValidate extends BaseDesktopSteps {
    private static final String VALIDATION_TAG = "VALIDATION.";
    private static final String HARD_STOP_ON_FAILURE = "HardStopOnFailure";
    private static final String STATUS_FAIL = "FAIL";
    private static final String VALIDATION_FAILED = "Validation Failed: ";


    @Then("^the user validates \"([^\"]*)\" that the value of the \"([^\"]*)\" field on the \"([^\"]*)\" desktop window is \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void theUserValidatesThatTheValueOfTheFieldOnTheDesktopWindowIs(String comparisonType,
                                                                           String fieldName,
                                                                           String windowName,
                                                                           String comparisonOperator,
                                                                           String expectedValue,
                                                                           String validationID,
                                                                           String onFailureFlag) throws GeneralLeanFtException {
        DesktopContext.getInstance().setCurrentLeanFTWindow(getDesktopWindow(windowName));
        String actualValue = getValueFromField(fieldName, windowName);
        expectedValue = parseValue(expectedValue);

        AssertHelper validator = new AssertHelper(comparisonType, comparisonOperator, onFailureFlag);
        TestContext.getInstance().testdataPut(VALIDATION_TAG + validationID, validator.getResultMessage(actualValue, expectedValue));
        validator.performValidation(actualValue, expectedValue, validationID,
                                    String.format("'%s' field value validation on the TE screen", fieldName));
    }

    @Then("^the user validates the \"([^\"]*)\" object is present at the \"([^\"]*)\" desktop window \"([^\"]*)\" \"([^\"]*)\"$")
    public void theUserValidatesThatTheElementIsAtTheDesktopWindow(String fieldName,
                                                                   String windowName,
                                                                   String validationID,
                                                                   String onFailureFlag) throws GeneralLeanFtException {
        DesktopContext.getInstance().setCurrentLeanFTWindow(getDesktopWindow(windowName));
        boolean focused = getDesktopObject(fieldName, windowName).exists() != null;
        final String compareDescription = String.format("Expecting %s to be present at the %s window", fieldName, windowName);

        TestContext.getInstance().testdata().put(VALIDATION_TAG + validationID, compareDescription + ": " + focused);

        if (onFailureFlag.equals(HARD_STOP_ON_FAILURE)) {
            assertThat(focused).as(compareDescription).isTrue();
        } else {
            sa().assertThat(focused).as(compareDescription).isTrue();
        }
    }

    @Then("^the user validates the \"([^\"]*)\" object is not present at the \"([^\"]*)\" desktop window \"([^\"]*)\" \"([^\"]*)\"$")
    public void theUserValidatesThatTheElementIsNotAtTheDesktopWindow(String fieldName,
                                                                      String windowName,
                                                                      String validationID,
                                                                      String onFailureFlag) throws GeneralLeanFtException {

        DesktopContext.getInstance().setCurrentLeanFTWindow(getDesktopWindow(windowName));
        boolean focused = getDesktopObject(fieldName, windowName).exists() == null;
        final String compareDescription = String.format("Expecting %s to be not present at the %s window", fieldName, windowName);

        TestContext.getInstance().testdata().put(VALIDATION_TAG + validationID, compareDescription + ": " + focused);

        if (onFailureFlag.equals(HARD_STOP_ON_FAILURE)) {
            assertThat(focused).as(compareDescription).isFalse();
        } else {
            sa().assertThat(focused).as(compareDescription).isFalse();
        }
        if (!focused) {
            Reporter.addStepLog(STATUS_FAIL, VALIDATION_FAILED + compareDescription);
        }
    }

    @Then("^the user validates \"([^\"]*)\" that the value of the \"([^\"]*)\" label on the \"([^\"]*)\" desktop window is \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void theUserValidatesThatTheValueOfTheLabelOnTheDesktopWindowIs(String comparisonType,
                                                                           String labelName,
                                                                           String windowName,
                                                                           String comparisonOperator,
                                                                           String expectedValue,
                                                                           String validationID,
                                                                           String onFailureFlag) throws GeneralLeanFtException {
        DesktopContext.getInstance().setCurrentLeanFTWindow(getDesktopWindow(windowName));
        String actualValue = getDesktopLabel(labelName, windowName).getText();
        expectedValue = parseValue(expectedValue);

        AssertHelper validator = new AssertHelper(comparisonType, comparisonOperator, onFailureFlag);
        TestContext.getInstance().testdataPut(VALIDATION_TAG + validationID, validator.getResultMessage(actualValue, expectedValue));
        validator.performValidation(actualValue, expectedValue, validationID,
                                    String.format("'%s' label value validation on the desktop window", labelName));
    }

    @Then("^the user validates \"([^\"]*)\" that the value of the \"([^\"]*)\" web label on the \"([^\"]*)\" desktop window is \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void theUserValidatesThatTheValueOfTheWebLabelOnTheDesktopWindowIs(String comparisonType,
                                                                              String labelName,
                                                                              String windowName,
                                                                              String comparisonOperator,
                                                                              String expectedValue,
                                                                              String validationID,
                                                                              String onFailureFlag) throws GeneralLeanFtException {
        DesktopContext.getInstance().setCurrentLeanFTWindow(getDesktopWindow(windowName));
        String actualValue = getDesktopWebElement(labelName, windowName).getText();
        expectedValue = parseValue(expectedValue);

        AssertHelper validator = new AssertHelper(comparisonType, comparisonOperator, onFailureFlag);
        TestContext.getInstance().testdataPut(VALIDATION_TAG + validationID, validator.getResultMessage(actualValue, expectedValue));
        validator.performValidation(actualValue, expectedValue, validationID,
                                    String.format("'%s' label value validation on the desktop window", labelName));
    }

    @Then("^the user validates the cell at row \"([^\"]*)\" and column \"([^\"]*)\" of the \"([^\"]*)\" table at the \"([^\"]*)\" window \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void theUserValidatesTheCellAtRowAndColumnOfTheTableAtThePage(String rowNum,
                                                                         String colNum,
                                                                         String tableName,
                                                                         String pageName,
                                                                         String comparisonOperator,
                                                                         String expectedValue,
                                                                         String validationID,
                                                                         String onFailureFlag) throws GeneralLeanFtException {

        DesktopContext.getInstance().setCurrentLeanFTWindow(getDesktopWindow(pageName));
        expectedValue = parseValue(expectedValue);
        String actualValue = getDesktopTable(tableName, pageName).getCellText(Integer.parseInt(rowNum), Integer.parseInt(colNum));
        AssertHelper validator = new AssertHelper(ComparisonType.COMPARE_STRINGS, ComparisonOperator.valueOfLabel(comparisonOperator), onFailureFlag);
        validator.performValidation(actualValue, expectedValue,
                                    validationID,
                                    String.format("Table cell value at row '%s' and column '%s' of the '%s' table", rowNum, colNum, tableName));
    }

    @Then("^the user validates the \"([^\"]*)\" object is disabled at the \"([^\"]*)\" desktop window \"([^\"]*)\" \"([^\"]*)\"$")
    public void theUserValidatesTheElementIsDisabledAtThePage(String fieldName,
                                                              String windowName,
                                                              String validationID,
                                                              String onFailureFlag) throws GeneralLeanFtException {

        DesktopContext.getInstance().setCurrentLeanFTWindow(getDesktopWindow(windowName));
        boolean isObjectEnabled = getDesktopObject(fieldName, windowName).isEnabled();
        final String compareDescription = String.format("Expected %s to be disabled at the %s page", fieldName, windowName);

        TestContext.getInstance().testdata().put(VALIDATION_TAG + validationID, compareDescription + ": " + isObjectEnabled);

        if (onFailureFlag.equals(HARD_STOP_ON_FAILURE)) {
            assertThat(isObjectEnabled).as(compareDescription).isFalse();
        } else {
            sa().assertThat(isObjectEnabled).as(compareDescription).isFalse();
        }
        if (isObjectEnabled) {
            Reporter.addStepLog(STATUS_FAIL, VALIDATION_FAILED + compareDescription);
        }
    }

    @Then("^the user validates the \"([^\"]*)\" listview is empty at the \"([^\"]*)\" desktop window \"([^\"]*)\" \"([^\"]*)\"$")
    public void theUserValidatesTheListViewIsEmptyAtThePage(String listView,
                                                              String windowName,
                                                              String validationID,
                                                              String onFailureFlag) throws GeneralLeanFtException {

        DesktopContext.getInstance().setCurrentLeanFTWindow(getDesktopWindow(windowName));
        boolean isObjectEmpty = getDesktopListView(listView, windowName).isEmpty();
        final String compareDescription = String.format("Expected %s to be empty at the %s page", listView, windowName);

        TestContext.getInstance().testdata().put(VALIDATION_TAG + validationID, compareDescription + ": " + isObjectEmpty);

        if (onFailureFlag.equals(HARD_STOP_ON_FAILURE)) {
            assertThat(isObjectEmpty).as(compareDescription).isTrue();
        } else {
            sa().assertThat(isObjectEmpty).as(compareDescription).isTrue();
        }
        if (isObjectEmpty) {
            Reporter.addStepLog(STATUS_FAIL, VALIDATION_FAILED + compareDescription);
        }
    }
    @Then("^the user validates the \"([^\"]*)\" object is enabled at the \"([^\"]*)\" desktop window \"([^\"]*)\" \"([^\"]*)\"$")
    public void theUserValidatesTheElementIsEnabledAtThePage(String fieldName,
                                                             String windowName,
                                                             String validationID,
                                                             String onFailureFlag) throws GeneralLeanFtException {

        DesktopContext.getInstance().setCurrentLeanFTWindow(getDesktopWindow(windowName));
        boolean isObjectEnabled = getDesktopObject(fieldName, windowName).isEnabled();
        final String compareDescription = String.format("Expected %s to be enabled at the %s page", fieldName, windowName);

        TestContext.getInstance().testdata().put(VALIDATION_TAG + validationID, compareDescription + ": " + isObjectEnabled);

        if (onFailureFlag.equals(HARD_STOP_ON_FAILURE)) {
            assertThat(isObjectEnabled).as(compareDescription).isTrue();
        } else {
            sa().assertThat(isObjectEnabled).as(compareDescription).isTrue();
        }
        if (!isObjectEnabled) {
            Reporter.addStepLog(STATUS_FAIL, VALIDATION_FAILED + compareDescription);
        }
    }

    @Then("^the user validates \"([^\"]*)\" that the value of the \"([^\"]*)\" listView on the \"([^\"]*)\" desktop window is \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void theUserValidatesThatTheValueOfTheListViewOnTheDesktopWindowIs(String comparisonType,
                                                                              String listView,
                                                                              String windowName,
                                                                              String comparisonOperator,
                                                                              String expectedValue,
                                                                              String validationID,
                                                                              String onFailureFlag) throws GeneralLeanFtException {
        DesktopContext.getInstance().setCurrentLeanFTWindow(getDesktopWindow(windowName));
        String actualValue = getDesktopListView(listView, windowName).getText();
        expectedValue = parseValue(expectedValue);

        AssertHelper validator = new AssertHelper(comparisonType, comparisonOperator, onFailureFlag);
        TestContext.getInstance().testdataPut(VALIDATION_TAG + validationID, validator.getResultMessage(actualValue, expectedValue));
        validator.performValidation(actualValue, expectedValue, validationID,
                                    String.format("'%s' ListView value validation on the desktop window", listView));
    }

    @Then("^the user validates the \"([^\"]*)\" checkbox is checked at the \"([^\"]*)\" desktop window \"([^\"]*)\" \"([^\"]*)\"$")
    public void theUserValidatesTheCheckboxIsCheckedAtTheDesktopWindow(String fieldName,
                                                                       String windowName,
                                                                       String validationID,
                                                                       String onFailureFlag) throws GeneralLeanFtException {

        DesktopContext.getInstance().setCurrentLeanFTWindow(getDesktopWindow(windowName));
        boolean checkBoxSelected = getDesktopCheckbox(fieldName, windowName).isChecked();
        final String compareDescription = String.format("Expected %s to be checked at the %s desktop window", fieldName, windowName);
        Reporter.addStepLog(compareDescription);
        TestContext.getInstance().testdata().put(VALIDATION_TAG + validationID, compareDescription + ": " + checkBoxSelected);

        if (onFailureFlag.equals(HARD_STOP_ON_FAILURE)) {
            assertThat(checkBoxSelected).as(compareDescription).isTrue();
        } else {
            sa().assertThat(checkBoxSelected).as(compareDescription).isTrue();
        }
        if (!checkBoxSelected) {
            Reporter.addStepLog(STATUS_FAIL, VALIDATION_FAILED + compareDescription);
        }
    }

    @Then("^the user validates \"([^\"]*)\" that the selected value of the \"([^\"]*)\" combobox on the \"([^\"]*)\" desktop window is \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void theUserValidatesThatTheSelectedValueOfTheComboBoxOnTheDesktopWindowIs(String comparisonType,
                                                                                      String combobox,
                                                                                      String windowName,
                                                                                      String comparisonOperator,
                                                                                      String expectedValue,
                                                                                      String validationID,
                                                                                      String onFailureFlag) throws GeneralLeanFtException {
        DesktopContext.getInstance().setCurrentLeanFTWindow(getDesktopWindow(windowName));
        String actualValue = getDesktopComboBox(combobox, windowName).getSelectedItem();
        expectedValue = parseValue(expectedValue);

        AssertHelper validator = new AssertHelper(comparisonType, comparisonOperator, onFailureFlag);
        TestContext.getInstance().testdataPut(VALIDATION_TAG + validationID, validator.getResultMessage(actualValue, expectedValue));
        validator.performValidation(actualValue, expectedValue, validationID,
                                    String.format("'%s' Combobox value validation on the desktop window", combobox));
    }


}
