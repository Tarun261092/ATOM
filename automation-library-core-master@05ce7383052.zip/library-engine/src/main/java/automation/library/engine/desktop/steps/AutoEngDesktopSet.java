package automation.library.engine.desktop.steps;

import automation.library.engine.desktop.BaseDesktopSteps;
import automation.library.leanft.exec.DesktopContext;
import com.hp.lft.sdk.GeneralLeanFtException;
import io.cucumber.java.en.When;

public class AutoEngDesktopSet extends BaseDesktopSteps {

    @When("^the user enters \"([^\"]*)\" into the \"([^\"]*)\" textbox at the \"([^\"]*)\" desktop window$")
    public void theUserEntersIntoTheFieldOnTheDesktopWindow(String value, String fieldName, String windowName) throws GeneralLeanFtException {
        DesktopContext.getInstance().setCurrentLeanFTWindow(getDesktopWindow(windowName));
        value = parseValue(value);
        getDesktopEditField(fieldName, windowName).setText(value);
        logStepMessage(String.format(ENTERED_VALUE, value));
    }
    @When("^the user enters \"([^\"]*)\" into the \"([^\"]*)\" textbox at the using Keyboard \"([^\"]*)\" desktop window$")
    public void theUserEntersIntoTheFieldOnTheDesktopWindowUsingKeyboard(String value, String fieldName, String windowName) throws GeneralLeanFtException {
        DesktopContext.getInstance().setCurrentLeanFTWindow(getDesktopWindow(windowName));
        value = parseValue(value);
        getDesktopEditField(fieldName, windowName).setString(value);
        logStepMessage(String.format(ENTERED_VALUE, value));
    }

    @When("^the user enters \"([^\"]*)\" into the \"([^\"]*)\" uiobject at the \"([^\"]*)\" desktop window$")
    public void theUserEntersIntoTheUIObjectOnTheDesktopWindow(String value, String fieldName, String windowName) throws GeneralLeanFtException {
        DesktopContext.getInstance().setCurrentLeanFTWindow(getDesktopWindow(windowName));
        value = parseValue(value);
        getDesktopUiObject(fieldName, windowName).sendKeys(value);
        logStepMessage(String.format(ENTERED_VALUE, value));
    }

    @When("^the user enters \"([^\"]*)\" into the \"([^\"]*)\" Editor at the \"([^\"]*)\" desktop window$")
    public void theUserEntersIntoTheEditorFieldOnTheDesktopWindow(String value, String objectName, String windowName) throws GeneralLeanFtException {
        DesktopContext.getInstance().setCurrentLeanFTWindow(getDesktopWindow(windowName));
        value = parseValue(value);
        getDesktopEditor(objectName, windowName).sendKeys(value);
        logStepMessage(String.format(ENTERED_VALUE, value));
    }

    @When("^the user enters \"([^\"]*)\" into the \"([^\"]*)\" textbox at the \"([^\"]*)\" desktop dialog window")
    public void theUserEntersIntoTheFieldOnTheDesktopDialog(String value, String fieldName, String dialogName) throws GeneralLeanFtException {
        DesktopContext.getInstance().setCurrentLeanFTDialog(getDesktopDialog(dialogName));
        value = parseValue(value);
        getDesktopEditField(fieldName, dialogName).setText(value);
        logStepMessage(String.format(ENTERED_VALUE, value));
    }

    @When("^the user enters the encrypted value \"([^\"]*)\" into the \"([^\"]*)\" textbox at the \"([^\"]*)\" desktop window$")
    public void theUserEntersTheSecureUserCredentialIntoTheTextboxAtTheDesktopWindow(String value,
                                                                                     String fieldName,
                                                                                     String windowName) throws GeneralLeanFtException {
        String valToEnter = parseSecureText(value);
        DesktopContext.getInstance().setCurrentLeanFTWindow(getDesktopWindow(windowName));
        getDesktopEditField(fieldName, windowName).setText(valToEnter);
    }

    @When("^the user enters the encrypted value \"([^\"]*)\" into the \"([^\"]*)\" textbox at the \"([^\"]*)\" desktop dialog window$")
    public void theUserEntersTheSecureUserCredentialIntoTheTextboxAtTheDesktopDialogWindow(String value,
                                                                                           String fieldName,
                                                                                           String dialogWindow) throws GeneralLeanFtException {
        String valToEnter = parseSecureText(value);
        DesktopContext.getInstance().setCurrentLeanFTDialog(getDesktopDialog(dialogWindow));
        getDesktopEditField(fieldName, dialogWindow).setText(valToEnter);
    }
}