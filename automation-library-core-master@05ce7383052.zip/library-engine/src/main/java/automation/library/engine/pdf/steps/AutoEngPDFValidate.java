package automation.library.engine.pdf.steps;

import static automation.library.engine.core.AutoEngConstants.PDF;
import static org.assertj.core.api.Assertions.assertThat;

import java.awt.Rectangle;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.apache.logging.log4j.util.Strings;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.text.PDFTextStripper;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.google.gson.Gson;

import automation.library.common.FileHelper;
import automation.library.common.PDFHelper;
import automation.library.common.TestContext;
import automation.library.engine.core.objects.StringRuleDefination;
import automation.library.engine.core.validator.AssertHelper;
import automation.library.engine.core.validator.ComparisonOperator;
import automation.library.engine.core.validator.ComparisonType;
import automation.library.engine.pdf.BasePDFSteps;
import automation.library.reporting.Reporter;
import automation.library.selenium.core.Constants;
import automation.library.selenium.exec.driver.factory.DriverContext;
import io.cucumber.java.en.Then;
import io.qameta.allure.Allure;

public class AutoEngPDFValidate extends BasePDFSteps {
	private static final String HARD_STOP_ON_FAILURE = "HardStopOnFailure";
	private static final String SCRIPT_FILE_PATH_TO_CONVERT_EMAIL_TO_PDF = "/ff-lookup/EmailToPDFMacroTool/mtp1.vbs";
	private static final String MACRO_FILE_PATH_TO_CONVERT_EMAIL_TO_PDF = "/ff-lookup/EmailToPDFMacroTool/PDF_Conversion_V6.3.xlsm";

	@Then("^the user validates the currently active pdf is in \"([^\"]*)\" orientation \"([^\"]*)\" \"([^\"]*)\"$")
	public void thePDFIsInPortraitMode(String orientation,
			String validationID,
			String onFailureFlag) throws IllegalAccessException {
		PDDocument document = getActivePDF();
		PDPage page = PDFHelper.getPDFPage(document, 0);
		PDRectangle mediaBox = page.getMediaBox();

		TestContext.getInstance().testdata().put(CURRENT_PAGE_PDF, -1);

		final String compareDescription = String.format("Expecting pdf to be in %s orientation", orientation);
		TestContext.getInstance().testdata().put(VALIDATION_TAG + validationID, compareDescription);

		boolean isLandscape = mediaBox.getWidth() > mediaBox.getHeight();
		boolean expectedOrientation = orientation.equalsIgnoreCase("landscape");

		if (onFailureFlag.equals(HARD_STOP_ON_FAILURE)) {
			assertThat(isLandscape).isEqualTo(expectedOrientation);
		} else {
			sa().assertThat(isLandscape).isEqualTo(expectedOrientation);
			if (isLandscape != expectedOrientation) {
				Reporter.addStepLog(STATUS_FAIL, VALIDATION_FAILED + compareDescription);
			}
		}
	}

	@Then("^the user validates the currently active pdf \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void thePDFContainsText(String comparisonOperator,
			String textToFind,
			String validationID,
			String onFailureFlag) throws IllegalAccessException {

		PDDocument document = getActivePDF();
		textToFind = parseValue(textToFind);
		String pdfDocumentText = PDFHelper.getPDFText(document);
		String actualResult = searchPDFForPattern(textToFind, pdfDocumentText);

		int pdfPageNum = PDFHelper.getPDFPageNumber(document, textToFind);

		if (pdfPageNum == 0) {
			TestContext.getInstance().testdata().put(CURRENT_PAGE_PDF, -1);
		} else {
			TestContext.getInstance().testdata().put(CURRENT_PAGE_PDF, pdfPageNum);
		}

		AssertHelper validator = new AssertHelper(ComparisonType.COMPARE_STRINGS, ComparisonOperator.valueOfLabel(comparisonOperator), onFailureFlag);
		validator.performValidation(actualResult.trim(), textToFind, validationID, "PDF text comparison");
	}

	@Then("^the user validates table contents in the currently active pdf where value1 \"([^\"]*)\" and value2 \"([^\"]*)\" are present in the same row \"([^\"]*)\" \"([^\"]*)\"$")
	public void thePDFTableContainsValue1Value2InSameRow(String textToFind1,
			String textToFind2,
			String validationID,
			String onFailureFlag) throws IllegalAccessException {

		PDDocument document = getActivePDF();
		textToFind1 = parseValue(textToFind1);
		textToFind2 = parseValue(textToFind2);

		final String compareDescription = String.format("Expecting pdf table to contain %s and %s in the same row", textToFind1, textToFind2);
		TestContext.getInstance().testdata().put(VALIDATION_TAG + validationID, compareDescription);

		String pdfDocumentText = PDFHelper.getPDFText(document);
		String actualResult = searchPDFForPatternDynamic(textToFind1, pdfDocumentText, textToFind2);

		if (onFailureFlag.equals(HARD_STOP_ON_FAILURE)) {
			if (actualResult != null && actualResult.contains(textToFind1) && actualResult.contains(textToFind2)) {
				assertThat(actualResult).as(compareDescription).isNotNull();
				int pdfPageNum = PDFHelper.getPDFPageNumber(document, actualResult);
				Reporter.addStepLog(String.format("Values %s and %s are present in the same row on the pdf table", textToFind1, textToFind2));
				log.debug(String.format("Values %s and %s are present in the same row on the pdf table", textToFind1, textToFind2));
				TestContext.getInstance().testdata().put(CURRENT_PAGE_PDF, pdfPageNum);
			} else {
				TestContext.getInstance().testdata().put(CURRENT_PAGE_PDF, -1);
				assertThat(actualResult).as(compareDescription).isNotNull();
			}
		} else {
			sa().assertThat(actualResult).as(compareDescription).isNotNull();
			if (actualResult == null) {
				TestContext.getInstance().testdata().put(CURRENT_PAGE_PDF, -1);
				Reporter.addStepLog(STATUS_FAIL, VALIDATION_FAILED + compareDescription);
			}
		}
	}

	@Then("^the user validates the currently active pdf \"([^\"]*)\" \"([^\"]*)\" on page \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void thePDFContainsTextOnPage(String comparisonOperator,
			String textToFind,
			int pageNum,
			String validationID,
			String onFailureFlag) throws IllegalAccessException {

		//route to other step def with same start and end
		thePDFContainsTextBetweenPages(comparisonOperator, textToFind, pageNum, pageNum, validationID, onFailureFlag);
	}

	@Then("^the user validates the currently active pdf \"([^\"]*)\" \"([^\"]*)\" between pages \"([^\"]*)\" to \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void thePDFContainsTextBetweenPages(String comparisonOperator,
			String textToFind,
			int pageNumStart,
			int pageNumEnd,
			String validationID,
			String onFailureFlag) throws IllegalAccessException {
		PDDocument document = getActivePDF();
		textToFind = parseValue(textToFind);

		String pdfDocumentText = PDFHelper.getPDFText(document, pageNumStart, pageNumEnd);

		String actualResult = searchPDFForPattern(textToFind, pdfDocumentText);

		int pdfPageNum = PDFHelper.getPDFPageNumberInBetweenDoc(document, textToFind, pageNumStart, pageNumEnd);

		TestContext.getInstance().testdata().put(CURRENT_PAGE_PDF, pdfPageNum);

		if (pdfPageNum == 0) {
			TestContext.getInstance().testdata().put(PGNUM_START_PDF, pageNumStart);
			TestContext.getInstance().testdata().put(PGNUM_END_PDF, pageNumEnd);
		}

		AssertHelper validator = new AssertHelper(ComparisonType.COMPARE_STRINGS, ComparisonOperator.valueOfLabel(comparisonOperator), onFailureFlag);
		validator.performValidation(actualResult, textToFind,
				validationID,
				String.format("PDF text comparison between pages '%s' and %s'", pageNumStart, pageNumEnd));
	}

	@Then("^the user validates the currently active pdf \"([^\"]*)\" \"([^\"]*)\" on page \"([^\"]*)\" at rectangle \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void thePDFContainsTextOnPageAtRectangle(String comparisonOperator,
			String textToFind,
			int pageNum,
			String rectangleCoords,
			String validationID,
			String onFailureFlag) throws IllegalAccessException {

		rectangleCoords = parseValue(rectangleCoords);

		List<Integer> coordinates = Arrays.stream(rectangleCoords.split("\\|"))
				.map(Integer::parseInt)
				.collect(Collectors.toList());

		if (!coordinates.isEmpty()) {
			Rectangle rectangleToSearch = new Rectangle(coordinates.get(0), coordinates.get(1), coordinates.get(2), coordinates.get(3));
			PDDocument document = getActivePDF();
			textToFind = parseValue(textToFind);

			String pdfDocumentText = PDFHelper.getPDFText(document, pageNum, rectangleToSearch);
			String actualResult = searchPDFForPattern(textToFind, pdfDocumentText);

			TestContext.getInstance().testdata().put(CURRENT_PAGE_PDF, pageNum);

			AssertHelper validator = new AssertHelper(ComparisonType.COMPARE_STRINGS, ComparisonOperator.valueOfLabel(comparisonOperator), onFailureFlag);
			validator.performValidation(actualResult, textToFind,
					validationID,
					String.format("PDF comparison on page '%s' at a given location", pageNum));
		}
	}

	@Then("^the user validates \"([^\"]*)\" for the currently active pdf \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")                                                              
	public void pdfImageValidation(String PDF_ValidateLogoColor,String pathToFile, String pdfTemplateName, String boldTexts,String italics,String validationId,String OnFailureFlag ) throws IllegalAccessException, InterruptedException {

		Thread.sleep(10000);
		//String downloadSettings = Property.getProperty(Constants.SELENIUMRUNTIMEPATH, "prefs.chrome.overrideDownloadSettings");
		//if(Boolean.parseBoolean(downloadSettings)) {
		//String downloadDir = Paths.get(Constants.DOWNLOADPATH).toAbsolutePath().toString();
		//pathToFile = downloadDir+"\\"+FileHelper.getLatestFilefromDir(downloadDir)+"";
		//} 
		//else
		//{ pathToFile = parseValue(pathToFile);

		//}
		pathToFile = parseValue(pathToFile);

		if(pathToFile.equals("None")) {
			String downloadDir = Paths.get(Constants.DOWNLOADPATH).toAbsolutePath().toString();
			pathToFile = downloadDir+"\\"+FileHelper.getLatestFilefromDir(downloadDir)+"";
		}else {
			pathToFile = parseValue(pathToFile);
		} 
		PDF_ValidateLogoColor = parseValue(PDF_ValidateLogoColor);
		pdfTemplateName = parseValue(pdfTemplateName);
		List<String> boldTextToFind = new ArrayList<String>();
		List<String> italicTextToFind=new ArrayList<String>();
		int i=0;
		int j=0;
		boldTextToFind= (List<String>) parseValueToObject(boldTexts);
		italicTextToFind = (List<String>) parseValueToObject(italics);
		TestContext.getInstance().testdataPut("fw.PDFCurrentPageNumber", -1);
		TestContext.getInstance().testdataPut("fw.PDFPageNumStart", 0);
		TestContext.getInstance().testdataPut("fw.PDFPageNumEnd", 0);
		TestContext.getInstance().testdataPut("fw.filePath", pathToFile);
		PDDocument pdfDoc=PDFHelper.getDoc(pathToFile);
		String validtionOutput=Strings.EMPTY;
		TestContext.getInstance().setActiveWindowType(PDF);
		//String downloadDir = Paths.get(Constants.DOWNLOADPATH).toAbsolutePath().toString();

		String downloadDir =new File(pathToFile).getParent();
		String fname =new File(pathToFile).getName();
		//zs75946 - 1/21

		List<String> ImageSrc=new ArrayList<String>();
		String strImageSrc="Nourl";

		if(pdfTemplateName.contains("Thankyouweb")) {


			List<WebElement> links=DriverContext.getInstance().getDriver().findElements(By.tagName("img"));

			for(WebElement ele:links){


				ImageSrc.add(ele.getAttribute("src").toString());
			} 

			List<WebElement> imgs = DriverContext.getInstance().getDriver().findElements(By.xpath("//*[contains(@style,'url')]"));
			for(WebElement img:imgs)
			{
				String image=img.getAttribute("style");
				String actual_image_url=(StringUtils.substringBetween(image, "(\"", "\")")).trim();

				ImageSrc.add(actual_image_url);
			}


			Gson gson = new Gson();
			strImageSrc = 	gson.toJson(ImageSrc);
		}


		// zs75946 - 1/21
		try {

			validtionOutput = validateLogoAndImageInPDF(pathToFile, pdfDoc,downloadDir,PDF_ValidateLogoColor,pdfTemplateName,boldTextToFind,italicTextToFind,strImageSrc);
			boolean fontPassBoldStatus=true;
			boolean fontPassItalicsStatus=true;
			if(validtionOutput.contains("Internal processing error")) {
				Reporter.addStepLog(STATUS_FAIL, VALIDATION_FAILED + "Exception in evaluating PDF");
				return;
			}
			else if(validtionOutput.contains("No match found")) {
				Reporter.addStepLog(STATUS_FAIL, VALIDATION_FAILED + "No image and logo and Font found");
				return;
			}
			else if(validtionOutput.contains("Logo And Color and Font Validation OutPut")) {

				PDDocument pdfOutDoc=PDFHelper.getDoc(downloadDir+"//Output_"+fname);
				TestContext.getInstance().testdataPut(ACTIVE_PDF, pdfOutDoc);
				System.out.println("--bold--"+validtionOutput.toString().contains(boldTextToFind.get(0).toString().trim()));
				if(italicTextToFind.size() >0)
					System.out.println("--italics--"+validtionOutput.toString().contains(italicTextToFind.get(0).toString().trim()));
				System.out.println("----"+validtionOutput+"----");
				System.out.println("----"+boldTextToFind+"----");
				if(validtionOutput.contains("Logo And Color and Font Validation OutPut") && !validtionOutput.contains("No bold/italics font found in pdf") && !validtionOutput.contains("Color validation failed") && !validtionOutput.contains("Citi logo validation failed"))
				{

					for(int bold=0;bold<boldTextToFind.size();bold++) {
						if(validtionOutput.contains(boldTextToFind.get(bold).toString()))
							fontPassBoldStatus=true;
						else
							fontPassBoldStatus=false;
					}	
					for(int italicsc=0;italicsc<italicTextToFind.size();italicsc++) {
						if(validtionOutput.contains(italicTextToFind.get(italicsc).toString()))
							fontPassItalicsStatus=true;
						else
							fontPassItalicsStatus=false;
					}
					if(fontPassItalicsStatus&&fontPassBoldStatus) {
						AssertHelper validator = new AssertHelper(ComparisonType.COMPARE_STRINGS,ComparisonOperator.CONTAINS,"HardStopOnFailure");
						validator.performValidation(validtionOutput, validtionOutput,
								validationId,
								OnFailureFlag);
					}
					else {
						Reporter.addStepLog(STATUS_FAIL, VALIDATION_FAILED + "1. Color Validation--> Success 2.Logo Validation--> Success 3..Font Validation Failed As Text<<"+boldTextToFind.toString()+" "+italicTextToFind.toString()+">> missing in PDF ");

						assertThat(fontPassBoldStatus).isEqualTo(true);
						assertThat(fontPassBoldStatus).isEqualTo(true);
					}


				}
				else if(validtionOutput.contains("Color validation failed") && !validtionOutput.contains("Citi logo validation failed")){
					for(int bold=0;bold<boldTextToFind.size();bold++) {
						if(validtionOutput.contains(boldTextToFind.get(bold).toString()))
							fontPassBoldStatus=true;
						else
							fontPassBoldStatus=false;
					}	
					for(int italicsc=0;italicsc<italicTextToFind.size();italicsc++) {
						if(validtionOutput.contains(italicTextToFind.get(italicsc).toString()))
							fontPassItalicsStatus=true;
						else
							fontPassItalicsStatus=false;
					}
					if(fontPassItalicsStatus&&fontPassBoldStatus) {
						Reporter.addStepLog(STATUS_FAIL, VALIDATION_FAILED + "1. Color Validation--> Failed 2.Logo Validation--> Success 3..Font Validation Failed As Text<<"+boldTextToFind.toString()+" "+italicTextToFind.toString()+">> missing in PDF ");
						assertThat(fontPassBoldStatus).isEqualTo(true);
						assertThat(fontPassBoldStatus).isEqualTo(true);
						assertThat(validtionOutput).doesNotContain("Citi logo validation failed");
						assertThat(validtionOutput).doesNotContain("Color validation failed");
					}
					else {
						Reporter.addStepLog(STATUS_FAIL, VALIDATION_FAILED + "1. Color Validation--> Failed 2.Logo Validation--> Success 3..Font Validation Failed As Text<<"+boldTextToFind.toString()+" "+italicTextToFind.toString()+">> missing in PDF ");
						assertThat(fontPassBoldStatus).isEqualTo(true);
						assertThat(fontPassBoldStatus).isEqualTo(true);
						assertThat(validtionOutput).doesNotContain("Citi logo validation failed");
						assertThat(validtionOutput).doesNotContain("Color validation failed");
					}


				}
				else if(!validtionOutput.contains("Color validation failed") && validtionOutput.contains("Citi logo validation failed")){
					for(int bold=0;bold<boldTextToFind.size();bold++) {
						if(validtionOutput.contains(boldTextToFind.get(bold).toString()))
							fontPassBoldStatus=true;
						else
							fontPassBoldStatus=false;
					}	
					for(int italicsc=0;italicsc<italicTextToFind.size();italicsc++) {
						if(validtionOutput.contains(italicTextToFind.get(italicsc).toString()))
							fontPassItalicsStatus=true;
						else
							fontPassItalicsStatus=false;
					}
					if(fontPassItalicsStatus&&fontPassBoldStatus) {
						Reporter.addStepLog(STATUS_FAIL, VALIDATION_FAILED + "1. Color Validation--> Sucess 2.Logo Validation--> Failed 3.Font Validation Failed As Text<<"+boldTextToFind.toString()+" "+italicTextToFind.toString()+">> missing in PDF ");
						assertThat(fontPassBoldStatus).isEqualTo(true);
						assertThat(fontPassBoldStatus).isEqualTo(true);
						assertThat(validtionOutput).doesNotContain("Citi logo validation failed");
						assertThat(validtionOutput).doesNotContain("Color validation failed");
					}
					else {
						Reporter.addStepLog(STATUS_FAIL, VALIDATION_FAILED + "1. Color Validation--> Success 2.Logo Validation--> Failed 3.Font Validation Failed As Text<<"+boldTextToFind.toString()+" "+italicTextToFind.toString()+">> missing in PDF ");
						assertThat(fontPassBoldStatus).isEqualTo(true);
						assertThat(fontPassBoldStatus).isEqualTo(true);
						assertThat(validtionOutput).doesNotContain("Citi logo validation failed");
						assertThat(validtionOutput).doesNotContain("Color validation failed");
					}


				}
				else if(!validtionOutput.contains("Color validation failed") && !validtionOutput.contains("Citi logo validation failed")){
					for(int bold=0;bold<boldTextToFind.size();bold++) {
						if(validtionOutput.contains(boldTextToFind.get(bold).toString()))
							fontPassBoldStatus=true;
						else
							fontPassBoldStatus=false;
					}	
					for(int italicsc=0;italicsc<italicTextToFind.size();italicsc++) {
						if(validtionOutput.contains(italicTextToFind.get(italicsc).toString()))
							fontPassItalicsStatus=true;
						else
							fontPassItalicsStatus=false;
					}
					if(fontPassItalicsStatus&&fontPassBoldStatus) {
						AssertHelper validator = new AssertHelper(ComparisonType.COMPARE_STRINGS,ComparisonOperator.CONTAINS,"HardStopOnFailure");
						validator.performValidation(validtionOutput, validtionOutput,
								validationId,
								OnFailureFlag);
					}
					else {
						Reporter.addStepLog(STATUS_FAIL, VALIDATION_FAILED + "1. Color Validation--> Sucess 2.Logo Validation--> Success 3.Font Validation Failed As Text<<"+boldTextToFind.toString()+" "+italicTextToFind.toString()+">> missing in PDF ");
						assertThat(fontPassBoldStatus).isEqualTo(true);
						assertThat(fontPassBoldStatus).isEqualTo(true);
						assertThat(validtionOutput).doesNotContain("Citi logo validation failed");
						assertThat(validtionOutput).doesNotContain("Color validation failed");
					}


				}
				else if(validtionOutput.contains("Color validation failed") && validtionOutput.contains("Citi logo validation failed")){
					for(int bold=0;bold<boldTextToFind.size();bold++) {
						if(validtionOutput.contains(boldTextToFind.get(bold).toString()))
							fontPassBoldStatus=true;
						else
							fontPassBoldStatus=false;
					}	
					for(int italicsc=0;italicsc<italicTextToFind.size();italicsc++) {
						if(validtionOutput.contains(italicTextToFind.get(italicsc).toString()))
							fontPassItalicsStatus=true;
						else
							fontPassItalicsStatus=false;
					}
					if(fontPassItalicsStatus&&fontPassBoldStatus) { 
						Reporter.addStepLog(STATUS_FAIL, VALIDATION_FAILED + "1. Color Validation--> Failed 2.Logo Validation--> Failed 3.Font Validation Success As Text<<"+boldTextToFind.toString()+" "+italicTextToFind.toString()+">> available in PDF ");
						assertThat(fontPassBoldStatus).isEqualTo(true);
						assertThat(fontPassBoldStatus).isEqualTo(true);
						assertThat(validtionOutput).doesNotContain("Citi logo validation failed");
						assertThat(validtionOutput).doesNotContain("Color validation failed");
					}
					else {
						Reporter.addStepLog(STATUS_FAIL, VALIDATION_FAILED + "1. Color Validation--> Failed 2.Logo Validation--> Failed 3.Font Validation Failed As Text<<"+boldTextToFind.toString()+" "+italicTextToFind.toString()+">> missing in PDF ");
						assertThat(fontPassBoldStatus).isEqualTo(true);
						assertThat(fontPassBoldStatus).isEqualTo(true);
						assertThat(validtionOutput).doesNotContain("Citi logo validation failed");
						assertThat(validtionOutput).doesNotContain("Color validation failed");
					}


				}
			}
			else if(validtionOutput.contains("Logo And Color Validation OutPut")) {

				PDDocument pdfOutDoc=PDFHelper.getDoc(downloadDir+"//Output_"+fname);
				TestContext.getInstance().testdataPut(ACTIVE_PDF, pdfOutDoc);
				if(validtionOutput.contains("Logo And Color Validation OutPut") && !validtionOutput.contains("Color validation failed") && !validtionOutput.contains("Citi logo validation failed"))
				{
					//Reporter.addStepLog("PASS","1. Logo Validation--> Success 2.Color Validation--> Success" );
					//assertThat(validtionOutput).doesNotContain("failed");
					AssertHelper validator = new AssertHelper(ComparisonType.COMPARE_STRINGS,ComparisonOperator.CONTAINS,"HardStopOnFailure");
					validator.performValidation(validtionOutput, validtionOutput,
							"123",
							"logo pass");
				}
				else {
					Reporter.addStepLog(STATUS_FAIL, VALIDATION_FAILED + validtionOutput.replace("Logo And Color and Font Validation OutPut:", ""));
					assertThat(validtionOutput).doesNotContain("failed");

				}
			}
			else if(validtionOutput.contains("Logo And Font Validation OutPut")) {

				PDDocument pdfOutDoc=PDFHelper.getDoc(downloadDir+"//Output_"+fname);
				TestContext.getInstance().testdataPut(ACTIVE_PDF, pdfOutDoc);
				System.out.println("--bold--"+validtionOutput.toString().contains(boldTextToFind.get(0).toString().trim()));
				if(italicTextToFind.size() >0)
					System.out.println("--italics--"+validtionOutput.toString().contains(italicTextToFind.get(0).toString().trim()));
				System.out.println("----"+validtionOutput+"----");
				System.out.println("----"+boldTextToFind+"----");
				if(validtionOutput.contains("Logo And Font Validation OutPut") && !validtionOutput.contains("No bold/italics font found in pdf") && !validtionOutput.contains("Citi logo validation failed"))
				{
					for(int bold=0;bold<boldTextToFind.size();bold++) {
						if(validtionOutput.contains(boldTextToFind.get(bold).toString()))
							fontPassBoldStatus=true;
						else
							fontPassBoldStatus=false;
					}	
					for(int italicsc=0;italicsc<italicTextToFind.size();italicsc++) {
						if(validtionOutput.contains(italicTextToFind.get(italicsc).toString()))
							fontPassItalicsStatus=true;
						else
							fontPassItalicsStatus=false;
					}
					if(fontPassItalicsStatus&&fontPassBoldStatus) {
						AssertHelper validator = new AssertHelper(ComparisonType.COMPARE_STRINGS,ComparisonOperator.CONTAINS,"HardStopOnFailure");
						validator.performValidation(validtionOutput, validtionOutput,
								validationId,
								OnFailureFlag);
					}
					else {
						Reporter.addStepLog(STATUS_FAIL, VALIDATION_FAILED + "1. Logo Validation--> Success 2.Font Validation Failed As Text<<"+boldTextToFind.toString()+" "+italicTextToFind.toString()+">> missing in PDF ");
						assertThat(fontPassBoldStatus).isEqualTo(true);
						assertThat(fontPassItalicsStatus).isEqualTo(true);
						assertThat(validtionOutput).doesNotContain("Citi logo validation failed");
					}


				}
				else if(!validtionOutput.contains("Citi logo validation failed")){
					for(int bold=0;bold<boldTextToFind.size();bold++) {
						if(validtionOutput.contains(boldTextToFind.get(bold).toString()))
							fontPassBoldStatus=true;
						else
							fontPassBoldStatus=false;
					}	
					for(int italicsc=0;italicsc<italicTextToFind.size();italicsc++) {
						if(validtionOutput.contains(italicTextToFind.get(italicsc).toString()))
							fontPassItalicsStatus=true;
						else
							fontPassItalicsStatus=false;
					}
					if(fontPassItalicsStatus&&fontPassBoldStatus) {
						Reporter.addStepLog(STATUS_FAIL, VALIDATION_FAILED + "1. Logo Validation--> Success 2.Font Validation Success As Text<<"+boldTextToFind.toString()+" "+italicTextToFind.toString()+">> available in PDF ");
						assertThat(fontPassBoldStatus).isEqualTo(true);
						assertThat(fontPassBoldStatus).isEqualTo(true);
						assertThat(validtionOutput).doesNotContain("Citi logo validation failed");
					}
					else {
						Reporter.addStepLog(STATUS_FAIL, VALIDATION_FAILED + "1. Logo Validation--> Success 2.Font Validation Failed As Text<<"+boldTextToFind.toString()+" "+italicTextToFind.toString()+">> missing in PDF ");
						assertThat(fontPassBoldStatus).isEqualTo(true);
						assertThat(fontPassBoldStatus).isEqualTo(true);
						assertThat(validtionOutput).doesNotContain("Citi logo validation failed");
					}
				}
				else {
					for(int bold=0;bold<boldTextToFind.size();bold++) {
						if(validtionOutput.contains(boldTextToFind.get(bold).toString()))
							fontPassBoldStatus=true;
						else
							fontPassBoldStatus=false;
					}	
					for(int italicsc=0;italicsc<italicTextToFind.size();italicsc++) {
						if(validtionOutput.contains(italicTextToFind.get(italicsc).toString()))
							fontPassItalicsStatus=true;
						else
							fontPassItalicsStatus=false;
					}
					if(fontPassItalicsStatus&&fontPassBoldStatus) {
						Reporter.addStepLog(STATUS_FAIL, VALIDATION_FAILED + "1. Logo Validation--> Failed 2.Font Validation Success As Text<<"+boldTextToFind.toString()+" "+italicTextToFind.toString()+">> available in PDF ");
						assertThat(fontPassBoldStatus).isEqualTo(true);
						assertThat(fontPassBoldStatus).isEqualTo(true);
						assertThat(validtionOutput).doesNotContain("Citi logo validation failed");
					}
					else {
						Reporter.addStepLog(STATUS_FAIL, VALIDATION_FAILED + "1. Logo Validation--> Failed 2.Font Validation Failed As Text<<"+boldTextToFind.toString()+" "+italicTextToFind.toString()+">> missing in PDF ");
						assertThat(fontPassBoldStatus).isEqualTo(true);
						assertThat(fontPassBoldStatus).isEqualTo(true);
						assertThat(validtionOutput).doesNotContain("Citi logo validation failed");
					}
				}
			}
			else if(validtionOutput.contains("Color And Font Validation OutPut")) {

				PDDocument pdfOutDoc=PDFHelper.getDoc(downloadDir+"//Output_"+fname);
				TestContext.getInstance().testdataPut(ACTIVE_PDF, pdfOutDoc);
				System.out.println("--bold--"+validtionOutput.toString().contains(boldTextToFind.get(0).toString().trim()));
				if(italicTextToFind.size() >0)
					System.out.println("--italics--"+validtionOutput.toString().contains(italicTextToFind.get(0).toString().trim()));
				System.out.println("----"+validtionOutput+"----");
				System.out.println("----"+boldTextToFind+"----");
				if(validtionOutput.contains("Color And Font Validation OutPut") && !validtionOutput.contains("No bold/italics font found in pdf") && !validtionOutput.contains("Color validation failed")) {
					for(int bold=0;bold<boldTextToFind.size();bold++) {
						if(validtionOutput.contains(boldTextToFind.get(bold).toString()))
							fontPassBoldStatus=true;
						else
							fontPassBoldStatus=false;
					}	
					for(int italicsc=0;italicsc<italicTextToFind.size();italicsc++) {
						if(validtionOutput.contains(italicTextToFind.get(italicsc).toString()))
							fontPassItalicsStatus=true;
						else
							fontPassItalicsStatus=false;
					}
					if(fontPassItalicsStatus&&fontPassBoldStatus) {
						AssertHelper validator = new AssertHelper(ComparisonType.COMPARE_STRINGS,ComparisonOperator.CONTAINS,"HardStopOnFailure");
						validator.performValidation(validtionOutput, validtionOutput,
								validationId,
								OnFailureFlag);
					}
					else {
						Reporter.addStepLog(STATUS_FAIL, VALIDATION_FAILED + "1. Color Validation--> Success 2.Font Validation Failed As Text<<"+boldTextToFind.toString()+" "+italicTextToFind.toString()+">> missing in PDF ");
						assertThat(fontPassBoldStatus).isEqualTo(true);
						assertThat(fontPassItalicsStatus).isEqualTo(true);
						assertThat(validtionOutput).doesNotContain("Color validation failed");
					}


				}
				else if(!validtionOutput.contains("Color validation failed")){
					for(int bold=0;bold<boldTextToFind.size();bold++) {
						if(validtionOutput.contains(boldTextToFind.get(bold).toString()))
							fontPassBoldStatus=true;
						else
							fontPassBoldStatus=false;
					}	
					for(int italicsc=0;italicsc<italicTextToFind.size();italicsc++) {
						if(validtionOutput.contains(italicTextToFind.get(italicsc).toString()))
							fontPassItalicsStatus=true;
						else
							fontPassItalicsStatus=false;
					}
					if(fontPassItalicsStatus&&fontPassBoldStatus) {
						Reporter.addStepLog(STATUS_FAIL, VALIDATION_FAILED + "1. Color Validation--> Success 2.Font Validation Success As Text<<"+boldTextToFind.toString()+" "+italicTextToFind.toString()+">> available in PDF ");
						assertThat(fontPassBoldStatus).isEqualTo(true);
						assertThat(fontPassBoldStatus).isEqualTo(true);
						assertThat(validtionOutput).doesNotContain("Color validation failed");
					}
					else {
						Reporter.addStepLog(STATUS_FAIL, VALIDATION_FAILED + "1. Color Validation--> Success 2.Font Validation Failed As Text<<"+boldTextToFind.toString()+" "+italicTextToFind.toString()+">> missing in PDF ");
						assertThat(fontPassBoldStatus).isEqualTo(true);
						assertThat(fontPassBoldStatus).isEqualTo(true);
						assertThat(validtionOutput).doesNotContain("Color validation failed");
					}
				}
				else {
					for(int bold=0;bold<boldTextToFind.size();bold++) {
						if(validtionOutput.contains(boldTextToFind.get(bold).toString()))
							fontPassBoldStatus=true;
						else
							fontPassBoldStatus=false;
					}	
					for(int italicsc=0;italicsc<italicTextToFind.size();italicsc++) {
						if(validtionOutput.contains(italicTextToFind.get(italicsc).toString()))
							fontPassItalicsStatus=true;
						else
							fontPassItalicsStatus=false;
					}
					if(fontPassItalicsStatus&&fontPassBoldStatus) {
						Reporter.addStepLog(STATUS_FAIL, VALIDATION_FAILED + "1. Color Validation--> Failed 2.Font Validation Success As Text<<"+boldTextToFind.toString()+" "+italicTextToFind.toString()+">> available in PDF ");
						assertThat(fontPassBoldStatus).isEqualTo(true);
						assertThat(fontPassItalicsStatus).isEqualTo(true);
						assertThat(validtionOutput).doesNotContain("Color validation failed");
					}
					else {
						Reporter.addStepLog(STATUS_FAIL, VALIDATION_FAILED + "1. Color Validation--> Failed 2.Font Validation Failed As Text<<"+boldTextToFind.toString()+" "+italicTextToFind.toString()+">> missing in PDF ");
						assertThat(fontPassBoldStatus).isEqualTo(true);
						assertThat(fontPassItalicsStatus).isEqualTo(true);
						assertThat(validtionOutput).doesNotContain("Color validation failed");
					}
				}
			}
			else if(validtionOutput.contains("Logo Validation OutPut")) {

				PDDocument pdfOutDoc=PDFHelper.getDoc(downloadDir+"//Output_"+fname);
				TestContext.getInstance().testdataPut(ACTIVE_PDF, pdfOutDoc);
				if(validtionOutput.contains("Logo Validation OutPut")  && !validtionOutput.contains("failed"))
				{

					//Reporter.addStepLog("PASS",validtionOutput.replace("Logo And Color and Font Validation OutPut:", ""));
					AssertHelper validator = new AssertHelper(ComparisonType.COMPARE_STRINGS,ComparisonOperator.CONTAINS,"HardStopOnFailure");
					validator.performValidation(validtionOutput, validtionOutput,
							validationId,
							OnFailureFlag);
					//assertThat(validtionOutput).doesNotContain("failed");

				}
				else {
					Reporter.addStepLog(STATUS_FAIL, VALIDATION_FAILED + validtionOutput.replace("Logo And Color and Font Validation OutPut:", ""));
					assertThat(validtionOutput).doesNotContain("failed");

				}
			}
			//zs75946
			else if(validtionOutput.contains("PDF layout validation")) {

				PDDocument pdfOutDoc=PDFHelper.getDoc(downloadDir+"//Output_"+fname);
				TestContext.getInstance().testdataPut(ACTIVE_PDF, pdfOutDoc);
				if(validtionOutput.contains("PDF layout validation")  && !validtionOutput.contains("failed"))
				{

					//Reporter.addStepLog("PASS",validtionOutput.replace("Logo And Color and Font Validation OutPut:", ""));
					AssertHelper validator = new AssertHelper(ComparisonType.COMPARE_STRINGS,ComparisonOperator.CONTAINS,"HardStopOnFailure");
					validator.performValidation(validtionOutput, validtionOutput,
							validationId,
							OnFailureFlag);
					//assertThat(validtionOutput).doesNotContain("failed");

				}
				else {
					Reporter.addStepLog(STATUS_FAIL, VALIDATION_FAILED + validtionOutput.replace("PDF layout validation:", ""));
					assertThat(validtionOutput).doesNotContain("failed");

				}
			}
			//zs75946	
			else if(validtionOutput.contains("Thankyou webpage")) {

				PDDocument pdfOutDoc=PDFHelper.getDoc(downloadDir+"//Output_"+fname);
				//TestContext.getInstance().testdataPut(ACTIVE_PDF, pdfOutDoc);
				FileInputStream fileInputStream = new FileInputStream(downloadDir+"//Output_"+fname);

				Allure.addAttachment("EvidenceFile",null,fileInputStream,"pdf");


				TestContext.getInstance().testdataPut("fw.excelPath", downloadDir+"//Output_"+fname);
				TestContext.getInstance().testdataPut("fw.stepExcelPath", downloadDir+"//Output_"+fname); 
				if(validtionOutput.contains("Thankyou webpage")  && !validtionOutput.contains("failed"))
				{

					//Reporter.addStepLog("PASS",validtionOutput.replace("Logo And Color and Font Validation OutPut:", ""));
					AssertHelper validator = new AssertHelper(ComparisonType.COMPARE_STRINGS,ComparisonOperator.CONTAINS,"HardStopOnFailure");
					validator.performValidation(validtionOutput, validtionOutput,
							validationId,
							OnFailureFlag);
					//assertThat(validtionOutput).doesNotContain("failed");

				}
				else {
					Reporter.addStepLog(STATUS_FAIL, VALIDATION_FAILED + validtionOutput.replace("PDF layout validation:", ""));
					assertThat(validtionOutput).doesNotContain("failed");

				}

			}

			else if(validtionOutput.contains("Font Validation OutPut")) {

				PDDocument pdfOutDoc=PDFHelper.getDoc(downloadDir+"//Output_"+fname);
				TestContext.getInstance().testdataPut(ACTIVE_PDF, pdfOutDoc);
				System.out.println("--bold--"+validtionOutput.toString().contains(boldTextToFind.get(0).toString().trim()));
				if(italicTextToFind.size() >0)
					System.out.println("--italics--"+validtionOutput.toString().contains(boldTextToFind.get(0).toString().trim()));
				System.out.println("----"+validtionOutput+"----");
				System.out.println("----"+boldTextToFind+"----");

				if(validtionOutput.contains("Font Validation OutPut") && !validtionOutput.contains("No bold/italics font found in pdf"))
				{
					for(int bold=0;bold<boldTextToFind.size();bold++) {
						if(validtionOutput.contains(boldTextToFind.get(bold).toString()))
							fontPassBoldStatus=true;
						else
							fontPassBoldStatus=false;
					}	
					for(int italicsc=0;italicsc<italicTextToFind.size();italicsc++) {
						if(validtionOutput.contains(italicTextToFind.get(italicsc).toString()))
							fontPassItalicsStatus=true;
						else
							fontPassItalicsStatus=false;
					}
					if(fontPassItalicsStatus&&fontPassBoldStatus) {
						AssertHelper validator = new AssertHelper(ComparisonType.COMPARE_STRINGS,ComparisonOperator.CONTAINS,"HardStopOnFailure");
						validator.performValidation(validtionOutput, validtionOutput,
								validationId,
								OnFailureFlag);
					}
					else {
						Reporter.addStepLog(STATUS_FAIL, VALIDATION_FAILED + "1.Font Validation Failed As Text<<"+boldTextToFind.toString()+" "+italicTextToFind.toString()+">> missing in PDF ");
						assertThat(fontPassBoldStatus).isEqualTo(true);
						assertThat(fontPassItalicsStatus).isEqualTo(true);
					}


				}
				else {
					for(int bold=0;bold<boldTextToFind.size();bold++) {
						if(validtionOutput.contains(boldTextToFind.get(bold).toString()))
							fontPassBoldStatus=true;
						else
							fontPassBoldStatus=false;
					}	
					for(int italicsc=0;italicsc<italicTextToFind.size();italicsc++) {
						if(validtionOutput.contains(italicTextToFind.get(italicsc).toString()))
							fontPassItalicsStatus=true;
						else
							fontPassItalicsStatus=false;
					}
					if(fontPassItalicsStatus&&fontPassBoldStatus) {
						Reporter.addStepLog(STATUS_FAIL, VALIDATION_FAILED + "1.Font Validation Success As Text<<"+boldTextToFind.toString()+" "+italicTextToFind.toString()+">> available in PDF ");
						assertThat(fontPassBoldStatus).isEqualTo(true);
						assertThat(fontPassBoldStatus).isEqualTo(true);
					}
					else {
						Reporter.addStepLog(STATUS_FAIL, VALIDATION_FAILED + "1.Font Validation Failed As Text<<"+boldTextToFind.toString()+" "+italicTextToFind.toString()+">> missing in PDF ");
						assertThat(fontPassBoldStatus).isEqualTo(true);
						assertThat(fontPassBoldStatus).isEqualTo(true);
					}
				}
			}
			else {
				PDDocument pdfOutDoc=PDFHelper.getDoc(downloadDir+"//Output_"+fname);
				TestContext.getInstance().testdataPut(ACTIVE_PDF, pdfOutDoc);
				if(validtionOutput.contains("Color Validation OutPut")  && !validtionOutput.contains("failed"))
				{
					AssertHelper validator = new AssertHelper(ComparisonType.COMPARE_STRINGS,ComparisonOperator.CONTAINS,"HardStopOnFailure");
					validator.performValidation(validtionOutput, validtionOutput,
							validationId,
							OnFailureFlag);

				}
				else {
					Reporter.addStepLog(STATUS_FAIL, VALIDATION_FAILED + validtionOutput.replace("Color Validation OutPut:", ""));
					assertThat(validtionOutput).doesNotContain("failed");

				}
			}
		} catch (IOException e) {
			Reporter.addStepLog(STATUS_FAIL, VALIDATION_FAILED + "Exception in internal program processing");
		}

	}
	// ED40177 Nov 12, 2021.  PDf Highlight Code Starts

	@Then("^the user highlights the pdf at \"([^\"]*)\" if text \"([^\"]*)\" is available \"([^\"]*)\" \"([^\"]*)\"$")
	public void userHighlightsTextOnPDF(String filePath,
			String textToFind,
			String validationID,
			String onFailureFlag) throws IOException, IllegalAccessException, InterruptedException {
		userHighlightsTextOnPDFPage(filePath,textToFind, "all", validationID,onFailureFlag);
	}
	@Then("^the user sets validtion rule for string expecting \"([^\"]*)\" in between \"([^\"]*)\" and \"([^\"]*)\" and adds to the rule in data dictonary with key \"([^\"]*)\"$")

	public void setValidationRuleInDataDictonary(String expectedValue ,String startingString , String endingString,  String dictonaryKey) throws IOException {

		String fieldName = expectedValue.replaceAll("[#()]", "");

		expectedValue = 	parseValue(expectedValue);
		startingString = parseValue(startingString);
		endingString = 	parseValue(endingString);
		List<StringRuleDefination> ruleList = (List<StringRuleDefination>) TestContext.getInstance().testdata().get(dictonaryKey);
		if(ruleList==null) {
			ruleList = new ArrayList<>();

		}
		StringRuleDefination stringRuleDefination = new StringRuleDefination(startingString,endingString,expectedValue,fieldName);
		ruleList.add(stringRuleDefination);
		TestContext.getInstance().testdata().put(dictonaryKey, ruleList);
		log.info("Added Rule ["+stringRuleDefination.getRuleDefinition()+"] To Rule List");
		Reporter.addStepLog("Pass", "Added Rule ["+stringRuleDefination.getRuleDefinition()+"] To Rule List");
		assertThat("Rule Added").isEqualTo("Rule Added");

	}
	@Then("^the user validates pdf availavle at \"([^\"]*)\" with all validation rules setted in data dictionary with key \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void validatePDFContentWithRuleList(String pathToPDF,String dictionarykeyToRuleList,
			String validationId,
			String onFailureFlag) throws IOException {
		try {

			log.info("Validating PDF");
			pathToPDF = 	parseValue(pathToPDF);
			File pdfFile = new File(pathToPDF);
			if(!pdfFile.exists())
			{

				log.error("PDF FILE NOT AVAILABLE AT "+pathToPDF);
				throw new Exception("PDF FILE NOT AVAILABLE AT "+pathToPDF);
			}
			String text = getPDFText(pathToPDF);

			List ruleList = (List) TestContext.getInstance().testdata().get(dictionarykeyToRuleList);
			boolean isValid = ruleList.size()>0;
			List<String> expectedValues = new ArrayList();
			List<String> actualValues = new ArrayList();


			for (int i = 0; i < ruleList.size(); i++) {
				StringRuleDefination rule =  (StringRuleDefination) ruleList.get(i);
				rule.validateString(getTrimedContentInBetweenTwoStrings(rule.getFirstString(),rule.getLastString(),text));
				if(!rule.isRulePassed()) {
					isValid= false;
				}
				expectedValues.add(rule.getFieldName()+" = "+rule.getExpectedValueInBetween());
				actualValues.add(rule.getFieldName()+" = "+rule.getActualValue());
			}

			if(isValid) {
				Reporter.addStepLog("Pass", "Validation Success");
				AssertHelper validator = new AssertHelper(ComparisonType.COMPARE_LISTS, ComparisonOperator.EQ, onFailureFlag);
				validator.performValidation(actualValues, expectedValues,
						validationId,onFailureFlag );
			}else {
				Reporter.addStepLog("Fail", "Validation Failed");
				assertThat(expectedValues).isEqualTo(actualValues);

			}
			FileInputStream fileInputStream = new FileInputStream(pathToPDF);
			Allure.addAttachment("EvidenceFile",null,fileInputStream,"pdf");
			TestContext.getInstance().testdataPut("fw.excelPath", pathToPDF);
			TestContext.getInstance().testdataPut("fw.stepExcelPath", pathToPDF);
		} catch (Exception e) {
			log.error(e.getMessage());
			Reporter.addStepLog("Fail", "Validation Failed");
			assertThat("PDF FILE").isEqualTo(e.getMessage());

		}


	}


	public String getTrimedContentInBetweenTwoStrings(String firstString , String secondString,String text) throws IOException{
		if(text!=null) {
			int startInd = text.indexOf(firstString)+firstString.length();
			if(startInd >= 0 ) {
				text = text.substring(startInd);
				startInd = 0;
			}
			int endInd = text.indexOf(secondString);

			if(endInd>startInd && endInd>=0 && startInd>=0) {
				text = (text.substring(startInd , endInd)).trim();
				if(text!=null && (text.trim().charAt(text.length()-1)==':' || text.trim().charAt(text.length()-1)=='.')) {
					text = text.substring(0,text.length()-1);
				}
			}else {
				text ="";
			}

		}else {
			text ="";
		}
		return text;
	}
	private String getPDFText(String pathToPDF) throws IOException {
		PDDocument doc = PDDocument.load(new File(pathToPDF));
		String text = new PDFTextStripper().getText(doc);
		doc.close();
		return text;
	}

	@Then("^the user converts unreadmail available on \"([^\"]*)\" folder and subject contains \"([^\"]*)\" as pdf and store path to data dictionary key \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void convertEmailToPDF(
			String outlookFolder,
			String mailSubject, 
			String dataDictonaryKey,
			String validationId,
			String onFailureFlag) {
	
		outlookFolder = 	parseValue(outlookFolder);
			mailSubject = parseValue(mailSubject);
			log.info(outlookFolder);
			log.info(mailSubject);

			File outFolder = new File("EmailToPDF");
			if(!outFolder.exists()) {
				outFolder.mkdir();
			}

			File file = new File(outFolder.getAbsolutePath()+"/pdfTool.vbs");
			File toolFile = new File(outFolder.getAbsolutePath()+"/PDF_Conversion.xlsm");
			if(toolFile.exists()) {
				toolFile.delete(); 
			} 

			if(file.exists()) {
				file.delete();
			}


			try (InputStream is =getClass().getResourceAsStream(SCRIPT_FILE_PATH_TO_CONVERT_EMAIL_TO_PDF))
			{
				FileHelper.copyFileFromInputStream(is, file.getAbsolutePath());
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}   
			try(InputStream toolStream =getClass().getResourceAsStream(MACRO_FILE_PATH_TO_CONVERT_EMAIL_TO_PDF);){

				FileHelper.copyFileFromInputStream(toolStream, toolFile.getAbsolutePath());
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			String fileName = mailSubject.replaceAll(" ", "~")+"_"+new Date().getTime();

			theUserConvertsMailToPDF(file.getAbsolutePath(), toolFile.getAbsolutePath(), mailSubject, outlookFolder, fileName,outFolder.getAbsolutePath(),dataDictonaryKey);



	}
	@Then("^the user converts unreadmail to pdf using script \"([^\"]*)\" and macro tool \"([^\"]*)\" with mail subject \"([^\"]*)\" in outlook folder \"([^\"]*)\" as pdf with filename \"([^\"]*)\" on location \"([^\"]*)\" and store path to data dictionary key \"([^\"]*)\"$")
	public void theUserConvertsMailToPDF(String vbScriptPath,
			String emailToolPath,
			String mailSubject,
			String outlookFolder,
			String fileName,
			String outputPath,
			String dataDictionaryKey) {

		outlookFolder = 	parseValue(outlookFolder);
		mailSubject = parseValue(mailSubject);
		vbScriptPath = parseValue(vbScriptPath);
		emailToolPath = parseValue(emailToolPath);
		fileName = parseValue(fileName);
		outputPath = parseValue(outputPath);

		try {

			log.info(mailSubject);
			File pdfFile = convertEmailToPDFAndSaveItInInputPath(vbScriptPath, outputPath, mailSubject, null, null, outlookFolder, fileName, emailToolPath, "unread")   ;
			String statusMSG = (pdfFile.exists())?"Succesfully converted mail as PDF":"Failed to convert mail with given subject in given folder not found";

			log.info(statusMSG);
			if("Succesfully converted mail as PDF".equalsIgnoreCase(statusMSG)) {
				String outputFilePath = pdfFile.getAbsolutePath();
				FileInputStream fileInputStream = new FileInputStream(outputFilePath );
				Allure.addAttachment("EvidenceFile",null,fileInputStream,"pdf");
				TestContext.getInstance().testdataPut("fw.excelPath", outputFilePath);
				TestContext.getInstance().testdataPut("fw.stepExcelPath", outputFilePath);

				Reporter.addStepLog("PASS",statusMSG);
				TestContext.getInstance().testdataPut(dataDictionaryKey, outputFilePath);

			}else {
				Reporter.addStepLog("FAIL",statusMSG);
				TestContext.getInstance().testdataPut(dataDictionaryKey, null);

			} 

			assertThat("Succesfully converted mail as PDF").isEqualTo(statusMSG);
		}
		catch( IOException e ) {
			e.printStackTrace();
		}
	}

	@Then("^the user highlights the pdf at \"([^\"]*)\" if text \"([^\"]*)\" is available on page \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void userHighlightsTextOnPDFPage(String filePath,
			String textToFind,
			String pageNum,
			String validationID,
			String onFailureFlag) throws IOException, IllegalAccessException, InterruptedException {


		filePath = parseValue(filePath);
		textToFind = parseValue(textToFind);
		pageNum = parseValue(pageNum);
		int intPageNum = 0;

		if (!pageNum.equals("all")) {
			try {
				intPageNum = Integer.parseInt(pageNum);

			} catch (NumberFormatException nfe){
				AssertHelper validator = new AssertHelper(ComparisonType.COMPARE_STRINGS, ComparisonOperator.EQ, onFailureFlag);
				validator.performValidation("pageNumber is not a number", "pageNumber is a number",
						validationID,
						"PDF Page Number check");
				return;
			}
		}



		if (!pageNum.equals("all") && intPageNum == 0) {
			AssertHelper validator = new AssertHelper(ComparisonType.COMPARE_STRINGS, ComparisonOperator.EQ, onFailureFlag);
			validator.performValidation("pageNumber is not a number", "pageNumber is a number",
					validationID,
					"PDF Page Number check");
			return;}

		String actualResult = PDFHelper.highlightTextOnPDFPage(filePath, textToFind, pageNum, validationID, onFailureFlag);

		String appendedName = "_highlighted_output_";
		Integer appendIndex = 1;
		filePath = filePath.replace(".pdf", "");
		String finalFilePath = filePath+appendedName+appendIndex.toString()+".pdf";
		while (new File(finalFilePath).exists()) {
			appendIndex = appendIndex+1;
			finalFilePath = filePath+appendedName+appendIndex.toString()+".pdf";
		}
		appendIndex--;
		finalFilePath = filePath+appendedName+appendIndex.toString()+".pdf";

		TestContext.getInstance().setActiveWindowType(PDF);
		TestContext.getInstance().testdataPut("fw.filePath", finalFilePath);
		PDDocument document = PDFHelper.getDoc(finalFilePath);
		if (document != null) {
			TestContext.getInstance().testdataPut(ACTIVE_PDF, document);
		} else {
			throw new IllegalArgumentException(String.format("Could not find PDF at path: %s", finalFilePath));
		}

		if (pageNum.equals("all")) {
			TestContext.getInstance().testdata().put(CURRENT_PAGE_PDF, -1);
		} else {
			TestContext.getInstance().testdata().put(CURRENT_PAGE_PDF, Integer.parseInt(pageNum));
		}

		AssertHelper validator = new AssertHelper(ComparisonType.COMPARE_STRINGS, ComparisonOperator.EQIC, onFailureFlag);
		validator.performValidation(actualResult, textToFind,
				validationID,
				String.format("PDF text comparison between pages '%s' and %s'", pageNum, pageNum));



	}

	@Then("^the user validates the font with text \"([^\"]*)\" and size \"([^\"]*)\" and name \"([^\"]*)\" for the pdf \"([^\"]*)\"$")
	public void userValidatesfontTextSizeAndName(String fontText,
			String fontSize,
			String fontName,
			String filePath) throws IOException, IllegalAccessException, InterruptedException {



		filePath = parseValue(filePath);
		List<String> fontTextList1 = (List<String>) parseValueToObject(fontText);
		List<String> fontSizeList1 = (List<String>) parseValueToObject(fontSize);
		List<String> fontNameList1 = (List<String>) parseValueToObject(fontName);
		Gson gson = new Gson();
		String fontTextList=" ";
		fontTextList =      gson.toJson(fontTextList1);
		Gson gson1 = new Gson();
		String fontSizeList=" ";
		fontSizeList =      gson1.toJson(fontSizeList1);
		Gson gson2 = new Gson();
		String fontNameList=" ";
		fontNameList =      gson2.toJson(fontNameList1);

		String actualResult = PDFHelper.validatePdfFont(filePath, fontTextList, fontSizeList, fontNameList);

		TestContext.getInstance().setActiveWindowType(PDF);
		TestContext.getInstance().testdataPut("fw.filePath", filePath);
		PDDocument document = PDFHelper.getDoc(filePath);
		if (document != null) {
			TestContext.getInstance().testdataPut(ACTIVE_PDF, document);
		} else {
			throw new IllegalArgumentException(String.format("Could not find PDF at path: %s", filePath));
		}

		TestContext.getInstance().testdata().put(CURRENT_PAGE_PDF, -1);

		if(actualResult.contains("success")  && !actualResult.contains("failed")) {
			AssertHelper validator = new AssertHelper(ComparisonType.COMPARE_STRINGS, ComparisonOperator.CONTAINS, "HardStopOnFailure");
			validator.performValidation(actualResult, actualResult,
					"pdfvalidation",
					String.format("PDF text comparison"));
		}
		else {
			Reporter.addStepLog(STATUS_FAIL, VALIDATION_FAILED+actualResult);
			assertThat(actualResult).doesNotContain("failed");

		}



	}
	public File convertEmailToPDFAndSaveItInInputPath(String vbScriptPath, String outputPath, String mailSubject, String mailBody, String date, String outlookFolder, String fileName, String emailToolPath, String read_UnRead_ALL) throws IOException {

		if(read_UnRead_ALL == null) {
			read_UnRead_ALL = "unread";
		}
		try {
			mailBody = (mailBody!=null)?parseValue(mailBody):"~";
		}catch (Exception e) {
			mailBody="~";
		}

		try {
			date = (date!=null)?parseValue(date):"~";
		}catch (Exception e) {
			date="~";
		}
		try {
			mailSubject = (mailSubject!=null)? parseValue(mailSubject):"~";
		}catch (Exception e) {
			mailSubject = "~";
		}
		String cmd = "cscript "+vbScriptPath.replaceAll(" ", "~")+" " + outputPath.replaceAll(" ", "~") + " "+read_UnRead_ALL+" "+ ((mailSubject==null)?"~": (mailSubject.trim().isEmpty())?"~":mailSubject.replaceAll(" ", "~")).trim() + " "+ ((mailBody ==null)?"~": mailBody.trim().isEmpty()?"~":mailBody.replaceAll(" ", "~")).trim()+" " + ((date ==null)?"~": date.trim().isEmpty()?"~":date.replaceAll(" ", "~")).trim()+ " "+ fileName.replaceAll(" ", "~")+" "+outlookFolder.replaceAll(" ", "~")+" "+emailToolPath.replaceAll(" ", "~");
		log.info(cmd);
		Runtime.getRuntime().exec(cmd);

		String outputFilePath = outputPath+"\\"+fileName+".pdf";
		outputFilePath= outputFilePath.replaceAll("~", " ");
		File pdfFile = new File(outputFilePath);

		long startTime = new Date().getTime();
		log.info("LOOKING FOR EMAIL ...");
 	synchronized (this) {
 		
 		while (!pdfFile.exists() && ((new Date().getTime() - startTime)<=60000)) {
 			try {
				wait(5000);
				if(!pdfFile.exists()  && ((new Date().getTime()-startTime)%30000 ==0) ) {

					if(!read_UnRead_ALL.equalsIgnoreCase("read")) {
						Runtime.getRuntime().exec(cmd);
					}
				}else if(pdfFile.exists()) {
					break;
					}
				} catch (InterruptedException e) {
					e.printStackTrace();

				}

		
		}
}
		return pdfFile;		

	}

	@Then("^the user converts unreadmail available on \"([^\"]*)\" folder and mail body contains \"([^\"]*)\" as pdf and store path to data dictionary key \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void convertEmailToPDFUsingBondyContent(
			String outlookFolder,
			String bodyContent, 
			String dataDictonaryKey,
			String validationId,
			String onFailureFlag) {
		try{
			outlookFolder = 	parseValue(outlookFolder);
			bodyContent = parseValue(bodyContent);
			log.info(outlookFolder);
			log.info(bodyContent);

			File outFolder = new File("EmailToPDF");
			if(!outFolder.exists()) {
				outFolder.mkdir();
			}

		 
		 File file = new File(outFolder.getAbsolutePath()+"/pdfTool.vbs");
		 File toolFile = new File(outFolder.getAbsolutePath()+"/PDF_Conversion.xlsm");
		 log.info(outFolder.getAbsolutePath());
 		 log.info(file.getAbsolutePath());
		 log.info(toolFile.getAbsolutePath());
		    
		 if(!file.exists()) {
			 InputStream is =getClass().getResourceAsStream(SCRIPT_FILE_PATH_TO_CONVERT_EMAIL_TO_PDF);
    		 log.info(is.toString());
    		
			 FileHelper.copyFileFromInputStream(is, file.getAbsolutePath());
		 }
		 if(!toolFile.exists()) {
			    
		 InputStream toolStream =getClass().getResourceAsStream(MACRO_FILE_PATH_TO_CONVERT_EMAIL_TO_PDF);
		 
		    FileHelper.copyFileFromInputStream(toolStream, toolFile.getAbsolutePath());
		 }
		 String fileName = bodyContent.replaceAll(" ", "~")+"_"+new Date().getTime();
		 
		 convertEmailToPDFWithFilters(file.getAbsolutePath(), toolFile.getAbsolutePath(), null,bodyContent,null, outlookFolder, fileName,outFolder.getAbsolutePath(),dataDictonaryKey);
		    
	 } catch (Exception e) {

			e.printStackTrace();
		}


	}


	@Then("^the user converts unreadmail available on \"([^\"]*)\" folder and received date with \"([^\"]*)\" as pdf and store path to data dictionary key \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void convertEmailToPDFUsingdate(
			String outlookFolder,
			String date, 
			String dataDictonaryKey,
			String validationId,
			String onFailureFlag) {
		try{



			outlookFolder = 	parseValue(outlookFolder);
			date = parseValue(date);
			log.info(outlookFolder);
			log.info(date);

			File outFolder = new File("EmailToPDF");
			if(!outFolder.exists()) {
				outFolder.mkdir();
			}

			File file = new File(outFolder.getAbsolutePath()+"/pdfTool.vbs");
			File toolFile = new File(outFolder.getAbsolutePath()+"/PDF_Conversion.xlsm");
			log.info(outFolder.getAbsolutePath());
			log.info(file.getAbsolutePath());
			log.info(toolFile.getAbsolutePath());

			if(!file.exists()) {
				InputStream is =getClass().getResourceAsStream(SCRIPT_FILE_PATH_TO_CONVERT_EMAIL_TO_PDF);
				log.info(is.toString());

				FileHelper.copyFileFromInputStream(is, file.getAbsolutePath());
			}
			if(!toolFile.exists()) {

				InputStream toolStream =getClass().getResourceAsStream(MACRO_FILE_PATH_TO_CONVERT_EMAIL_TO_PDF);

				FileHelper.copyFileFromInputStream(toolStream, toolFile.getAbsolutePath());
			}
			String fileName = date.replaceAll(" ", "~")+"_"+new Date().getTime();

			convertEmailToPDFWithFilters(file.getAbsolutePath(), toolFile.getAbsolutePath(), null,null,date, outlookFolder, fileName,outFolder.getAbsolutePath(),dataDictonaryKey);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
@Then("^the user converts unreadmail to pdf using script \"([^\"]*)\" and macro tool \"([^\"]*)\" with mail subject \"([^\"]*)\" and with date filter \"([^\"]*)\" and with body content filter \"([^\"]*)\" and  in outlook folder \"([^\"]*)\" as pdf with filename \"([^\"]*)\" on location \"([^\"]*)\" and store path to data dictionary key \"([^\"]*)\"$")
public void convertEmailToPDFWithFilters(String vbScriptPath,
		String emailToolPath,
        String mailSubject,
        String mailBody,
        String date,
        String outlookFolder,
        String fileName,
        String outputPath,
        String dataDictionaryKey) {
	
	outlookFolder = 	parseValue(outlookFolder);
	try {
mailSubject = (mailSubject!=null)? parseValue(mailSubject):"~";
	}catch (Exception e) {
		mailSubject = "~";	}

vbScriptPath = parseValue(vbScriptPath);
emailToolPath = parseValue(emailToolPath);
fileName = parseValue(fileName);
outputPath = parseValue(outputPath);
String out = "Succesfully converted mail as PDF";


   try {
	   	File pdfFile = convertEmailToPDFAndSaveItInInputPath(vbScriptPath, outputPath, mailSubject, mailBody, date, outlookFolder, fileName, emailToolPath, "unread");
			String statusMSG = 	(pdfFile.exists())?out:"Failed to convert : mail with given subject in given folder not found";
  
	    	log.info(statusMSG);
    			if("Succesfully converted mail as PDF".equalsIgnoreCase(statusMSG)) {
    				 String outputFilePath = pdfFile.getAbsolutePath();
					FileInputStream fileInputStream = new FileInputStream(outputFilePath );
    	         	    Allure.addAttachment("EvidenceFile",null,fileInputStream,"pdf");
    	                 TestContext.getInstance().testdataPut("fw.excelPath", outputFilePath);
    	         	    TestContext.getInstance().testdataPut("fw.stepExcelPath", outputFilePath);
    	         	
    				Reporter.addStepLog("PASS",statusMSG);
    				TestContext.getInstance().testdataPut(dataDictionaryKey, outputFilePath);
			}else {
				Reporter.addStepLog("FAIL",statusMSG);
				TestContext.getInstance().testdataPut(dataDictionaryKey, null);

			} 

			assertThat(statusMSG).isEqualTo(out);
		}
		catch( IOException e ) {
			e.printStackTrace();
			assertThat(out).isEqualTo(e.getMessage());
		}
	}


	@Then("^the user extracts words from PDF located at \"([^\"]*)\" which are available in between \"([^\"]*)\" and \"([^\"]*)\" and from line \"([^\"]*)\" and store as list in datadictionary with key \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void extractPDFDataToList(String pathToPDF, String startStr , String endStr,String lineNumber ,String dictionaryKey, String validationId,
			String onFailureFlag){
		try {
			pathToPDF = parseValue(pathToPDF);

			


			if(pathToPDF.equals("None")) {
			String downloadDir = Paths.get(Constants.DOWNLOADPATH).toAbsolutePath().toString();
			pathToPDF = downloadDir+"\\"+FileHelper.getLatestFilefromDir(downloadDir)+"";
			}else {
				pathToPDF = parseValue(pathToPDF);
			}
			startStr = parseValue(startStr);

			endStr = parseValue(endStr);
			String text = getPDFText(pathToPDF);
			String [] textLineArr = text.split("\n");
			String newTxt = "";
			for (int i =Integer.valueOf(lineNumber)-1; i < textLineArr.length; i++) {
				newTxt=newTxt+" "+textLineArr[i].trim();
			}

			int startInd = newTxt.indexOf(startStr);
			newTxt = newTxt.substring(startInd+startStr.length());

			startInd=0;
			int endInd = newTxt.indexOf(endStr);
			newTxt = newTxt.substring(startInd, endInd);

			newTxt= newTxt.replaceAll("[-]{2,}","").trim();

			List outList = Arrays.asList(newTxt.split(" "));
			TestContext.getInstance().testdataPut(dictionaryKey, outList);

			Reporter.addStepLog("Extracted Data is ["+outList.toString()+"] and stored in datadictionary with key ["+dictionaryKey+"]");
			assertThat("Extracted DataToList").isEqualTo("Extracted DataToList");
			log.info("Extracted Data");

		} catch (IOException e) {
			Reporter.addStepLog("Failed TO Extract Data To List");

			e.printStackTrace();
			log.error(e.getMessage());
			assertThat(e.getMessage()).isEqualTo("ERROR");

		}

	}
	@Then("^the user extracts value from PDF located at \"([^\"]*)\" which are available in between \"([^\"]*)\" and \"([^\"]*)\" and from line \"([^\"]*)\" and store as single value in datadictionary with key \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void extractValueFromPirticularLineAndStoreInDataDictionary(String pathToPDF,String startStr , String endStr,String lineNumber , String dictionaryKey, String validationId,
			String onFailureFlag){
		try {
			pathToPDF= parseValue(pathToPDF);

			startStr= parseValue(startStr);
			endStr= parseValue(endStr);

			String text = getPDFText(pathToPDF);
			String [] textLineArr = text.split("\n");
			String newTxt = "";
			for (int i =Integer.valueOf(lineNumber)-1; i < textLineArr.length; i++) {
				newTxt=newTxt+" "+textLineArr[i].trim();
			}
			int startInd = newTxt.indexOf(startStr);
			newTxt = newTxt.substring(startInd);
			startInd=0;
			int endInd = newTxt.indexOf(endStr);


			newTxt = newTxt.substring(startInd+startStr.length(), endInd);

			TestContext.getInstance().testdataPut(dictionaryKey, newTxt.trim());

			Reporter.addStepLog("Extracted Data is ["+newTxt.trim()+"] and stored in datadictionary with key ["+dictionaryKey+"]");
			assertThat("Extracted Data").isEqualTo("Extracted Data");
			log.info("Extracted Data");

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

			Reporter.addStepLog("Failed To Extract Data");
			log.error(e.getMessage());
			assertThat(e.getMessage()).isEqualTo("ERROR");

		}

	}

	@Then("^the user extracts value from PDF located at \"([^\"]*)\" which are available in between \"([^\"]*)\" and \"([^\"]*)\" and store as single value in datadictionary with key \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void extractValueAndStoreInDataDictionary(String pathToPDF, String startStr , String endStr,String dictionaryKey, String validationId,
			String onFailureFlag){
		try {
			pathToPDF= parseValue(pathToPDF);
			String text = getPDFText(pathToPDF);

			startStr = parseValue(startStr);

			endStr = parseValue(endStr);


			int startInd = text.indexOf(startStr);

			text = text.substring(startInd);
			startInd =0;
			int endInd = text.indexOf(endStr);
			text = text.substring(startInd+startStr.length()-1, endInd);


			TestContext.getInstance().testdataPut(dictionaryKey, text.trim());

			Reporter.addStepLog("Extracted Data is ["+text.trim()+"] and stored in datadictionary with key ["+dictionaryKey+"]");

			assertThat("Extracted Data").isEqualTo("Extracted Data");

		} catch (Exception e) {
			// TODO Auto-generated catch block

			Reporter.addStepLog("Failed To Extract Data");
			e.printStackTrace();
			log.error(e.getMessage());
			assertThat(e.getMessage()).isEqualTo("ERROR");

		}

	}

	

	@Then("^the user gets number of elements from list available in datadictionary with key \"([^\"]*)\" and store result in datadictionary with key \"([^\"]*)\"$")
	public void getListCountFromDataDictionary(String listKey, String countKey) {
		List l = (List) TestContext.getInstance().testdataGet(listKey);
		if (l != null && !l.isEmpty()) {
			TestContext.getInstance().testdataPut(countKey, l.size());
			Reporter.addStepLog("List Count : " + l.size() + " is added to data dictionary with key " + listKey);
			assertThat("Count Result Stored").isEqualTo("Count Result Stored");
		} else {
			Reporter.addStepLog("List Is Not Available");
			assertThat("Count Result Stored").isEqualTo("No Records Found");
		}

	}


	
	@Then("^the user validates the images in pdf at \"([^\"]*)\" against the images in template pdf \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void userCheckImagesInPdfAgainstTemplate(String filePath,
			String templatePath,
			String validationID,
			String onFailureFlag) throws IOException, IllegalAccessException, InterruptedException {


		filePath = parseValue(filePath);
		templatePath = parseValue(templatePath);

		ArrayList<String> actualResult = PDFHelper.validatePdfImagesAgainstTemplate(filePath, templatePath);
		log.info("Status: " + actualResult.get(0));
		log.info("Reason: " + actualResult.get(1));

		AssertHelper validator = new AssertHelper(ComparisonType.COMPARE_STRINGS, ComparisonOperator.EQ, onFailureFlag);
		validator.performValidation(actualResult.get(0), "Passed",
				validationID,
				String.format("PDF image comparison between subject and template"));

	}

	@Then("^the user finds the first \"([^\"]*)\" email in folder \"([^\"]*)\" with subject \"([^\"]*)\" and body text \"([^\"]*)\" and date \"([^\"]*)\" and converts it to a PDF with file name \"([^\"]*)\" at file path \"([^\"]*)\" and stores that file path in the data dictionary with the key \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void convertEmailWithMultipleParametersToPDF(
			String readStatus,
			String outlookFolder,
			String mailSubject,
			String mailBody,
			String mailDate,
			String fileName,
			String filePath,
			String dataDictionaryKey,
			String validationId,
			String onFailureFlag) {
		try{


			readStatus = parseValue(readStatus);
			outlookFolder = parseValue(outlookFolder);
			mailSubject = parseValue(mailSubject);
			mailBody = parseValue(mailBody);
			mailDate = parseValue(mailDate);
			fileName = parseValue(fileName);
			filePath = parseValue(filePath);
			log.info("Email to PDF Conversion: Outlook Folder: " + outlookFolder);
			log.info("Email to PDF Conversion: Mail Subject: " + mailSubject);
			log.info("Email to PDF Conversion: Mail Body: " + mailBody);
			log.info("Email to PDF Conversion: Mail Date: " + mailDate);
			log.info("Email to PDF Conversion: File Name: " + fileName);
			log.info("Email to PDF Conversion: File Path: " + filePath);
			log.info("Email to PDF Conversion: Data Dictionary Key: " + dataDictionaryKey);


			File file = new File(filePath + "pdfTool.vbs");
			File toolFile = new File(filePath + "PDF_Conversion.xlsm");
			File outFile = new File(filePath + fileName+".pdf");
			
			if(toolFile.exists()) {
				toolFile.delete(); 
			} 

			if(file.exists()) {
				file.delete();
			}
			if(outFile.exists()) {
				outFile.delete();
			}


			try (InputStream is = getClass().getResourceAsStream(SCRIPT_FILE_PATH_TO_CONVERT_EMAIL_TO_PDF))
			{
				FileHelper.copyFileFromInputStream(is, file.getAbsolutePath());
			}   
			try(InputStream toolStream =getClass().getResourceAsStream(MACRO_FILE_PATH_TO_CONVERT_EMAIL_TO_PDF);){

				FileHelper.copyFileFromInputStream(toolStream, toolFile.getAbsolutePath());
			}
			

			try {

				log.info(mailSubject);

				//////// Inline Convert to PDF
				
				if(readStatus == null) {
					readStatus = "unread";
				}
				
				try {
					mailBody = (mailBody!=null || mailBody.equals("") || mailBody.equals("none"))?parseValue(mailBody):"~";
				}catch (Exception e) {
					mailBody="~";
				}

				try {
					mailDate = (mailDate!=null  || mailDate.equals("") || mailDate.equals("none"))?parseValue(mailDate):"~";
				}catch (Exception e) {
					mailDate="~";
				}
				
				try {
					mailSubject = (mailSubject!=null)? parseValue(mailSubject):"~";
				}catch (Exception e) {
					mailSubject = "~";
				}
				String cmd = "cscript "+
					file.getAbsolutePath().replaceAll(" ", "~")+" " +
					filePath.replaceAll(" ", "~") + " "+
					readStatus+" "+
					((mailSubject==null)?"~": (mailSubject.trim().isEmpty())?"~":mailSubject.replaceAll(" ", "~")).trim() + " " +
					((mailBody ==null)?"~": mailBody.trim().isEmpty()?"~":mailBody.replaceAll(" ", "~")).trim()+ " " + 
					((mailDate ==null)?"~": mailDate.trim().isEmpty()?"~":mailDate.replaceAll(" ", "~")).trim()+ " " +
					fileName.replaceAll(" ", "~") + " " + 
					outlookFolder.replaceAll(" ", "~") + " " + 
					toolFile.getAbsolutePath().replaceAll(" ", "~");
				log.info("Command: " + cmd);
				
				
				
				
							///////////////////////////////
				
				
				
				File pdfFile = convertEmailToPDFAndSaveItInInputPath(file.getAbsolutePath().replaceAll(" ", "~"), filePath.replaceAll(" ", "~"), mailSubject, mailBody, mailDate, outlookFolder, fileName, toolFile.getAbsolutePath().replaceAll(" ", "~"), readStatus);
				
				String statusMSG = (pdfFile.exists())?"Succesfully converted mail as PDF":"Failed to convert mail with given subject in given folder not found";

				log.info("Status Message: " + statusMSG);
				if("Succesfully converted mail as PDF".equalsIgnoreCase(statusMSG)) {
				
					FileInputStream fileInputStream = new FileInputStream( pdfFile.getAbsolutePath() );
					Allure.addAttachment("EvidenceFile",null,fileInputStream,"pdf");
					TestContext.getInstance().testdataPut("fw.excelPath",  pdfFile.getAbsolutePath());
					TestContext.getInstance().testdataPut("fw.stepExcelPath",  pdfFile.getAbsolutePath());

					Reporter.addStepLog("PASS",statusMSG);
					TestContext.getInstance().testdataPut(dataDictionaryKey,  pdfFile.getAbsolutePath());

				}else {
					Reporter.addStepLog("FAIL",statusMSG);
					TestContext.getInstance().testdataPut(dataDictionaryKey, null);

				} 

				assertThat("Succesfully converted mail as PDF").isEqualTo(statusMSG);

				if(toolFile.exists()) {
					toolFile.delete(); 
				} 

				if(file.exists()) {
					file.delete();
				}
			}
			catch( IOException e ) {
				e.printStackTrace();
			}


		} catch (Exception e) {
			e.printStackTrace();
		}


	}

    @Then("^the user validates that the pdf located at \"([^\"]*)\" has instance \"([^\"]*)\" of text \"([^\"]*)\" immediately preceding text \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void verifyMailTextSucceeding(String filePath, String instance, String preceedingText, String succeedingText, String validationId, String onFailureFlag) {
		
        String fullText = null;
        
		try {
			fullText = getPDFText(parseValue(filePath));
			log.info("Found text: " + fullText);
		} catch (IOException e) {
			e.printStackTrace();
		}
		Integer intInstance = Integer.parseInt(instance); 
        
		
		
        if (fullText == null) {
    		Reporter.addStepLog(STATUS_FAIL, "Chosen pdf has no text.");
    		assertThat("Chosen PDF has no text").isEqualTo("Found chosen PDF text");
    		return;
        }
        
        if (!fullText.contains(preceedingText)) {
    		Reporter.addStepLog(STATUS_FAIL, "No preceeding text in the element");
    		assertThat("No preceeding text in the element").isEqualTo("Preceding text found");
    		return;
        }
        
        ArrayList<String> splitStrings = new ArrayList<String>();
        for(String string: fullText.split(preceedingText)){
        	log.info("Located String: " + string);
        	splitStrings.add(string);
        }

        if (intInstance >= splitStrings.size()) {
    		Reporter.addStepLog(STATUS_FAIL, "There is no instance of preceedingText that matches the input instance");
    		assertThat("There is no instance of preceeding text that matches the input instance").isEqualTo("Found text after instance");
    		return;
        }
        
        
        
        fullText = splitStrings.get(intInstance);
        
        if (fullText.length() < succeedingText.length()) {
    		Reporter.addStepLog(STATUS_FAIL, "Length of following string too short to compare to following text");
    		assertThat("Length of following string too short to compare to following text").isEqualTo("viable text is the correct length");
    		return;
        }
        

		AssertHelper validator = new AssertHelper(ComparisonType.COMPARE_STRINGS, ComparisonOperator.EQ, onFailureFlag);
		validator.performValidation(fullText.substring(0, Math.min(fullText.length(), succeedingText.length())), succeedingText,
				validationId,
				String.format("PDF given text after given text"));

        
		
	}
    
    @Then("^the user calculates mathematical formula \"([^\"]*)\" and store result in datadictionary with key \"([^\"]*)\"$")
    public void calculateFormulaeResultAndStoreInDataDictionary( String formula, String dictionaryKey ) {
           try {
             TestContext.getInstance().testdataPut(dictionaryKey,getCalculatedFormulaeValue(formula));

                  Reporter.addStepLog("Result of Formula ["+formula+"]  is ("+TestContext.getInstance().testdataGet(dictionaryKey)+") and Stored To Data Dictionary With Key ("+dictionaryKey+")");
                  assertThat("Formula Result Stored").isEqualTo("Formula Result Stored");

           } catch (ScriptException e) {
                  e.printStackTrace();

            Reporter.addStepLog("INVALID FORMULA : "+formula);
                  assertThat(e.getMessage()).isEqualTo("ERROR");

           }
           
    }



    public  String getCalculatedFormulaeValue(String formula ) throws ScriptException {
           
           
           int ind  = formula.indexOf("#");
           
           while(ind >=0) {
                  String formulaKey = formula.substring(ind);
                  int endInd  = (formulaKey.indexOf(")")>=0)?formulaKey.indexOf(")"):formulaKey.length()-1;
                  formulaKey = formulaKey.substring(0,endInd+1);
                  System.out.println(formulaKey);
                  formula = formula.replace(formulaKey, parseValue(formulaKey));
                  System.out.println(formula);
                  ind  = formula.indexOf("#");
           }
           ScriptEngineManager mgr = new ScriptEngineManager();
        ScriptEngine engine = mgr.getEngineByName("JavaScript");
                  return engine.eval(formula).toString();
    }
    @Then("^the user filters accountnumbers from list available in datadictionary with key \"([^\"]*)\" and store result in datadictionary with key \"([^\"]*)\"$")

    public void getFilteredAccountNumbers(String listName, String filterListKey ) {
           
           @SuppressWarnings("rawtypes")
		List l = (List) TestContext.getInstance().testdataGet(listName);
           if(l!=null && !l.isEmpty()) {
           @SuppressWarnings({ "unchecked", "rawtypes" })
		List finalList = (List) l.stream().filter(v->{
                  return ((String)v).trim().matches("[a-zA-Z0-9]{5,}")&& ((String)v).trim().matches("[0-9]{1,}");
                  }).collect(Collectors.toList());
           
           if(finalList==null || finalList.isEmpty()) {
           finalList = Collections.emptyList();
           }
           log.info("Filtered List :"+finalList);
           
           TestContext.getInstance().testdataPut(filterListKey,finalList);
                  Reporter.addStepLog("Filtered List : "+finalList);
                assertThat("Filtered list is successfully added").isEqualTo("Filtered list is successfully added");
           }else {
                  Reporter.addStepLog("No data in data dictionary with Key "+listName);
                assertThat("Filtered List is Success").isEqualTo("Filtered List is failed");
           }
           
    }
	@Then("^the user verifies that the hyperlink urls \"([^\"]*)\" are present in the pdf located at \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void verifyHyperlinkLocatedInPdf( String hyperlinkUrls, String pdfFilePath, String validationId, String onFailureFlag) {

		HttpPost post = new HttpPost("http://sd-35d4-9d73:6660/Hyperlinksvalidation/Geturls");

		File file = new File(pdfFilePath);


		@SuppressWarnings("unchecked")
		List<String> hyperlinkUrlsToFind = (List<String>) parseValueToObject(hyperlinkUrls);

		post.addHeader("expected_hyperlinks", hyperlinkUrlsToFind.toString());

		MultipartEntityBuilder builder = MultipartEntityBuilder.create();
		builder.setMode(HttpMultipartMode.BROWSER_COMPATIBLE);
		builder.addBinaryBody("file", file, ContentType.DEFAULT_BINARY, "");
		HttpEntity entity = builder.build();
		post.setEntity(entity);

		try (DefaultHttpClient client = new DefaultHttpClient()){
			HttpResponse response = client.execute(post);

			if (response.getStatusLine() == null) {
				log.info("Response was null");
			} else {
				log.info("Response Status: " + response.getStatusLine().getStatusCode());
			}

			String results = "Server unreached";
			if (response.getStatusLine() != null && response.getStatusLine().getStatusCode() == 200) {
				results = response.getFirstHeader("validation_status").getValue();
				log.info("Status: " + results);
			}
			else {
				if (response.getStatusLine() != null){
					log.info("print data in response error" + response.getStatusLine().getStatusCode());
				}
				log.info("data in response is blank");
			}

			AssertHelper validator = new AssertHelper(ComparisonType.COMPARE_STRINGS, ComparisonOperator.CONTAINS, onFailureFlag);
			validator.performValidation(  results,"success",
					validationId,
					String.format("Hyperlinks were present in PDF"));


		} catch (Exception e) {
			e.printStackTrace();
		}
	}







	@Then("^the user verifies that the language of the pdf located at \"([^\"]*)\" is \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void verifyLanguageOfPDF(String pdfFilePath, String language, String validationId, String onFailureFlag) {

		pdfFilePath = parseValue(pdfFilePath);
		language = parseValue(language);

		File file = null;
		if (pdfFilePath.contains("\\") || pdfFilePath.contains("/")) {
			file = new File(pdfFilePath);
		} else if (pdfFilePath.contains("latestDownload")){
			file = new File(FileHelper.getLatestFilefromDir(Constants.DOWNLOADPATH + pdfFilePath));

		}

		String text = null;
		if (file != null) { 
			try(PDDocument doc = PDDocument.load(new File(file.getAbsolutePath()));) {
				text = new PDFTextStripper().getText(doc);

			} catch (FileNotFoundException e1) {
				e1.printStackTrace();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			if (file == null || text == null){
				AssertHelper validator = new AssertHelper(ComparisonType.COMPARE_STRINGS, ComparisonOperator.EQ, onFailureFlag);
				validator.performValidation( "File Located" , "File Could not be located.",
						validationId,
						String.format("File path or downloads directory might be missing"));

			}

			HttpPost post = new HttpPost("http://sd-35d4-9d73:3330/PDFlanguageValidation/getfile");

			try {
				log.info("PDF TEXT: " + text);

				MultipartEntityBuilder builder = MultipartEntityBuilder.create();
				builder.setMode(HttpMultipartMode.BROWSER_COMPATIBLE);
				post.addHeader("languagetext", text);
				HttpEntity entity = builder.build();
				post.setEntity(entity);
				log.info("POST: " + post.toString());

				try (DefaultHttpClient client = new DefaultHttpClient()){
					HttpResponse response = client.execute(post);
					String returnLanguage = null;
					if (response.getStatusLine() == null) {
						log.info("Response was null");
					} else {
						log.info("Response Status: " + response.getStatusLine().getStatusCode());
					}

					String result = "Server unreached";
					if (response.getStatusLine() != null && response.getStatusLine().getStatusCode() == 200) {
						returnLanguage = response.getFirstHeader("language").getValue();
					}
					else {
						if (response.getStatusLine() != null){
							log.info("print data in response error" + response.getStatusLine().getStatusCode());
						}
						log.info("data in response is blank");
					}



					AssertHelper validator = new AssertHelper(ComparisonType.COMPARE_STRINGS, ComparisonOperator.EQ, onFailureFlag);
					validator.performValidation( language.toLowerCase() , returnLanguage.toLowerCase(),
							validationId,
							String.format("Expected Language: " + language.toLowerCase() + ", actual language was " + returnLanguage.toLowerCase()));


				} catch (Exception e) {
					e.printStackTrace();
				} 
			} finally {

			}
		}
	}

	@Then("^the user verifies that the languages present in text \"([^\"]*)\" include \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void verifyLanguageOfText(String text, String languages, String validationId, String onFailureFlag) {

		text = parseValue(text);
		@SuppressWarnings("unchecked")
		List<String> languageList = (List<String>) parseValueToObject(languages);

		//HttpPost post = new HttpPost("http://sd-35d4-9d73:3330/PDFlanguageValidation/getfile");
		//HttpPost post = new HttpPost("http://10.44.151.230:3330/PDFlanguageValidation/getfile");
		HttpPost post = new HttpPost("http://sd-35d4-9d73:3338/TextlanguageValidation/gettext");

		try {
			log.info("PDF TEXT: " + text);

			MultipartEntityBuilder builder = MultipartEntityBuilder.create();
			builder.setMode(HttpMultipartMode.BROWSER_COMPATIBLE);
			post.addHeader("language", text);
			HttpEntity entity = builder.build();
			post.setEntity(entity);
			log.info("POST: " + post.toString());

			try (DefaultHttpClient client = new DefaultHttpClient()){
				HttpResponse response = client.execute(post);
				String s = EntityUtils.toString(response.getEntity());
				Gson jsonObj = new Gson(); 
				@SuppressWarnings("unchecked")
				ArrayList<String> res = jsonObj.fromJson(s,ArrayList.class);
				log.info("Array Size: " + res.size());
				for(String string: res) {
					log.info("\n\n RES == " + string + "\n");
				}



				if (response.getStatusLine() == null) {
					log.info("Response was null");
				} else {
					log.info("Response Status: " + response.getStatusLine().getStatusCode());
				}

				String result = "Server unreached";
				if (response.getStatusLine() != null && response.getStatusLine().getStatusCode() == 200) {

				}
				else {
					if (response.getStatusLine() != null){
						log.info("print data in response error" + response.getStatusLine().getStatusCode());
					}
					log.info("data in response is blank");
				}


				for (String expectedLanguage : languageList) {
				
				String foundLanguage = "language was not found in text";
				if (res.contains(expectedLanguage)) {
					foundLanguage = "Found language " + expectedLanguage + " in text";
				} else {
					log.info("Language " + expectedLanguage + " was not located in response list");
				}
				
				AssertHelper validator = new AssertHelper(ComparisonType.COMPARE_STRINGS, ComparisonOperator.EQ, onFailureFlag);
				validator.performValidation( foundLanguage, "Found language " + expectedLanguage + " in text", 
						validationId,
						String.format("Expected Language: " + expectedLanguage.toLowerCase() + ", but was not present in the text"));
					if (foundLanguage.equals("language was not found in text")) {
						break;
					}
				}

			} catch (Exception e) {
				e.printStackTrace();
			}
		} finally {

		}
	}


}