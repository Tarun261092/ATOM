package automation.library.engine.desktop.steps;

import automation.library.common.TestContext;
import automation.library.engine.desktop.BaseDesktopSteps;
import automation.library.leanft.exec.DesktopContext;
import com.hp.lft.sdk.GeneralLeanFtException;
import io.cucumber.java.en.When;

import java.util.List;

public class AutoEngDesktopStore extends BaseDesktopSteps {

    @When("^store value of the \"([^\"]*)\" label at the \"([^\"]*)\" desktop window into the data dictionary with key \"([^\"]*)\"$")
    public void storeTooltipValueOfTheElementAtThePageIntoTheDataDictionaryWithKey(String labelName,
                                                                                   String windowName,
                                                                                   String dictionaryKey) throws GeneralLeanFtException {
        DesktopContext.getInstance().setCurrentLeanFTWindow(getDesktopWindow(windowName));
        dictionaryKey = parseDictionaryKey(dictionaryKey);
        String valToStore = getDesktopLabel(labelName, windowName).getText();
        TestContext.getInstance().testdataPut(dictionaryKey, valToStore);
        logStepMessage(String.format(STORED_VALUE, valToStore, dictionaryKey));
    }

    @When("^store list values from the \"([^\"]*)\" combobox at the \"([^\"]*)\" desktop window into the data dictionary with key \"([^\"]*)\"$")
    public void storeListValuesFromTheDropdownAtTheIntoTheDataDictionaryWithKey(String objectName,
                                                                                String windowName,
                                                                                String dictionaryKey) throws GeneralLeanFtException {
        DesktopContext.getInstance().setCurrentLeanFTWindow(getDesktopWindow(windowName));
        dictionaryKey = parseDictionaryKey(dictionaryKey);
        List<String> valToStore = getDesktopComboBox(objectName, windowName).getComboboxValue();
        TestContext.getInstance().testdataPut(dictionaryKey, valToStore);
        logStepMessage(String.format(STORED_VALUE, valToStore, dictionaryKey));
    }

    @When("^store value of the \"([^\"]*)\" textbox at the \"([^\"]*)\" desktop dialog window into the data dictionary with key \"([^\"]*)\"$")
    public void storeTooltipValueOfTheTextBoxAtTheDesktopDialogWindowIntoTheDataDictionaryWithKey(String labelName,
                                                                                                  String windowName,
                                                                                                  String dictionaryKey) throws GeneralLeanFtException {
        DesktopContext.getInstance().setCurrentLeanFTDialog(getDesktopDialog(windowName));
        dictionaryKey = parseDictionaryKey(dictionaryKey);
        String valToStore = getDesktopEditField(labelName, windowName).getText();
        TestContext.getInstance().testdataPut(dictionaryKey, valToStore);
        logStepMessage(String.format(STORED_VALUE, valToStore, dictionaryKey));
    }

    @When("^store value of the cell at row \"([^\"]*)\" and column \"([^\"]*)\" of the \"([^\"]*)\" table at the \"([^\"]*)\" window into the data dictionary with key \"([^\"]*)\"$")
    public void storecellValueOfTheTextAtTheDesktopWindowIntoTheDataDictionaryWithKey(String rowNum,
                                                                                      String colNum,
                                                                                      String tableName,
                                                                                      String window,
                                                                                      String dictionaryKey) throws GeneralLeanFtException {
        DesktopContext.getInstance().setCurrentLeanFTWindow(getDesktopWindow(window));
        dictionaryKey = parseDictionaryKey(dictionaryKey);
        String valToStore = getDesktopTable(tableName, window).getCellText(Integer.valueOf(rowNum), Integer.valueOf(colNum));
        TestContext.getInstance().testdataPut(dictionaryKey, valToStore);
        logStepMessage(String.format(STORED_VALUE, valToStore, dictionaryKey));
    }

}
