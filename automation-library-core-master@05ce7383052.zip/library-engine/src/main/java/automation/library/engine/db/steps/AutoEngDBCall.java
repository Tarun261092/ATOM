package automation.library.engine.db.steps;

import automation.library.engine.db.BaseDBSteps;
import io.cucumber.java.en.Given;

import java.io.IOException;

public class AutoEngDBCall extends BaseDBSteps {

    @Given("^the user executes the \"([^\"]*)\" query$")
    public void theUserExecutesTheQuery(String queryName) throws Exception {
        queryName = getDBObject(parseValue(queryName));

        if (queryName != null) {
            callDBQuery(queryName);
        }
    }

}
