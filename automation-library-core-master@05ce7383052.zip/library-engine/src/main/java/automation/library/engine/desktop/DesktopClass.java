package automation.library.engine.desktop;

import java.util.Arrays;
import java.util.Optional;

enum DesktopClass {
    DESKTOP_WF_UIOBJECT("WFDesktopUIObject"),
    DESKTOP_SW_RADIOBUTTON("SWDesktopRadioButton"),
    DESKTOP_SW_CHECKBOX("SWDesktopCheckbox"),
    DESKTOP_WEB_CHECKBOX("DesktopWebCheckbox"),
    DESKTOP_SW_UIOBJECT("SWDesktopUIObject"),
    DESKTOP_SW_LABEL("SWDesktopLabel"),
    DESKTOP_SW_TABCONTROL("SWDesktopTabControl"),
    DESKTOP_SW_COMBOBOX("SWDesktopComboBox"),
    DESKTOP_SW_DIALOG("SWDesktopDialog"),
    DESKTOP_SW_BUTTON("SWDesktopButton"),
    DESKTOP_SW_EDITFIELD("SWDesktopEditField"),
    DESKTOP_SW_WINDOW("SWDesktopWindow"),
    DESKTOP_SW_EDITOR("SWDesktopEditor"),
    DESKTOP_SW_STATIC("SWDesktopStatic"),
    DESKTOP_WF_RADIOBUTTON("WFDesktopRadioButton"),
    DESKTOP_WF_CHECKBOX("WFDesktopCheckbox"),
    DESKTOP_WF_EDIT_FIELD("WFDesktopEditField"),
    DESKTOP_WF_TABCONTROL("WFDesktopTabControl"),
    DESKTOP_WF_BUTTON("WFDesktopButton"),
    DESKTOP_WF_WINDOW("WFDesktopWindow"),
    DESKTOP_WF_LABEL("WFDesktopLabel"),
    DESKTOP_WF_COMBOBOX("WFDesktopComboBox"),
    DESKTOP_WF_TOOLBAR("WFDesktopToolBar"),
    DESKTOP_WF_LISTVIEW("WFDesktopListView"),
    DESKTOP_WF_TABLE("WFDesktopTable"),
    DESKTOP_WEB_TABLE("DesktopWebTable"),
    DESKTOP_WF_EDITOR("WFDesktopEditor"),
    DESKTOP_WF_STATIC("WFDesktopStatic"),
    DESKTOP_WF_DIALOG("WFDesktopDialog"),
    DESKTOP_WEB_ELEMENT("DesktopWebElement"),
    DESKTOP_WEB_LINK("DesktopWebLink"),
    DESKTOP_WEB_LIST_BOX("DesktopWebListBox"),
    DESKTOP_WEB_RADIO_GROUP("DesktopWebRadioGroup"),
    DESKTOP_WEB_EDIT_FIELD("DesktopWebEditField"),
    DESKTOP_WEB_WINDOW("WebDesktopBrowserWindow"),
    DESKTOP_WEB_BUTTON("DesktopWebButton"),
    DESKTOP_WEB_IMAGE("DesktopWebImage");

    private String className;

    DesktopClass(String className) {
        this.className = className;
    }

    public String getClassName() {
        return className;
    }

    public static DesktopClass get(String className) {
        Optional<DesktopClass> first = Arrays.stream(DesktopClass.values())
                                            .filter(server -> server.getClassName()
                                                                    .equalsIgnoreCase(className))
                                            .findFirst();

        return first.orElse(null);
    }
}
