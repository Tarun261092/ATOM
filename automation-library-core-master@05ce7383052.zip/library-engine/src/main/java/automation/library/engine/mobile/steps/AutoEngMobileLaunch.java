package automation.library.engine.mobile.steps;

import automation.library.engine.mobile.BaseMobileSteps;
import io.cucumber.java.en.Given;

public class AutoEngMobileLaunch extends BaseMobileSteps {

    @Given("^the mobile application \"([^\"]*)\" is launched$")
    public void theWebApplicationIsLaunchedInA(String appName)  {
        System.setProperty("fw.mobileAppName", appName);
        launchMobile();
        openApplication(appName,getMobileDriver());
    }

    @Given("^the user closes the mobile application \"([^\"]*)\"$")
    public void theUserClosesTheMobileApp(String appName)  {
        closeAppilcation(appName, getMobileDriver());
    }

    @Given("^the user switches to mobile context \"([^\"]*)\"$")
    public void theUserSwitchesTheMobileContext(String context)  {
        switchContext(context);
    }
    
    @Given("^the web application \"([^\"]*)\" is launched in mobile browser$")
    public void theWebApplicationIsLaunchedInAMobileDevice(String webAppName)  {
    	openWebApplicationInBrowser(webAppName, null, getMobileDriver());        
    }
}
