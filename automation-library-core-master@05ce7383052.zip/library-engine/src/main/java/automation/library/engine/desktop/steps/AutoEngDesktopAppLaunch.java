package automation.library.engine.desktop.steps;

import automation.library.common.Property;
import automation.library.engine.desktop.BaseDesktopSteps;
import automation.library.leanft.core.Constants;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class AutoEngDesktopAppLaunch extends BaseDesktopSteps {

    @Given("^the desktop application \"([^\"]*)\" is launched$")
    public void theDesktopApplicationIsLaunched(String appName) {
        launchApplication(appName);
    }

    @When("^the user waits for socket connection$")
    public void theUserWaitsForSocketConnection() throws InterruptedException {
           Thread.sleep(Long.parseLong(Property.getProperty(Constants.LEANFTRUNTIMEPATH, "avayaWaitTime")));
    }

    @Then("^the user closes the desktop application \"([^\"]*)\"$")
    public void theUserClosesTheDesktopApplication(String appName) {
        closeApplication(appName);
    }

    @Then("^the user switches to the web application with title \"([^\"]*)\" in \"([^\"]*)\"$")
    public void theUserSwitchestoTheWebApplicationWithTittleInBrowser(String pageTitle, String browser) {
        launchApplication(pageTitle, browser);
    }
}