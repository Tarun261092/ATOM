/**
 * 
 */
package automation.library.engine.core.objects;

import java.io.Serializable;

public class StringRuleDefination implements Serializable {

	public String getFieldName() {
		return fieldName;
	}


	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}
	
	public String getRuleDefinition() {
		
		return "expecting <<"+expectedValueInBetween+ ">> in between <<"+firstString+">> and <<"+lastString+">>";
	}

	@Override
	public String toString() {
		return "StringRuleDefination [firstString=" + firstString + ", lastString=" + lastString
				+ ", expectedValueInBetween=" + expectedValueInBetween + ", actualValue=" + actualValue
				+ ", isRulePassed=" + isRulePassed + "]";
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * 
	 */
	public StringRuleDefination(String firstString, String lastString , String expectedValueInBetween,String fieldName) {
		this.firstString=firstString;
		this.lastString= lastString;
		this.expectedValueInBetween = expectedValueInBetween;
		this.fieldName = fieldName;
		// TODO Auto-generated constructor stub
	}
	
	private String firstString;
	private String lastString;
	private String expectedValueInBetween;
	private String actualValue;
	private String fieldName;
	private Boolean isRulePassed = false;
	
	
public String getFirstString() {
		return firstString;
	}


	public void setFirstString(String firstString) {
		this.firstString = firstString;
	}


	public String getLastString() {
		return lastString;
	}


	public void setLastString(String lastString) {
		this.lastString = lastString;
	}


	public String getExpectedValueInBetween() {
		return expectedValueInBetween;
	}


	public void setExpectedValueInBetween(String expectedValueInBetween) {
		this.expectedValueInBetween = expectedValueInBetween;
	}


	public String getActualValue() {
		return actualValue;
	}


	public void setActualValue(String actualValue) {
		this.actualValue = actualValue;
	}


	public Boolean isRulePassed() {
		return isRulePassed;
	}


	public void setRulePassed(Boolean isRulePassed) {
		this.isRulePassed = isRulePassed;
	}


public Boolean validateString(String input) {
	actualValue=input;
	isRulePassed = (expectedValueInBetween !=null && input!=null && expectedValueInBetween.trim().equals(input.trim()));
	return  isRulePassed;
}
}
