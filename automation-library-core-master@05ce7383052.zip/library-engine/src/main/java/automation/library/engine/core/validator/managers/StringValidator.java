package automation.library.engine.core.validator.managers;

import automation.library.common.TestContext;
import automation.library.engine.core.validator.FailureFlag;
import automation.library.engine.core.validator.ValidatorManager;

import static automation.library.engine.core.validator.FailureFlag.*;
import static org.assertj.core.api.Assertions.assertThat;

public class StringValidator extends ValidatorManager {
    private FailureFlag onFailureFlag;

    public StringValidator(String onFailureFlag) {
        this.onFailureFlag = valueOfLabel(onFailureFlag);
    }

    @Override
    protected void assertEquals(Object actual, Object expected, String assertMsg) {
        if(onFailureFlag == HARD_STOP_ON_FAILURE) {
            assertThat(actual.toString()).as(assertMsg).isEqualTo(expected.toString());
        } else {
            TestContext.getInstance().sa().assertThat(actual.toString()).as(assertMsg).isEqualTo(expected.toString());
        }
    }

    @Override
    protected void assertNotEquals(Object actual, Object expected, String assertMsg) {
        if (onFailureFlag == HARD_STOP_ON_FAILURE) {
            assertThat(actual.toString()).as(assertMsg).isNotEqualTo(expected.toString());
        } else {
            TestContext.getInstance().sa().assertThat(actual).as(assertMsg).isNotEqualTo(expected);
        }
    }

    @Override
    protected void assertLessThan(Object actual, Object expected, String assertMsg) {
        if (onFailureFlag == HARD_STOP_ON_FAILURE) {
            assertThat(actual.toString()).as(assertMsg).isLessThan(expected.toString());
        } else {
            TestContext.getInstance().sa().assertThat(actual.toString()).as(assertMsg).isLessThan(expected.toString());
        }
    }

    @Override
    protected void assertLessThanOrEqual(Object actual, Object expected, String assertMsg) {
        if (onFailureFlag == HARD_STOP_ON_FAILURE) {
            assertThat(actual.toString()).as(assertMsg).isLessThanOrEqualTo(expected.toString());
        } else {
            TestContext.getInstance().sa().assertThat(actual.toString()).as(assertMsg).isGreaterThan(expected.toString());
        }
    }

    @Override
    protected void assertGreaterThan(Object actual, Object expected, String assertMsg) {
        if (onFailureFlag == HARD_STOP_ON_FAILURE) {
            assertThat(actual.toString()).as(assertMsg).isGreaterThan(expected.toString());
        } else {
            TestContext.getInstance().sa().assertThat(actual.toString()).as(assertMsg).isGreaterThan(expected.toString());
        }
    }

    @Override
    protected void assertGreaterThanOrEqual(Object actual, Object expected, String assertMsg) {
        if (onFailureFlag == HARD_STOP_ON_FAILURE) {
            assertThat(actual.toString()).as(assertMsg).isGreaterThanOrEqualTo(expected.toString());
        } else {
            TestContext.getInstance().sa().assertThat(actual.toString()).as(assertMsg).isGreaterThan(expected.toString());
        }
    }

    @Override
    protected void assertContains(Object actual, Object expected, String assertMsg) {
        if (onFailureFlag == HARD_STOP_ON_FAILURE) {
            assertThat(actual.toString()).as(assertMsg).contains(expected.toString());
        } else {
            TestContext.getInstance().sa().assertThat(actual.toString()).as(assertMsg).contains(expected.toString());
        }
    }

    protected void assertDoesNotContain(Object actual, Object expected, String assertMsg) {
        if (onFailureFlag == HARD_STOP_ON_FAILURE) {
            assertThat(actual.toString()).as(assertMsg).doesNotContain(expected.toString());
        } else {
            TestContext.getInstance().sa().assertThat(actual.toString()).as(assertMsg).doesNotContain(expected.toString());
        }
    }

    protected void assertEqualsIgnoreCase(Object actual, Object expected, String assertMsg) {
        if(onFailureFlag == HARD_STOP_ON_FAILURE) {
            assertThat(actual.toString()).as(assertMsg).isEqualToIgnoringCase(expected.toString());
        } else {
            TestContext.getInstance().sa().assertThat(actual.toString()).as(assertMsg).isEqualToIgnoringCase(expected.toString());
        }
    }

}
