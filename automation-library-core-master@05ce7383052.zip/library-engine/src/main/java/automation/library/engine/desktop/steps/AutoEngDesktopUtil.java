package automation.library.engine.desktop.steps;

import static automation.library.leanft.core.ScreenshotBase.saveScreenshot;
import static automation.library.leanft.core.desktop.DesktopScreenshot.grabScreenshot;
import static automation.library.reporting.Reporter.addScreenCaptureFromPath;
import static automation.library.reporting.Reporter.getScreenshotPath;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.Keyboard;

import automation.library.common.Property;
import automation.library.engine.desktop.BaseDesktopSteps;
import automation.library.leanft.core.Constants;
import automation.library.leanft.core.desktop.web.DesktopWebFrame;
import automation.library.leanft.exec.DesktopContext;
import io.cucumber.java.en.And;
import io.cucumber.java.en.When;

public class AutoEngDesktopUtil extends BaseDesktopSteps{

    @When("^the user presses keys \"([^\"]*)\" to the \"([^\"]*)\" desktop window$")
    public void theUserPressKeysToTheDesktopWindows(String key, String windowName) throws GeneralLeanFtException {
        DesktopContext.getInstance().setCurrentLeanFTWindow(getDesktopWindow(windowName));
        pressKeyboardKey(Keyboard.Keys.valueOf(key));
    }

    @When("^the user sends keys \"([^\"]*)\" \"([^\"]*)\" to the \"([^\"]*)\" desktop window$")
    public void theUserSendsKeysToTheDesktopWindows(String modifierKey, String key, String windowName) throws GeneralLeanFtException {
        DesktopContext.getInstance().setCurrentLeanFTWindow(getDesktopWindow(windowName));
        getDesktopWindow(windowName).sendKeys(getMnemonicKey(key), getMnemonicKey(modifierKey));
        logStepMessage(String.format(ENTERED_VALUE, parseValue(modifierKey + key)));
    }

    @When("^the user sends keys \"([^\"]*)\" to the \"([^\"]*)\" desktop window$")
    public void theUserSendsKeysToTheDesktopWindows(String key, String windowName) throws GeneralLeanFtException {

        DesktopContext.getInstance().setCurrentLeanFTWindow(getDesktopWindow(windowName));
        getDesktopWindow(windowName).sendKeys(Keyboard.Keys.valueOf(key.toUpperCase()).toString());
        logStepMessage(String.format(ENTERED_VALUE, parseValue(key)));
    }

    @And("^the user hovers the \"([^\"]*)\" web element at the \"([^\"]*)\" desktop window$")
    public void theUserHoversOnWebElementAtTheDesktopWindow(String fieldName, String windowName) throws GeneralLeanFtException {
        DesktopContext.getInstance().setCurrentLeanFTWindow(getDesktopWindow(windowName));
        getDesktopWebElement(fieldName, windowName).hover();
    }

    @And("^the user waits for the element in \"([^\"]*)\" and element type as \"([^\"]*)\" to be visible with XPATH \"([^\"]*)\"$")
    public void UserWaitsfortheElementToLoad(String pageName,String elementType,String XPATH) throws GeneralLeanFtException, InterruptedException, FileNotFoundException {
    	String browserType="";
    	String pageTitle="";
    	String PageobjectsFile=Constants.PAGEOBJECTJAVAPATH+pageName+".java";
    	XPATH = parseValue(XPATH);
    	File file_element =new File(PageobjectsFile); 
    	Scanner in = new Scanner(file_element);
        while(in.hasNext())
        {
            String line=in.nextLine();	
            if(line.contains("return new WebDesktopBrowserWindow")) { 
            	
            	pageName = (StringUtils.substringBetween(line, "WebDesktopBrowserWindow", ");")).trim();
            	pageTitle = StringUtils.substringBeforeLast(pageName, ",");
            	browserType = StringUtils.substringAfterLast(pageName, ",");
            	pageTitle = pageTitle.replaceAll("\"","");
            	pageTitle = pageTitle.replace("(","");
            	browserType = browserType.replaceAll("\"","").trim();
            }
        }
        	in.close();
        	try 
        	{
        		WaitfortheElementVisible(pageTitle,browserType,elementType,XPATH);
        	}catch(Exception e)
        	{
        		e.printStackTrace();
        	}
    	 }
    
    @And("^the user waits for the element in \"([^\"]*)\" and element type as \"([^\"]*)\" to be visible in a Frame \"([^\"]*)\" with XPATH \"([^\"]*)\"$")
    public void UserWaitsfortheElementInFrameToLoad(String pageName,String elementType,String frameName,String XPATH) throws GeneralLeanFtException, InterruptedException, FileNotFoundException {
    	String browserType="";
    	String pageTitle="";
    	String PageobjectsFile=Constants.PAGEOBJECTJAVAPATH+pageName+".java";
    	XPATH = parseValue(XPATH);
    	File file_element =new File(PageobjectsFile); 
    	Scanner in = new Scanner(file_element);
        while(in.hasNext())
        {
            String line=in.nextLine();	
     	       if(line.contains("return new WebDesktopBrowserWindow")) {             	
            	pageName = (StringUtils.substringBetween(line, "WebDesktopBrowserWindow", ");")).trim();
            	pageTitle = StringUtils.substringBeforeLast(pageName, ",");
            	browserType = StringUtils.substringAfterLast(pageName, ",");
            	pageTitle = pageTitle.replaceAll("\"","");
            	pageTitle = pageTitle.replace("(","");
            	browserType = browserType.replaceAll("\"","").trim();
            }
        }
        	in.close();
        	try 
        	{
        		WaitfortheElementVisibleInFrame(pageTitle,browserType,elementType,frameName,XPATH);
        	}catch(Exception e)
        	{
        		e.printStackTrace();
        	}
    	 }

    @When("^the user takes a screenshot of the \"([^\"]*)\" desktop window$")
    public void theUserTakesDesktopscreenshot(String windowName) {
        File file = saveScreenshot(grabScreenshot(getDesktopWindow(windowName)), getScreenshotPath());
        addScreenCaptureFromPath(file.getAbsolutePath());
    }
    
    @When("^the user closes other applications coming from firefly except \"([^\"]*)\" window$")
    public void theUserClosesOtherApplicationsComingFromFirefly(String windowName) throws IOException, InterruptedException {
    	windowName = parseValue(windowName).toUpperCase();
    	Process process = Runtime.getRuntime().exec("tasklist /fi \"imagename eq iexplore.exe\"");
    	switch(windowName) {
    		case "ECLIPSE":
    			process = Runtime.getRuntime().exec("taskkill /F /FI \"WINDOWTITLE eq Sawgrass - Single Sign On Login - |ie|\"");
    			process = Runtime.getRuntime().exec("taskkill /F /FI \"WINDOWTITLE eq Single Sign-On\"");    			
                log.info(String.format("All windows closed coming from firefly except: %s", windowName));
			break;
    		case "SAWGRASS":
    			process = Runtime.getRuntime().exec("taskkill /F /FI \"WINDOWTITLE eq Eclipse - |ie|\"");
    			process = Runtime.getRuntime().exec("taskkill /F /FI \"WINDOWTITLE eq Single Sign-On\"");    			
                log.info(String.format("All windows closed coming from firefly except: %s", windowName));
			break;
    		case "SALESFORCE":
    			process = Runtime.getRuntime().exec("taskkill /F /FI \"WINDOWTITLE eq Sawgrass - Single Sign On Login - |ie|\"");
    			process = Runtime.getRuntime().exec("taskkill /F /FI \"WINDOWTITLE eq Eclipse - |ie|\"");    			
                log.info(String.format("All windows closed coming from firefly except: %s", windowName));
			break;
    		default:
    			log.info(String.format("Wrong option, unable to close, please choose from followings: ECLIPSE, SAWGRASS, SALESFORCE"));
			break;
    	}
		
		process.waitFor();
    }
}
