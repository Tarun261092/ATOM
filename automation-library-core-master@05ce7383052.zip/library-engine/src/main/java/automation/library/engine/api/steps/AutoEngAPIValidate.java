package automation.library.engine.api.steps;

import automation.library.common.TestContext;
import automation.library.engine.api.BaseAPISteps;
import automation.library.engine.core.validator.AssertHelper;
import automation.library.engine.core.validator.ComparisonOperator;
import automation.library.engine.core.validator.ComparisonType;
import io.cucumber.java.en.Then;

public class AutoEngAPIValidate extends BaseAPISteps {

    private static final String EQUAL_TO = "Equal To";
    private static final String ATTRIBUTE_PRESENT = "#present";

    @Then("^the user validates the API response has attribute \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void theUserValidatesResponseHasAttributeEqualTo(String attributeName,
                                                            String validationID,
                                                            String onFailureFlag) {
        validateAPIResponse(RESPONSE_KEY,
                            attributeName,
                            ROOT_ATTRIBUTE,
                            EQUAL_TO,
                            ATTRIBUTE_PRESENT,
                            validationID,
                            onFailureFlag);
    }

    @Then("^the user validates the API response has attribute \"([^\"]*)\" within parent attribute \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void theUserValidatesTheAPIResponseHasAttributeWithinParentAttribute(String attributeName,
                                                                                String parentAttributeName,
                                                                                String validationID,
                                                                                String onFailureFlag) {

        validateAPIResponse(RESPONSE_KEY,
                            attributeName,
                            parentAttributeName,
                            EQUAL_TO,
                            ATTRIBUTE_PRESENT,
                            validationID,
                            onFailureFlag);
    }

    @Then("^the user validates the API response attribute \"([^\"]*)\" is \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void theUserValidatesTheAPIResponseAttributeIs(String attributeName,
                                                          String comparisonType,
                                                          String expectedValue,
                                                          String validationID,
                                                          String onFailureFlag) {

        validateAPIResponse(RESPONSE_KEY,
                            attributeName,
                            ROOT_ATTRIBUTE,
                            comparisonType,
                            expectedValue,
                            validationID,
                            onFailureFlag);
    }

    @Then("^the user validates the attribute \"([^\"]*)\" from the JSON payload at dictionary key \"([^\"]*)\" is \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void theUserValidatesTheJSONResponseAttributeIs(String attributeName,
                                                           String dictionaryKey,
                                                           String comparisonType,
                                                           String expectedValue,
                                                           String validationID,
                                                           String onFailureFlag) {


        validateAPIResponse(parseDictionaryKey(dictionaryKey),
                            attributeName,
                            ROOT_ATTRIBUTE,
                            comparisonType,
                            expectedValue,
                            validationID,
                            onFailureFlag);
    }

    @Then("^the user validates the attribute \"([^\"]*)\" within parent attribute \"([^\"]*)\" from the JSON payload at dictionary key \"([^\"]*)\" is \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void theUserValidatesTheJSONResponseAttributeWithParent(String attributeName,
                                                                   String parentAttributeName,
                                                                   String dictionaryKey,
                                                                   String comparisonType,
                                                                   String expectedValue,
                                                                   String validationID,
                                                                   String onFailureFlag) {


        validateAPIResponse(parseDictionaryKey(dictionaryKey),
                            attributeName,
                            parentAttributeName,
                            comparisonType,
                            expectedValue,
                            validationID,
                            onFailureFlag);
    }

    @Then("^the user validates the API response attribute \"([^\"]*)\" within parent attribute \"([^\"]*)\" is \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void theUserValidatesTheAPIResponseAttributeWithParentIs(String attributeName,
                                                                    String parentAttributeName,
                                                                    String comparisonOperator,
                                                                    String expectedValue,
                                                                    String validationID,
                                                                    String onFailureFlag) {

        validateAPIResponse(RESPONSE_KEY,
                            attributeName,
                            parentAttributeName,
                            comparisonOperator,
                            expectedValue,
                            validationID,
                            onFailureFlag);
    }

    @Then("^the user validates the API response has status code of \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void theUserValidatesTheAPIResponseHasStatusCodeOf(String expectedStatus,
                                                              String validationID,
                                                              String onFailureFlag) {
        expectedStatus = parseValue(expectedStatus);
        String actualStatus = TestContext.getInstance().testdataGet(RESPONSE_STATUS_KEY).toString();

        AssertHelper validator = new AssertHelper(ComparisonType.COMPARE_STRINGS, ComparisonOperator.EQ, onFailureFlag);
        validator.performValidation(actualStatus, expectedStatus, validationID, "API response code validation");
    }

    @Then("^the user validates the schema of JSON payload at dictionary key \"([^\"]*)\" response against expected schema \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void theUserValidatesSchemaOfJsonPayload(String dictionaryKey,
                                                    String schemaName,
                                                    String validationID,
                                                    String onFailureFlag) {

        validateJsonSchema(parseDictionaryKey(dictionaryKey),
                           schemaName,
                           validationID,
                           onFailureFlag);

    }

    @Then("^the user validates the schema of the API response against expected schema \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void theUserValidatesSchemaOfAPIResponse(String schemaName,
                                                    String validationID,
                                                    String onFailureFlag) {

        validateJsonSchema(RESPONSE_KEY,
                           schemaName,
                           validationID,
                           onFailureFlag);

    }

}