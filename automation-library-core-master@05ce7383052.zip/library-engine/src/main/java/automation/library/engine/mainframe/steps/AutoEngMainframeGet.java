package automation.library.engine.mainframe.steps;

import automation.library.common.TestContext;
import automation.library.engine.mainframe.BaseMFSteps;
import automation.library.leanft.core.mainframe.LeanFTField;
import automation.library.leanft.core.mainframe.LeanFTTable;
import automation.library.leanft.exec.DesktopContext;
import com.hp.lft.sdk.GeneralLeanFtException;
import io.cucumber.java.en.When;

import java.util.List;
import java.util.Optional;

import static automation.library.common.DateHelper.*;

public class AutoEngMainframeGet extends BaseMFSteps {

    @When("^the user gets the value from the \"([^\"]*)\" field on the \"([^\"]*)\" TE screen and stores into data dictionary with key \"([^\"]*)\"$")
    public void theUserGetsTheValueFromTheFieldOnTheTEScreenAndStoresIntoDataDictionaryWithKey(String fieldName,
                                                                                               String screenName,
                                                                                               String dictionaryKey) throws GeneralLeanFtException {
        DesktopContext.getInstance().setCurrentLeanFTScreen(getMainframeScreen(screenName));
        dictionaryKey = parseDictionaryKey(dictionaryKey);
        LeanFTField field = getMainframeObject(fieldName, screenName);

        if (field.exists() != null) {
            String valToStore = field.getText();
            TestContext.getInstance().testdataPut(dictionaryKey, valToStore);
            logStepMessage(String.format(STORED_VALUE, valToStore, dictionaryKey));
        }
    }

    @When("^store text from the \"([^\"]*)\" column where the \"([^\"]*)\" column is the first \"([^\"]*)\" in the \"([^\"]*)\" table on the \"([^\"]*)\" TE screen into the data dictionary with key \"([^\"]*)\"$")
    public void theUserStoresValOnColumnMatchToType(String colToRetrieve,
                                                    String colToMatch,
                                                    String typeToMatch,
                                                    String tableName,
                                                    String screenName,
                                                    String dictionaryKey) throws GeneralLeanFtException {

        theUserStoresValOnColumnMatchToValue(colToRetrieve,
                                             colToMatch,
                                             typeToMatch,
                                             tableName,
                                             screenName,
                                             dictionaryKey);
    }

    @When("^store text from the \"([^\"]*)\" column where the \"([^\"]*)\" column is \"([^\"]*)\" in the \"([^\"]*)\" table on the \"([^\"]*)\" TE screen into the data dictionary with key \"([^\"]*)\"$")
    public void theUserStoresValOnColumnMatchToValue(String colToRetrieve,
                                                     String colToMatch,
                                                     String valToMatch,
                                                     String tableName,
                                                     String screenName,
                                                     String dictionaryKey) throws GeneralLeanFtException {

        DesktopContext.getInstance().setCurrentLeanFTScreen(getMainframeScreen(screenName));
        valToMatch = parseValue(valToMatch);
        dictionaryKey = parseDictionaryKey(dictionaryKey);

        LeanFTTable table = getMainframeTable(tableName, screenName);
        String actualFieldText = table.retrieveColumnVal(colToRetrieve, colToMatch, valToMatch);

        if(!actualFieldText.isEmpty()) {
            TestContext.getInstance().testdataPut(dictionaryKey, actualFieldText);
            logStepMessage(String.format(STORED_VALUE, actualFieldText, dictionaryKey));
        }
    }

    @When("^store text from the \"([^\"]*)\" column where the \"([^\"]*)\" column is \"([^\"]*)\" and the \"([^\"]*)\" column is \"([^\"]*)\" in the \"([^\"]*)\" table on the \"([^\"]*)\" TE screen into the data dictionary with key \"([^\"]*)\"$")
    public void theUserStoresValOnColumnMatchToTwoValues(String colToRetrieve,
                                                         String colToMatch1,
                                                         String valToMatch1,
                                                         String colToMatch2,
                                                         String valToMatch2,
                                                         String tableName,
                                                         String screenName,
                                                         String dictionaryKey) throws GeneralLeanFtException {

        DesktopContext.getInstance().setCurrentLeanFTScreen(getMainframeScreen(screenName));
        valToMatch1 = parseValue(valToMatch1);
        valToMatch2 = parseValue(valToMatch2);
        dictionaryKey = parseDictionaryKey(dictionaryKey);

        LeanFTTable table = getMainframeTable(tableName, screenName);
        String actualFieldText = table.retrieveColumnVal(colToRetrieve, colToMatch1, valToMatch1, colToMatch2, valToMatch2);

        storeReturnedValueFromList(dictionaryKey, actualFieldText);
    }

    @When("^store text from the \"([^\"]*)\" column where the \"([^\"]*)\" column is \"([^\"]*)\" and the \"([^\"]*)\" column is \"([^\"]*)\" and the \"([^\"]*)\" column is \"([^\"]*)\" in the \"([^\"]*)\" table on the \"([^\"]*)\" TE screen into the data dictionary with key \"([^\"]*)\"$")
    public void theUserStoresValOnColumnMatchToThreeValues(String colToRetrieve,
                                                           String colToMatch1,
                                                           String valToMatch1,
                                                           String colToMatch2,
                                                           String valToMatch2,
                                                           String colToMatch3,
                                                           String valToMatch3,
                                                           String tableName,
                                                           String screenName,
                                                           String dictionaryKey) throws GeneralLeanFtException {

        DesktopContext.getInstance().setCurrentLeanFTScreen(getMainframeScreen(screenName));
        valToMatch1 = parseValue(valToMatch1);
        valToMatch2 = parseValue(valToMatch2);
        valToMatch3 = parseValue(valToMatch3);
        dictionaryKey = parseDictionaryKey(dictionaryKey);

        LeanFTTable table = getMainframeTable(tableName, screenName);
        String actualFieldText = table.retrieveColumnVal(colToRetrieve,
                                                         colToMatch1, valToMatch1,
                                                         colToMatch2, valToMatch2,
                                                         colToMatch3, valToMatch3);

        storeReturnedValueFromList(dictionaryKey, actualFieldText);
    }

    @When("^store text from the \"([^\"]*)\" column where the \"([^\"]*)\" column is \"([^\"]*)\" and the \"([^\"]*)\" column is \"([^\"]*)\" and the \"([^\"]*)\" column is \"([^\"]*)\" and the \"([^\"]*)\" column is \"([^\"]*)\" in the \"([^\"]*)\" table on the \"([^\"]*)\" TE screen into the data dictionary with key \"([^\"]*)\"$")
    public void theUserStoresValOnColumnMatchToFourValues(String colToRetrieve,
                                                          String colToMatch1,
                                                          String valToMatch1,
                                                          String colToMatch2,
                                                          String valToMatch2,
                                                          String colToMatch3,
                                                          String valToMatch3,
                                                          String colToMatch4,
                                                          String valToMatch4,
                                                          String tableName,
                                                          String screenName,
                                                          String dictionaryKey) throws GeneralLeanFtException {

        DesktopContext.getInstance().setCurrentLeanFTScreen(getMainframeScreen(screenName));
        valToMatch1 = parseValue(valToMatch1);
        valToMatch2 = parseValue(valToMatch2);
        valToMatch3 = parseValue(valToMatch3);
        valToMatch4 = parseValue(valToMatch4);
        dictionaryKey = parseDictionaryKey(dictionaryKey);

        LeanFTTable table = getMainframeTable(tableName, screenName);
        String actualFieldText = table.retrieveColumnVal(colToRetrieve,
                                                         colToMatch1, valToMatch1,
                                                         colToMatch2, valToMatch2,
                                                         colToMatch3, valToMatch3,
                                                         colToMatch4, valToMatch4);

        storeReturnedValueFromList(dictionaryKey, actualFieldText);
    }

    @When("^store minimum value from the \"([^\"]*)\" column where the column \"([^\"]*)\" is \"([^\"]*)\" and the column \"([^\"]*)\" is \"([^\"]*)\" in the \"([^\"]*)\" table on the \"([^\"]*)\" TE screen and stores into data dictionary with key \"([^\"]*)\"$")
    public void theUserExtractsOneColumnUsingTwoColumnMatch(String colToRetrieve,
                                                            String colToMatch1,
                                                            String valToMatch1,
                                                            String colToMatch2,
                                                            String valToMatch2,
                                                            String tableName,
                                                            String screenName,
                                                            String dictionaryKey) throws GeneralLeanFtException {

        valToMatch1 = parseValue(valToMatch1);
        valToMatch2 = parseValue(valToMatch2);
        dictionaryKey = parseDictionaryKey(dictionaryKey);
        DesktopContext.getInstance().setCurrentLeanFTScreen(getMainframeScreen(screenName));

        LeanFTTable table = getMainframeTable(tableName, screenName);
        List<String> actualFieldText = table.retrieveAllColumnVals(colToRetrieve, colToMatch1, valToMatch1,colToMatch2, valToMatch2);

        if (!actualFieldText.isEmpty()) {
            final Optional<String> first = actualFieldText.stream().sorted().findFirst();
            if(first.isPresent()) {
                String valueFetched = first.get();
                TestContext.getInstance().testdataPut(dictionaryKey, valueFetched);
                logStepMessage(String.format(STORED_VALUE, valueFetched, dictionaryKey));
            }
        }
    }

    @When("^store value from the \"([^\"]*)\" column where the column \"([^\"]*)\" or \"([^\"]*)\" column where the column \"([^\"]*)\" or \"([^\"]*)\" column where the column \"([^\"]*)\" is \"([^\"]*)\" in the \"([^\"]*)\" table on the \"([^\"]*)\" TE screen with the dictionary key \"([^\"]*)\"$")
    public void theUserStoreValueFromMatchingColumns(String colToRetrieve1,
                                                     String colToMatch1,
                                                     String colToRetrieve2,
                                                     String colToMatch2,
                                                     String colToRetrieve3,
                                                     String colToMatch3,
                                                     String valToMatch,
                                                     String tableName,
                                                     String screenName,
                                                     String dictionaryKey) throws GeneralLeanFtException {

        colToRetrieve1 = parseValue(colToRetrieve1);
        colToRetrieve2= parseValue(colToRetrieve2);
        colToRetrieve3 = parseValue(colToRetrieve3);
        valToMatch = parseValue(valToMatch);
        dictionaryKey = parseDictionaryKey(dictionaryKey);
        DesktopContext.getInstance().setCurrentLeanFTScreen(getMainframeScreen(screenName));
        String actualFieldText = "";
        LeanFTTable table = getMainframeTable(tableName, screenName);
        if (table.retrieveAllColumnVals(colToMatch1).contains(valToMatch)) {
            actualFieldText = table.retrieveColumnVal(colToRetrieve1, colToMatch1, valToMatch);
        } else if (table.retrieveAllColumnVals(colToMatch2).contains(valToMatch)) {
            actualFieldText = table.retrieveColumnVal(colToRetrieve2, colToMatch2, valToMatch);

        } else if (table.retrieveAllColumnVals(colToMatch3).contains(valToMatch)) {
            actualFieldText = table.retrieveColumnVal(colToRetrieve3, colToMatch3, valToMatch);
        }
        storeReturnedValueFromList(dictionaryKey, actualFieldText);

    }

    @When("^store values from the \"([^\"]*)\" column where \"([^\"]*)\" column value is closest to \"([^\"]*)\" and \"([^\"]*)\" column value is \"([^\"]*)\" in the \"([^\"]*)\" table on the \"([^\"]*)\" TE screen with the dictionary key \"([^\"]*)\"$")
    public void theUserStoreValuesFromColumnContainigClosest(String colToRetrieve,
                                                             String colToMatch1,
                                                             String valToMatch1,
                                                             String colToMatch2,
                                                             String valToMatch2,
                                                             String tableName,
                                                             String screenName,
                                                             String dictionaryKey) throws GeneralLeanFtException {

        valToMatch1 = parseValue(valToMatch1);
        valToMatch2 = parseValue(valToMatch2);
        dictionaryKey = parseDictionaryKey(dictionaryKey);
        DesktopContext.getInstance().setCurrentLeanFTScreen(getMainframeScreen(screenName));

        LeanFTTable table = getMainframeTable(tableName, screenName);
        List<String> listToCompare = table.retrieveAllColumnVals(colToMatch1, colToMatch2, valToMatch2);
        String closetTime = getClosestTimeFromList(listToCompare, valToMatch1);
        String justAboveclosestTime = getAboveClosestTimeFromList(listToCompare, closetTime);
        String justBelowclosestTime = getBelowClosestTimeFromList(listToCompare, closetTime);
        String actualFieldTextForAboveClosest = table.retrieveColumnVal(colToRetrieve, colToMatch1, justAboveclosestTime, colToMatch2, valToMatch2).split("\\|")[1].trim();
        String actualFieldTextForBelowClosest = table.retrieveColumnVal(colToRetrieve, colToMatch1, justBelowclosestTime, colToMatch2, valToMatch2).split("\\|")[1].trim();
        storeReturnedValueFromList(dictionaryKey + " ONE", actualFieldTextForAboveClosest);
        storeReturnedValueFromList(dictionaryKey + " TWO", actualFieldTextForBelowClosest);
    }

    @When("^the user stores value of \"([^\"]*)\" length from the field by searching with unique key \"([^\"]*)\" on the \"([^\"]*)\" TE screen with the dictionary key \"([^\"]*)\"$")
    public void theUserStoresValueOfLengthFromTheFieldBySearchingWithUniqueKeyOnTheTEScreenWithTheDictionaryKey(String valueLength, String uniqueKey, String screenName, String dictionaryKey) throws GeneralLeanFtException, InterruptedException {
    	valueLength = parseValue(valueLength);
    	uniqueKey = parseValue(uniqueKey);
    	dictionaryKey = parseDictionaryKey(dictionaryKey);
        DesktopContext.getInstance().setCurrentLeanFTScreen(getMainframeScreen(screenName));
        
        String valueToStore = "";
        List<String> actualValueList = searchUniqueTextInAllScreens(valueLength, uniqueKey, true);        
        if(actualValueList == null) {
        	log.error(String.format("Unable to find the value : %s in the current screen", uniqueKey));
        } else {
        	valueToStore = actualValueList.get(0);	
        }               
        
        if(!valueToStore.isEmpty()) {
        	TestContext.getInstance().testdataPut(dictionaryKey, valueToStore);
            logStepMessage(String.format(STORED_VALUE, valueToStore, dictionaryKey));
        } else {
        	log.error(String.format("Unable to find the value : %s in the current screen", uniqueKey));
        }
    }
    
    @When("^the user stores list of values of \"([^\"]*)\" length from the field by searching with unique key \"([^\"]*)\" on the \"([^\"]*)\" TE screen with the dictionary key \"([^\"]*)\"$")
    public void theUserStoresListOfValuesOfLengthFromTheFieldBySearchingWithUniqueKeyOnTheTEScreenWithTheDictionaryKey(String valueLength, String uniqueKey, String screenName, String dictionaryKey) throws GeneralLeanFtException, InterruptedException {
    	valueLength = parseValue(valueLength);
    	uniqueKey = parseValue(uniqueKey);
    	dictionaryKey = parseDictionaryKey(dictionaryKey);
        DesktopContext.getInstance().setCurrentLeanFTScreen(getMainframeScreen(screenName));
        
        List<String> listOfValueToStore = searchUniqueTextInAllScreens(valueLength, uniqueKey, false);
        
        if(listOfValueToStore != null) {
        	TestContext.getInstance().testdataPut(dictionaryKey, listOfValueToStore);
            logStepMessage(String.format(STORED_VALUE, listOfValueToStore, dictionaryKey));
        } else {
        	log.error(String.format("Unable to find the value : %s in the current screen", uniqueKey));
        }
    }
}
