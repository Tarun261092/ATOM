package automation.library.engine.db.steps;

import automation.library.common.ExcelHelper;
import automation.library.common.FileHelper;
import automation.library.common.TestContext;
import automation.library.cucumber.core.Constants;
import automation.library.engine.core.validator.AssertHelper;
import automation.library.engine.db.BaseDBSteps;
import io.cucumber.java.en.Then;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class AutoEngDBValidate extends BaseDBSteps {

    @Then("^the user validates that the \"([^\"]*)\" DB column contains a value of \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void theUserValidatesTheQueryResultHasTableColumnWithValue(String columnName,
                                                                      String expectedValue,
                                                                      String validationID,
                                                                      String onFailureFlag)  {

        theUserValidatesTheQueryResultHasTableColumnIs("Compare_Strings",
                                                       columnName,
                                                       "Contains",
                                                       expectedValue,
                                                       validationID,
                                                       onFailureFlag);
    }

    @Then("^the user validates \"([^\"]*)\" that the \"([^\"]*)\" DB column is \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void theUserValidatesTheQueryResultHasTableColumnIs(String comparisonType,
                                                               String columnName,
                                                               String comparisonOperator,
                                                               String expectedValue,
                                                               String validationID,
                                                               String onFailureFlag) {

        columnName = parseDictionaryKey(columnName);
        expectedValue = parseValue(expectedValue);

        Object actualValue = getActualValueFromDBResult(TestContext.getInstance().testdataToClass(QUERY_RESULT, List.class),
                                                        columnName,
                                                        1);

        AssertHelper validator = new AssertHelper(comparisonType, comparisonOperator, onFailureFlag);
        validator.performValidation(actualValue, expectedValue,
                                    validationID,
                                    String.format("'%s' DB column comparison", columnName));
    }

    @Then("^the user validates all blanks in the DB query result based on mapping sheet \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void theUserValidatesMappingSheet(String mappingSheetFileName,
                                             String tabNameWithRules,
                                             String SASVarColumnName,
                                             String expectedCitiValColName,
                                             String acceptableBlankValues,
                                             String validationID,
                                             String onFailureFlag) {

        String pathToMappingSheet = FileHelper.findFileInPath(Constants.TESTDATAPATH, mappingSheetFileName);
        List<Map<String, Object>> mappingSheetData = ExcelHelper.getExcelDataAsMapWithoutIndex(pathToMappingSheet,
                                                                                               tabNameWithRules);
        List<Map<String, Object>> queryResultToValidate = TestContext.getInstance().testdataToClass(QUERY_RESULT, List.class);
        List<String> expectedBlankVals = Arrays.stream(acceptableBlankValues.split("\\|")).map(String::trim).collect(Collectors.toList());
        expectedBlankVals.add("");

        if (!mappingSheetData.isEmpty() && !queryResultToValidate.isEmpty()) {
            mappingSheetData.stream()
                            .filter(entry -> entry.get(expectedCitiValColName) != null)
                            .filter(entry -> entry.get(SASVarColumnName) != null)
                            .filter(entry -> entry.get(expectedCitiValColName).toString().equalsIgnoreCase("Blank"))
                            .forEach(entry -> {
                                validateBlankValsFromDB(entry.get(SASVarColumnName).toString(),
                                                        queryResultToValidate,
                                                        expectedBlankVals,
                                                        validationID,
                                                        onFailureFlag);
                            });
        }

    }
}