package automation.library.engine.db.steps;

import automation.library.engine.db.BaseDBSteps;
import io.cucumber.java.en.When;

public class AutoEngDBStoreValue extends BaseDBSteps {

    @When("^store query result into the data dictionary with key \"([^\"]*)\"$")
    public void theUserStoresFromtheQueryIntoTheDataDictionaryWithKey(String dictionaryKey)  {
        dictionaryKey = parseDictionaryKey(dictionaryKey);
        storeQueryResults(dictionaryKey);
    }

    @When("^store the \"([^\"]*)\" DB column value into the data dictionary with key \"([^\"]*)\"$")
    public void theUserStoresFromtheQueryResultIntoTheDataDictionaryWithKey(String columnName,
                                                                            String dictionaryKey)  {
        dictionaryKey = parseDictionaryKey(dictionaryKey);
        storeColumnValueFromQueryResults("0", parseValue(columnName), dictionaryKey);
    }

    @When("^store index \"([^\"]*)\" of the \"([^\"]*)\" DB column value into the data dictionary with key \"([^\"]*)\"$")
    public void theUserStoresIndexOfColumnValueFromtheQueryResultIntoTheDataDictionaryWithKey(String index,
                                                                                              String columnName,
                                                                                              String dictionaryKey)  {
        dictionaryKey = parseDictionaryKey(dictionaryKey);
        storeColumnValueFromQueryResults(index, columnName, dictionaryKey);
    }
}
