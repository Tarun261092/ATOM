package automation.library.engine.web.steps;

import automation.library.common.TestContext;
import automation.library.engine.web.BaseWebSteps;
import io.cucumber.java.en.*;

import org.openqa.selenium.By;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class AutoEngWebAppLaunch extends BaseWebSteps {
    @Given("^the web application \"([^\"]*)\" is launched in a \"([^\"]*)\"$")
    public void theWebApplicationIsLaunchedInA(String appName, String location)  {
        launchApplication(appName, location);
        TestContext.getInstance().pushWindowHandle(getDriver().getWindowHandle());
    }

    @Given("^the web application \"([^\"]*)\" is launched in \"([^\"]*)\" in a \"([^\"]*)\"$")
    public void theWebApplicationIsLaunchedInBrowser(String appName, String browserName, String location)  {
        launchApplication(appName, browserName, location);
        TestContext.getInstance().pushWindowHandle(getDriver().getWindowHandle());
    }

    @Given("^the user bypasses the IE security certificate page$")
    public void theUserBypassIESecurityCertificatePage() {
        if (getDriver() instanceof InternetExplorerDriver) {
            getDriver().navigate().to("javascript:document.getElementById('overridelink').click()");
        } else {
            log.warn("Not running an IE browser. Skipping step");
        }
    }
    @Given("^the user relaunches the site in the \"([^\"]*)\" environment$")
    public void theUserRelaunchesTheSiteInNewEnvironment(String environment) {
        
    	environment = parseValue(environment);
    	String URL = getDriver().getCurrentUrl();
    	String header = "";
    	
    	if (URL.contains("https://")) {
    		header= "https://";
    	}
    	else {
    		header = "http://";
    	}
    	
    	URL = URL.replace(header, "");
    	URL = header + environment + "." + URL; 
    	getDriver().navigate().to(URL);
    }
    
    @Given("^the user bypasses the Chrome private connection page$")
    public void theUserBypassTheChromePrivateConnectionPage() {
    	 try {
 			Thread.sleep(1000);
 		} catch (InterruptedException e) {
 			e.printStackTrace();
 		}
        getDriver().findElement(By.xpath("//button[@id='details-button']")).click();
        try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
        getDriver().findElement(By.xpath("//a[@id='proceed-link']")).click();
    }

    @And("^the user bypasses the browser security certificate page$")
	public void theUserBypassBrowserSecurityCertificatePage() {
		if (getDriver() instanceof InternetExplorerDriver) {
			theUserBypassIESecurityCertificatePage();
		} else {
			if (getDriver().findElement(By.id("details-button")).isDisplayed()) {
				getDriver().findElement(By.id("details-button")).click();
				getDriver().findElement(By.id("proceed-link")).click();
			}
		}
	}

}
