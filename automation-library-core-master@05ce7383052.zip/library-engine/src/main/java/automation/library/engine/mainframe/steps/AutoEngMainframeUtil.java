package automation.library.engine.mainframe.steps;

import automation.library.common.ExcelHelper;
import automation.library.common.FileHelper;
import automation.library.common.Property;
import automation.library.cucumber.core.Constants;
import automation.library.engine.core.runner.FDRDataConditionWriter;
import automation.library.engine.mainframe.BaseMFSteps;
import automation.library.leanft.exec.DesktopContext;
import com.hp.lft.sdk.GeneralLeanFtException;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.configuration2.PropertiesConfiguration;

import java.io.File;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static automation.library.leanft.core.mainframe.MainframeScreenshot.grabScreenshot;
import static automation.library.leanft.core.mainframe.MainframeScreenshot.saveScreenshot;
import static automation.library.reporting.Reporter.addScreenCaptureFromPath;
import static automation.library.reporting.Reporter.getScreenshotPath;

public class AutoEngMainframeUtil extends BaseMFSteps {

    @Then("^the user waits for the \"([^\"]*)\" TE screen to load$")
    public void theUserWaitsForTEScreenToLoad(String screenName) throws GeneralLeanFtException {
        DesktopContext.getInstance().setCurrentLeanFTScreen(getMainframeScreen(screenName));
        getMainframeScreen(screenName).getScreen().sync();
    }

    @When("^the user takes a screenshot of the \"([^\"]*)\" TE screen$")
    public void theUserTakesTEscreenshot(String screen) {
        File file = saveScreenshot(grabScreenshot(getMainframeScreen(screen)), getScreenshotPath());
        addScreenCaptureFromPath(file.getAbsolutePath());
    }

    @When("generate data input files from the \"([^\"]*)\" tab in the FDR conditioning sheet \"([^\"]*)\"")
    public void generateFDRDataConditions(String tabName, String fileName) {

        String pathToInputSheet = FileHelper.findFileInPath(Constants.TESTDATAPATH, parseValue(fileName));
        PropertiesConfiguration fdrProps = Property.getProperties(Constants.FDR_PROPERTIES_FILE_PATH);
        Map<String, LinkedHashMap<String, Object>> logicMap = ExcelHelper.getDataAsMap(Constants.BASEPATH + fdrProps.getString("conditionLogicFileName"),
                                                                                       fdrProps.getString("conditionLogicSheetName"));
        List<Map<String, Object>> conditioningInputs = ExcelHelper.getExcelDataAsMapWithoutIndex(pathToInputSheet, parseValue(tabName), true);
        if (!conditioningInputs.isEmpty()) {
            conditioningInputs.stream()
                              .filter(entry -> entry.get(fdrProps.getString("MainCriteria")) != null)
                              .filter(entry -> entry.get(fdrProps.getString("AdditionalCriteria")) != null)
                              .forEach(entry -> new FDRDataConditionWriter().generateJSONFromDataConditions(entry.get(fdrProps.getString("MainCriteria")),
                                                                                                        entry.get(fdrProps.getString("AdditionalCriteria")),
                                                                                                        entry.get(fdrProps.getString("StoreNumbers")),
                                                                                                        entry.get(fdrProps.getString("Embossing")),
                                                                                                        logicMap));
        }
    }

}
