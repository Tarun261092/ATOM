package automation.library.engine.mainframe;

import automation.library.common.Property;
import automation.library.common.StringHelper;
import automation.library.common.TestContext;
import automation.library.engine.core.BaseStepsEngine;
import automation.library.engine.core.objectmatcher.ObjectNotFoundException;
import automation.library.leanft.core.Constants;
import automation.library.leanft.core.mainframe.LeanFTField;
import automation.library.leanft.core.mainframe.LeanFTScreen;
import automation.library.leanft.core.mainframe.LeanFTTable;
import automation.library.leanft.exec.DesktopContext;
import automation.library.leanft.exec.maps.App;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.stream.JsonReader;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.te.Keys;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static automation.library.cucumber.core.Constants.ENVIRONMENTPATH;
import static automation.library.engine.core.AutoEngConstants.LEANFT;
import static automation.library.engine.core.objectmatcher.ObjectFinder.getMatchingElement;

public class BaseMFSteps extends BaseStepsEngine {
    protected static final String LIST_DELIMITER = " | ";
    public static final String EMB_TRAN_TYPE = "EMB TRAN TYPE";
    public static final String NA = "NA";
    public static final String FE = "FE";
    protected String jsonName = "";

    protected void launchApplication(String appName) {
        TestContext.getInstance().setActiveWindowType(LEANFT);
        DesktopContext.getInstance().setDesktopContextWithLaunchInfo(appName);
        DesktopContext.getInstance().getAut(appName);
    }

    protected void launchApplication(String appName, String location) {
        DesktopContext.getInstance().setEmulatorName(appName, location);
        launchApplication(appName);
    }

    protected void launchApplicationWithLaunchText(String appName, String launchText) {
        launchApplication(appName);
        enterLaunchTextForApp(DesktopContext.getInstance().getAppLaunchData().getAppList().get(appName), launchText, appName);
    }

    private void enterLaunchTextForApp(App appLaunchData, String launchTextToUse, String appName) {
        String launchText = launchTextToUse.isEmpty() ? getLaunchTextFromEnvFile(appName) : launchTextToUse;
        String screenName = appLaunchData.getStartingScreen();
        String fieldName = appLaunchData.getStartingField();

        try {
            if (launchText != null) {
                List<String> listOfLaunchText = Arrays.asList(launchText.split("\\s+"));
                listOfLaunchText = listOfLaunchText.stream()
                                                   .map(this::parseIfVariable)
                                                   .collect(Collectors.toList());
                DesktopContext.getInstance().setCurrentLeanFTScreen(getMainframeScreen(screenName));
                getMainframeObject(fieldName, screenName).setText(String.join(" ", listOfLaunchText));
                logStepMessage(String.format(ENTERED_VALUE, String.join(" ", listOfLaunchText)));
                getMainframeScreen(screenName).sendKeys(Keys.ENTER);
            }
        } catch (GeneralLeanFtException e) {
            log.error(e.getMessage());
        }
    }

    private String getLaunchTextFromEnvFile(String appName) {
        String propsFilePath = ENVIRONMENTPATH + Property.getVariable(ENV_PROP) + PROPERTIES_EXT;
        return Property.getProperty(propsFilePath, StringHelper.removeSpecialChars(appName));
    }

    protected void closeApplication(String appName) {
        DesktopContext.getInstance().quitAut(appName);
    }

    /**
     * Generic method to find object
     *
     * @param fieldName
     * @param screenName
     */
    protected LeanFTField getMainframeObject(String fieldName, String screenName) {
        Object ele = getMatchingElement(fieldName, screenName);

        if (ele instanceof LeanFTField) {
            return (LeanFTField) ele;
        } else {
            throw new ObjectNotFoundException("The \"" + fieldName + "\" was not found in the page object: : \"" + screenName + "\"");
        }
    }

    /**
     * Generic method to find object
     *
     * @param screenName
     */
    public static LeanFTScreen getMainframeScreen(String screenName) {
        Object ele = getMatchingElement("screen", screenName);

        if (ele instanceof LeanFTScreen) {
            return (LeanFTScreen) ele;
        } else {
            throw new ObjectNotFoundException("The 'screen' was not found in the page object: : \"" + screenName + "\"");
        }
    }

    /**
     * Generic method to find object
     *
     * @param tableName
     * @param screenName
     */
    protected LeanFTTable getMainframeTable(String tableName, String screenName) {
        Object ele = getMatchingElement(tableName, screenName);

        if (ele instanceof LeanFTTable) {
            return (LeanFTTable) ele;
        } else {
            throw new ObjectNotFoundException("The \"" + tableName + "\" was not found in the page object: : \"" + screenName + "\"");
        }
    }


    /**
     * @param key
     * @return
     */
    protected String getMnemonicKey(String key) {
        Gson gson = new Gson();
        try {
            JsonReader reader = new JsonReader(new FileReader(Constants.KEYBOARDMAINFRAMEJSON));
            JsonObject jsonObject = gson.fromJson(reader, JsonObject.class);
            key = jsonObject.get(key.toUpperCase()).getAsString();
        } catch (FileNotFoundException e) {
            log.error(e.getMessage());
        }
        return key;
    }

    protected String getValueFromField(String fieldName, String screenName) throws GeneralLeanFtException {
        LeanFTField field = getMainframeObject(fieldName, screenName);

        String actualVal = null;

        if (field.exists() != null) {
            if (Boolean.parseBoolean(System.getProperty("fw.trimMFTextOnRetrieval"))) {
                actualVal = field.getText().trim();
            } else {
                actualVal = field.getText();
            }
        }

        return actualVal;
    }

    protected void storeReturnedValueFromList(String dictionaryKey, String actualFieldText) {
        if (!actualFieldText.isEmpty()) {
            actualFieldText = getLastValueFromDelimitedList(actualFieldText);
            TestContext.getInstance().testdataPut(dictionaryKey, actualFieldText);
            logStepMessage(String.format(STORED_VALUE, actualFieldText, dictionaryKey));
        }
    }

    private String getLastValueFromDelimitedList(String strListOfVals) {
        List<String> arrListOfVals = Arrays.asList(strListOfVals.split(Pattern.quote(LIST_DELIMITER)));
        return arrListOfVals.get(arrListOfVals.size() - 1);
    }
    
    protected List<String> searchUniqueTextInAllScreens(String valueLength, String uniqueKey,
			Boolean onlyFirstOccurance) throws GeneralLeanFtException, InterruptedException {
		LeanFTScreen currentScreen = DesktopContext.getInstance().getCurrentLeanFTScreen();
		List<String> actualValueList = new ArrayList<String>();
		if (currentScreen.begOfScreenIndicator == null) {
			actualValueList = searchUniqueTextInTheScreen(valueLength, uniqueKey, currentScreen);
		} else {
			boolean atEndOfScreen = false;
			boolean foundMatch = false;
			boolean advanceToNextScreen = false;

			currentScreen.goToFirstPage();

			do {
				actualValueList.addAll(searchUniqueTextInTheScreen(valueLength, uniqueKey, currentScreen));

				foundMatch = !actualValueList.isEmpty();
				atEndOfScreen = currentScreen.atEndOfScreen();
				advanceToNextScreen = currentScreen.advanceToNextScreen(foundMatch && onlyFirstOccurance);
				Thread.sleep(2000);
			} while (!atEndOfScreen && !(foundMatch && onlyFirstOccurance) && advanceToNextScreen);
		}
		if (actualValueList.isEmpty())
			return null;
		else
			return actualValueList;
	}

	protected List<String> searchUniqueTextInTheScreen(String valueLength, String uniqueKey, LeanFTScreen currentScreen)
			throws GeneralLeanFtException {
		List<String> listOfExtractedValues = new ArrayList<String>();
		if (currentScreen.startX == currentScreen.endX) {
			for (int j = currentScreen.startY; j < currentScreen.endY; j++) {
				String extractedValue = currentScreen.getTextFromCoordinates(currentScreen.startX, j,
						currentScreen.startX, j + Integer.parseInt(valueLength));
				if (extractedValue.contains(uniqueKey))
					listOfExtractedValues.add(extractedValue);
			}
		} else if (currentScreen.startY == currentScreen.endY) {
			for (int i = currentScreen.startX; i < currentScreen.endX; i++) {
				String extractedValue = currentScreen.getTextFromCoordinates(i, currentScreen.startY, i,
						currentScreen.startY + Integer.parseInt(valueLength));
				if (extractedValue.contains(uniqueKey))
					listOfExtractedValues.add(extractedValue);
			}
		} else {
			for (int i = currentScreen.startX; i < currentScreen.endX; i++) {
				for (int j = currentScreen.startY; j < currentScreen.endY; j++) {
					String extractedValue = currentScreen.getTextFromCoordinates(i, j, i,
							j + Integer.parseInt(valueLength));
					if (extractedValue.contains(uniqueKey))
						listOfExtractedValues.add(extractedValue);
				}
			}
		}
		return listOfExtractedValues;
	}
}