package automation.library.engine.core.objectmatcher.rating;

public class FlatFileObjectRating {
    private String flatFileObjectName;
    private Double similarityScore;
    private String searchResultMsg;
    private String flatFileObjectList;

    public FlatFileObjectRating(String flatFileObjectName, Double similarityScore){
        this.flatFileObjectName = flatFileObjectName;
        this.similarityScore = similarityScore;
    }

    public FlatFileObjectRating(String flatFileObjectName, Double similarityScore, String searchResultMsg, String flatFileObjectList) {
        this.flatFileObjectName = flatFileObjectName;
        this.similarityScore = similarityScore;
        this.searchResultMsg = searchResultMsg;
        this.flatFileObjectList = flatFileObjectList;
    }

    public String getFlatFileObjectName() {
        return flatFileObjectName;
    }

    public Double getSimilarityScore() {
        return similarityScore;
    }

    public void setSimilarityScore(Double similarityScore) {
        this.similarityScore = similarityScore;
    }

    public String getSearchResultMsg() {
        return searchResultMsg;
    }

    public void setSearchResultMsg(String searchResultMsg) {
        this.searchResultMsg = searchResultMsg;
    }

    public String getFlatFileObjectList() { return flatFileObjectList; }

    public void setFlatFileObjectList(String flatFileObjectList) { this.flatFileObjectList = flatFileObjectList; }
}
