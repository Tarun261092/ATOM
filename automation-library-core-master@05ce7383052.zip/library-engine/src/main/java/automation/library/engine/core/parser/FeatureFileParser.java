package automation.library.engine.core.parser;

import automation.library.common.TestContext;
import automation.library.engine.core.objectmatcher.ObjectFinder;
import automation.library.engine.core.objectmatcher.fflookup.FunctionFeatureAnalyzer;
import automation.library.engine.core.objectmatcher.rating.FieldRating;
import automation.library.engine.core.objectmatcher.rating.FlatFileObjectRating;
import automation.library.engine.core.objectmatcher.rating.PageObjectRating;
import automation.library.reporting.ObjectAssociatorReporter;
import cucumber.util.FixJava;
import gherkin.AstBuilder;
import gherkin.Parser;
import gherkin.ParserException;
import gherkin.TokenMatcher;
import gherkin.ast.*;
import io.qameta.allure.model.Status;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static automation.library.common.StringHelper.removeSpecialChars;
import static java.util.stream.Collectors.toList;

public class FeatureFileParser {
    protected final Logger log = LogManager.getLogger(FeatureFileParser.class);
    protected final Set<File> featureFiles;
    private final List<String> stepDefAnnotationList;
    protected static final String FEATURE = ".feature";
    private final ObjectAssociatorReporter objectAssociatorReporter;

    public enum FieldEnum {
        ELEMENT("element"),
        TEXTBOX("textbox"),
        CHECKBOX("checkbox"),
        DROPDOWN("dropdown"),
        RADIOBUTTON("radiobutton"),
        FIELD("field");

        private final String text;

        FieldEnum(final String text) {
            this.text = text;
        }

        public String getVal() {
            return text;
        }
    }

    public FeatureFileParser() {
        featureFiles = Collections.unmodifiableSet(TestContext.getInstance().setOfFeatureFiles());
        stepDefAnnotationList = Collections.unmodifiableList(new StepDefParser().getListOfStepDefs());
        objectAssociatorReporter = new ObjectAssociatorReporter();
    }

    public void checkObjectAssociation() {
        Parser<GherkinDocument> parser = new Parser<>(new AstBuilder());
        TokenMatcher matcher = new TokenMatcher();

        for (File fil : featureFiles) {
            if (fil.getName().endsWith(FEATURE)) {
                parseFeature(parser, matcher, fil);
            }
        }
    }

    public void checkObjectAssociation(String featureName) {
        Parser<GherkinDocument> parser = new Parser<>(new AstBuilder());
        TokenMatcher matcher = new TokenMatcher();

        for (File fil : featureFiles) {
            if (fil.getName().equalsIgnoreCase(featureName)) {
                parseFeature(parser, matcher, fil);
            }
        }
    }

    private void parseFeature(Parser<GherkinDocument> parser, TokenMatcher matcher, File fil) {
        String gherkin;
        try {
            gherkin = FixJava.readReader(new InputStreamReader(new FileInputStream(fil), StandardCharsets.UTF_8));
            GherkinDocument d3 = parser.parse(gherkin, matcher);
            Feature feature = d3.getFeature();
            log.debug(">>>>>>>>>> Feature File: \"{}\" <<<<<<<<<", feature.getName());
            objectAssociatorReporter.resetFeature();
            objectAssociatorReporter.setFeatureName(feature.getName());
            parseFeatureSteps(feature);
        } catch (ParserException e) {
            objectAssociatorReporter.setFeatureName(fil.getName().substring(0, fil.getName().length() - 8));
            addParseErrorsToReport((ParserException.CompositeParserException) e);
            objectAssociatorReporter.resetScenario();
            objectAssociatorReporter.resetFeature();
            log.error(e.getMessage());
        } catch (IOException e) {
            log.error(e.getMessage(), e);
        }
    }

    private void addParseErrorsToReport(ParserException.CompositeParserException e) {
        List<String> tags = new ArrayList<>();
        tags.add("@parseError");
        objectAssociatorReporter.addScenario("FailedFeatureParsing", "FeatureFile Parsing Failed", tags);
        for (ParserException error : e.errors) {
            String message = error.getMessage();
            objectAssociatorReporter.beginStep("", message.substring(message.indexOf('\'') + 1, message.lastIndexOf('\'')));
            objectAssociatorReporter.addSubStepResult(Status.FAILED,
                                                      "Invalid feature file statement. Check Gherkin keyword used in the step and scenario tags.");
            objectAssociatorReporter.resetStep();
        }
    }

    private void parseFeatureSteps(Feature feature) {
        List<ScenarioDefinition> parts = feature.getChildren();

        for (ScenarioDefinition sd : parts) {
            objectAssociatorReporter.addScenario(sd.getName(), sd.getDescription(), getScenarioLabels(sd));
            parseFunctionFeature(sd);
            List<Step> steps = sd.getSteps();
            for (Step s : steps) {
                log.debug("  ** Step: {} {}", s.getKeyword(), s.getText());
                objectAssociatorReporter.beginStep(s.getKeyword(), s.getText());

                if (!isValidStep(s)) {
                    log.debug("Not a valid template sentence");
                    objectAssociatorReporter.addSubStepResult(Status.FAILED, "Not a valid template sentence.");
                } else {
                    objectAssociatorReporter.addSubStepResult(Status.PASSED, "Valid template sentence");
                    log.debug("Valid template sentence");
                    checkObjectNames(s);

                }
                objectAssociatorReporter.resetStep();
            }
            objectAssociatorReporter.resetScenario();
        }
    }

    private void checkObjectNames(Step s) {
        String pageName = getPageNameFromStep(s);
        if (pageName != null) {
            parsePageAndElement(s, pageName);
        }

        String apiName = getAPINameFromStep(s);
        if (apiName != null) {
            parseAPI(apiName);
        }

        String queryName = getQueryNameFromStep(s);
        if (queryName != null) {
            parseQuery(queryName);
        }
    }

    private String getPageNameFromStep(Step s) {
        String pageName = null;
        Matcher pageMatcher = getPageNameRegEx().matcher(s.getText());

        if (pageMatcher.find()) {
            pageName = pageMatcher.group(2);
        }
        return pageName;
    }

    private String getAPINameFromStep(Step s) {
        String apiName = null;
        Matcher apiMatcher = getAPINameRegEx().matcher(s.getText());

        if (apiMatcher.find()) {
            apiName = apiMatcher.group(1);
        }
        return apiName;
    }

    private String getQueryNameFromStep(Step s) {
        String queryName = null;
        Matcher queryMatcher = getQueryNameRegEx().matcher(s.getText());

        if (queryMatcher.find()) {
            queryName = queryMatcher.group(1);
        }
        return queryName;
    }

    private void parsePageAndElement(Step s, String pageName) {
        PageObjectRating poj = ObjectFinder.findMatchingPage(removeSpecialChars(pageName));
        objectAssociatorReporter.addSubStepResult(poj.getSimilarityScore(), poj.getSearchResultMsg(), poj.getPageObjList());

        Matcher eleMatcher = getElementRegEx().matcher(s.getText());
        if (eleMatcher.find() && poj.getPageObjectClazz() != null) {
            FieldRating topMatchingField = ObjectFinder.findMatchingElement(removeSpecialChars(eleMatcher.group(1)), poj.getPageObjectClazz());
            objectAssociatorReporter.addSubStepResult(topMatchingField.getSimilarityScore(), topMatchingField.getSearchResultMsg(), topMatchingField.getFieldList());
        } else if (poj.getPageObjectClazz() == null) {
            objectAssociatorReporter.addSubStepResult(Status.SKIPPED, "Page does not exist. Skipping object associator check for field.");
            log.debug("Page does not exist. Skipping object associator check for elements.");
        }
    }

    private void parseAPI(String featureName) {
        FlatFileObjectRating flatFileObjectRating = ObjectFinder.getMatchingAPIFeature(removeSpecialChars(featureName));
        objectAssociatorReporter.addSubStepResult(flatFileObjectRating.getSimilarityScore(),
                                                  flatFileObjectRating.getSearchResultMsg(),
                                                  flatFileObjectRating.getFlatFileObjectList());
    }

    private void parseQuery(String queryName) {
        FlatFileObjectRating dbObjectRating = ObjectFinder.getMatchingDBQuery(removeSpecialChars(queryName));
        objectAssociatorReporter.addSubStepResult(dbObjectRating.getSimilarityScore(),
                                                  dbObjectRating.getSearchResultMsg(),
                                                  dbObjectRating.getFlatFileObjectList());
    }


    private Pattern getElementRegEx() {
        StringBuilder regex = new StringBuilder();

        regex.append("\"([^\"]*)\"\\s(");
        Arrays.stream(FieldEnum.values())
              .forEach(word -> regex.append(word.getVal()).append("|"));
        regex.setLength(regex.length() - 1);
        regex.append(")");
        return Pattern.compile(regex.toString());
    }

    private Pattern getPageNameRegEx() {
        return Pattern.compile("(at|on) the \"([^\"]*)\" (page|TE)");
    }

    private Pattern getAPINameRegEx() {
        return Pattern.compile("\"([^\"]*)\" (API)");
    }

    private Pattern getQueryNameRegEx() {
        return Pattern.compile("\"([^\"]*)\" (query)");
    }

    protected List<String> getScenarioLabels(ScenarioDefinition sd) {
        List<Tag> scenarioLabels = new ArrayList<>();

        if (sd instanceof Scenario) {
            scenarioLabels = ((Scenario) sd).getTags();
        } else if (sd instanceof ScenarioOutline) {
            scenarioLabels = ((ScenarioOutline) sd).getTags();
        }

        return scenarioLabels.stream().map(Tag::getName).collect(toList());
    }

    private boolean isValidStep(Step s) {
        final List<String> matchingStepDefs = stepDefAnnotationList.stream()
                                                                   .filter(stepDef -> s.getText().matches(stepDef))
                                                                   .collect(toList());

        return !matchingStepDefs.isEmpty();
    }


    private void parseFunctionFeature(ScenarioDefinition sd) {
        final List<String> scenarioTags = getScenarioLabels(sd).stream()
                                                               .map(entry -> entry.replace("@", ""))
                                                               .collect(toList());
        scenarioTags.removeIf(tag -> tag.contains("ALM"));
        scenarioTags.removeIf(tag -> tag.contains("Flow"));

        objectAssociatorReporter.beginStep("Function Feature Validation Step: ",
                                           "Function Feature validation to Feature Master Analytics DB");

        if (!scenarioTags.isEmpty()) {
            FunctionFeatureAnalyzer functionFeatureAnalyzer = new FunctionFeatureAnalyzer();
            final boolean functionFound = functionFeatureAnalyzer.searchForMatchingFunction(scenarioTags);

            boolean completeMatchFound = false;
            if (functionFound) {
                completeMatchFound = functionFeatureAnalyzer.matchBothFunctionAndSubFeature(scenarioTags,
                                                                                            functionFeatureAnalyzer.getFunctionMatchName());
            }

            printFunctionFeatureResults(functionFeatureAnalyzer, functionFound, completeMatchFound);
            functionFeatureAnalyzer.closeDBConnection();
            objectAssociatorReporter.resetStep();

        } else {
            log.error("NO Function Feature or Sub function Tags added");
            objectAssociatorReporter.addSubStepResult(Status.FAILED, "NO Function Feature or Sub function Tags added");
        }

    }

    private void printFunctionFeatureResults(FunctionFeatureAnalyzer functionFeatureAnalyzer,
                                             boolean functionFound,
                                             boolean completeMatchFound) {
        if (completeMatchFound) {
            final String msg = String.format("Exact Match Found for Function : %s and Sub Feature : %s",
                                             functionFeatureAnalyzer.getFunctionMatchName(),
                                             functionFeatureAnalyzer.getSubFeatureMatchName());
            log.debug(msg);
            objectAssociatorReporter.addSubStepResult(Status.PASSED, msg);
        } else if (functionFound) {
            final String functionMsg = String.format("Function: found match on function '%s'.",
                                                     functionFeatureAnalyzer.getFunctionMatchName());

            log.info(functionMsg);
            objectAssociatorReporter.addSubStepResult(Status.PASSED, functionMsg);

            final String subFunctionMessage = "Sub Feature: did not find match. See list of possible matches below.";
            log.warn(functionMsg);
            objectAssociatorReporter.addSubStepResult(.85, subFunctionMessage, functionFeatureAnalyzer.getSubFeatureMatches());
        } else if (!functionFeatureAnalyzer.getFunctionMatches().isEmpty()) {
            final String msg = "Function: did not find exact match. Possible matches include: " ;
            log.warn(msg);
            objectAssociatorReporter.addSubStepResult(.85, msg, functionFeatureAnalyzer.getFunctionMatches());
        } else {
            log.error("Match not found on function or sub feature");
            objectAssociatorReporter.addSubStepResult(Status.FAILED, "No Match Found for Function Feature and Sub Feature");
        }
    }

}