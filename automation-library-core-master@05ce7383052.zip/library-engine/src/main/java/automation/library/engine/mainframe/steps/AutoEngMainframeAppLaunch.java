package automation.library.engine.mainframe.steps;

import automation.library.engine.mainframe.BaseMFSteps;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class AutoEngMainframeAppLaunch extends BaseMFSteps {

    @Given("^the mainframe application \"([^\"]*)\" is launched in \"([^\"]*)\"$")
    public void theMainframeApplicationIsLaunchedInA(String appName, String location) {
        launchApplication(appName, location);
    }

    @Given("^the mainframe application \"([^\"]*)\" is launched$")
    public void theMainframeApplicationIsLaunched(String appName) {
        launchApplication(appName);
    }

    @Given("^the mainframe application \"([^\"]*)\" is launched with the default launch text$")
    public void theMainframeApplicationIsLaunchedwithDefault(String appName) {
        launchApplicationWithLaunchText(appName, "");
    }

    @Given("^the mainframe application \"([^\"]*)\" is launched with the launch text as \"([^\"]*)\"$")
    public void theMainframeApplicationIsLaunchedwithDefault(String appName, String screenText) {
        launchApplicationWithLaunchText(appName, screenText);
    }

    @Then("^the user closes the mainframe application \"([^\"]*)\"$")
    public void theUserClosesTheMainframeApplication(String appName) {
        closeApplication(appName);
    }

    @Then("^the user closes the mainframe application \"([^\"]*)\" launched in \"([^\"]*)\"$")
    public void theUserClosesTheMainframeApplicationLaunchedInA(String appName, String location) {
        closeApplication(appName);
    }

}