package automation.library.engine.api.steps;

import automation.library.common.TestContext;
import automation.library.engine.api.BaseAPISteps;
import io.cucumber.java.en.When;

import java.util.HashMap;
import java.util.Map;

public class AutoEngAPISet extends BaseAPISteps {

    @When("^set \"([^\"]*)\" to \"([^\"]*)\" within parent attribute \"([^\"]*)\" in the API response at key \"([^\"]*)\"$")
    public void theUserSetsAttributeInPayloadWithParent(String attributeName,
                                                        String attributeValue,
                                                        String parentAttributeName,
                                                        String dictionaryKey) {
        dictionaryKey = parseDictionaryKey(dictionaryKey);
        Map<String, Object> args = new HashMap<>();
        args.put(PARENT_ATTRIBUTE_NAME, parentAttributeName);
        args.put(ATTRIBUTE_NAME, attributeName);
        args.put(RESPONSE, TestContext.getInstance().testdataGet(dictionaryKey));
        args.put(ATTRIBUTE_VALUE, parseValueToObject(attributeValue));

        final String featureToRun = getSetFeature(args.get("parentAttributeName").toString(), StoreType.SINGLE);

        setAPIAttribute(featureToRun, args, attributeName, dictionaryKey);

    }

    @When("^set \"([^\"]*)\" to \"([^\"]*)\" in the API response at key \"([^\"]*)\"$")
    public void theUserSetsAttributeInPayload(String attributeName,
                                              String attributeValue,
                                              String dictionaryKey) {

        theUserSetsAttributeInPayloadWithParent(attributeName,
                                                attributeValue,
                                                ROOT_ATTRIBUTE,
                                                dictionaryKey);

    }

    @When("^set \"([^\"]*)\" to \"([^\"]*)\" at index \"([^\"]*)\" within parent attribute \"([^\"]*)\" in the API response at key \"([^\"]*)\"$")
    public void theUserSetsAttributeInPayloadWithParentArray(String attributeName,
                                                             String attributeValue,
                                                             String arrayIndex,
                                                             String parentAttributeName,
                                                             String dictionaryKey) {
        dictionaryKey = parseDictionaryKey(dictionaryKey);
        Map<String, Object> args = new HashMap<>();
        args.put(PARENT_ATTRIBUTE_NAME, parentAttributeName);
        args.put(ATTRIBUTE_NAME, attributeName);
        args.put(RESPONSE, TestContext.getInstance().testdataGet(dictionaryKey));
        args.put(ATTRIBUTE_VALUE, parseValueToObject(attributeValue));
        args.put("arrayIndex", Integer.parseInt(arrayIndex));

        final String featureToRun = getSetFeature(args.get("parentAttributeName").toString(), StoreType.ATINDEX);

        setAPIAttribute(featureToRun, args, attributeName, dictionaryKey);

    }

}