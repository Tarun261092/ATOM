package automation.library.engine.mobile.steps;

import static automation.library.cucumber.core.Constants.TESTDATAPATH;

import java.io.File;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.JavascriptExecutor;

import automation.library.engine.mobile.BaseMobileSteps;
import automation.library.reporting.Reporter;
import automation.library.selenium.exec.driver.factory.DriverContext;
import io.cucumber.java.en.When;

public class AutoEngNSMobileUtility extends BaseMobileSteps {

	@When("^the user terminates mobile connection$")
	public void theUserTerminatesMobileConnection() {
		DriverContext.getInstance().quitMobile();
	}

	@When("^the user uploads file from \"([^\"]*)\" to the \"([^\"]*)\" mobile device location$")
	public void theUserUploadsFileFromToTheMobileDeviceLocation(String filePath, String devicePath) throws Exception {
		filePath = parseValue(filePath);
		devicePath = parseValue(devicePath);

		String fileName = filePath.substring(filePath.lastIndexOf("\\") + 1);
		String repositoryPath = "PRIVATE:" + fileName;
		uploadToRepository(filePath, repositoryPath);

		uploadFromRepositoryToDevice(repositoryPath, devicePath);
	}

	@When("^the user uploads file from \"([^\"]*)\" to the \"([^\"]*)\" perfecto repository location$")
	public void theUserUploadsFileFromToThePerfectoRepositoryLocation(String filePath, String repositoryPath)
			throws Exception {
		filePath = parseValue(filePath);
		repositoryPath = parseValue(repositoryPath);

		uploadToRepository(filePath, repositoryPath);
	}

	@When("^the user uploads file from perfecto repository location \"([^\"]*)\" to the \"([^\"]*)\" mobile device location$")
	public void theUserUploadsFileFromPerfectoRepositoryLocationToTheMobileDeviceLocation(String repositoryPath,
			String devicePath) throws Exception {
		repositoryPath = parseValue(repositoryPath);
		devicePath = parseValue(devicePath);

		uploadFromRepositoryToDevice(repositoryPath, devicePath);
	}

	@When("^the user installs the application from local \"([^\"]*)\"$")
	public void theUserInstallsTheApplicationFromLocal(String filePath) throws Exception {
		filePath = parseValue(filePath);

		File fileToUpload = new File(filePath);
		// default to src/test/resources/testdata folder if only a file name is provided
		if (!fileToUpload.isAbsolute()) {
			fileToUpload = new File(Paths.get(TESTDATAPATH + filePath).toString());
		}

		if (!fileToUpload.exists()) {
			String errorMsg = String.format("File does not exist at path: %s", fileToUpload);
			log.error(errorMsg);
			Reporter.addStepLog("ERROR", errorMsg);
			return;
		}

		uploadToRepository(fileToUpload.getAbsolutePath(), String.format("PRIVATE:%s", fileToUpload.getName()));

		theUserInstallsTheApplicationFromPerfectoRepository(String.format("PRIVATE:%s", fileToUpload.getName()));
	}

	@When("^the user installs the application from perfecto repository \"([^\"]*)\"$")
	public void theUserInstallsTheApplicationFromPerfectoRepository(String repositoryPath) throws Exception {
		repositoryPath = parseValue(repositoryPath);

		JavascriptExecutor js = (JavascriptExecutor) getMobileDriver();
		Map<String, Object> params = new HashMap<>();
		params.put("file", repositoryPath);
		js.executeScript("mobile:application:install", params);
		
		log.info("Your application is installed successfully.");
	}

}
