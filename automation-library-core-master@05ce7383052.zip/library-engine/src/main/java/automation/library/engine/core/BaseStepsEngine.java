package automation.library.engine.core;

import automation.library.api.test.utils.JSONFormatter;
import automation.library.common.FileHelper;
import automation.library.common.Property;
import automation.library.common.TestContext;
import automation.library.engine.core.objectmatcher.ObjectNotFoundException;
import automation.library.reporting.Reporter;
import automation.library.selenium.core.Constants;
import automation.library.selenium.core.Element;
import automation.library.tlm.TlmContext;
import automation.library.tlm.common.entity.TlmRunStep;
import automation.library.selenium.exec.driver.factory.DriverContext;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonSyntaxException;
import io.cucumber.java8.En;
import org.apache.commons.configuration2.PropertiesConfiguration;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NotFoundException;
import org.openqa.selenium.WebElement;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.StringReader;
import java.nio.file.Paths;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAccessor;
import java.time.temporal.TemporalAmount;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static automation.library.common.DateHelper.formatAsDate;
import static automation.library.common.DateHelper.formatAsTime;
import static automation.library.common.DateHelper.getDateTimeFormat;
import static automation.library.common.DateHelper.convertEpochToNormal;
import static automation.library.cucumber.core.Constants.ENVIRONMENTPATH;
import static automation.library.cucumber.core.Constants.RUNTIMEPATH;
import static automation.library.engine.core.objectmatcher.ObjectFinder.getMatchingElement;


public class BaseStepsEngine implements En {
    protected final Logger log = LogManager.getLogger(BaseStepsEngine.class);
    protected static final String ERROR = "ERROR";
    protected static final String REGEX_FULLKEY = "(#\\(\\S*?\\))";
    protected static final String REGEX_VALIDATION = "\"([^\"]*)\"";
    protected static final String ENV_PROP = "cukes.env";
    protected static final String PROPERTIES_EXT = ".properties";
    protected static final String ENTERED_VALUE = "Entered value: \"%s\"";
    protected static final String STORED_VALUE = "Stored value \"%s\" into key \"%s\"";
    protected static final String JAVAX_NET_SSL_TRUST_STORE = "javax.net.ssl.trustStore";
    protected static final String FORMATTED_AS = "Formatted as Day Suffix {}";
    protected static final String JSON = ".json";
    protected static final String ZONE = " ZONE_";
    protected static final String MQ_ENV_PROP = "cukes.mq";
    protected static final String ELEMENT_REF = "fw.elementRef";

    public BaseStepsEngine() {
        //base steps
    }

    public SoftAssertions sa() {
        return TestContext.getInstance().sa();
    }

    public enum ScreenShotType {
        DISPLAY, AREA, SCROLLING;
    }

    /**
     * Generic method to find object
     *
     * @param objectName
     * @param pageName
     */
    protected Element getObject(String objectName, String pageName) {
        Object ele = getMatchingElement(objectName, pageName);
        Element returnVal;

        if (ele != null) {
            returnVal = (Element) ele;
            if (returnVal.element() != null){
                TestContext.getInstance().testdataPut(ELEMENT_REF, returnVal);
                return returnVal;
            }
            else {
                String errorMsg = String.format("The \"%s\" element is not present on the page : \"%s\"", objectName, pageName);
                log.error(errorMsg);
                throw new NotFoundException(errorMsg);
            }
        } else {
            throw new ObjectNotFoundException(String.format("The \"%s\" was not found in the page object: : \"%s\"",
                    objectName, pageName));
        }
    }

    /**
     * Generic method to find object lists
     *
     * @param objectName
     * @param pageName
     */
    protected List<Element> getObjects(String objectName, String pageName) {
        Object ob = getMatchingElement(objectName, pageName);
        List<Element> ele = (List<Element>) ob;

        if (ele != null) {
            TestContext.getInstance().testdataPut(ELEMENT_REF, ele);
            return ele;
        } else {
            throw new ObjectNotFoundException("The \"" + objectName + "\" element was not found in the page object: \"" + pageName + "\"");
        }
    }

    /**
     * Generic method to allow object Null
     *
     * @param objectName
     * @param pageName
     */

    protected Element getObjectAllowNull(String objectName, String pageName) {
        Object ele = getMatchingElement(objectName, pageName);

        if (ele != null) {
            TestContext.getInstance().testdataPut(ELEMENT_REF, ele);
            return (Element) ele;
        } else {
            throw new ObjectNotFoundException(
                    "The \"" + objectName + "\" was not found in the page object: : \"" + pageName + "\"");
        }
    }

    protected List<Keys> getKeysToPress(String keySequence) {
        Gson gson = new GsonBuilder().create();
        List<ArrayList<String>> keyArrayList;
        Map<String, ArrayList<String>> keyArray = new HashMap<>();
        List<Keys> keysToPress = new ArrayList<>();

        try {
            keyArray = gson.fromJson(new FileReader(Constants.KEYBOARDKEYSJSON), Map.class);
        } catch (FileNotFoundException e) {
            log.error(e.getMessage(), e);
        }

        if (keyArray.size() > 0) {
            keyArrayList = keyArray.entrySet().stream()
                    .filter(key -> key.getKey().equalsIgnoreCase(keySequence))
                    .map(Map.Entry::getValue)
                    .collect(Collectors.toList());

            if (!keyArrayList.isEmpty()) {
                for (String key : keyArrayList.get(0)) {
                    keysToPress.add(Keys.valueOf(key));
                }
            } else {
                log.error("Unable to find key: '{}'. Is keyboard.json defined for the project?", keySequence);
            }
        }

        return keysToPress;
    }


    /**
     * @param value
     * @param formatType
     * @throws ParseException
     */
    protected String format(String value, String formatType) throws ParseException {
        if (formatTypeIsDate(formatType)) {
            return formatValueToDate(value, formatType);
        } else if(formatTypeIsTime(formatType)){
            return formatValueToTime(value, formatType);
        }else if (formatTypeIsPhone(formatType)) {
            return formatValueToPhone(value, formatType);
        } else if (formatTypeIsString(formatType)) {
            return formatValueToString(value, formatType);
        } else {
            return formatValueToNumber(value, formatType);
        }
    }
     
    protected String convertEpoch(String value, String formatType) throws ParseException {
    	String convertedEpochDateAndTime = convertEpochToNormal(value);
    	if (formatTypeIsDate(formatType)) {
    		String convertedEpochDate = convertedEpochDateAndTime.split(" ")[0];
    		return formatValueToDate(convertedEpochDate, formatType);
        } else if(formatTypeIsTime(formatType)){
    		String convertedEpochTime = convertedEpochDateAndTime.split(" ")[1];
            return formatValueToTime(convertedEpochTime, formatType);
        } else {        	
        	log.info("As {} type parsed, returning as default Date and Time format (YYYY-MM-DD HH:mm:ss)", formatType);
        	return convertedEpochDateAndTime;
        }
    	
    }
    
    protected String convertLocal(String value, String unit) throws ParseException {
    	long convertedLocalDateAndTime = automation.library.common.DateHelper.convertNormalToEpochInSeconds(value);
    	if (unit.equalsIgnoreCase("milliseconds")) {
    		convertedLocalDateAndTime = convertedLocalDateAndTime*1000;
    		}
        	return Long.toString(convertedLocalDateAndTime);
    	
    }

    private boolean formatTypeIsDate(String formatType) {
        return formatType.matches("(?i).*(DATE|MMDDYYYY|MM-DD-YYYY|MM/DD/YYYY|YYYYMMDD|YYYY-MM-DD|YYYY/MM/DD|YYMMDD|M/dd/yy|YY-MM-DD).*(?i)");
    }
    
    private boolean formatTypeIsTime(String formatType){
    	return formatType.matches("(?i).*(TIME|HHmmss|HH:mm:ss|HH:mm:ss.S|HH:mm:ss.SS|HH:mm:ss.S Z|HH:mm:ss.SS Z|HH:mm:ss.SSS|HH:mm:ss.SSS Z|HH:mm|mm:ss|mm:ss.S|T HH:mm:ss.S Z|T HH:mm:ss.SSS Z|T HH:mm:ss).*(?i)");
    }

    private boolean formatTypeIsPhone(String formatType) {
        return formatType.matches("(?i).*(PHONE|INTERNATIONAL).*(?i)");
    }

    private boolean formatTypeIsString(String formatType) {
        return formatType.matches("(?i).*(REMOVESQUAREBRACKETSPACE|TRIM_SPACES|REMOVE_COMMA|REMOVE_SPECIALCHARACTER|UPPER_CASE|TRIM_MIDDLE_SPACES|REMOVE_SQUARE_BRACKETS|DAY_SUFFIX|REMOVE_FIRSTDIGIT).*(?i)");
    }

    private String formatValueToString(String value, String formatType) {
        switch (formatType.toUpperCase()) {
            case "TRIM_SPACES":
                value = value.trim();
                log.info("Formatted as without spaces {}", value);
                return value;
            case "REMOVE_COMMA":
                value = value.replace(",", "");
                log.info("Formatted as without comma {}", value);
                return value;
            case "REMOVE_FIRSTDIGIT":
                value=value.substring(1);
                log.info("Formatted as without first digit {}", value);
                return value;
            case "REMOVE_SPECIALCHARACTER":
                value = value.replaceAll("[!//%|^&*()#$@,!*_=-]", "");
                log.info("Formatted as without Special Characters {}", value);
                return value;
            case "UPPER_CASE":
                value = value.toUpperCase();
                log.info("Formatted as with uppercase {}", value);
                return value;
            case "TRIM_MIDDLE_SPACES":
                value = value.replaceAll("\\s", "");
                log.info("Formatted as without middle spaces {}", value);
                return value;
            case "REMOVE_SQUARE_BRACKETS":
                value = value.replaceAll("\\[|\\]", "");
                log.info("Formatted as without Square Brackets {}", value);
                return value;
            case "REMOVESQUAREBRACKETSPACE":
                value = value.replace("[ ", "[");
                value = value.replace(" ]", "]");
                log.info("Formatted as without Square Brackets spaces {}", value);
                return value;
            case "DAY_SUFFIX":
                int num = Integer.parseInt(value);
                if (num >= 11 && num <= 13) {
                    log.info(FORMATTED_AS, "th");
                    return num + "th";
                }
                switch (num % 10) {
                    case 1:
                        log.info(FORMATTED_AS, "st");
                        return num + "st";
                    case 2:
                        log.info(FORMATTED_AS, "nd");
                        return num + "nd";
                    case 3:
                        log.info(FORMATTED_AS, "rd");
                        return num + "rd";
                    default:
                        log.info(FORMATTED_AS, "th");
                        return num + "th";
                }

            default:
                return value;
        }
    }

    private String formatValueToDate(String dateToFormat, String formatType) {
        LocalDateTime valueAsDate = formatAsDate(dateToFormat);
        final String datePattern1 = "^DATE-(PLUS|MINUS)(\\d+)(DAYS?|MONTHS?|YEARS?)$";
        final String datePattern2 = "^DATE-(.*)$";
        final String dateTimeZone = "^(.*)ZONE_(.*)$";
        final String datePattern3 = "(?i)(MMDDYYYY|MM-DD-YYYY|MM/DD/YYYY|YYYYMMDD|YYYY-MM-DD|YYYY/MM/DD|YYMMDD|M/dd/yy|MMM DD, YYYY|YYYY-MMM-DD|YY-MMM-DD|MM/DD/YYYY HH:mm:ss|MM-DD-YYYY HH:mm:ss)(?i)";

        if (formatType.matches(datePattern1)) {
            Map<String, String> origFormatMap = getDateTimeFormat(dateToFormat);
            String originalFormat = origFormatMap.get("DATE") != null ? origFormatMap.get("DATE") : origFormatMap.get("DATE-TIME");

            Matcher m = Pattern.compile(datePattern1).matcher(formatType);
            if (m.matches()) {
                return updateDateByPeriod(valueAsDate, m.group(1), m.group(2), m.group(3)).format(DateTimeFormatter.ofPattern(originalFormat)
                        .withLocale(Locale.ENGLISH));
            }
        } else if (formatType.matches(datePattern2)) {
            Matcher m = Pattern.compile(datePattern2).matcher(formatType);
            if (m.matches()) {
                return valueAsDate.format(DateTimeFormatter.ofPattern(reformatDatePattern(m.group(1))).withLocale(Locale.ENGLISH));
            }
        } else if (formatType.matches(datePattern3)) {
            Matcher m = Pattern.compile(datePattern3).matcher(formatType);
            if (m.matches()) {
                return valueAsDate.format(DateTimeFormatter.ofPattern(reformatDatePattern(m.group(1))).withLocale(Locale.ENGLISH));
            }
        } else if (parseValue(formatType).matches(dateTimeZone)) {
            return getdateTime(dateToFormat, formatType, dateTimeZone);
        } else {
            logStepMessage(String.format("Unmatched date format type: %s. Returning original value.", formatType));
            return dateToFormat;
        }

        return dateToFormat;
    }
    
    private String formatValueToTime(String timeToFormat, String formatType) throws ParseException {
    	//formatType = formatType.toLowerCase();
    	LocalTime valueAsTime = formatAsTime(timeToFormat);        
    	final String timePattern = "(?i).*(HH:mma|HHmmss|HH:mm:ssa|HH:mm:ss.S|HH:mm:ss.SS|HH:mm:ss.SSS|HH:mm|mm:ss|mm:ss.S).*(?i)";
    	if (formatType.matches(timePattern)) {
            Matcher m = Pattern.compile(timePattern).matcher(formatType);
            if (m.matches()) {
            	System.out.println(m.group());
                return valueAsTime.format(DateTimeFormatter.ofPattern(m.group()));
            }            
            else {
                logStepMessage(String.format("Unmatched date format type: %s. Returning original value.", formatType));
                return timeToFormat;
            }
    	}
            return timeToFormat;
    }

    private String getdateTime(String dateToFormat, String formatType, String dateTimeZone) {
        boolean instant = false;
        String dateTimeStr = "";
        Matcher m = Pattern.compile(dateTimeZone).matcher(parseValue(formatType));
        if (m.matches()) {
            String dateTime = dateToFormat.split(ZONE)[0];
            String zoneFrom = dateToFormat.split(ZONE)[1];
            String zoneTo = parseValue(formatType).split(ZONE)[1];
            if (zoneTo.contains("INSTANT")) {
                zoneTo = zoneTo.split(" ")[0];
                instant = true;
            }

            String originalPattern = getDateTimeFormat(dateToFormat).get("DATE-TIME-ZONE").split(" z")[0];
            String requiredPattern = parseValue(formatType).split(ZONE)[0];
            dateTimeStr = convertTimeBasedOnTimeZoneAndTimePattern(dateTime, zoneFrom, zoneTo, originalPattern, requiredPattern, instant);
        }
        return dateTimeStr;

    }

    public static String convertTimeBasedOnTimeZoneAndTimePattern(String dateTime, String zonefrom, String zoneTo, String originalPattern, String requiredPattern, boolean timeInstant) {
        DateTimeFormatter formatterNew = DateTimeFormatter.ofPattern(requiredPattern);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(originalPattern);

        TemporalAccessor temporalAccessor = formatter.parse(dateTime);

        ZoneId zoneId = ZoneId.of(zonefrom);
        LocalDateTime localDateTime = LocalDateTime.from(temporalAccessor);
        ZonedDateTime zonedDateTime = ZonedDateTime.of(localDateTime, zoneId);
        Instant instant = Instant.from(zonedDateTime);
        if (timeInstant) {
            ZonedDateTime zonedDateTimeFrom = instant.atZone(ZoneId.of(zoneTo));
            String fromZoneDateTime = zonedDateTimeFrom.format(formatterNew);
            return fromZoneDateTime.split(" ")[0] + "T" + fromZoneDateTime.split(" ")[1] + "Z";
        } else {
            ZonedDateTime zonedDateTimeFrom = instant.atZone(ZoneId.of(zoneTo));
           return zonedDateTimeFrom.format(formatterNew);

        }

    }

    private LocalDateTime updateDateByPeriod(LocalDateTime dateToFormat, String operation, String increment, String period) {
        if (operation.equalsIgnoreCase("PLUS")) {
            return dateToFormat.plus(getPeriod(period, increment));
        } else {
            return dateToFormat.minus(getPeriod(period, increment));
        }
    }

    private TemporalAmount getPeriod(String period, String increment) {
        switch (period) {
            case "DAY":
            case "DAYS":
                return Period.ofDays(Integer.parseInt(increment));
            case "MONTH":
            case "MONTHS":
                return Period.ofMonths(Integer.parseInt(increment));
            case "YEAR":
            case "YEARS":
                return Period.ofYears(Integer.parseInt(increment));
            default:
                return Period.ofDays(0);
        }
    }

    private String reformatDatePattern(String origPattern) {
        return origPattern.replace("D", "d").replace("Y", "y");
    }

    private String formatValueToPhone(String value, String formatType) {
        boolean checkformat = false;

        switch (formatType.toUpperCase()) {
            case "PHONE":
                Pattern pattern = Pattern.compile("\\d{3}-\\d{3}-\\d{4}");
                checkformat = pattern.matcher(value).matches();
                if (!checkformat) value = value.replaceFirst("(\\d{3})(\\d{3})(\\d+)", "($1) $2-$3");
                log.info("Formatted as PHONE {}", value);
                return value;
            case "INTERNATIONAL_PHONE":
                Pattern patternint = Pattern.compile("\\d{3}-\\d{15}");
                checkformat = patternint.matcher(value).matches();
                if (!checkformat) value = value.replaceFirst("(\\d{3})(\\d+)", "+$1 $2");
                log.info("Formatted as PHONE {}", value);
                return value;
            default:
                return value;
        }
    }

    private String formatValueToNumber(String value, String formatType) throws ParseException {
        boolean checkformat = false;

        switch (formatType.toUpperCase()) {
            case "REMOVELEADINGZEROS":
                checkformat = !value.startsWith("0");
                if (!checkformat) {
                    value = value.replaceFirst("^0+(?!$)", "");
                }
                log.info("Formatted as REMOVELEADINGZEROS {}", value);
                return value;
            case "TWOZEROSAFTERDECIMAL":
                checkformat = value.split(".")[1].length() == 2;
                if (!checkformat) {
                    DecimalFormat df = new DecimalFormat("#.00");
                    value = df.format(value);
                }
                log.info("Formatted as TWOZEROSAFTERDECIMAL {}", value);
                return value;
            case "USD":
                DecimalFormat df = new DecimalFormat();
                value = df.parse(value).toString();
                NumberFormat numberCurFormat = NumberFormat.getCurrencyInstance(Locale.US);
                numberCurFormat.setMaximumFractionDigits(2);
                if (value.startsWith("-")) {
                    DecimalFormat format = (DecimalFormat) numberCurFormat;
                    String symbol = format.getCurrency().getSymbol();
                    format.setNegativePrefix(symbol + "-");
                    format.setNegativeSuffix("");
                    value = format.format(Double.valueOf(value));
                } else {
                    value = numberCurFormat.format(Double.valueOf(value));
                }
                return value;
            case "PERCENTAGE":
                DecimalFormat df1 = new DecimalFormat();
                value = df1.parse(value).toString();
                NumberFormat numberFormat = NumberFormat.getPercentInstance();
                numberFormat.setMaximumFractionDigits(2);
                value = numberFormat.format(Float.valueOf(value));
                return value;
            case "ROUNDTOTWODECIMAL":
                value = String.format("%.2f", Double.parseDouble(value));
                log.info("Formatted as to two decimal places {}", value);
                return value;
            case "ROUNDOFF":
                value = String.format("%.0f", Double.parseDouble(value));
                log.info("Formatted as to round off: {}", value);
                return value;
            case "REMOVE_FIRSTLINE":
                value = value.substring(value.indexOf('\n')+1);
                log.info("Formatted as without first line in xml string {}", value);
                return value;
            case "ROUNDTONODECIMAL":
                value = String.valueOf(Math.round(Double.parseDouble(value)));
                log.info("Formatted to round with no decimals: {}", value);
                return value;
            default:
                log.warn("Unmatched format type: {}. Options are REMOVELEADINGZEROS | TWOZEROSAFTERDECIMAL | USD | " +
                         "PERCENTAGE | ROUNDTOTWODECIMAL | ROUNDOFF| ROUNDTONODECIMAL", formatType);
                return value;
        }
    }

    /**
     * @param value
     * @param delimiter
     * @return
     */
    public String[] split(String value, String delimiter) {
        String[] resultValues = new String[0];
        switch (delimiter.toUpperCase()) {
            case "COMMA":
                resultValues = value.split(",");
                break;
            case "PIPE":
                resultValues = value.split("\\|");
                break;
            case "DOUBLE-PIPE":
                resultValues = value.split("\\|\\|");
                break;
            case "COLON":
                resultValues = value.split(":");
                break;
            case "SEMICOLON":
                resultValues = value.split(";");
                break;
            case "DASH":
                resultValues = value.split("-");
                break;
            case "NEWLINE":
                resultValues = value.split("\n");
                break;
            default:
                log.warn("Given delimiter type doesn't exist: {}. Options are COMMA | PIPE | DOUBLE-PIPE | COLON | SEMICOLON | DASH | NEWLINE", delimiter);
                break;
        }
        return resultValues;
    }

    protected String parseValue(String value) {
        return AutoEngParser.parseValue(value);
    }

    protected Object parseValueToObject(String value) {
        return AutoEngParser.parseValueToObject(value);
    }

    protected String parseDictionaryKey(String keyName) {
        return getValueOrVariable(keyName);
    }

    protected String parseSecureText(String value) {
        return AutoEngParser.parseSecureText(value);
    }
    
    protected String parseSecureTextfromjson(String value) {
        return AutoEngParser.parseSecureTextfromJson(value);
    }

    protected String parseUser(String value) {
        return AutoEngParser.parseUser(value);
    }

    private String getValueOrVariable(String value) {
        return AutoEngParser.getValueOrVariable(value);
    }

    protected String parseIfVariable(String value) {
        return AutoEngParser.parseIfVariable(value);
    }

    protected void logStepMessage(String message) {
        logStepMessage("DEBUG", message);
    }

    private void logStepMessage(String type, String message) {
        Reporter.addStepLog(type, message);
        log.debug(message);

        if (TlmContext.getInstance().updateTlmFlag()) {
            TlmContext.getInstance().getTlmManager().addLastStep(new TlmRunStep(null, message));
        }
    }

    protected String getConcatenatedVal(String valsToConcat, String splitDelimiter, String joinDelimiter) {
        List<String> stringsToCombine = Arrays.asList(valsToConcat.split(splitDelimiter));
        return stringsToCombine.stream()
                .map(value -> getDictionaryValOrRealVal(value.trim()))
                .filter(value -> !value.isEmpty())
                .collect(Collectors.joining(joinDelimiter));
    }

    protected String getDictionaryValOrRealVal(String value) {
        try {
            return parseValue(value);
        } catch (IllegalArgumentException e) {
            logStepMessage(ERROR, String.format("%s String will not include value at that key.", e.getMessage()));
            return "";
        }
    }

    protected String getSubstringVal(String fullValue, String substringPattern) {
        switch (substringPattern) {
            case "LAST-FOUR":
                return fullValue.substring(fullValue.length() - 4);
            case "BEFORE-PERCENTAGE":
                return fullValue.split("%")[0];
            case "FIRST-FOUR":
                return fullValue.substring(0, 4);
            case "FIRST-FIVE":
                return fullValue.substring(0, 5);
            case "AFTER-COLON":
                return fullValue.split(":")[1].trim();
            case "AFTER-COMMA":
                return fullValue.split(",")[1].trim();
            case "AFTER-DOLLAR":
                return fullValue.split("[$]")[1].trim();
            case "THIRD-FIFTH-SIXTH":
                fullValue = fullValue.substring(2, fullValue.length()).replaceAll("[!//%|^&*()#$@,!*_=-]", "");

                if (fullValue.length() == 4) {
                    return fullValue.substring(0, 1) + fullValue.substring(2, fullValue.length());
                }
                return fullValue;
            case "FIRST-TWO-NOSPECIALCHAR":
                return fullValue.substring(0, 3).replaceAll("[\\[\\]!//%|^&*()#$@,!*_=-]", "");
            case "EXTRA_XML_CHARACTER":
                fullValue = fullValue.replaceAll("\\[[^\\[]*\\]", "");
                log.info("Formatted XML file without extra character {}", fullValue);
                return fullValue;
            default:
                List<String> stringIndices = Arrays.asList(substringPattern.split("-"));
                if (NumberUtils.isParsable(stringIndices.get(0)) &&
                        NumberUtils.isParsable(stringIndices.get(1))) {
                    return fullValue.substring(Integer.parseInt(stringIndices.get(0)),
                            Integer.parseInt(stringIndices.get(1)));
                } else {
                    log.warn("Not a valid pattern to substring. Returning blank value");
                    return "";
                }

        }
    }

    protected String getXMLAttributeVal(String response, String attributeName) throws ParserConfigurationException, IOException, SAXException {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance("com.sun.org.apache.xerces.internal.jaxp.DocumentBuilderFactoryImpl", null);
        factory.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, "");
        factory.setAttribute(XMLConstants.ACCESS_EXTERNAL_SCHEMA, "");
        factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document document = builder.parse(new InputSource(new StringReader(response)));
        return document.getElementsByTagName(attributeName).item(0).getTextContent();
    }
    
    protected String getXMLAttributeValByIndex(String response, String attributeName, int index) throws ParserConfigurationException, IOException, SAXException {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance("com.sun.org.apache.xerces.internal.jaxp.DocumentBuilderFactoryImpl", null);
        factory.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, "");
        factory.setAttribute(XMLConstants.ACCESS_EXTERNAL_SCHEMA, "");
        factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document document = builder.parse(new InputSource(new StringReader(response)));
        return document.getElementsByTagName(attributeName).item(index).getTextContent();
    }

    protected String setTrustStoreBasedOnEnv() {
        String envPropsFile = ENVIRONMENTPATH + Property.getVariable(ENV_PROP) + PROPERTIES_EXT;
        String certFile = Property.getProperty(envPropsFile, "certFileForEnv");

        if (certFile != null) {
            String pathToCertFile = Paths.get(ENVIRONMENTPATH + certFile).toAbsolutePath().toString();
            String currentCertFile = Property.getVariable(JAVAX_NET_SSL_TRUST_STORE);
            log.debug(currentCertFile);
            setTrustStore(pathToCertFile);
            return currentCertFile;
        } else {
            log.warn("Path to cert file not defined in current env.properties file: {}", envPropsFile);
            return "";
        }
    }

    protected void setTrustStore(String pathToCertFile) {
        if (pathToCertFile != null) {
            System.setProperty(JAVAX_NET_SSL_TRUST_STORE, pathToCertFile);
            log.debug("Switching {} to {}", JAVAX_NET_SSL_TRUST_STORE, pathToCertFile);
        }
    }

    public String replaceParameterVals(String stringToReplace) {
        StringBuffer sb = new StringBuffer();
        Pattern p = Pattern.compile(REGEX_FULLKEY);
        Matcher m = p.matcher(stringToReplace);

        while (m.find()) {
            String fullKey = m.group(1);
            m.appendReplacement(sb, Matcher.quoteReplacement(getDictionaryValOrRealVal(fullKey)));
        }

        m.appendTail(sb);
        return sb.toString();
    }

    public String getValidationId(String stepText, boolean validationStep) {
        if (validationStep) {
            Pattern p = Pattern.compile(REGEX_VALIDATION);
            Matcher m = p.matcher(stepText);
            List<String> matches = new ArrayList<>();
            while (m.find()) {
                matches.add(m.group(1));
            }
            return matches.get(matches.size() - 2);
        }
        return null;
    }

    protected void logAndReportJSON(String logTitle, Object attributeToLog) {
        if (attributeToLog != null && !attributeToLog.toString().isEmpty()) {
            PropertiesConfiguration props = Property.getProperties(RUNTIMEPATH);
            String jsonPayload = JSONFormatter.formatJSON(attributeToLog);
            jsonPayload = filterIgnoredTagsFromPayload(jsonPayload, props);
            log.debug(jsonPayload);

            Reporter.addTextLogContent(logTitle, jsonPayload);

            if (TlmContext.getInstance().updateTlmFlag()) {
                TlmContext.getInstance().getTlmManager().addLastStep(new TlmRunStep(null, jsonPayload));
            }
        }
    }

    private String filterIgnoredTagsFromPayload(String jsonPayload, PropertiesConfiguration props) {
        boolean xmlVal = Boolean.parseBoolean(props.getString("ignoreTagsXML"));
        boolean jsonVal = Boolean.parseBoolean(props.getString("ignoreAttributeJSON"));
        List<String> list = props.getList("ignoreTagInformation").stream().map(token -> (String) token).collect(Collectors.toList());
        StringTokenizer ignoreTagValues;
        String token;
        if (!list.isEmpty() && xmlVal) {
        	ignoreTagValues = new StringTokenizer(list.get(0), ",");
            while (ignoreTagValues.hasMoreTokens()) {
                token = ignoreTagValues.nextToken();
                Pattern p = Pattern.compile("<" + token + ">" + "(\\S+)" + "</" + token + ">");
                Matcher m = p.matcher(jsonPayload);
                if (m.find()) {
                    jsonPayload = m.replaceAll(Matcher.quoteReplacement(m.group(0).replace(m.group(1), "*****")));
                }
            }
        } else if (!list.isEmpty() && jsonVal) {
        	ignoreTagValues =new StringTokenizer(list.get(0), ",");
            while (ignoreTagValues.hasMoreTokens()) {
                 token = ignoreTagValues.nextToken();
                Pattern p = Pattern.compile(("\"" + token + "\"" + ":" + " " + "\"(\\S+)" +"\"") +"|"+ ("\"" + token + "\"" + ":" + " " + "\"(\\S+)" +"\","));
                Matcher m = p.matcher(jsonPayload);

                if (m.find()) {
                    jsonPayload = m.replaceAll(Matcher.quoteReplacement(m.group(0).replace(m.group(1), "*****")));

                }

            }
        }
        return jsonPayload;
    }

    protected String getDollarAmountFromString(String string) {
        String valToReturn = "";

        Pattern pattern = Pattern.compile("\\$ ?(\\d?(,?\\d+)+(\\.\\d+)?)");
        Matcher matcher = pattern.matcher(string);
        if (matcher.find()) {
            valToReturn = matcher.group(1).replaceAll("[^0-9.]+", "");
        }
        return valToReturn.trim();

    }

    public Object getAllAttributesOfElement(WebElement element) {
        JavascriptExecutor javascriptExecutor = (JavascriptExecutor) DriverContext.getInstance().getDriver();
        return javascriptExecutor.executeScript(
                "var items = {}; for (index = 0; index < arguments[0].attributes.length; ++index) {items[arguments[0].attributes[index].name]" +
                        " = arguments[0].attributes[index].value}; return items;", element);
    }

    protected String getTextFromFile(String textFileAsString) throws IOException {
        String textContent = "";
        textContent = FileHelper.getFileAsString(textFileAsString, "\n");

        return textContent;
    }

    protected String getPathToTextFile(String fileName) {
        return FileHelper.findFileInPath(automation.library.cucumber.core.Constants.TESTDATAPATH, fileName);
    }

    protected String getValueFromText(String text, String pattern, String textToSearch, int index) {
        String value = "";
        pattern = pattern.equals("") ? "[ ]{2,}" : pattern;
        String[] lines = text.split("\\n");
        for (String line : lines) {
            line = line.replaceAll(pattern, "\t");
            if (line.contains(textToSearch)) {
                value = line.split("\t")[index];
                break;
            }
        }
        return value;
    }

    protected List<String> setupActualListOfVals(String dictionaryKey) {
        List<String> actualList;

        if (!TestContext.getInstance().testdata().containsKey(dictionaryKey)) {
            log.warn("Expected dictionary key not found in data dictionary list: {}", dictionaryKey);
            actualList = Collections.emptyList();
        } else {
            actualList = TestContext.getInstance().testdataToClass(dictionaryKey, List.class);
        }
        return actualList;
    }

    protected String getValueFromText(String text, String index, String pattern) {
        String value = "";
        int index1 = Integer.parseInt(index);
        text = text.replace("[","").replace("]","").replace("{","");

        String[] lines = text.split(pattern);
        if(lines.length >= index1) {
            return lines[index1].replace("\"","");
        }
        return value;
    }

    protected List<String> getListFromDictionary(String dictionaryKey) {
        try {
            final Object jsonArray = TestContext.getInstance().testdataGet(parseDictionaryKey(dictionaryKey));
            if (jsonArray != null) {
                if (jsonArray instanceof List) {
                    return (List) jsonArray;
                } else {
                    return new Gson().fromJson(jsonArray.toString(), List.class);
                }
            }
        } catch (JsonSyntaxException e) {
            logStepMessage(String.format("Did not find a JSON array. Found: %s. Error: %s",
                                         TestContext.getInstance().testdataGet(parseDictionaryKey(dictionaryKey)),
                                         e.getMessage()));
        }

        return Collections.emptyList();
    }

    protected List<Element> getObjectsAllowNull(String objectName, String pageName) {
		Object ob = getMatchingElement(objectName, pageName);
		List<Element> ele = (List<Element>) ob;

		if (ele != null) {
			if (!ele.isEmpty()) {
				TestContext.getInstance().testdataPut(ELEMENT_REF, ele);
				return ele;
			} else {
				return null;
			}
		} else {
			throw new ObjectNotFoundException(
					"The \"" + objectName + "\" element was not found in the page object: \"" + pageName + "\"");
		}
	}

}