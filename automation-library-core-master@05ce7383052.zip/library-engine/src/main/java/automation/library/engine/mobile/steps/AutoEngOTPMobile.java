package automation.library.engine.mobile.steps;

import automation.library.common.TestContext;
import automation.library.engine.mobile.BaseMobileSteps;
import automation.library.selenium.exec.driver.factory.DriverContext;
import io.cucumber.java.en.When;

import java.io.IOException;

public class AutoEngOTPMobile extends BaseMobileSteps {

    private static final String OTP_MESSAGE = "OTPMessage";

    @When("^the user stores the OTP value from the mobile SMS into the data dictionary with key \"([^\"]*)\"$")
    public void theUserStoresTheOTPValueFromTheMobileSMS(String dictionaryKey) throws IOException, InterruptedException {
        dictionaryKey = parseDictionaryKey(dictionaryKey);
        String otpMessage = getOTPMessage(getMobileDriver(), null);
        String otpCode = getSixDigitOTP(otpMessage);
        TestContext.getInstance().testdataPut(OTP_MESSAGE, otpMessage);
        TestContext.getInstance().testdataPut(dictionaryKey, otpCode);
        logStepMessage(String.format(STORED_VALUE, otpCode, dictionaryKey));
        logStepMessage(String.format(STORED_VALUE, otpMessage, OTP_MESSAGE));
        DriverContext.getInstance().quitMobile();
    }

    @When("^the user stores the OTP message with label \"([^\"]*)\" from the mobile SMS into the data dictionary with key \"([^\"]*)\"$")
    public void theUserStoresTheOTPMessageWithLabelFromTheMobileSMS(String messageLabel, String dictionaryKey) throws IOException, InterruptedException {
        dictionaryKey = parseDictionaryKey(dictionaryKey);
        messageLabel = parseValue(messageLabel);
        String otpMessage = getOTPMessage(getMobileDriver(), messageLabel);
        TestContext.getInstance().testdataPut(dictionaryKey, otpMessage);
        logStepMessage(String.format(STORED_VALUE, otpMessage, dictionaryKey));
        DriverContext.getInstance().quitMobile();
    }

    @When("^the user stores the OTP value with message label \"([^\"]*)\" from the mobile SMS into the data dictionary with key \"([^\"]*)\"$")
    public void theUserStoresTheOTPValueWithLabelFromTheMobileSMS(String messageLabel, String dictionaryKey) throws IOException, InterruptedException {
        dictionaryKey = parseDictionaryKey(dictionaryKey);
        messageLabel = parseValue(messageLabel);
        String otpMessage = getOTPMessage(getMobileDriver(), messageLabel);
        String otpCode = getSixDigitOTP(otpMessage);
        TestContext.getInstance().testdataPut(OTP_MESSAGE, otpMessage);
        TestContext.getInstance().testdataPut(dictionaryKey, otpCode);
        logStepMessage(String.format(STORED_VALUE, otpCode, dictionaryKey));
        logStepMessage(String.format(STORED_VALUE, otpMessage, OTP_MESSAGE));
        DriverContext.getInstance().quitMobile();
    }
}
