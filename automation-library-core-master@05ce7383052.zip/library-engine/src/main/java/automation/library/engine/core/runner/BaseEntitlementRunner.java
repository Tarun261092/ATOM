package automation.library.engine.core.runner;

import automation.library.engine.core.parser.FeatureFileParserUtil;
import org.testng.annotations.Test;

import java.io.IOException;

public class BaseEntitlementRunner extends FeatureFileParserUtil {

    @Test
    public void test() throws IOException {
        log.info("Updating feature file");
        reformFeatureFile();
    }
}
