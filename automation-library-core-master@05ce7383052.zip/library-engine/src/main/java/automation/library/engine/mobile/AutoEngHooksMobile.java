package automation.library.engine.mobile;

import automation.library.selenium.exec.driver.factory.DriverContext;
import io.cucumber.core.api.Scenario;
import io.cucumber.java8.En;

public class AutoEngHooksMobile implements En {

    public AutoEngHooksMobile() {
      After(40, (Scenario scenario) -> {
          if (DriverContext.getInstance().getMobileTechStack() != null) {
              DriverContext.getInstance().quitMobile();
          }
        });
    }

}

