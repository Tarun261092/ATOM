package automation.library.engine.db;

import automation.library.common.Property;
import automation.library.common.TestContext;
import automation.library.db.exec.DBContext;
import automation.library.engine.core.objectmatcher.fetch.FetchFlatFileObjects;
import io.cucumber.core.api.Scenario;
import io.cucumber.java8.En;
import org.apache.commons.configuration2.PropertiesConfiguration;

import static automation.library.db.core.Constants.DBRUNTIMEPATH;

public class AutoEngHooksDB implements En {

    public AutoEngHooksDB() {
        Before(35, (Scenario scenario) -> {
            TestContext.getInstance().setOfDB().addAll(FetchFlatFileObjects.populateListOfDBObjects());
            setDBRuntimeProperties();
        });

        After(40, (Scenario scenario) -> {
            if (DBContext.getInstance().isConnActive()) {
                DBContext.getInstance().closeConnection();
                DBContext.removeInstance();
            }
        });
    }

    private void setDBRuntimeProperties() {

        PropertiesConfiguration props = Property.getProperties(DBRUNTIMEPATH);

        if (props != null) {
            String dbMaxRowCount = props.getString("DBMaxRowCount") == null ? "100" : props.getString("DBMaxRowCount");
            System.setProperty("fw.DBMaxRowCount", dbMaxRowCount);
            String dbNullFlag = props.getString("dbNullFlag") == null ? "false" : props.getString("dbNullFlag");
            System.setProperty("fw.dbNullFlag", dbNullFlag);
        }
    }
}