package automation.library.engine.pdf;

import automation.library.common.PDFHelper;
import automation.library.common.Property;
import automation.library.common.TestContext;
import automation.library.cucumber.core.Constants;
import io.cucumber.core.api.Scenario;
import io.cucumber.java8.En;
import org.apache.commons.configuration2.PropertiesConfiguration;
import org.apache.pdfbox.pdmodel.PDDocument;

import static automation.library.engine.pdf.BasePDFSteps.ACTIVE_PDF;

public class AutoEngHooksPDF implements En {

	public AutoEngHooksPDF() {
		Before(35, (Scenario scenario) -> {
			setPDFProperties();
		});

		After(30, (Scenario scenario) -> {
			if(TestContext.getInstance().testdataGet(ACTIVE_PDF) != null) {
				PDFHelper.closePDFDoc(TestContext.getInstance().testdataToClass(ACTIVE_PDF, PDDocument.class));
				TestContext.getInstance().testdata().remove(ACTIVE_PDF);
			}
		});
	}

	private void setPDFProperties() {
		PropertiesConfiguration runTimeProps = Property.getProperties(Constants.RUNTIMEPATH);
		if (runTimeProps != null) {
			boolean ignoreCaseOnPDFCompare = Boolean.parseBoolean(runTimeProps.getString("ignoreCaseOnPDFCompare"));
			String numLeadingCharactersforPDFCompare = runTimeProps.getString("numLeadingCharactersforPDFCompare")  == null ? "0" : runTimeProps.getString("numLeadingCharactersforPDFCompare");
			boolean ignoreWhitespaceOnPDFCompare = Boolean.parseBoolean(runTimeProps.getString("ignoreWhitespaceOnPDFCompare"));

			System.setProperty("fw.ignoreCaseOnPDFCompare", Boolean.toString(ignoreCaseOnPDFCompare));
			System.setProperty("fw.numLeadingCharactersforPDFCompare", numLeadingCharactersforPDFCompare);
			System.setProperty("fw.ignoreWhitespaceOnPDFCompare", Boolean.toString(ignoreWhitespaceOnPDFCompare));
		}
	}
}