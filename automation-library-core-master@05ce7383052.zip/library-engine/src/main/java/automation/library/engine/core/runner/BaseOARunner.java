package automation.library.engine.core.runner;

import automation.library.common.TestContext;
import automation.library.engine.core.objectmatcher.fetch.FetchFlatFileObjects;
import automation.library.engine.core.objectmatcher.fetch.FetchFeatureFiles;
import automation.library.engine.core.objectmatcher.fetch.FetchPageObjects;
import automation.library.engine.core.parser.FeatureFileParser;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.ThreadContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class BaseOARunner {

	//TestNG before hook
	@BeforeClass
	public static void setup() {
		TestContext.getInstance().setOfPO().addAll(FetchPageObjects.populateListOfPO());
		TestContext.getInstance().setOfAPI().addAll(FetchFlatFileObjects.populateListOfAPIObjects());
		TestContext.getInstance().setOfFeatureFiles().addAll(FetchFeatureFiles.populateListOfFeatureFiles());
		TestContext.getInstance().setOfDB().addAll(FetchFlatFileObjects.populateListOfDBObjects());
		System.setProperty("fw.DBMaxRowCount", "10000");
	}

	@Test
	public static void verifyObjectAssociation() {
		String featureToRun = System.getProperty("fw.featureFileName");

		if(featureToRun != null && !featureToRun.equalsIgnoreCase("All")) {
			ThreadContext.put("scenarioName", featureToRun);
			featureToRun += ".feature";
			LogManager.getLogger(BaseOARunner.class).info("Running object associator on feature file: '{}'", featureToRun);
			new FeatureFileParser().checkObjectAssociation(featureToRun);
		}
		else {
			ThreadContext.put("scenarioName", "AllFeatures");
			LogManager.getLogger(BaseOARunner.class).info("Feature file name not provided. Running object associator on all features in the features folder");
			new FeatureFileParser().checkObjectAssociation();
		}
	}

}