package automation.library.engine.core.objectmatcher.fetch;

import org.apache.commons.io.FilenameUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.stream.Stream;

import static automation.library.api.Constants.APIOBJECTSPATH;
import static automation.library.db.core.Constants.DBOBJECTSPATH;

public class FetchFlatFileObjects {

    private FetchFlatFileObjects() {
        //Utility class
    }

    private static Logger getLogger() {
        return LogManager.getLogger(FetchFlatFileObjects.class);
    }

    public static Set<String> populateListOfAPIObjects() {
        List<String> fileExtensions = Collections.singletonList("feature");
        if(Paths.get(APIOBJECTSPATH).toFile().exists()) {
            return findMatchingFilesInPath(APIOBJECTSPATH, fileExtensions);
        }  else {
            return Collections.emptySet();
        }
    }

    public static Set<String> populateListOfDBObjects() {
        List<String> fileExtensions = Arrays.asList("sql", "json");
        if(Paths.get(DBOBJECTSPATH).toFile().exists()) {
            return findMatchingFilesInPath(DBOBJECTSPATH, fileExtensions);
        } else {
            return Collections.emptySet();
        }
    }

    private static Set<String> findMatchingFilesInPath(String rootDir, List<String> fileExtensions) {
        Path filePath = Paths.get(rootDir);
        final Set<String> fileList = new HashSet<>();

        try (Stream<Path> files = Files.find(filePath, 5,
                                             (path, attributes) -> {
                                                 File file = path.toFile();
                                                 return !file.isDirectory() &&
                                                        getEndsWithFilter(file, fileExtensions);
                                             })) {

            files.forEach(file -> fileList.add(getFileNameWithoutExtension(file)));
            if (fileList.isEmpty()) {
                getLogger().error("No file found within path \"{}\"", rootDir);
            } else {
                return fileList;
            }
        } catch (IOException e) {
            getLogger().error(e.getMessage(), e);
        }

        return fileList;
    }

    private static boolean getEndsWithFilter(File file, List<String> fileExtensions) {
        if(fileExtensions.size() == 1) {
            return file.getName().endsWith(fileExtensions.get(0));
        } else if(fileExtensions.size() == 2) {
            return (file.getName().endsWith(fileExtensions.get(0)) || file.getName().endsWith(fileExtensions.get(1)));
        } else if(!fileExtensions.isEmpty()) {
            getLogger().warn("Got more than 2 file extensions. Skipping check.");
            return false;
        }

        return false;
    }

    public static String getFileNameWithoutExtension(Path path) {
        String fileName = path.getFileName().toString();
        fileName = FilenameUtils.removeExtension(fileName);

        return fileName;
    }
}