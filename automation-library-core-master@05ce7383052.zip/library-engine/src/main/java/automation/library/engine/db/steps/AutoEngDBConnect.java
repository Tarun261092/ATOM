package automation.library.engine.db.steps;

import automation.library.engine.db.BaseDBSteps;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class AutoEngDBConnect extends BaseDBSteps {
    @Given("^DB connection for application \"([^\"]*)\" is established$")
    public void connectToDatabase(String appNameDbType) {
    	createConnection(appNameDbType);
    }
    
    @Then("^DB connection for application \"([^\"]*)\" is closed$")
    public void closeDBConnection(String appName) {
    	closeActiveConnection();
    }

}
