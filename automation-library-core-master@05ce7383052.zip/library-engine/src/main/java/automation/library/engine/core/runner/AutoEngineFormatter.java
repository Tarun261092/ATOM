package automation.library.engine.core.runner;

import static automation.library.common.StringHelper.getClassShortName;
import static automation.library.engine.core.AutoEngConstants.API;
import static automation.library.engine.core.AutoEngConstants.DB;
import static automation.library.engine.core.AutoEngConstants.DESKTOP;
import static automation.library.engine.core.AutoEngConstants.IVR;
import static automation.library.engine.core.AutoEngConstants.KAFKA;
import static automation.library.engine.core.AutoEngConstants.LEANFT;
import static automation.library.engine.core.AutoEngConstants.MOBILE;
import static automation.library.engine.core.AutoEngConstants.PDF;
import static automation.library.engine.core.AutoEngConstants.SELENIUM;
import static automation.library.reporting.Reporter.addADAReportFromPath;
import static automation.library.reporting.Reporter.addScreenCaptureFromPath;
import static automation.library.reporting.Reporter.getADAReportPath;
import static automation.library.tdaas.core.Constants.ERROR_RESPONSE;
import static cucumber.api.Result.Type.FAILED;
import static cucumber.api.Result.Type.PASSED;
import static cucumber.api.Result.Type.UNDEFINED;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.configuration2.PropertiesConfiguration;
import org.apache.logging.log4j.ThreadContext;
import org.openqa.selenium.WebDriver;

import automation.library.ada.AXEAccessibilitySteps;
import automation.library.common.FileHelper;
import automation.library.common.Property;
import automation.library.common.StringHelper;
import automation.library.common.TestContext;
import automation.library.engine.core.BaseStepsEngine;
import automation.library.selenium.core.Constants;
import automation.library.selenium.exec.driver.factory.DriverContext;
import automation.library.tlm.TlmContext;
import automation.library.tlm.common.entity.TlmRunStep;
import cucumber.api.PickleStepTestStep;
import cucumber.api.Result;
import cucumber.api.event.ConcurrentEventListener;
import cucumber.api.event.EventHandler;
import cucumber.api.event.EventPublisher;
import cucumber.api.event.TestCaseFinished;
import cucumber.api.event.TestCaseStarted;
import cucumber.api.event.TestSourceRead;
import cucumber.api.event.TestStepFinished;
import cucumber.api.event.TestStepStarted;
import cucumber.runtime.formatter.TestSourcesModelProxy;

public class AutoEngineFormatter implements ConcurrentEventListener {
    private final EventHandler<TestSourceRead> featureStartedHandler = this::handleFeatureStartedHandler;
    private final EventHandler<TestCaseStarted> caseStartedHandler = this::handleTestCaseStarted;
    private final EventHandler<TestCaseFinished> caseFinishedHandler = this::handleTestCaseFinished;
    private final EventHandler<TestStepStarted> stepStartedHandler = this::handleTestStepStarted;
    private final EventHandler<TestStepFinished> stepFinishedHandler = this::handleTestStepFinished;
    private final TestSourcesModelProxy testSources = new TestSourcesModelProxy();
    private final ThreadLocal<String> currentFeatureFile = new InheritableThreadLocal<>();
    private final ThreadLocal<Map<String, String>> screenshotBehaviorMap = new InheritableThreadLocal<>();
    private final ThreadLocal<Map<String, String>> classToWindowMapping = new InheritableThreadLocal<>();
    private final ThreadLocal<ScreenshotHandler> screenshotHandler = new InheritableThreadLocal<>();
    private final ThreadLocal<String> screenshotPath = new InheritableThreadLocal<>();
    private final ThreadLocal<Result.Type> lastStepStatus = new InheritableThreadLocal<>();
    private final ThreadLocal<Integer> stepNum = new InheritableThreadLocal<>();
    private static final String FW_SCENARIO_NAME = "fw.scenarioName";
    private static final String IGNORE = "Ignore";

    @Override
    public void setEventPublisher(EventPublisher eventPublisher) {
        eventPublisher.registerHandlerFor(TestSourceRead.class, featureStartedHandler);

        eventPublisher.registerHandlerFor(TestCaseStarted.class, caseStartedHandler);
        eventPublisher.registerHandlerFor(TestCaseFinished.class, caseFinishedHandler);

        eventPublisher.registerHandlerFor(TestStepStarted.class, stepStartedHandler);
        eventPublisher.registerHandlerFor(TestStepFinished.class, stepFinishedHandler);
    }

    private void handleFeatureStartedHandler(final TestSourceRead event) {
        testSources.addTestSourceReadEvent(event.uri, event);
    }

    private void loadDefaultExpectedResults() {
        if (TlmContext.getInstance().updateTlmFlag()) {
            TlmContext.getInstance().getTlmManager().loadDefaultExpectedResults();
        }
    }

    private void handleTestCaseStarted(TestCaseStarted event) {
        currentFeatureFile.set(event.testCase.getUri());
        TestContext.getInstance().testdataPut("fw.featureName",
                                              this.testSources.getFeature(this.currentFeatureFile.get()).getName());
        TestContext.getInstance().testdataPut(FW_SCENARIO_NAME, event.testCase.getName());
        TestContext.getInstance().testdataPut("fw.logFileName",
                                              StringHelper.removeSpecialChars(String.format("%s-%s",
                                                                                            TestContext.getInstance().testdataGet("fw.featureName"),
                                                                                            TestContext.getInstance().testdataGet(FW_SCENARIO_NAME))));

        ThreadContext.put("scenarioName", TestContext.getInstance().testdataGet("fw.logFileName").toString());
        loadDefaultExpectedResults();
        screenshotBehaviorMap.set(readScreenshotMap());
        classToWindowMapping.set(getWindowTypeMap());
        screenshotHandler.set(new ScreenshotHandler());
        lastStepStatus.set(PASSED);
        stepNum.set(0);
    }

    private void handleTestCaseFinished(final TestCaseFinished event) {
        currentFeatureFile.remove();
        screenshotBehaviorMap.remove();
        screenshotPath.remove();
        classToWindowMapping.remove();
        screenshotHandler.remove();
        lastStepStatus.remove();
        stepNum.remove();
    }

    private void handleTestStepStarted(TestStepStarted event) {
        if (event.testStep instanceof PickleStepTestStep) {
            setWindowType(event.testStep.getCodeLocation());

            final PickleStepTestStep testStep = (PickleStepTestStep) event.testStep;
            if (isBeforeStep(event.testStep.getCodeLocation(), testStep.getPickleStep().getText())) {
                String stepText = getStepDescription(testStep, lastStepStatus.get());
                screenshotPath.set(screenshotHandler.get().addScreenshotToStep(stepText, lastStepStatus.get()));
            } else {
                screenshotPath.set(ERROR_RESPONSE);
            }

            stepNum.set(stepNum.get() + 1);
        }
    }

    private Map<String, String> readScreenshotMap() {
        Map<String, String> tmpMap = FileHelper.loadJsonMapFromResources(AutoEngineFormatter.class,
                                                                         "ScreenshotBehavior.json");
        updateScreenshotMap(tmpMap);
        if (tmpMap != null && !tmpMap.isEmpty()) {
            return tmpMap.entrySet()
                         .stream()
                         .filter(entry -> entry.getValue()
                                               .equalsIgnoreCase("before"))
                         .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
        } else {
            return Collections.emptyMap();
        }
    }
    
    private void updateScreenshotMap(Map<String, String> tmpMap) {
    	PropertiesConfiguration props = Property.getProperties(Constants.SELENIUMRUNTIMEPATH);
    	
    	if(props.containsKey("extendScreenshotBehavior")) {
    		tmpMap.put((String) props.getProperty("extendScreenshotBehavior"),"Before");
    	}
		
	}

    private boolean isBeforeStep(String codeLocation, String stepText) {
        return (screenshotBehaviorMap.get().get(getClassShortName(codeLocation)) != null) ||
               (stepText.matches("the user sends keys \"(Key_enter|ENTER)\" to the \"([^\"]*)\" element(.*)"));
    }

    private void handleTestStepFinished(TestStepFinished event) {
        String errorMsg = null;
        String adaReportPath = null;
        lastStepStatus.set(event.result.getStatus());

        if (event.result.getStatus() == FAILED) {
            errorMsg = event.result.getErrorMessage();
        }

        if (event.testStep instanceof PickleStepTestStep) {
            final PickleStepTestStep testStep = (PickleStepTestStep) event.testStep;
            String stepText = getStepDescription(testStep, event.result.getStatus());

            if (screenshotPath.get().equalsIgnoreCase(ERROR_RESPONSE))
                screenshotPath.set(screenshotHandler.get().addScreenshotToStep(stepText, event.result.getStatus()));

            if (!stepText.contains("waits")) {
                adaReportPath = addADAResultToStep(event.result.getStatus(), testStep.getStepLine());
            }

            addScreenCaptureToAllure(screenshotPath.get());

            if (TlmContext.getInstance().updateTlmFlag()) {
                String stepStatus = getStepStatus(event.result, stepText);
                String actualResult = getActualResult(errorMsg, event.testStep.getCodeLocation(), event.result.getStatus());
                String expectedResult = getExpectedResult(event.testStep.getCodeLocation());

                addRunStep(stepText,
                           screenshotPath.get(),
                           adaReportPath,
                           stepStatus,
                           actualResult,
                           expectedResult,
                           stepNum.get(),
                           getNonResolvedStepDescription(testStep));

                if (event.result.getStatus() == FAILED || !TestContext.getInstance().sa().wasSuccess()) {
                    prepDefect(stepText, expectedResult, actualResult);
                }

                TlmContext.getInstance().getTlmManager().resetLastRunStep();
            }
        }

    }

    private void addScreenCaptureToAllure(String screenshotPath) {
        if (!screenshotPath.equalsIgnoreCase(ERROR_RESPONSE)) {
            addScreenCaptureFromPath(screenshotPath);
            TestContext.getInstance().testdata().put("fw.screenshotAbsolutePath", screenshotPath);
        }
    }

    private void addRunStep(String stepText,
                            String screenshotPath,
                            String adaReportPath,
                            String stepStatus,
                            String actualResult,
                            String expectedResult,
                            int stepNum,
                            String nonResolvedDescription) {
    	
    	Object path = TestContext.getInstance().testdata().get("fw.stepExcelPath");
    	List<String> excelPath = null;
    	if(path instanceof List) {

        	 excelPath =(List<String>)  TestContext.getInstance().testdata().get("fw.stepExcelPath");	
    	}else if (TestContext.getInstance().testdata().get("fw.stepExcelPath")!=null){
    		excelPath = new ArrayList<String>();
    		excelPath.add((String)TestContext.getInstance().testdata().get("fw.stepExcelPath"));
    	}
        TlmContext.getInstance().getTlmManager().addRunStep(new TlmRunStep(stepText,
                                                                           stepStatus,
                                                                           expectedResult,
                                                                           actualResult,
                                                                           screenshotPath,
                                                                           adaReportPath,
                                                                           excelPath,
                                                                           stepNum,
                                                                           nonResolvedDescription));
        TlmContext.getInstance().getTlmManager().resetLastRunStep();
    }

    private String getExpectedResult(String codeLocation) {
        if (TlmContext.getInstance().getTlmManager().stepAlreadyHasExpectedResult()) {
            return TlmContext.getInstance().getTlmManager().getLastStep().getExpectedResult();
        } else {
            return TlmContext.getInstance().getTlmManager().lookupDefaultExpectedResult(codeLocation);
        }
    }

    private String getActualResult(String errorMsg, String codeLocation, Result.Type status) {
        final List<String> actualResultList = new ArrayList<>();
        actualResultList.add(getLastStepActualResult());

        if (errorMsg != null) {
            actualResultList.add(errorMsg.split("at automation.")[0]);
        }

        if (actualResultList.size() > 1 || !actualResultList.get(0).isEmpty()) {
            return actualResultList.stream()
                                   .filter(entry -> !entry.isEmpty())
                                   .collect(Collectors.joining(System.lineSeparator()));
        } else if (status == PASSED) {
            return TlmContext.getInstance().getTlmManager().lookupDefaultExpectedResult(codeLocation);
        }

        return "";
    }

    private String getLastStepActualResult() {
        if (TlmContext.getInstance().getTlmManager().getLastStep() != null) {
            return TlmContext.getInstance().getTlmManager().getLastStep().getActualResult();
        } else {
            return "";
        }
    }

    private String getNonResolvedStepDescription(PickleStepTestStep testStep) {
        final String stepKeyword = Optional.ofNullable(
                testSources.getKeywordFromSource(currentFeatureFile.get(), testStep.getStepLine()))
                                           .orElse("UNDEFINED");

        return String.format("%s %s", stepKeyword, testStep.getPickleStep().getText());
    }

    private String getStepDescription(PickleStepTestStep testStep, Result.Type status) {
        String stepText = getNonResolvedStepDescription(testStep);

        if (stepExecuted(status)) {
            return replaceDictionaryKeysWithVals(stepText);
        } else {
            return stepText;
        }
    }

    private String replaceDictionaryKeysWithVals(String textToReplace) {
        if (!isStoreSentence(textToReplace)) {
            return new BaseStepsEngine().replaceParameterVals(textToReplace);
        } else {
            return textToReplace;
        }
    }

    private boolean isStoreSentence(String text) {
        if (text.matches("(.*)concatenated (string|value) of \"([^\"]*)\"(.*)")) {
            return false;
        } else {
            return (text.matches("store in new key \"([^\"]*)\"(.*)") ||
                    text.matches("store(.*)into the data dictionary with key \"([^\"]*)\"(.*)") ||
                    text.matches("(.*)data dictionary value at key \"([^\"]*)\"(.*)") ||
                    text.matches("(.*)enters the encrypted value \"([^\"]*)\"(.*)") ||
                    text.matches("(.*)enters the user credential \"([^\"]*)\"(.*)") ||
                    text.matches("(.*)loads secure credential into the data dictionary at key \"([^\"]*)\"(.*)")||
                    text.matches("(.*)enters the secure credential \"([^\"]*)\"(.*)"));
        }
    }

    private Map<String, String> getWindowTypeMap() {
        Map<String, String> tmpMap = new HashMap<>();

        tmpMap.put("AutoEngAPI", API);
        tmpMap.put("AutoEngKafka", KAFKA);
        tmpMap.put("AutoEngDB", DB);
        tmpMap.put("AutoEngMobile", MOBILE);
        tmpMap.put("AutoEngIVR", IVR);
        tmpMap.put("AutoEngMainframe", LEANFT);
        tmpMap.put("AutoEngDesktop", DESKTOP);
        tmpMap.put("AutoEngPDF", PDF);
        tmpMap.put("AutoEngWeb", SELENIUM);
        tmpMap.put("AutoEngUtility", IGNORE);
        tmpMap.put("AutoEngStore", IGNORE);
        tmpMap.put("AutoEngOTPMobile", IGNORE);
        tmpMap.put("AutoEngValidate", IGNORE);
        tmpMap.put("AutoEngNSMobile", IGNORE);

        return tmpMap;
    }

    private void setWindowType(String classLocation) {
        String classShortName = getClassShortName(classLocation);

        Map<String, String> matchingWindowType = classToWindowMapping.get()
                                                                     .entrySet()
                                                                     .stream()
                                                                     .filter(entry -> classShortName.contains(entry.getKey()))
                                                                     .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));

        matchingWindowType.values().forEach(value -> TestContext.getInstance().setActiveWindowType(value));
    }

    private boolean stepExecuted(Result.Type status) {
        return status == FAILED || status == PASSED;
    }

    private boolean isValidatonStep(String stepText) {
        return stepText.contains("validates");
    }

    private String getStepStatus(final Result testCaseResult, String stepText) {
        Result.Type testCaseResultToUse;

        if (continueOnFailureAndValidationFailed(stepText)) {
            testCaseResultToUse = FAILED;
        } else if (stepText.contains("completes the rest of the test manually")) {
            testCaseResultToUse = UNDEFINED;
        } else {
            testCaseResultToUse = testCaseResult.getStatus();
        }

        return TlmContext.getInstance().getTlmManager().translateStepStatusToTLMStatus(testCaseResultToUse);

    }

    private boolean continueOnFailureAndValidationFailed(String stepText) {
        return isValidatonStep(stepText) &&
               stepText.toLowerCase().contains("continueonfailure") &&
               !TestContext.getInstance().sa().wasSuccess();
    }

    private void prepDefect(String stepText, String expectedResult, String actualResult) {
        String defectSummary = String.format("%s: %s",
                                             TestContext.getInstance().testdataGet(FW_SCENARIO_NAME),
                                             stepText);

        TlmContext.getInstance().getTlmManager().prepDefectRecord(new BaseStepsEngine().getValidationId(stepText,
                                                                                                        isValidatonStep(stepText)),
                                                                  defectSummary,
                                                                  expectedResult,
                                                                  actualResult);
    }

    private String addADAResultToStep(Result.Type status, int stepLine) {

        if (stepExecuted(status) && Boolean.parseBoolean(System.getProperty("fw.ExecuteAttestPerStep"))) {
            String activeWindowType = TestContext.getInstance().getActiveWindowType();

            if (activeWindowType != null && activeWindowType.equalsIgnoreCase("SELENIUM")) {
                WebDriver driver = DriverContext.getInstance().getDriver();
                String scenario = TestContext.getInstance().testdataGet(FW_SCENARIO_NAME).toString();
                return addADAresultToReport(new File(String.format("%s%s", getADAReportPath(scenario), new AXEAccessibilitySteps().generateAxeReport(driver, scenario, stepLine))),
                                            driver.getCurrentUrl(),
                                            driver.getPageSource());
            }
        }
        return null;
    }

    private String addADAresultToReport(File file, String stepURL, String pagesource) {
        String path = null;
        if (file != null && file.exists()) {
            path = file.getAbsolutePath();
            addADAReportFromPath(path, stepURL, pagesource);
            TestContext.getInstance().testdata().put("fw.ADAResultAbsolutePath", path);
        }
        return path;
    }


}
