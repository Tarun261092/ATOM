package automation.library.engine.api.runner;

import automation.library.api.Constants;
import automation.library.common.Property;
import automation.library.engine.core.runner.AutoEngBaseTest;
import org.testng.annotations.BeforeClass;

public class AutoEngBaseTestAPI extends AutoEngBaseTest {
    @BeforeClass
    public static void beforeClass() {
        if (Property.getVariable("cukes.env") != null) {
            System.setProperty("karate.env", Property.getVariable("cukes.env"));
        }

        if (Property.getVariable("fw.threadsForAPI") != null) {
            System.setProperty("threads", Property.getVariable("fw.threadsForAPI"));
        } else {
            System.setProperty("threads", "3");
        }

        System.setProperty("fw.apiObjectsFolder", Constants.APIOBJECTSFOLDER);
    }
}
