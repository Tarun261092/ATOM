package automation.library.engine.core.steps;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.util.ZipSecureFile;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.google.common.collect.LinkedListMultimap;
import com.google.common.collect.ListMultimap;

import automation.library.common.ExcelHelper;
import automation.library.common.Property;
import automation.library.common.TestContext;
import automation.library.common.exception.InvalidExcellFileOperationException;
import automation.library.cucumber.core.Constants;
import automation.library.engine.core.BaseStepsEngine;
import automation.library.engine.core.validator.AssertHelper;
import automation.library.engine.core.validator.ComparisonOperator;
import automation.library.engine.core.validator.ComparisonType;
import automation.library.reporting.Reporter;
import automation.library.rpa.api.authentication.AutomationAnywhereApp;
import automation.library.rpa.api.exception.BotOperationFailedException;
import automation.library.rpa.api.util.AppConstants;
import io.cucumber.java.en.Then;
import io.qameta.allure.Allure;

public class AutoEngValidate extends BaseStepsEngine {



	@Then("^the user validates the data dictionary list \"([^\"]*)\" contains \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void theUserValidatesTheDataDictionaryListContains(String dictionaryKey,
			String expectedValue,
			String validationID,
			String onFailureFlag) {

		dictionaryKey = parseDictionaryKey(dictionaryKey);
		expectedValue = parseValue(expectedValue);
		List<String> expectedList = Collections.singletonList(expectedValue);
		List<String> actualList = setupActualListOfVals(dictionaryKey);

		AssertHelper validator = new AssertHelper("Compare_Lists", "Contains", onFailureFlag);
		validator.performValidation(actualList, expectedList,
				validationID,
				String.format("Dictionary list at key '%s' contains '%s'", dictionaryKey, expectedValue));
	}

	@Then("^the user validates the data dictionary list \"([^\"]*)\" does not contain \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void theUserValidatesTheDataDictionaryListDoesNotContain(String dictionaryKey,
			String expectedValue,
			String validationID,
			String onFailureFlag) {

		dictionaryKey = parseDictionaryKey(dictionaryKey);
		expectedValue = parseValue(expectedValue);
		List<String> expectedList = Collections.singletonList(expectedValue);
		List<String> actualList = setupActualListOfVals(dictionaryKey);

		AssertHelper validator = new AssertHelper(ComparisonType.COMPARE_LISTS, ComparisonOperator.NOT_CONTAINS, onFailureFlag);
		validator.performValidation(actualList, expectedList,
				validationID,
				String.format("Dictionary list at key '%s' does not contain '%s'", dictionaryKey, expectedValue));
	}

	@Then("^the user validates \"([^\"]*)\" that the data dictionary value of \"([^\"]*)\" is \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void theUserValidatesThatTheDataDictionaryValueOf(String comparisonType,
			String dictionaryKey,
			String comparisonOperator,
			String expectedValue,
			String validationID,
			String onFailureFlag) {
		dictionaryKey = parseDictionaryKey(dictionaryKey);
		expectedValue = parseValue(expectedValue);
		if (!TestContext.getInstance().testdata().containsKey(dictionaryKey)) {
			log.warn("Expected dictionary key not found: {}", dictionaryKey);
		}
		String actualValue = String.valueOf(TestContext.getInstance().testdataGet(dictionaryKey));
		AssertHelper validator = new AssertHelper(comparisonType, comparisonOperator, onFailureFlag);
		validator.performValidation(actualValue, expectedValue,
				validationID,
				String.format("Dictionary key '%s' validation", dictionaryKey));
	}

	@Then("^the user validates the data dictionary value of \"([^\"]*)\" is \"([^\"]*)\" data dictionary value of \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void theUserValidatesTheDataDictionaryValueOfIsDataDictionaryValueOf(String dataDictionaryVal1,
			String comparisonOperator,
			String dataDictionaryVal2,
			String validationID,
			String onFailureFlag) {
		dataDictionaryVal1 = parseDictionaryKey(dataDictionaryVal1);
		dataDictionaryVal2 = parseDictionaryKey(dataDictionaryVal2);
		dataDictionaryVal1 = String.valueOf(TestContext.getInstance().testdataGet(dataDictionaryVal1));
		dataDictionaryVal2 = String.valueOf(TestContext.getInstance().testdataGet(dataDictionaryVal2));

		AssertHelper validator = new AssertHelper(ComparisonType.COMPARE_STRINGS, ComparisonOperator.valueOfLabel(comparisonOperator), onFailureFlag);
		validator.performValidation(dataDictionaryVal1, dataDictionaryVal2,
				validationID,
				String.format("Compare data dictionary key '%s' to key '%s'", dataDictionaryVal1, dataDictionaryVal2));
	}

	@Then("^the user validates that the stored data dictionary map \"([^\"]*)\" has a key equal to \"([^\"]*)\" where the value is \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void theUserValidatesTheKeyCorrespondsValueOfIsDataDictionaryMap(String storedMapDictionaryKey,
			String expectedRate,
			String amount,
			String validationID,
			String onFailureFlag) {

		storedMapDictionaryKey = parseDictionaryKey(storedMapDictionaryKey);
		expectedRate = parseValue(expectedRate);
		amount = parseValue(amount).replace(",", "");

		ListMultimap<String, String> storedValue = TestContext.getInstance().testdataToClass(storedMapDictionaryKey, LinkedListMultimap.class);
		String key= null;
		for (Map.Entry<String, String> entry : storedValue.entries()) {
			if (Double.parseDouble(amount) < Double.parseDouble(entry.getValue().replace(",", ""))) {
				key = entry.getKey().trim();
				break;
			}
		}
		AssertHelper validator = new AssertHelper(ComparisonType.COMPARE_STRINGS, ComparisonOperator.CONTAINS, onFailureFlag);
		validator.performValidation(expectedRate, key, validationID,
				String.format("Map at dictionary key '%s' has matching key with value", storedMapDictionaryKey));
	}

	@Then("^the user splits the data dictionary value of \"([^\"]*)\" by matching the pattern \"([^\"]*)\" and validates \"([^\"]*)\" is present at index \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void theUserSplitsTheDataDictionaryValueOfAndValidatesAtIndex(String dictionaryKey,
			String pattern,
			String expectedValue,
			String index,
			String validationID,
			String onFailureFlag) {

		dictionaryKey = parseDictionaryKey(dictionaryKey);
		expectedValue = parseValue(expectedValue);

		if (TestContext.getInstance().testdata().containsKey(dictionaryKey)) {
			log.warn("Expected dictionary key not found: {}", dictionaryKey);
		}

		String actualValue = String.valueOf(TestContext.getInstance().testdataGet(dictionaryKey));
		actualValue = getValueFromText(actualValue, parseValue(index), parseValue(pattern));
		AssertHelper validator = new AssertHelper(ComparisonType.COMPARE_STRINGS, ComparisonOperator.CONTAINS, onFailureFlag);
		validator.performValidation(actualValue, expectedValue, validationID, String.format("Dictionary key '%s' validation", dictionaryKey));
	}

	@Then("^the user validates the email with subject \"([^\"]*)\" and verifies rows with \"([^\"]*)\" and the column values \"([^\"]*)\" in the sheet \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void theuservalidatestheemailwithsubjectandverifiescolumnvalues(String SubjectName,String expectedRowValue,String expectedColumnValue,String SheetName,String validationID,
			String onFailureFlag) throws FileNotFoundException
	{
		try {
			ExcelHelper.deleteFolderCreatedBeforeNumOfRequestedDays(AppConstants.BOT_ROOT_PATH,2);


			ExcelHelper.deleteTempFiles();

			String botRootPath = AppConstants.BOT_ROOT_PATH+"\\{fileNameWithExt}";
			List<String> ColumnValues=new ArrayList<String>();
			List<String> Column=new ArrayList<String>();
			List<String> ActualValue=new ArrayList<String>();
			String RowValue=parseValue(expectedRowValue);
			String email_subject=parseValue(SubjectName);
			String sheet=parseValue(SheetName);
			//Validating the expected value and actual value from the excel
			List<String> expectedColumnLists = Arrays.asList(expectedColumnValue.split("\\|"));
			for(String expectedColumnList : expectedColumnLists)
			{
				log.debug(expectedColumnList);
				Pattern p = Pattern.compile("#\\((.*)\\)");
				Matcher m = p.matcher(expectedColumnList);
				if (m.matches()) {
					String valToRetrieve = m.group(1);
					Column.add(valToRetrieve);
					ColumnValues.add("("+valToRetrieve+" : "+parseValue(expectedColumnList.trim())+")");
				}
			}
			AutomationAnywhereApp app = new AutomationAnywhereApp();
			List<File> pathList = Collections.emptyList();
			try {
				String requestId =  app.triggerDownloadEmailAttachmentBot(RowValue,email_subject);
				File f = new File(botRootPath.replace("{fileNameWithExt}",requestId));
				if(f.exists() && f.isDirectory()) {
					File [] innerFiles = f.listFiles();
					if(innerFiles!=null && innerFiles.length>0)
						pathList =  Arrays.asList(innerFiles);
				}
			} catch (BotOperationFailedException e) {
				e.printStackTrace();
				Reporter.addStepLog("FAIL", "BOT_EXECUTION_FAILED" +"--->"+e.getMessage());
				assertThat("Not Found").isEqualTo("Attachment");
			}
			if(!pathList.isEmpty() ) {
				File inputFile = pathList.get(0);
				String fileExtString = inputFile.getName().substring(inputFile.getName().lastIndexOf(".") + 1);
				File tf = new File("tempFiles");
				if(!tf.exists()) {
					tf.mkdir();
				}
				String outputFilePath = tf.getAbsolutePath()+"//"+new Date().getTime()+"EmailAttachment."+fileExtString;
				File outPutFile = new File(outputFilePath);
				if(outPutFile.exists()) {
					outPutFile.delete();
				}


				Map<String, HashMap<String, Object>> exceldata=ExcelHelper.getExcelDataAsHashMapwithPrimaryColumnAsKey(inputFile, sheet,Column,expectedRowValue,RowValue,outPutFile,false,true);
				HashMap<String, Object> SOEID=exceldata.get(RowValue);
				if(SOEID!=null)
				{
					for(String col : Column)
					{

						String value=SOEID.get(col).toString().trim();
						if(value.contains("."))
						{
							int intTemp = Float.valueOf(value).intValue();
							value=String.valueOf(intTemp);
						}

						ActualValue.add("("+col +" : "+value+")");

					}
					FileInputStream fileInputStream = new FileInputStream(outputFilePath);

					Allure.addAttachment("EvidenceFile",null,fileInputStream,fileExtString);


					TestContext.getInstance().testdataPut("fw.excelPath", outputFilePath);
					TestContext.getInstance().testdataPut("fw.stepExcelPath", outputFilePath);

					Reporter.addStepLog("PASS", "VALIDATION_PASSED" +"--->DocuSign Validation Of SOEID :"+ RowValue+" Matched");
					AssertHelper validator = new AssertHelper(ComparisonType.COMPARE_LISTS, ComparisonOperator.EQ, onFailureFlag);
					validator.performValidation(ActualValue, ColumnValues,
							validationID,onFailureFlag );

				}
				else
				{
					FileInputStream fileInputStream = new FileInputStream(outputFilePath);
					Allure.addAttachment("EvidenceFile",null,fileInputStream,fileExtString);
					TestContext.getInstance().testdataPut("fw.excelPath", outputFilePath);
					TestContext.getInstance().testdataPut("fw.stepExcelPath", outputFilePath);

					Reporter.addStepLog("FAIL", "VALIDATION_FAILED" +"--->"+RowValue+"--->is not present in the excel");
					assertThat(SOEID).isEqualTo(RowValue);
				}

			}else {
				Reporter.addStepLog("FAIL", "Attachment With Given Subject Not Found");
				assertThat("Not Found").isEqualTo("Attachment");

			}
		} catch (Exception e) {
			e.printStackTrace();
			Reporter.addStepLog("FAIL", "Error Occured While Processing");
			assertThat("SOEID").isEqualTo(e.getMessage());
		}


	}

	@Then("^the user downloads email attachment with subject from input file \"([^\"]*)\" and sheet \"([^\"]*)\" and store path to data dictionary key \"([^\"]*)\"$")
	public void theuserdownloadsattachmentsoftheemailwithsubject(String InputFile,String Sheetname, String dictionaryKeyToAttachmentPath )    {
		try {
			ExcelHelper.deleteFolderCreatedBeforeNumOfRequestedDays(AppConstants.BOT_ROOT_PATH,2);

			String userName = Property.getProperty(Constants.ALMPROPERTIESPATH, "aLMUser");

			String botRootPath = AppConstants.BOT_ROOT_PATH+"\\{fileNameWithExt}";
			InputFile=parseValue(InputFile);
			Sheetname=parseValue(Sheetname);
			ZipSecureFile.setMinInflateRatio(0);
			String emailSubject=null;
			String fileExtensionName = InputFile.substring(InputFile.lastIndexOf(".") + 1);

			if(fileExtensionName.equals("xlsx")){

				try(FileInputStream inputStream = new FileInputStream(InputFile);Workbook workbook = new XSSFWorkbook(inputStream);)
				{

					Sheet Sheet = workbook.getSheet(Sheetname);
					Row row = Sheet.getRow(1);
					emailSubject =row.getCell(0).getStringCellValue();
				}catch (Exception e) {
					e.printStackTrace();
					throw new InvalidExcellFileOperationException(e.getMessage());

				}
			} else {
				try(FileInputStream inputStream = new FileInputStream(InputFile);Workbook workbook = new HSSFWorkbook(inputStream);)
				{

					Sheet Sheet = workbook.getSheet(Sheetname);
					Row row = Sheet.getRow(1);
					emailSubject =row.getCell(0).getStringCellValue();
				}catch (Exception e) {
					e.printStackTrace();
					throw new InvalidExcellFileOperationException(e.getMessage());
				}
			}




			AutomationAnywhereApp app = new AutomationAnywhereApp();
			List<File> pathList = Collections.emptyList();
			String requestId =  app.triggerDownloadEmailAttachmentBot(userName,emailSubject);
			File f = new File(botRootPath.replace("{fileNameWithExt}",requestId));
			if(f.exists() && f.isDirectory()) {
				File [] innerFiles = f.listFiles();
				if(innerFiles!=null && innerFiles.length>0)
					pathList =  Arrays.asList(innerFiles);
			}
			if(pathList.size()>0) {

				String outputFilePath	= pathList.get(0).getAbsolutePath();

				TestContext.getInstance().testdataPut(dictionaryKeyToAttachmentPath, outputFilePath);
				Reporter.addStepLog("PASS", "Attachment Downloaded Successfully");
				assertThat("Attachment Found").isEqualTo("Attachment Found");

				try(FileInputStream fileInputStream = new FileInputStream(outputFilePath);){

					String	fileExtString = outputFilePath.substring(outputFilePath.lastIndexOf(".") + 1);
					Allure.addAttachment("EvidenceFile",null,fileInputStream,fileExtString);
					List<String> fileList = new ArrayList<String>();
					if(  TestContext.getInstance().testdataGet("fw.excelPath")!=null) {
						Object o = TestContext.getInstance().testdataGet("fw.excelPath");
						if(o instanceof List) {
							fileList = (List)o;
						}else {
							fileList.add((String)o);
						}
					}
					fileList.add(outputFilePath);
					TestContext.getInstance().testdataPut("fw.excelPath", fileList);

					TestContext.getInstance().testdataPut("fw.stepExcelPath", outputFilePath);
				} catch (Exception e) {

				}
			}
		} catch (Exception e) {

			Reporter.addStepLog("FAIL", "Download Attachment Failed "+e.getMessage());
			assertThat("Not Found").isEqualTo("Attachment");

		}
	}



	@Then("^the user validates the excel from \"([^\"]*)\" with file on data dictionary with key \"([^\"]*)\" and verifies rows with key column \"([^\"]*)\" with value \"([^\"]*)\" and the column names \"([^\"]*)\" in the sheet \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void validateExcelRowsWithMailAttachment(String userInputFilePath, String sourceFilePath , String keyCol,String keyColValue, String colNames ,String sheetName ,String validationID,
			String onFailureFlag)  {
		try {
			ExcelHelper.deleteTempFiles();

			userInputFilePath = 	parseValue(userInputFilePath);
			sourceFilePath = parseValue(sourceFilePath);
			TreeMap<String, String> inputMap = new TreeMap<String,String>();
			keyColValue = 	parseValue(keyColValue);
			sheetName = 	parseValue(sheetName);
			List<String> columnNameList = new ArrayList<String>();
			List<String> expectedColumnLists = Arrays.asList(colNames.split("\\|"));
			List<String> actualValues = new ArrayList<>();
			for(String expectedColumnList : expectedColumnLists)
			{
				log.debug(expectedColumnList);
				Pattern p = Pattern.compile("#\\((.*)\\)");
				Matcher m = p.matcher(expectedColumnList);
				if (m.matches()) {
					String valToRetrieve = m.group(1);

					columnNameList.add(valToRetrieve);
				}
			}
			File sourceFile = new File(sourceFilePath);
			String	fileExtString = sourceFilePath.substring(sourceFilePath.lastIndexOf(".") + 1);
			File tf = new File("tempFiles");
			if(!tf.exists()) {
				tf.mkdir();
			}
			String outputFilePath = tf.getAbsolutePath()+"//"+new Date().getTime()+"EmailAttachment."+fileExtString;

			//	String outputFilePath = new Date().getTime()+"EmailAttachment."+fileExtString;
			File outPutFile = new File(outputFilePath);
			if(outPutFile.exists()) {
				outPutFile.delete();
			}

			List<String> expectedColumnValues =	ExcelHelper.getExcelInputWorkBookandMatchedRows(userInputFilePath, keyCol, keyColValue, columnNameList, sheetName,inputMap);
			Map<String, HashMap<String, Object>> exceldata = ExcelHelper.getExcelDataAsHashMapwithPrimaryColumnAsKey(sourceFile, sheetName, columnNameList, keyCol, keyColValue, outPutFile, false, true); 

			HashMap<String, Object> keyValues = exceldata.get(keyColValue);
			if(keyCol!=null && keyCol.contains("#(")) {
				keyCol =  	keyCol.substring(keyCol.indexOf("#(")+2, keyCol.indexOf(")"));
			}
			actualValues.add("("+keyCol +" : "+keyColValue+")");
			if(keyValues!=null)
			{
				for(String col : columnNameList)
				{
					String value=keyValues.get(col).toString().trim();
					if(value.contains("."))
					{
						int intTemp = Float.valueOf(value).intValue();
						value=String.valueOf(intTemp);
					}

					actualValues.add("("+col +" : "+value+")");

				}
				Collections.sort(actualValues);
				Collections.sort(expectedColumnValues);
				FileInputStream fileInputStream = new FileInputStream(outputFilePath);
				Allure.addAttachment("EvidenceFile",null,fileInputStream,fileExtString);
				List<String> fileList = new ArrayList<String>();
				if(  TestContext.getInstance().testdataGet("fw.excelPath")!=null) {
					Object o = TestContext.getInstance().testdataGet("fw.excelPath");
					if(o instanceof List) {
						fileList = (List)o;
					}else {
						fileList.add((String)o);
					}
				}

				fileList.add(outputFilePath);
				TestContext.getInstance().testdataPut("fw.excelPath", fileList);

				TestContext.getInstance().testdataPut("fw.stepExcelPath", outputFilePath);

				Reporter.addStepLog("PASS", "VALIDATION_PASSED" +"--->DocuSign Validation Of SOEID :"+ keyColValue+" Matched");
				AssertHelper validator = new AssertHelper(ComparisonType.COMPARE_LISTS, ComparisonOperator.EQ, onFailureFlag);
				validator.performValidation(actualValues, expectedColumnValues,
						validationID,onFailureFlag );
			}else
			{
				FileInputStream fileInputStream = new FileInputStream(outputFilePath);
				Allure.addAttachment("EvidenceFile",null,fileInputStream,fileExtString);
				List<String> fileList = new ArrayList<String>();
				if(  TestContext.getInstance().testdataGet("fw.excelPath")!=null) {
					Object o = TestContext.getInstance().testdataGet("fw.excelPath");
					if(o instanceof List) {
						fileList = (List)o;
					}else {
						fileList.add((String)o);
					}
				}

				fileList.add(outputFilePath);
				TestContext.getInstance().testdataPut("fw.excelPath", fileList);

				TestContext.getInstance().testdataPut("fw.stepExcelPath", outputFilePath);
				Reporter.addStepLog("FAIL", "VALIDATION_FAILED" +"--->"+keyColValue+"--->is not present in the excel");
				assertThat(keyValues).isEqualTo(keyColValue);
			}

		}catch (Exception e) {

			Reporter.addStepLog("FAIL", "Attachment With Given Subject Not Found");
			assertThat("Not Found").isEqualTo("Attachment");

		}

	}

	@Then("^the user compares excel file data from sheet \"([^\"]*)\" in file \"([^\"]*)\" with excel file data from sheet \"([^\"]*)\" in file \"([^\"]*)\" for columns \"([^\"]*)\"$")
	public void compareExcelSheets( String userInputSheetName ,String userInputFilePath ,  String programInputSheetName , String programInputFilePath, String columnsToCompare)    {

		ExcelHelper.deleteTempFiles();

		userInputFilePath = 	parseValue(userInputFilePath);
		programInputFilePath = parseValue(programInputFilePath);

		programInputSheetName = 	parseValue(programInputSheetName);
		userInputSheetName = 	parseValue(userInputSheetName);
		List<String> columnNameList = new ArrayList<String>();
		List<String> expectedColumnLists = Arrays.asList(columnsToCompare.split("\\|"));
		for(String expectedColumnList : expectedColumnLists)
		{
			log.debug(expectedColumnList);
			columnNameList.add(expectedColumnList);           
		}

		String value = "NOT MATCHED";
		try {

			Map<String, String> responseMap =  ExcelHelper.compareTwoExcelSheet(userInputFilePath, programInputFilePath, userInputSheetName, programInputSheetName, columnNameList);
			String userOutputFilePath =  responseMap.get("userInputFilePath");

			String	fileOutExtString = userOutputFilePath.substring(userOutputFilePath.lastIndexOf(".") + 1);
			String programOutputFilePath =  responseMap.get("programInputFilePath");
			String programFileOutExtString = programOutputFilePath.substring(programOutputFilePath.lastIndexOf(".") + 1);
			try {
				FileInputStream fileInputStream = new FileInputStream(userOutputFilePath);
				Allure.addAttachment("Input File",null,fileInputStream,fileOutExtString);
				FileInputStream fileInputStream1 = new FileInputStream(programOutputFilePath);

				Allure.addAttachment("Output File",null,fileInputStream1,programFileOutExtString);


				List<String> stepFileList = new ArrayList<String>();
				List<String> fileList = new ArrayList<String>();
				if(  TestContext.getInstance().testdataGet("fw.excelPath")!=null) {
					Object o = TestContext.getInstance().testdataGet("fw.excelPath");
					if(o instanceof List) {
						fileList = (List)o;
					}else {
						fileList.add((String)o);
					}
				}

				fileList.add(userOutputFilePath);
				fileList.add(programOutputFilePath);
				stepFileList.add(userOutputFilePath);
				stepFileList.add(programOutputFilePath);
				//TestContext.getInstance().testdataPut("fw.excelPathList", fileList);
				TestContext.getInstance().testdataPut("fw.excelPath", fileList);

				TestContext.getInstance().testdataPut("fw.stepExcelPath", stepFileList);


			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
			if(responseMap!=null) {
				if(responseMap.get("statusCode")!=null && responseMap.get("statusCode").equals("1")){
					value = "All Records Matched";
					Reporter.addStepLog("PASS", value);
					assertThat(value).isEqualTo(value);


				}else if(responseMap.get("statusCode")!=null && responseMap.get("statusCode").equals("3")){
					value = "Partial Records Matched";
					Reporter.addStepLog("FAIL", value);
					assertThat(value).isEqualTo("All Records Matched");

				}else {
					Reporter.addStepLog("FAIL", value);
					assertThat(value).isEqualTo("All Records Matched");

				}
			}else {
				Reporter.addStepLog("FAIL", value);
				assertThat("All Records Matched").isEqualTo(value);

			}

		} catch (InvalidExcellFileOperationException e) {

			// TODO Auto-generated catch block
			e.printStackTrace();
			Reporter.addStepLog("FAIL", value);
			assertThat("All Records Matched").isEqualTo(e.getMessage());

		}
	}

	@Then("^the user compares excel file data from sheet \"([^\"]*)\" in file \"([^\"]*)\" with excel file data from sheet \"([^\"]*)\" in file \"([^\"]*)\"$")
	public void compareExcelSheetsForAllColumns( String userInputSheetName ,String userInputFilePath ,  String programInputSheetName , String programInputFilePath)    {

		ExcelHelper.deleteTempFiles();

		userInputFilePath = 	parseValue(userInputFilePath);
		programInputFilePath = parseValue(programInputFilePath);

		programInputSheetName = 	parseValue(programInputSheetName);
		userInputSheetName = 	parseValue(userInputSheetName);

		String value = "NOT MATCHED";
		try {

			Map<String, String> responseMap =  ExcelHelper.compareTwoExcelSheetAllcolumns(userInputFilePath, programInputFilePath, userInputSheetName, programInputSheetName);
			String userOutputFilePath =  responseMap.get("userInputFilePath");

			String	fileOutExtString = userOutputFilePath.substring(userOutputFilePath.lastIndexOf(".") + 1);
			String programOutputFilePath =  responseMap.get("programInputFilePath");
			String programFileOutExtString = programOutputFilePath.substring(programOutputFilePath.lastIndexOf(".") + 1);
			try {
				FileInputStream fileInputStream = new FileInputStream(userOutputFilePath);
				Allure.addAttachment("Input File",null,fileInputStream,fileOutExtString);
				FileInputStream fileInputStream1 = new FileInputStream(programOutputFilePath);

				Allure.addAttachment("Output File",null,fileInputStream1,programFileOutExtString);


				List<String> stepFileList = new ArrayList<String>();
				List<String> fileList = new ArrayList<String>();
				if(  TestContext.getInstance().testdataGet("fw.excelPath")!=null) {
					Object o = TestContext.getInstance().testdataGet("fw.excelPath");
					if(o instanceof List) {
						fileList = (List)o;
					}else {
						fileList.add((String)o);
					}
				}

				fileList.add(userOutputFilePath);
				fileList.add(programOutputFilePath);
				stepFileList.add(userOutputFilePath);
				stepFileList.add(programOutputFilePath);
				//TestContext.getInstance().testdataPut("fw.excelPathList", fileList);
				TestContext.getInstance().testdataPut("fw.excelPath", fileList);

				TestContext.getInstance().testdataPut("fw.stepExcelPath", stepFileList);


			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
			if(responseMap!=null) {
				if(responseMap.get("statusCode")!=null && responseMap.get("statusCode").equals("1")){
					value = "All Records Matched";


					Reporter.addStepLog("PASS", value);
					assertThat(value).isEqualTo(value);


				}else if(responseMap.get("statusCode")!=null && responseMap.get("statusCode").equals("3")){
					value = "Partial Records Matched";
					Reporter.addStepLog("FAIL", value);
					assertThat(value).isEqualTo("All Records Matched");

				}else {
					Reporter.addStepLog("FAIL", value);
					assertThat(value).isEqualTo("All Records Matched");

				}
			}else {
				Reporter.addStepLog("FAIL", value);
				assertThat("All Records Matched").isEqualTo(value);

			}

		} catch (InvalidExcellFileOperationException e) {

			// TODO Auto-generated catch block
			e.printStackTrace();
			Reporter.addStepLog("FAIL", value);
			assertThat("All Records Matched").isEqualTo(e.getMessage());

		}
	}

	@Then("^the user validates the data dictionary value with key \"([^\"]*)\" \"([^\"]*)\" data dictionary value with key \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void theUserValidatesDataDictionaryKeyValueToAnotherDataDictionaryKeyValue(String dataDictionaryVal,
			String comparisonOperator,
			String jsonKeyVal,
			String validationID,
			String onFailureFlag) {
		dataDictionaryVal = parseDictionaryKey(dataDictionaryVal);
		jsonKeyVal = parseDictionaryKey(jsonKeyVal);    	
		dataDictionaryVal = String.valueOf(TestContext.getInstance().testdataGet(dataDictionaryVal));
		jsonKeyVal = String.valueOf(TestContext.getInstance().testdataGet(jsonKeyVal));
		jsonKeyVal = "#("+ jsonKeyVal +")";
		jsonKeyVal = parseValue(jsonKeyVal);
		AssertHelper validator = new AssertHelper(ComparisonType.COMPARE_STRINGS, ComparisonOperator.valueOfLabel(comparisonOperator), onFailureFlag);
		validator.performValidation(dataDictionaryVal, jsonKeyVal,
				validationID,
				String.format("Compare data dictionary key '%s' to key '%s'", dataDictionaryVal, jsonKeyVal));
	}

	//Validating the Header Column Value along with the position

	@Then("^the user validates the data dictionary list \"([^\"]*)\" contains \"([^\"]*)\" at position \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")

	public void theUserValidatesTheDataDictionaryListContainsAtPostion(String dictionaryKey,
			String expectedValue, String position,
			String validationID,
			String onFailureFlag) {

		dictionaryKey = parseDictionaryKey(dictionaryKey);
		expectedValue = parseValue(expectedValue);
		position =parseValue(position);
		List<String> actualList = setupActualListOfVals(dictionaryKey);

		int pos = Integer.parseInt(position);
		String result ="null";    	
		for(int i=0;i<actualList.size();i++) {

			if((actualList.get(i).contentEquals(expectedValue)) && (pos == i )) {

				System.out.println("The position of the Requested value---" +actualList.get(i)+ " is at  " + i +"th Postion");
				result = "true";
				break;
			}
			else 
				result ="false";
		}	
		assertThat(result).isEqualTo("true");}

	@Then("^the user \"([^\"]*)\" a test$")
	public void PassorFailTest(String result){

		assertThat(result).isEqualTo("passes");
	}
	
	
	//Validates field values from Data Dictionary based on Delimiter
	 
	@Then("^the user validates the field values from data dictionary value with key \"([^\"]*)\" containing \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void theuservalidatesvaluesfromdictionary(String dataDictionaryVal,String delimiter,String fieldName1, String fieldName2, String validationID,String onFailureFlag) throws FileNotFoundException, InvalidExcellFileOperationException
	{

	    String value = "NOT MATCHED";    
	    delimiter = parseValue(delimiter);
	    dataDictionaryVal = parseValue(dataDictionaryVal);

	    fieldName1 = parseValue(fieldName1);
	    fieldName2 = parseValue(fieldName2);

	    String[] xmls = dataDictionaryVal.split(delimiter);
	    for (String xml : xmls) {
	        if(xml.contains(fieldName1)) {
	 
	            if(xml.contains(fieldName2)) {

	                value="Records Matched";
	                Reporter.addStepLog("PASS", value);
	                assertThat(value).isEqualTo(value);

	            }
	            else {
	                Reporter.addStepLog("FAIL", value);

	            }
	 
	}   
	    }assertThat("Records Matched").isEqualTo(value);
	}
}
