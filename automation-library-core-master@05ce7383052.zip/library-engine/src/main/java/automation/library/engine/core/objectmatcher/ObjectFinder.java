package automation.library.engine.core.objectmatcher;

import automation.library.common.CommonPageObject;
import automation.library.common.TestContext;
import automation.library.engine.api.BaseAPISteps;
import automation.library.engine.core.objectmatcher.rating.FlatFileObjectRating;
import automation.library.engine.core.objectmatcher.rating.FieldRating;
import automation.library.engine.core.objectmatcher.rating.PageObjectRating;
import info.debatty.java.stringsimilarity.JaroWinkler;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import static automation.library.common.StringHelper.*;

public class ObjectFinder {
    private static final double ELEMENT_NOT_FOUND = -1.0;
    private static final double EXACT_THRESHOLD = 1;
    private static final double ABOVE_THRESHOLD = 0.85;
    private static final double BELOW_THRESHOLD = 0.7;
    public static final String WARNING_TEMPLATE = "{} {}";

    private ObjectFinder() {
        //Utility class
    }

    private static Logger getLogger() {
        return LogManager.getLogger(ObjectFinder.class);
    }

    /**
     * Generic method to find object
     *
     * @param objectName
     * @param pageName
     */
    public static Object getMatchingElement(String objectName, String pageName) {
        PageObjectRating pageObjMatch = null;
        FieldRating fieldMatch = null;
        CommonPageObject pageObj = null;
        Object ele = null;

        pageObjMatch = findMatchingPage(pageName);

        if (pageObjMatch.getSimilarityScore() != ELEMENT_NOT_FOUND) {
            fieldMatch = findMatchingElement(objectName, pageObjMatch.getPageObjectClazz());

            if (fieldMatch.getSimilarityScore() != ELEMENT_NOT_FOUND) {
                try {
                    if (pageObjMatch.getPageObjectClazz().newInstance() instanceof CommonPageObject)
                        pageObj = (CommonPageObject) pageObjMatch.getPageObjectClazz().newInstance();

                    ele = invokeMethod(pageObj, fieldMatch.getFieldName());
                } catch (InstantiationException | IllegalAccessException | NullPointerException e) {
                    getLogger().error(e.getMessage(), e);
                }
            }
        }

        return ele;
    }


    /**
     * Generic method to find object
     *
     * @param pageName
     */
    public static PageObjectRating findMatchingPage(String pageName) {
        Set<Class<?>> pageObjects = TestContext.getInstance().setOfPO();
        List<PageObjectRating> listOfFilteredPOs;
        PageObjectRating topMatch = null;

        listOfFilteredPOs = pageObjects.stream()
                                       .map(clazz -> new PageObjectRating(getClassName(clazz),
                                                                          getSimilarityScore(getClassName(clazz), removeSpecialChars(pageName)),
                                                                          clazz))
                                       .filter(pObject -> pObject.getSimilarityScore() >= BELOW_THRESHOLD)
                                       .sorted(Comparator.comparing(PageObjectRating::getSimilarityScore).reversed())
                                       .collect(Collectors.toList());

        if (!listOfFilteredPOs.isEmpty()) {
            topMatch = listOfFilteredPOs.get(0);

            if (topMatch.getSimilarityScore() >= EXACT_THRESHOLD) {
                topMatch.setSearchResultMsg(String.format("Page Object: found exact match on the page: \"%s\"", topMatch.getPageObjectName()));
                getLogger().debug(topMatch.getSearchResultMsg());
            } else if (topMatch.getSimilarityScore() >= ABOVE_THRESHOLD) {
                topMatch.setSearchResultMsg(String.format("Page Object: couldn't find exact page match for: \"%s\". Using a similar match: \"%s\"",
                                                          pageName, topMatch.getPageObjectName()));
                getLogger().warn(topMatch.getSearchResultMsg());
            } else if (topMatch.getSimilarityScore() >= BELOW_THRESHOLD) {
                String searchResultMsg = String.format("Page Object: Couldn't find a similar page match for: \"%s\". Potential pages for a similar match are: ", pageName);
                StringBuilder pageObjList = new StringBuilder();

                listOfFilteredPOs.forEach(p -> {
                    pageObjList.append(p.getPageObjectName());
                    pageObjList.append(System.lineSeparator());
                });

                topMatch.setSimilarityScore(ELEMENT_NOT_FOUND);
                topMatch.setSearchResultMsg(searchResultMsg);
                topMatch.setPageObjList(pageObjList.toString());
                getLogger().warn(WARNING_TEMPLATE, searchResultMsg, pageObjList);
            }
        } else {
            String searchResultMsg = "Page Object: Matching page name of \"" + pageName + "\" not found in available list of pages. Available page objects: " + System.lineSeparator();
            StringBuilder pageObjList = new StringBuilder();

            pageObjects.forEach(p -> {
                pageObjList.append(p.getName());
                pageObjList.append(System.lineSeparator());
            });

            topMatch = new PageObjectRating(null, ELEMENT_NOT_FOUND, null, searchResultMsg, pageObjList.toString());
            getLogger().error(WARNING_TEMPLATE, searchResultMsg, pageObjList);
        }

        return topMatch;
    }

    public static FieldRating findMatchingElement(String objectName, Class<?> pageObjectClazz) {
        List<FieldRating> listOfFilteredFields;
        FieldRating topMatch = null;

        final Field[] declaredFields = pageObjectClazz.getDeclaredFields();

        listOfFilteredFields = Arrays.stream(declaredFields)
                                     .map(field -> new FieldRating(field.getName(),
                                                                   getSimilarityScore(field.getName(), removeSpecialChars(objectName))))
                                     .filter(field -> field.getSimilarityScore() >= BELOW_THRESHOLD)
                                     .sorted(Comparator.comparing(FieldRating::getSimilarityScore).reversed())
                                     .collect(Collectors.toList());

        if (!listOfFilteredFields.isEmpty()) {
            topMatch = listOfFilteredFields.get(0);

            if (topMatch.getSimilarityScore() >= EXACT_THRESHOLD) {
                topMatch.setSearchResultMsg("Element: found exact match for the element \"" + objectName + "\"");
                getLogger().debug(topMatch.getSearchResultMsg());
            } else if (topMatch.getSimilarityScore() >= ABOVE_THRESHOLD) {
                topMatch.setSearchResultMsg("Element: couldn't find exact element match for: \"" + objectName + "\". " + "Using a similar match: \"" + topMatch.getFieldName() + "\"");
                getLogger().warn(topMatch.getSearchResultMsg());
            } else if (topMatch.getSimilarityScore() >= BELOW_THRESHOLD) {
                String searchResultMsg = "Element: couldn't find a similar match for the \"" + objectName + "\" element in the provided page object class \""
                                         + getPageObjName(pageObjectClazz.toString()) + "\".   " + "Here are few elements similar to the provided element name: " + System.lineSeparator();


                String fieldList = getSortedFieldListAsString(listOfFilteredFields.stream()
                                                                                  .map(FieldRating::getFieldName)
                                                                                  .collect(Collectors.toList()));

                topMatch.setSimilarityScore(ELEMENT_NOT_FOUND);
                topMatch.setSearchResultMsg(searchResultMsg);
                topMatch.setFieldList(fieldList);
                getLogger().warn(WARNING_TEMPLATE, searchResultMsg, fieldList);
            }
        } else {
            String searchResultMsg = System.lineSeparator() + "Element: The \"" + objectName + "\" element was not found in the \"" + getPageObjName(pageObjectClazz.toString()) + "\" page object. " +
                                     "Full list of elements in this page object are: " + System.lineSeparator();

            String fieldList = getSortedFieldListAsString(Arrays.stream(declaredFields)
                                                                .map(Field::getName)
                                                                .collect(Collectors.toList()));

            topMatch = new FieldRating(null, ELEMENT_NOT_FOUND, searchResultMsg, fieldList);
            getLogger().error(WARNING_TEMPLATE, searchResultMsg, fieldList);
        }

        return topMatch;
    }

    private static FlatFileObjectRating getMatchingFlatFile(Set<String> flatFileObjects,
                                                            String objectNameToFind,
                                                            String objectType) {
        List<FlatFileObjectRating> listOfFilteredFiles;
        FlatFileObjectRating topMatch = null;

        listOfFilteredFiles = flatFileObjects.stream()
                                       .map(flatFileName -> new FlatFileObjectRating(flatFileName,
                                                                                getSimilarityScore(flatFileName, removeSpecialChars(objectNameToFind))))
                                       .filter(fName -> getSimilarityScore(fName.getFlatFileObjectName(), objectNameToFind) >= BELOW_THRESHOLD)
                                       .sorted(Comparator.comparing(FlatFileObjectRating::getSimilarityScore).reversed())
                                       .collect(Collectors.toList());


        if (!listOfFilteredFiles.isEmpty()) {
            topMatch = listOfFilteredFiles.get(0);

            if (topMatch.getSimilarityScore() >= EXACT_THRESHOLD) {
                topMatch.setSearchResultMsg(String.format("%s Object: found exact match : \"%s\"",
                                                          objectType,
                                                          topMatch.getFlatFileObjectName()));
                getLogger().debug(topMatch.getSearchResultMsg());
            } else if (topMatch.getSimilarityScore() >= ABOVE_THRESHOLD) {
                topMatch.setSearchResultMsg(String.format("%s Object: couldn't find exact match for: \"%s\". Using a similar match: \"%s\"",
                                                          objectType,
                                                          objectNameToFind,
                                                          topMatch.getFlatFileObjectName()));

                getLogger().warn(topMatch.getSearchResultMsg());
            } else if (topMatch.getSimilarityScore() >= BELOW_THRESHOLD) {
                String searchResultMsg = String.format("%s Object: Couldn't find a similar match for: \"%s\". Potential %s objects for similar match are: ",
                                                       objectType,
                                                       objectNameToFind,
                                                       objectType);
                StringBuilder apiObjList = new StringBuilder();

                listOfFilteredFiles.forEach(p -> {
                    apiObjList.append(p.getFlatFileObjectName());
                    apiObjList.append(System.lineSeparator());
                });

                topMatch.setSimilarityScore(ELEMENT_NOT_FOUND);
                topMatch.setSearchResultMsg(searchResultMsg);
                topMatch.setFlatFileObjectList(apiObjList.toString());
                getLogger().warn(WARNING_TEMPLATE, searchResultMsg, apiObjList);
            }
        } else {
            String searchResultMsg = String.format("%s Object: Matching page name of \"%s\" not found in available list of %s objects. Available %ss are: %s",
                                                   objectType,
                                                   objectNameToFind,
                                                   objectType,
                                                   objectType,
                                                   System.lineSeparator());
            StringBuilder apiObjList = new StringBuilder();

            flatFileObjects.forEach(p -> {
                apiObjList.append(p);
                apiObjList.append(System.lineSeparator());
            });

            topMatch = new FlatFileObjectRating(null, ELEMENT_NOT_FOUND, searchResultMsg, apiObjList.toString());
            getLogger().error(WARNING_TEMPLATE, searchResultMsg, apiObjList);
        }

        return topMatch;
    }

    public static FlatFileObjectRating getMatchingAPIFeature(String featureName) {
        Set<String> apiObjects = TestContext.getInstance().setOfAPI();
        return getMatchingFlatFile(apiObjects, featureName, "API");
    }

    public static FlatFileObjectRating getMatchingDBQuery(String queryName) {
        Set<String> dbObjects = TestContext.getInstance().setOfDB();
        return getMatchingFlatFile(dbObjects, queryName, "query");
    }

    private static String getSortedFieldListAsString(List<String> sortedFieldList) {
        StringBuilder fieldList = new StringBuilder();

        sortedFieldList.sort(String.CASE_INSENSITIVE_ORDER);
        sortedFieldList.forEach(f -> {
            fieldList.append(f);
            fieldList.append(System.lineSeparator());
        });

        return fieldList.toString();
    }

    private static String getPageObjName(String pageObjFullName) {
        List<String> name = Arrays.asList(pageObjFullName.split("\\."));
        if (!name.isEmpty()) {
            return name.get(name.size() - 1);
        } else {
            return null;
        }
    }

    /**
     * @param pageObj
     * @param objectName
     * @return element invoked
     */

    private static Object invokeMethod(CommonPageObject pageObj, String objectName) {
        Object returnObj = null;
        try {
            Method method = pageObj.getClass().getMethod(objectName);
            returnObj = method.invoke(pageObj);
        } catch (NoSuchMethodException | IllegalAccessException | InvocationTargetException e) {
            getLogger().warn(e.getMessage(), e);
        }
        return returnObj;
    }

    /**
     * @param clazz
     * @return Class Name
     */
    private static String getClassName(Class<?> clazz) {
        return clazz.getName().substring(clazz.getName().lastIndexOf('.') + 1);
    }

    /**
     * @param str1
     * @param str2
     * @return Similarity score
     */
    private static double getSimilarityScore(String str1, String str2) {
        JaroWinkler jw = new JaroWinkler();
        return jw.similarity(str1.toLowerCase(), str2.toLowerCase());
    }

    public static void invokePOMethod(String pageName, String methodName) throws IllegalAccessException,
                                                                                 InstantiationException {
        PageObjectRating matchingPage = ObjectFinder.findMatchingPage(pageName);
        CommonPageObject challengePageObj = null;
        BaseAPISteps baseAPISteps = null;
        if (matchingPage.getSimilarityScore() != ELEMENT_NOT_FOUND) {
            if (matchingPage.getPageObjectClazz().newInstance() instanceof CommonPageObject) {
                challengePageObj = (CommonPageObject) matchingPage.getPageObjectClazz().newInstance();
                invokeMethod(challengePageObj, methodName);
            } else if (matchingPage.getPageObjectClazz().newInstance() instanceof BaseAPISteps) {
                baseAPISteps = (BaseAPISteps) matchingPage.getPageObjectClazz().newInstance();
                invokeMethod(baseAPISteps, methodName);
            }
        } else {
            getLogger().error("Did not find method in page object");
        }
    }

    private static Object invokeMethod(BaseAPISteps pageObj, String objectName) {
        Object returnObj = null;
        try {
            Method method = pageObj.getClass().getMethod(objectName);
            returnObj = method.invoke(pageObj);
        } catch (NoSuchMethodException | IllegalAccessException | InvocationTargetException e) {
            getLogger().warn(e.getMessage(), e);
        }
        return returnObj;
    }


}
