package automation.library.engine.core;

public class AutoEngConstants {
    public static final String LEANFT = "LeanFT";
    public static final String DESKTOP = "Desktop";
    public static final String SELENIUM = "Selenium";
    public static final String API = "API";
    public static final String DB = "DB";
    public static final String PDF = "PDF";
    public static final String KAFKA = "KAFKA";
    public static final String MOBILE = "Mobile";
    public static final String IVR = "IVR";
    public static final String VALIDATION_TAG = "VALIDATION.";

    private AutoEngConstants() {
        //Utility class
    }
}
