package automation.library.engine.core.parser;

import automation.library.common.TestContext;
import automation.library.engine.core.objectmatcher.fetch.FetchFeatureFiles;
import cucumber.util.FixJava;
import gherkin.AstBuilder;
import gherkin.Parser;
import gherkin.TokenMatcher;
import gherkin.ast.*;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.stream.Collectors;

import static automation.library.common.FileHelper.getFileAsString;
import static automation.library.common.FileHelper.writeDataToFile;


public class FeatureFileParserUtil extends FeatureFileParser {
    protected Parser<GherkinDocument> parser = new Parser<>(new AstBuilder());
    protected TokenMatcher matcher = new TokenMatcher();

    public void reformFeatureFile() throws IOException {
        Map<String, String> inputScenarios = new HashMap<>();
        reformFeatureFile(inputScenarios, null, 0);
    }


    public void reformFeatureFile(Map<String, String> scenarioNameMap, List<String> jsonName, int jsonNumber) throws IOException {
        TestContext.getInstance().setOfFeatureFiles().addAll(FetchFeatureFiles.populateListOfFeatureFiles());
        List<String> scenarioSteps;
        String setExample = null;
        String filePath = System.getProperty("filePath");

        if (filePath != null) {
            String fileData = getFileAsString(filePath, "\n");
            if (scenarioNameMap.isEmpty()) {
                scenarioNameMap = getInputScenarios(filePath);
            }
            if (jsonName != null && jsonNumber > 0) {
                scenarioSteps = getScenarioOutlineAndSteps(scenarioNameMap);
                setExample = setJSONExamples(jsonName, jsonNumber);
                fileData = addStepsAndExamplesToScenarioOutline(scenarioSteps, setExample, fileData);
            } else {
                for (Map.Entry<String, String> entry : scenarioNameMap.entrySet()) {
                    List<String> steps = getScenarioNameAndSteps(entry.getValue());
                    fileData = addStepsToScenario(fileData, steps, entry.getValue());
                }
            }
            writeDataToFile(filePath, fileData);
        } else {
            log.error("File path not found");
        }

    }

    private String addStepsAndExamplesToScenarioOutline(List<String> steps, String setExample, String fileData) {
        StringBuilder sb = new StringBuilder(fileData);
        sb.append("\n");
        sb.append(steps.stream().collect(Collectors.joining()));
        sb.append(setExample);

        return sb.toString();
    }


    public String setJSONExamples(List<String> jsonNameList, int jsonNumber) {
        String setExample = null;
        String delimeter = " | ";
        try {
            setExample = " Examples: \n" + delimeter + "Data" + delimeter + "\n";
            for (String jsonName : jsonNameList) {
                for (int i = 0; i < jsonNumber; i++) {
                    setExample = setExample.concat(delimeter + jsonName + delimeter + "\n");
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage());
        }

        return setExample;
    }


    private String addStepsToScenario(String valToUpdate, List<String> steps, String scenarioTag) {
        StringBuilder sb;
        String replaceData = null;
        if (!steps.isEmpty() && !scenarioTag.isEmpty()) {
            replaceData = "Scenario: " + scenarioTag;
            try {
                sb = new StringBuilder(valToUpdate);
                if (valToUpdate.contains(replaceData)) {
                    int start = valToUpdate.indexOf(replaceData);
                    int end = replaceData.length();
                    sb.replace(start, start + end, steps.stream().collect(Collectors.joining()));
                    return sb.toString();
                }
            } catch (Exception e) {
                log.debug(e.getMessage());
            }
        }
        return valToUpdate;
    }

    private Map<String, String> getInputScenarios(String file) throws FileNotFoundException {
        String gherkin;
        Map<String, String> scenarioMap = new HashMap<>();
        gherkin = FixJava.readReader(new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8));
        GherkinDocument d3 = parser.parse(gherkin, matcher);
        Feature feature = d3.getFeature();
        List<ScenarioDefinition> parts = feature.getChildren();
        int count = 1;
        for (ScenarioDefinition sd : parts) {
            String scenarioName = sd.getName();
            scenarioMap.put(String.valueOf(count), scenarioName);
            count++;
        }
        return scenarioMap;
    }


    public List<String> getScenarioNameAndSteps(String scenarioName) {
        boolean flag = false;
        List<String> steps = new ArrayList<>();
        List<String> scenarioLength = Arrays.asList(scenarioName.split(","));

        if (scenarioLength.size() > 1) {
            scenarioName = scenarioLength.get(0);
            flag = true;
        }

        for (File fil : featureFiles) {
            if (fil.getName().endsWith(FEATURE)) {
                String gherkin;
                try {
                    gherkin = FixJava.readReader(new InputStreamReader(new FileInputStream(fil), StandardCharsets.UTF_8));
                    GherkinDocument d3 = parser.parse(gherkin, matcher);
                    Feature feature = d3.getFeature();
                    List<ScenarioDefinition> parts = feature.getChildren();
                    if (findMatchingScenario(scenarioName, flag, steps, scenarioLength, parts)) return steps;
                } catch (Exception e) {
                    log.error(e.getMessage());
                }
            }
        }
        return steps;
    }

    private boolean findMatchingScenario(String scenarioName,
                                         boolean flag,
                                         List<String> steps,
                                         List<String> scenarioLength,
                                         List<ScenarioDefinition> parts) {
        for (ScenarioDefinition sd : parts) {
            List<String> tags = getScenarioLabels(sd);
            for (String tag : tags) {
                if (tag.equalsIgnoreCase(scenarioName) || sd.getName().equalsIgnoreCase(scenarioName)) {
                    String scenarioStep = "Scenario: " + getScenarioName(sd) + "\n";
                    steps.add(scenarioStep);
                    if (flag) {
                        steps.add("  And load data from JSON file \"" + scenarioLength.get(1) + "\" into the data dictionary \n");
                    }
                    for (Step s : sd.getSteps()) {
                        steps.add("    " + s.getKeyword() + s.getText() + "\n");
                    }
                    return true;
                }
            }
        }
        return false;
    }

    public List<String> getScenarioOutlineAndSteps(Map<String, String> scenarioNameMap) {
        List<String> steps = new ArrayList<>();
        boolean flag = false;

        for(Map.Entry<String, String> line: scenarioNameMap.entrySet()) {
            for (File fil : featureFiles) {
                if (fil.getName().endsWith(FEATURE)) {
                    String gherkin;
                    try {
                        gherkin = FixJava.readReader(new InputStreamReader(new FileInputStream(fil), StandardCharsets.UTF_8));
                        GherkinDocument d3 = parser.parse(gherkin, matcher);
                        Feature feature = d3.getFeature();
                        List<ScenarioDefinition> parts = feature.getChildren();
                        for (ScenarioDefinition sd : parts) {
                            List<String> tags = getScenarioLabels(sd);
                            if (sd.getName().equals(line.getValue()) || tags.get(0).equals(line.getValue())) {
                                if (!flag) {
                                    if (!tags.isEmpty()) {
                                        steps.add(tags.get(0) + "\n");
                                    }
                                    steps.add(" Scenario Outline: " + getScenarioName(sd) + " <Data>\n");
                                    steps.add("  Given load data from JSON file \"StaticData\" into the data dictionary \n");
                                    steps.add("  And load data from JSON file \"<Data>\" into the data dictionary \n");
                                    flag = true;
                                }
                                for (Step s : sd.getSteps()) {
                                    steps.add("  " + s.getKeyword() + s.getText() + "\n");
                                }
                            }
                        }
                    } catch (Exception e) {
                        log.warn(e.getMessage());
                    }
                }
            }
        }
        return steps;
    }

    private String getScenarioName(ScenarioDefinition sd) {
        String scenarioName = null;

        if (sd instanceof Scenario) {
            scenarioName = ((Scenario) sd).getName();
        } else if (sd instanceof ScenarioOutline) {
            scenarioName = ((ScenarioOutline) sd).getName();
        }
        return scenarioName;
    }
}
