package automation.library.engine.core.runner;

import automation.library.common.FileHelper;
import automation.library.common.ZipHelper;
import automation.library.reporting.Reporter;
import automation.library.tlm.TlmContext;
import automation.library.tlm.common.TlmConstants;
import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.ReadContext;
import net.minidev.json.JSONArray;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.Test;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.*;
import java.util.stream.Collectors;

public class ReportUploadRunner {
    private final Logger log = LogManager.getLogger(ReportUploadRunner.class);
    private static final String ALLURE_TEST_ID = "allureTestID";

    @Test
    public void uploadAllureResultsToALM() {
        Set<String> reportJSONs = FileHelper.getMatchingFilesFromDirectory(TlmConstants.TLM_HISTORY_PATH, ".json");
        Map<String, String> pathToZipResults = new HashMap<>();
        Gson gsonObj = new Gson();

        for (String reportJSON : reportJSONs) {
            try (FileReader jsonReader = new FileReader(TlmConstants.TLM_HISTORY_PATH + reportJSON)) {
                final Map<String, String> updateHistory = gsonObj.fromJson(jsonReader, Map.class);
                final String allureResultFileName = String.format("%s-%s.json", updateHistory.get(ALLURE_TEST_ID), "result");
                final String pathToAllureResult = FileHelper.findFileInPath(Reporter.getReportPath(), allureResultFileName);

                if (pathToAllureResult != null && updateHistory.get("testID") != null) {
                    log.debug("Found Allure result file for test with ALM ID {}", updateHistory.get("testID"));
                    final String pathToUploadDir = createTempFolderForResults(Paths.get(Reporter.getReportPath()).toAbsolutePath().toString() + "-upload/", updateHistory.get(ALLURE_TEST_ID));
                    copyToUploadDir(Reporter.getReportPath(), pathToUploadDir, allureResultFileName);
                    findAllureFilesAndMoveToTempFolder(pathToAllureResult, pathToUploadDir);
                    findContainerJsonAndMoveToTempFolder(pathToUploadDir, updateHistory.get(ALLURE_TEST_ID));
                    pathToZipResults.put(updateHistory.get("runID"),
                                         zipFolderForUpload(pathToUploadDir, updateHistory.get(ALLURE_TEST_ID) + ".zip"));
                } else {
                    log.debug("ALM test ID not found. Skipping test");
                }
            } catch (IOException e) {
                log.error(e);
            }
        }

        if (!pathToZipResults.isEmpty()) {
            TlmContext.getInstance().getTlmManager().addAttachmentsToCompletedRun(pathToZipResults, "Allure Results");
        }
    }

    private String createTempFolderForResults(String allureResultsDir, String allureTestID) {
        String resultFolders = String.format("%s/%s/", allureTestID, "allure-results");
        File resultDir = new File(allureResultsDir, resultFolders);

        if (!resultDir.exists()) {
            resultDir.mkdirs();
        }

        return resultDir.getAbsolutePath();
    }

    private void findAllureFilesAndMoveToTempFolder(String pathToAllureResult,
                                                    String pathToUploadDir) {
        ReadContext testResultJsonFile = readJsonFile(pathToAllureResult);

        if (testResultJsonFile != null) {
            List<JSONArray> attachments = testResultJsonFile.read("$..attachments", List.class);

            for (JSONArray attachment : attachments) {
                if (attachment != null && !attachment.isEmpty()) {
                    moveAttachmentsToTempFolder(attachment, Reporter.getReportPath(), pathToUploadDir);
                }
            }
        }
    }

    private ReadContext readJsonFile(String pathToAllureResult) {
        if (pathToAllureResult != null) {
            try {
                return JsonPath.parse(new FileInputStream(new File(pathToAllureResult)));
            } catch (FileNotFoundException | NullPointerException | JsonSyntaxException e) {
                log.error(e.getMessage(), e);
                return null;
            }
        } else {
            return null;
        }
    }

    private void moveAttachmentsToTempFolder(JSONArray attachment, String pathToAllureResult, String pathToUploadDir) {
        for (Object attachmentObj : attachment) {
            Map<String, String> attachmentDetail = (Map) attachmentObj;

            log.debug("Including the {} attachment: {}", attachmentDetail.get("name"), attachmentDetail.get("source"));
            copyToUploadDir(pathToAllureResult, pathToUploadDir, attachmentDetail.get("source"));
        }
    }

    private void copyToUploadDir(String pathToAllureResult, String pathToUploadDir, String fileName) {
        String sourceFile = String.format("%s%s", pathToAllureResult, fileName);
        String targetFile = String.format("%s/%s", pathToUploadDir, fileName);
        copyFile(sourceFile, targetFile);
    }

    private void copyFile(String sourceFile, String targetDir) {
        try {
            Files.copy(Paths.get(sourceFile), Paths.get(targetDir), StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            log.error("Unable to copy file: {}", e.getMessage(), e);
        }
    }

    private void findContainerJsonAndMoveToTempFolder(String pathToUploadDir,
                                                      String allureTestID) {
        Set<String> reportJSONs = FileHelper.getMatchingFilesFromDirectory(Reporter.getReportPath(), ".json");
        List<String> containerJSONs = reportJSONs.stream()
                                                 .filter(fileName -> fileName.contains("container"))
                                                 .collect(Collectors.toList());

        String matchingContainerJson = findContainerJsonFile(allureTestID, containerJSONs);
        copyToUploadDir(Reporter.getReportPath(), pathToUploadDir, matchingContainerJson);
    }

    private String findContainerJsonFile(String allureTestID, List<String> containerJSONs) {
        for (String containerJSON : containerJSONs) {
            ReadContext containerJsonFile = readJsonFile(Reporter.getReportPath() + containerJSON);

            if (containerJsonFile != null) {
                List<JSONArray> children = containerJsonFile.read("$..children", List.class);
                if (!children.isEmpty()) {
                    final Optional<Object> matchingChild = children.get(0)
                                                                   .stream()
                                                                   .filter(entry -> entry.toString().equalsIgnoreCase(allureTestID))
                                                                   .findFirst();
                    if (matchingChild.isPresent()) {
                        return containerJSON;
                    }
                }
            }
        }

        return null;
    }

    private String zipFolderForUpload(String pathToUploadDir, String zipFileName) throws IOException {
        String zipFilePath = String.format("%s/%s", Paths.get(pathToUploadDir).getParent().toAbsolutePath().toString(), zipFileName);
        ZipHelper.zipit(pathToUploadDir, zipFilePath);

        log.debug("Zipped results folder path: {}", zipFilePath);
        return zipFilePath;
    }

}