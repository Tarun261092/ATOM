package automation.library.engine.core.runner;

import automation.library.common.PDFHelper;
import automation.library.common.Property;
import automation.library.common.TestContext;
import automation.library.engine.web.steps.AutoEngWebUtility;
import automation.library.leanft.core.desktop.DesktopScreenshot;
import automation.library.leanft.core.mainframe.MainframeScreenshot;
import automation.library.leanft.exec.DesktopContext;
import automation.library.selenium.core.Constants;
import automation.library.selenium.core.Element;
import automation.library.selenium.exec.driver.factory.DriverContext;
import cucumber.api.Result;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.openqa.selenium.TimeoutException;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static automation.library.engine.core.AutoEngConstants.*;
import static automation.library.reporting.Reporter.getScreenshotPath;
import static automation.library.selenium.core.Screenshot.grabScreenshot;
import static automation.library.selenium.core.Screenshot.saveScreenshot;
import static automation.library.tdaas.core.Constants.ERROR_RESPONSE;
import static cucumber.api.Result.Type.FAILED;
import static cucumber.api.Result.Type.PASSED;

public class ScreenshotHandler {
    private boolean waitForPageToLoad;
    private static final String ELEMENT_REF = "fw.elementRef";
    private static final String VALIDATES = "validates";
    private static final String SCROLLING_SCREENSHOT_FLAG = "fw.scrollingScreenshot";
    private Logger log = LogManager.getLogger(this.getClass().getName());

    public String addScreenshotToStep(String stepText, Result.Type status) {
        String screenshotPath = ERROR_RESPONSE;

        setWaitForPageLoad(stepText);

        if (stepExecuted(status) && !isStepRequiredScreenshot(stepText)) {
            if (Boolean.parseBoolean(System.getProperty("fw.screenshotOnEveryStep"))) {
                screenshotPath = takeScreenshot();
            } else if (isValidatonStep(stepText) &&
                       Boolean.parseBoolean(System.getProperty("fw.screenshotOnValidation"))) {
                screenshotPath = takeScreenshot();
            } else if ((status == FAILED || isSoftAssertionFailure(stepText)) &&
                       Boolean.parseBoolean(System.getProperty("fw.screenshotOnFailure"))) {
                System.setProperty("screenshotOnFailure", "true");
                screenshotPath = takeScreenshot();
            }
        }
        return screenshotPath;
    }

    private void setWaitForPageLoad(String stepText) {
        waitForPageToLoad = Boolean.parseBoolean(String.valueOf(TestContext.getInstance().testdataGet("fw.waitForPageLoad"))) &&
                            isStepRefreshRequired(stepText);

        if (Boolean.parseBoolean(Property.getProperties(Constants.SELENIUMRUNTIMEPATH).getString("scrollingScreenshot"))) {
            try {
                if (stepText.contains(VALIDATES)) {
                    System.setProperty(SCROLLING_SCREENSHOT_FLAG, "true");

                } else {
                    System.setProperty(SCROLLING_SCREENSHOT_FLAG, "false");
                }
            } catch (Exception e) {
                log.warn("Validate scrollingScreenshot flag in runtime.properties");
            }
        }

    }

    private boolean stepExecuted(Result.Type status) {
        return status == FAILED || status == PASSED;
    }

    private boolean isStepRequiredScreenshot(String stepText) {
        return (stepText.contains("pop up") || stepText.contains("closes the current browser") ||
                stepText.contains("pop-up"));
    }

    private boolean isValidatonStep(String stepText) {
        return stepText.contains(VALIDATES);
    }

    private boolean isStepRefreshRequired(String stepText) {
        List<String> criteria = new ArrayList<>();

        if (TestContext.getInstance().testdata().containsKey("fw.stepTextKeyRefresh")) {
            criteria = Arrays.asList(TestContext.getInstance()
                                                .testdataGet("fw.stepTextKeyRefresh")
                                                .toString()
                                                .split(","));
        }

        return stepText.contains(VALIDATES) || (criteria.stream().anyMatch(stepText::contains));
    }

    private boolean isSoftAssertionFailure(String stepText) {
        return stepText.contains("ContinueOnFailure") && !TestContext.getInstance().sa().wasSuccess();
    }

    private String takeScreenshot() {
        String screenshotPath = ERROR_RESPONSE;
        File file = null;

        String activeWindowType = TestContext.getInstance().getActiveWindowType();

        if (activeWindowType != null) {
            switch (activeWindowType) {
                case SELENIUM:
                    highlightActiveWebElement();
                    file = getWebScreenshot(file);
                    unhighlightActiveWebElement();
                    break;
                case MOBILE:
            		file = saveScreenshot(grabScreenshot(DriverContext.getInstance().getMobileDriver()), getScreenshotPath());
                    break;
                case LEANFT:
                case DESKTOP:
                    file = getLeanFTScreenshot(activeWindowType);
                    break;
                case PDF:
                    file = takePDFScreenShot(file);
                    break;
                default:
                    //other technologies; do not take screenshot
                    break;
            }
        }

        if (file != null && file.exists()) {
            screenshotPath = file.getAbsolutePath();
        }

        return screenshotPath;
    }
    
    private File getWebScreenshot(File file) {
    	if (waitForPageToLoad) {
            try {
                new AutoEngWebUtility().theUserWaitsForThePageToLoad();

            } catch (TimeoutException e) {
                log.debug("Wait for page load failed");
            }
        }    	
    	if (DriverContext.getInstance().isMobileDriverRunning() && Boolean.parseBoolean(System.getProperty("fw.mobileWebAutomation"))) {            
    		file = saveScreenshot(grabScreenshot(DriverContext.getInstance().getMobileDriver()), getScreenshotPath());
        } else if (DriverContext.getInstance().isDriverRunning()) {
        	file = saveScreenshot(grabScreenshot(DriverContext.getInstance().getDriver()), getScreenshotPath());            
        }
        return file;
    }

    private File getLeanFTScreenshot(String activeWindowType) {
        if (activeWindowType.equalsIgnoreCase(LEANFT) &&
            DesktopContext.getInstance().getCurrentLeanFTScreen() != null) {
            return saveScreenshot(MainframeScreenshot.grabScreenshot(DesktopContext.getInstance().getCurrentLeanFTScreen()),
                                  getScreenshotPath());
        } else if (activeWindowType.equalsIgnoreCase(DESKTOP)) {
            return saveScreenshot(DesktopScreenshot.grabScreenshot(), getScreenshotPath());
        }

        return null;
    }

    private File takePDFScreenShot(File file) {
        Integer pgNum = 0;
        Integer pgNumStart = 0;
        Integer pgNumEnd = 0;

        if (TestContext.getInstance().testdataGet("fw.activePDF") != null) {
            pgNum = TestContext.getInstance().testdataToClass("fw.PDFCurrentPageNumber", Integer.class);
            pgNumStart = TestContext.getInstance().testdataToClass("fw.PDFPageNumStart", Integer.class);
            pgNumEnd = TestContext.getInstance().testdataToClass("fw.PDFPageNumEnd", Integer.class);
            PDDocument activePDF = TestContext.getInstance().testdataToClass("fw.activePDF", PDDocument.class);

            if (pgNum == -1) {
                List<File> pdfDocAsList = PDFHelper.takeScreenshotOfFullDoc(activePDF, getScreenshotPath());
                file = PDFHelper.combinePDFPageScreenshotsIntoOne(activePDF, pdfDocAsList, getScreenshotPath());
            } else if (pgNum >= 1) {
                file = PDFHelper.takeScreenshotOfPage(activePDF, getScreenshotPath(), pgNum);
            } else if (pgNumStart != null && pgNumStart >= 1 && pgNumEnd != null && pgNumEnd >= 1) {
                List<File> pdfDocAsList = PDFHelper.takeScreenshotInBetweenPagesOfDoc(activePDF, getScreenshotPath(), pgNumStart, pgNumEnd);
                file = PDFHelper.combinePDFPageScreenshotsIntoOne(activePDF, pdfDocAsList, getScreenshotPath());
            }
        }

        return file;
    }

    private void highlightActiveWebElement() {
        if (Boolean.parseBoolean(System.getProperty("fw.highlightElementOnScreenshot"))) {
            Object ob = TestContext.getInstance().testdataGet(ELEMENT_REF);
            if (ob instanceof List) {
                List<Element> ele = (List<Element>) ob;
                if (!ele.isEmpty()) ele.forEach(Element::highlight);
            } else if (ob instanceof Element) {
                ((Element) ob).highlight();
            }
        }
    }

    private void unhighlightActiveWebElement() {
        if (Boolean.parseBoolean(System.getProperty("fw.highlightElementOnScreenshot"))) {
            Object ob = TestContext.getInstance().testdataGet(ELEMENT_REF);
            if (ob instanceof List) {
                List<Element> ele = (List<Element>) ob;
                if (!ele.isEmpty()) ele.forEach(Element::unhighlight);
            } else if (ob instanceof Element) {
                ((Element) ob).unhighlight();
            }
        }
        TestContext.getInstance().testdata().remove(ELEMENT_REF);
    }

}
