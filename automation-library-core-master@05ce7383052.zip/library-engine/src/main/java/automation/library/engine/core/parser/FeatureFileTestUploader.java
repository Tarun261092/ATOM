package automation.library.engine.core.parser;

import automation.library.engine.core.parser.maps.ScenarioMap;
import automation.library.tlm.TlmContext;
import automation.library.tlm.common.entity.FeaturePayload;
import automation.library.tlm.common.entity.TlmRunStep;
import cucumber.util.FixJava;
import gherkin.AstBuilder;
import gherkin.Parser;
import gherkin.TokenMatcher;
import gherkin.ast.*;
import org.testng.annotations.Test;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class FeatureFileTestUploader extends FeatureFileParser {
    protected Parser<GherkinDocument> parser = new Parser<>(new AstBuilder());
    protected TokenMatcher matcher = new TokenMatcher();
    private static final String FILEPATH = "\\src\\test\\resources\\features";
    private static final String FILEPATH2 = "\\src\\test\\resources\\features\\";
    private static final String FOLDERPATH = System.getProperty("user.dir");

    @Test
    public void uploadTestsInFeatureFile() {
        String fileName = System.getProperty("fw.featureFileName");
        File folder = new File(FOLDERPATH + FILEPATH);
        List<File> ftrFiles = new ArrayList<>();

        if (!fileName.equals("All")) {
            ftrFiles.add(new File(FOLDERPATH + FILEPATH2 + fileName + ".feature"));
        } else {
            ftrFiles.addAll(Arrays.asList(Objects.requireNonNull(folder.listFiles())));
        }
        for (File fil : ftrFiles) {
            if (fil.getName().endsWith(FEATURE)) {
                modifyFeatureFile(fil.getAbsolutePath(), getScenarioNameAndSteps(fil));
            }
        }

    }

    private List<FeaturePayload> getScenarioNameAndSteps(File file) {
        List<FeaturePayload> pldLst = new ArrayList<>();
        List<TlmRunStep> steps = new ArrayList<>();
        StepDefParser stepDefParser = new StepDefParser();
        TlmContext.getInstance().getTlmManager().loadDefaultExpectedResults();

        if (file.getName().endsWith(".feature")) {
            String gherkin;
            try {
                gherkin = FixJava.readReader(new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8));
                GherkinDocument d3 = parser.parse(gherkin, matcher);
                Feature feature = d3.getFeature();
                List<ScenarioDefinition> parts = feature.getChildren();
                for (ScenarioDefinition sd : parts) {
                    FeaturePayload payload = new FeaturePayload();
                    List<String> tags = getScenarioLabels(sd);
                    payload.setScenarioTag(String.valueOf(tags));
                    payload.setScenarioName(getScenarioName(sd));
                    payload.setDescription(sd.getDescription());

                    for (Step s : sd.getSteps()) {
                        steps.add(new TlmRunStep(String.format("    %s%s%s", s.getKeyword(), s.getText(), System.lineSeparator()),
                                                 "No Run",
                                                 getExpectedResult(stepDefParser, s.getText()),
                                                 "N/A"));
                    }
                    payload.setSteps(steps);
                    pldLst.add(payload);
                }

            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        }
        return pldLst;
    }

    private String getExpectedResult(StepDefParser stepDefParser, String stepDescription) {
        Map<String, List<String>> matchingStepDef = stepDefParser.getAnnotationsMap()
                                                                 .entrySet()
                                                                 .stream().collect(Collectors.toMap(Map.Entry::getKey,
                                                                                                    stepDef -> stepDef.getValue()
                                                                                                                      .stream()
                                                                                                                      .filter(stepDescription::matches)
                                                                                                                      .collect(Collectors.toList())))
                                                                 .entrySet()
                                                                 .stream()
                                                                 .filter(entry -> !entry.getValue().isEmpty())
                                                                 .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
        if(!matchingStepDef.isEmpty()) {
           return TlmContext.getInstance()
                            .getTlmManager()
                            .lookupDefaultExpectedResult(new ArrayList<>(matchingStepDef.keySet()).get(0));
        } else {
            return "";
        }
    }

    private String getScenarioName(ScenarioDefinition sd) {
        String scenarioName = null;

        if (sd instanceof Scenario) {
            scenarioName = ((Scenario) sd).getName();
        } else if (sd instanceof ScenarioOutline) {
            scenarioName = ((ScenarioOutline) sd).getName();
        }
        return scenarioName;
    }

    private void modifyFeatureFile(String filePath, List<FeaturePayload> pldLst) {
        Path path = Paths.get(filePath);

        try {
            final String tlmTag = TlmContext.getInstance().getTlmManager().getTagPrefix();
            List<String> featureText = Files.readAllLines(path);
            List<ScenarioMap> scenarioMapLst = new ArrayList<>();

            int featureLineNo = 0;
            int currentPosition = 0;
            int tagindex = 0;

            for (String currentLine : featureText) {
                currentPosition++;

                if (currentLine.contains("Feature:")) {
                    featureLineNo = currentPosition;
                } else if (isStartOfScenario(tlmTag, featureLineNo, currentLine)) {
                    tagindex++;

                    String testId = TlmContext.getInstance().getTlmManager().addTestAndStepsToTLMTool(pldLst.get(tagindex - 1));
                    log.info("Added test with test ID: @{}{}", tlmTag, testId);

                    ScenarioMap scnMap = new ScenarioMap();
                    scnMap.setScnVal(replaceOrAddTLMTag(currentLine, tlmTag, testId));
                    scnMap.setLineNo(currentPosition);
                    scenarioMapLst.add(scnMap);
                }
            }

            for (ScenarioMap scenarioMap : scenarioMapLst) {
                featureText.set(scenarioMap.getLineNo() - 1, scenarioMap.getScnVal());
            }

            Files.write(path, featureText, StandardCharsets.UTF_8);

        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    private boolean isStartOfScenario(String tlmTag, int featureLineNo, String currentLine) {
        return featureLineNo != 0 &&
               lineContainsTags(currentLine) &&
               scenarioDoesNotHaveTLMTag(currentLine, tlmTag);
    }

    private String replaceOrAddTLMTag(String currentLine, String tlmTag, String testId) {
        Matcher stepMatcher = Pattern.compile(String.format("(?i).*(@%s[a-zA-Z0-9_-]+|@%s)\\s*", tlmTag, tlmTag))
                                     .matcher(currentLine);
        final String newTag = String.format("@%s%s", tlmTag, testId);

        if (stepMatcher.find()) {
            return currentLine.replace(stepMatcher.group(1), newTag);
        } else {
            return currentLine + " " + newTag;
        }
    }

    private boolean scenarioDoesNotHaveTLMTag(String currentLine, String tlmTag) {
        Matcher stepMatcher = Pattern.compile(String.format("(?i).*@%s[a-zA-Z0-9_-]+\\s*", tlmTag)).matcher(currentLine);

        if(stepMatcher.find()) {
            log.info("Test already has tag. Skipping test. Current tags: {}", currentLine);
            return false;
        } else {
            return true;
        }
    }

    private boolean lineContainsTags(String currentLine) {
        Matcher stepMatcher = Pattern.compile("^\\s*@").matcher(currentLine);
        return stepMatcher.find();
    }
}
