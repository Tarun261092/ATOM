package automation.library.engine.api.steps;

import automation.library.api.kafka.KafkaHandler;
import automation.library.common.StringHelper;
import automation.library.common.TestContext;
import automation.library.engine.api.BaseAPISteps;
import com.google.gson.Gson;
import io.cucumber.java.en.When;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class AutoEngKafka extends BaseAPISteps {

    private static final String NO_MESSAGES_FOUND = "No messages found";
    private static final String MESSAGE_PAYLOAD = "Message Payload";

    @When("^subscribe to the \"([^\"]*)\" Kafka topic")
    public void subscribeToKafkaTopic(String topicNameLogical) throws Exception {
        subscribeToKafkaTopicWithTwoFilters(topicNameLogical, null, null);
    }

    @When("^subscribe to the \"([^\"]*)\" Kafka topic where body contains \"([^\"]*)\"$")
    public void subscribeToKafkaTopicWithOneFilter(String topicNameLogical,
                                                   String attributeValue) throws Exception {
        subscribeToKafkaTopicWithTwoFilters(topicNameLogical, attributeValue, null);
    }

    @When("^subscribe to the \"([^\"]*)\" Kafka topic where body contains \"([^\"]*)\" and \"([^\"]*)\"$")
    public void subscribeToKafkaTopicWithTwoFilters(String topicNameLogical,
                                                    String attributeValue,
                                                    String attributeValue2) throws Exception {
        final String scenarioName = StringHelper.removeSpecialChars(String.valueOf(TestContext.getInstance()
                                                                                              .testdataGet("fw.scenarioName")))
                                                .toLowerCase();
        final String topicNameActual = getActualKafkaTopicName(topicNameLogical);
        final String attributeValToUse = attributeValue == null ? null : parseValue(attributeValue);
        final String attributeValToUse2 = attributeValue2 == null ? null : parseValue(attributeValue2);

        KafkaHandler kafkaHandler = getNewOrActiveKafkaHandler(scenarioName);
        final boolean subscribed = kafkaHandler.subscribeToTopic(topicNameActual,
                                                                 attributeValToUse,
                                                                 attributeValToUse2);

        if (subscribed) {
            TestContext.getInstance().testdataPut(TOPIC_KEY, kafkaHandler);
            logStepMessage("Subscribed to topic: " + topicNameActual);
        }

    }

    @When("^the user sends message \"([^\"]*)\" to the \"([^\"]*)\" Kafka topic")
    public void theUserSendsMsgToKafkaTopic(String msgToSend, String topicNameLogical) throws IOException {
        theUserSendsMsgWithHeadersToKafkaTopic(msgToSend, null, topicNameLogical);
    }

    @When("^the user sends message \"([^\"]*)\" with headers \"([^\"]*)\" to the \"([^\"]*)\" Kafka topic")
    public void theUserSendsMsgWithHeadersToKafkaTopic(String msgToSend,
                                                       String headerObject,
                                                       String topicNameLogical) throws IOException {
        final String scenarioName = StringHelper.removeSpecialChars(String.valueOf(TestContext.getInstance()
                                                                                              .testdataGet("fw.scenarioName")))
                                                .toLowerCase();
        final String topicNameActual = getActualKafkaTopicName(topicNameLogical);
        final KafkaHandler kafkaHandler = getNewOrActiveKafkaHandler(scenarioName);
        final Map<String, Object> kafkaHeaders = getKafkaHeaders(headerObject);
        final Object msgToSendPayload = getKafkaPayload(parseValue(msgToSend));

        final boolean msgSentToTopic = kafkaHandler.sendMessageToTopic(topicNameActual,
                                                                       kafkaHeaders,
                                                                       new Gson().toJson(msgToSendPayload));
        if(msgSentToTopic) {
            logAndReportJSON("Sent Message", msgToSendPayload);
        }

        if (TestContext.getInstance().testdataGet(TOPIC_KEY) == null) {
            TestContext.getInstance().testdataPut(TOPIC_KEY, kafkaHandler);
        }
    }

    @When("^the user adds Kafka message header with key \"([^\"]*)\" and value \"([^\"]*)\"")
    public void theUserSendsMsgWithHeadersToKafkaTopic(String headerKey,
                                                       String headerValue) {

        Map<String, Object> kafkaHeaderMap = getKafkaHeaderObject();
        kafkaHeaderMap.put(parseValue(headerKey), parseValue(headerValue));
        TestContext.getInstance().testdataPut(FW_KAFKA_HEADER_MAP, kafkaHeaderMap);
    }

    @When("^store full list of messages received from the \"([^\"]*)\" Kafka topic into data dictionary key \"([^\"]*)\"")
    public void theUserStoresFullListOfMessagesFromKafkaTopic(String topicNameLogical,
                                                              String dictionaryKey) {
        final KafkaHandler kafkaHandler = getActiveKafkaHandler();
        final String topicNameActual = getActualKafkaTopicName(topicNameLogical);
        final List<Object> messages = kafkaHandler.saveListOfMessagesFromEndPoint(topicNameActual);

        if (!messages.isEmpty()) {
            TestContext.getInstance().testdataPut(parseDictionaryKey(dictionaryKey),
                                                  messages);
            logAndReportJSON(MESSAGE_PAYLOAD, messages);
        } else {
            logStepMessage(NO_MESSAGES_FOUND);
        }
    }

    @When("^store last message received from the \"([^\"]*)\" Kafka topic into data dictionary key \"([^\"]*)\"")
    public void theUserStoresLastMessageFromKafkaTopic(String topicNameLogical,
                                                       String dictionaryKey) {
        final KafkaHandler kafkaHandler = getActiveKafkaHandler();
        final String topicNameActual = getActualKafkaTopicName(topicNameLogical);
        final List<Object> messages = kafkaHandler.saveListOfMessagesFromEndPoint(topicNameActual);

        if (!messages.isEmpty()) {
            TestContext.getInstance().testdataPut(parseDictionaryKey(dictionaryKey),
                                                  messages.get(messages.size() - 1));
            logAndReportJSON(MESSAGE_PAYLOAD, messages.get(messages.size() - 1));
        } else {
            logStepMessage(NO_MESSAGES_FOUND);
        }
    }

    @When("^store message received from the \"([^\"]*)\" Kafka topic where \"([^\"]*)\" is \"([^\"]*)\" \"([^\"]*)\" into data dictionary key \"([^\"]*)\"")
    public void theUserStoresMessageFromKafkaTopicThatMatchesFilter(String topicNameLogical,
                                                                    String attributeName,
                                                                    String comparisonOperator,
                                                                    String attributeValue,
                                                                    String dictionaryKey) {

        theUserStoresMessageFromKafkaTopicThatMatchesTwoFilters(topicNameLogical,
                                                                attributeName,
                                                                comparisonOperator,
                                                                attributeValue,
                                                                null,
                                                                null,
                                                                null,
                                                                dictionaryKey);

    }

    @When("^store message received from the \"([^\"]*)\" Kafka topic where \"([^\"]*)\" is \"([^\"]*)\" \"([^\"]*)\" and \"([^\"]*)\" is \"([^\"]*)\" \"([^\"]*)\" into data dictionary key \"([^\"]*)\"")
    public void theUserStoresMessageFromKafkaTopicThatMatchesTwoFilters(String topicNameLogical,
                                                                        String attributeName,
                                                                        String comparisonOperator,
                                                                        String attributeValue,
                                                                        String attributeName2,
                                                                        String comparisonOperator2,
                                                                        String attributeValue2,
                                                                        String dictionaryKey) {

        final KafkaHandler kafkaHandler = getActiveKafkaHandler();
        final String topicNameActual = getActualKafkaTopicName(topicNameLogical);
        final String attributeVal = parseValue(attributeValue);
        final String attributeVal2 = attributeValue2 != null ? parseValue(attributeValue2) : null;

        final List<Object> matchingMessages = kafkaHandler.saveListOfMessagesFromEndPoint(topicNameActual, attributeVal, attributeVal2)
                                                          .stream()
                                                          .filter(message -> jsonHasMatchingAttribute(message,
                                                                                                      attributeName,
                                                                                                      attributeVal,
                                                                                                      comparisonOperator,
                                                                                                      attributeName2,
                                                                                                      attributeVal2,
                                                                                                      comparisonOperator2))
                                                          .collect(Collectors.toList());

        if (matchingMessages.isEmpty()) {
            logStepMessage(NO_MESSAGES_FOUND);
        } else {
            if (matchingMessages.size() > 1) {
                log.warn("Found more than one match. Storing first matching message");
            }

            TestContext.getInstance().testdataPut(parseDictionaryKey(dictionaryKey),
                                                  matchingMessages.get(0));
            logAndReportJSON(MESSAGE_PAYLOAD, matchingMessages.get(0));
        }

    }

    @When("^unsubscribe to the \"([^\"]*)\" Kafka topic")
    public void unSubscribesToKafkaTopic(String topicNameLogical) throws Exception {

        final String topicNameActual = getActualKafkaTopicName(topicNameLogical);
        KafkaHandler kafkaHandler = getActiveKafkaHandler();
        kafkaHandler.unsubscribe(topicNameActual);
    }

}
