package automation.library.engine.core;

import static automation.library.common.FileHelper.getPropertiesAsMap;
import static automation.library.cucumber.core.Constants.ENVIRONMENTPATH;
import static automation.library.db.core.Constants.DBRUNTIMEPATH;
import static automation.library.engine.core.BaseStepsEngine.ENV_PROP;
import static automation.library.engine.core.BaseStepsEngine.PROPERTIES_EXT;
import static automation.library.leanft.core.Constants.LEANFTPROPERTIESPATH;
import static automation.library.leanft.core.Constants.LEANFTRUNTIMEPATH;
import static automation.library.selenium.core.Constants.SELENIUMRUNTIMEPATH;
import static automation.library.tlm.common.TlmConstants.TLM_PROPERTIES_FILE_PATH;
import static automation.library.tlm.common.enums.AttachmentType.CONSOLE_LOG;
import static automation.library.tlm.common.enums.AttachmentType.DATA_TABLE;
import static automation.library.tlm.common.enums.AttachmentType.FILE;
import static automation.library.tlm.common.enums.AttachmentType.VALIDATIONS;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.configuration2.PropertiesConfiguration;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.google.gson.Gson;

import automation.library.common.DataTableFormatter;
import automation.library.common.FileHelper;
import automation.library.common.JSONHelper;
import automation.library.common.Property;
import automation.library.common.TestContext;
import automation.library.cucumber.core.Constants;
import automation.library.cyara.core.CyaraContext;
import automation.library.engine.core.dataspec.DataSpecHelper;
import automation.library.reporting.Reporter;
import automation.library.tdaas.core.dataspec.common.CommonUtils;
import automation.library.tdaas.core.dataspec.tdaas.DataRetrievalClient;
import automation.library.tlm.TlmContext;
import automation.library.tlm.common.TLMException;
import automation.library.tlm.common.TlmConstants;
import automation.library.tlm.common.entity.TlmAttachment;
import io.cucumber.core.api.Scenario;
import io.cucumber.java8.En;

public class AutoEngHooks implements En {

    protected final Logger log = LogManager.getLogger(AutoEngHooks.class);
    private String jenkinsLabel = Property.getVariable("label");

    public AutoEngHooks() {
        Before(15, (Scenario scenario) -> {
            TlmContext.getInstance().setUpdateFlag(scenario);

            //add test data to current thread
            List<Map<String, Object>> dataPermutations = new DataSpecHelper().processDataSpec(scenario.getName());
            if (!dataPermutations.isEmpty()) {
                Map<String, Object> dataRow = dataPermutations.get(0);
                dataRow.forEach((dataItem, val) -> TestContext.getInstance().testdataPut(dataItem, val));
            }

            String multiDayFlag = Property.getProperty(Constants.ALMPROPERTIESPATH, "enableMultiDayInput");
          
            
            if(Boolean.parseBoolean(multiDayFlag))
            	loadDataFromPriorRun(scenario);
            else
            	log.info("Using current data only for flow. MultiDay Flag Disabled.");
            
            FileHelper.loadDataParametersFromPropsFile(ENVIRONMENTPATH + Property.getVariable(ENV_PROP) + PROPERTIES_EXT,
                                                       "data");

            log.info(String.format("****************library.engine.version: %s ****************",
                                   FileHelper.getLibraryEngineVersion()));

            logRunSpecificWarnings();

        });

        After(15, (Scenario scenario) -> {
            log.info(DataTableFormatter.getDataDictionaryAsFormattedTable());

            logPropertiesContents();

            if (jenkinsLabel != null)
                Reporter.addLink(jenkinsLabel, automation.library.cucumber.core.Constants.WATCHPOST);

            Reporter.startFinalStep(scenario.isFailed());
            List<TlmAttachment> attachmentList = addTestLevelAttachmentsToReport();
            addLinkToCyaraReport();
            Reporter.stopFinalStep();

            TlmContext.getInstance().updateStatus(scenario, attachmentList);

            writeHistoryObjectToFile();

            checkOnTestDataUnblock(scenario);

            TestContext.getInstance().testdata().clear();
            TlmContext.removeInstance();
        });
    }

    private List<TlmAttachment> addTestLevelAttachmentsToReport() throws IOException {
        List<TlmAttachment> tlmAttachments = new ArrayList<>();

        tlmAttachments.add(new TlmAttachment(DATA_TABLE, prepAndAddDataTable()));
        tlmAttachments.add(new TlmAttachment(VALIDATIONS, prepAndAddValidationsTable()));
        tlmAttachments.add(new TlmAttachment(CONSOLE_LOG, prepAndAddConsoleLog()));
        if(TestContext.getInstance().testdataGet("fw.filePath")!=null)
            tlmAttachments.add(new TlmAttachment(FILE, prepAndAddFile()));
		
        if(TestContext.getInstance().testdataGet("fw.excelPath")!=null) {
        	if(TestContext.getInstance().testdataGet("fw.excelPath") instanceof List) {
        		List<String> fileList  = (List<String>) TestContext.getInstance().testdataGet("fw.excelPath");
        		for (String path : fileList) {
                	tlmAttachments.add(new TlmAttachment(FILE,attachExcelSheetPath(path)));
				}
        	}else if(TestContext.getInstance().testdataGet("fw.excelPath") instanceof String) {

            	tlmAttachments.add(new TlmAttachment(FILE,attachexcelsheet("fw.excelPath")));	
        	}
        }
        return tlmAttachments;
    }
    private String attachexcelsheet(String key) throws FileNotFoundException
    {
    	   final String filePath = (String)TestContext.getInstance().testdataGet(key);
    	   attachExcelSheetPath(filePath);
    	return filePath;
    }
    private String attachExcelSheetPath(String path) throws FileNotFoundException
    {
    	String fileExt =  path.substring(path.indexOf('.'), path.length()).trim();
		    InputStream is =   new FileInputStream(path);
        	 Reporter. addAttachment(FILE.name(), is,fileExt);
    	return path;
    }
    private String prepAndAddFile() throws IOException {
        final String filePath = TestContext.getInstance().testdataGet("fw.filePath").toString();

        Reporter.addTextLogContent(FILE.getAttachmentName(),
                FileHelper.getFileAsString(filePath, "\n"));

        return filePath;
    }

    private String prepAndAddDataTable() {
        final String dataTableFileName = Reporter.addDataTable(DATA_TABLE.getAttachmentName(),
                                                               DataTableFormatter.getFilteredDataTableAsMap());

        addPriorDataTablesToReport();

        Map<String, Object> dataTableMap = DataTableFormatter.getFilteredPriorDataTableAsMap().entrySet().stream()
                                                             .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
        dataTableMap.put("lastRun", DataTableFormatter.getFilteredDataTableAsMap());

        return JSONHelper.convertMapToJSON(dataTableMap,
                                           getJSONFileName(Reporter.getReportPath(), dataTableFileName));
    }

    private String prepAndAddValidationsTable() {
        String validationTableFileName = Reporter.addDataTable(VALIDATIONS.getAttachmentName(),
                                                               DataTableFormatter.getValidationTableAsMap());

        return JSONHelper.convertMapToJSON(DataTableFormatter.getValidationTableAsMap(),
                                           getJSONFileName(Reporter.getReportPath(), validationTableFileName));
    }

    private String prepAndAddConsoleLog() throws IOException {
        final String consoleLogPath = getPathToLogFile();
        Reporter.addTextLogContent(CONSOLE_LOG.getAttachmentName(),
                                   FileHelper.getFileAsString(consoleLogPath, "\n"));

        return consoleLogPath;
    }

    private void addPriorDataTablesToReport() {
        if (TestContext.getInstance().testdataGet("fw.priorData") != null) {
            List<Map<String, Object>> priorRunData = TestContext.getInstance().testdataToClass("fw.priorData", List.class);
            final int[] idx = {1};
            priorRunData.forEach(entry -> Reporter.addDataTable("Prior Run: Test Data Table - Step " + idx[0]++, entry));
        }
    }

    private String getPathToLogFile() {
        if (TestContext.getInstance().testdataGet("fw.logFileName") != null) {
            return FileHelper.findFileInPath(Constants.LOGPATH,
                                             TestContext.getInstance().testdataGet("fw.logFileName").toString() + ".log");
        } else {
            return FileHelper.findFileInPath(Constants.LOGPATH, "default.log");
        }
    }

    private String getJSONFileName(String reportPath, String dataTableFileName) {
        return String.format("%s%s.json", reportPath, FileHelper.getFileNameWithoutExtension(dataTableFileName));
    }

    private void logRunSpecificWarnings() {
        if (!getPropertiesAsMap(SELENIUMRUNTIMEPATH).isEmpty()) {
            if (Boolean.parseBoolean(getPropertiesAsMap(SELENIUMRUNTIMEPATH).get("screenshotOnEveryStep"))) {
                log.info("****************Screenshot On Every Step is enabled**************");
                log.info("Screenshot on every step is enabled, there could be issues with navigation related screenshots.");
            }
            if (Boolean.parseBoolean(getPropertiesAsMap(SELENIUMRUNTIMEPATH).get("executeAXEPerStep"))) {
                log.info("*****************ADA flag is enabled********************");
                log.info("ADA test will be performed as User has enabled Accessibility test flag");
            }
        }
    }

    private void logPropertiesContents() {
        if (!getPropertiesAsMap(SELENIUMRUNTIMEPATH).isEmpty())
            log.info("Selenium Properties: {}",
                     () -> DataTableFormatter.getPropertiesAsFormattedTable(getPropertiesAsMap(SELENIUMRUNTIMEPATH)));
        if (!getPropertiesAsMap(TLM_PROPERTIES_FILE_PATH).isEmpty())
            log.info("TLM Properties: {}",
                     () -> DataTableFormatter.getPropertiesAsFormattedTable(getPropertiesAsMap(TLM_PROPERTIES_FILE_PATH)));
        if (!getPropertiesAsMap(LEANFTRUNTIMEPATH).isEmpty())
            log.info("LeanFT Runtime Properties: {}",
                     () -> DataTableFormatter.getPropertiesAsFormattedTable(getPropertiesAsMap(LEANFTRUNTIMEPATH)));
        if (!getPropertiesAsMap(LEANFTPROPERTIESPATH).isEmpty())
            log.info("LeanFT Properties: {}",
                     () -> DataTableFormatter.getPropertiesAsFormattedTable(getPropertiesAsMap(LEANFTPROPERTIESPATH)));
        if (!getPropertiesAsMap(DBRUNTIMEPATH).isEmpty())
            log.info("DB Properties: {}",
                     () -> DataTableFormatter.getPropertiesAsFormattedTable(getPropertiesAsMap(DBRUNTIMEPATH)));
    }

    private void addLinkToCyaraReport() {
        if (Boolean.parseBoolean((String) TestContext.getInstance().testdataGet("fw.cyaraRunning")) &&
            getCyaraReportURL() != null) {
            Reporter.addLink("Cyara Inbound Test Run Report", getCyaraReportURL());
        }
        if (Boolean.parseBoolean((String) TestContext.getInstance().testdataGet("fw.cyaraOBRunning"))) {
            Reporter.addLink("Cyara Outbound Test Run Report", getCyaraOutboundReportURL());
        }
    }

    private void checkOnTestDataUnblock(Scenario scenario) {
        if (TestContext.getInstance().testdataGet("fw.dataConsumed") != null &&
            TestContext.getInstance().testdataGet("TDaaSUnblockURL") != null &&
            TlmContext.getInstance().getTestStatus(scenario).equalsIgnoreCase("Passed")) {

            final boolean dataConsumed = Boolean.parseBoolean(TestContext.getInstance().testdataGet("fw.dataConsumed").toString());
            final String requestID = Paths.get(String.valueOf(TestContext.getInstance().testdataGet("TDaaSUnblockURL")))
                                          .getFileName()
                                          .toString();

            if (dataConsumed) {
                log.debug("Attempting to unblock data in TDaaS...");
                new DataRetrievalClient(CommonUtils.getTDaaSClient()).unblockDataInTDaaS(requestID);
            }
        }
    }

    private String getCyaraReportURL() {
        PropertiesConfiguration cyaraProps = Property.getProperties(Constants.RUNTIMEPATH);
        final String testResultId = CyaraContext.getInstance().getTestResultID();

        if (cyaraProps != null && testResultId != null) {
            final String accountId = cyaraProps.getString("accountId");
            final String cyaraBaseURL = cyaraProps.getString("CyaraURL");
            return cyaraBaseURL + "/" + accountId + "/Report/ResultDetails?testResultId=" + testResultId + "&MediaType=Voice";
        }
        return null;
    }

    private String getCyaraOutboundReportURL() {
        PropertiesConfiguration cyaraProps = Property.getProperties(Constants.RUNTIMEPATH);

        if (cyaraProps != null) {
            final String accountId = cyaraProps.getString("accountId");
            final String cyaraBaseURL = cyaraProps.getString("CyaraURL");
            return cyaraBaseURL + "/" + accountId + "/report/ResultsSummary";
        }
        return null;
    }

    private void loadDataFromPriorRun(Scenario scenario) {
        final Collection<String> scenarioTags = scenario.getSourceTagNames();

        try {
            Map<String, Object> preBatchDataPermutations = new DataSpecHelper().processPreBatchDataSpec(getPriorDataRunFlowKey(scenarioTags));
            preBatchDataPermutations.forEach((dataItem, val) -> TestContext.getInstance().testdataPut(dataItem, val));
        } catch (TLMException e) {
            log.info(e.getMessage());
        }
    }

    private String getPriorDataRunFlowKey(Collection<String> scenarioTags) {
        final String flowName = parseFlowTag(scenarioTags, "Flow_");
        final int flowNum = Integer.parseInt(parseFlowTag(scenarioTags, "FlowStep_"));

        if (flowNum > 1)
            return String.format("%s_%s", flowName, flowNum - 1);
        else
            throw new TLMException("First step in flow. Using current data");
    }

    private String parseFlowTag(Collection<String> scenarioTags, String tagPrefix) {
        Optional<String> matchingTag = scenarioTags.stream()
                                                   .sorted()
                                                   .filter(tag -> tag.contains(tagPrefix))
                                                   .findFirst();

        if (matchingTag.isPresent()) {
            List<String> tagParts = Arrays.asList(matchingTag.get().split("_"));
            if (tagParts.size() > 1) {
                return tagParts.get(1);
            }
        }

        throw new TLMException("Using current data only for flow. No prior run data");
    }

    private void writeHistoryObjectToFile() {
        Map<String, String> updateHistory = TestContext.getInstance().testdataToClass("fw.updateHistory", Map.class);

        if (updateHistory != null) {
            File updateDirectory = new File(TlmConstants.TLM_HISTORY_PATH);
            if (!updateDirectory.exists()) {
                updateDirectory.mkdir();
            }

            String pathToHistory = TlmConstants.TLM_HISTORY_PATH + updateHistory.get("allureTestID") + ".json";
            try (FileWriter jsonWriter = new FileWriter(pathToHistory)) {
                new Gson().toJson(updateHistory, jsonWriter);
            } catch (IOException e) {
                log.error(e);
            }
        }
    }
}
