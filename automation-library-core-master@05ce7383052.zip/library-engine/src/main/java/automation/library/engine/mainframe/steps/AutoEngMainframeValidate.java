package automation.library.engine.mainframe.steps;

import automation.library.common.TestContext;
import automation.library.engine.core.validator.AssertHelper;
import automation.library.engine.core.validator.ComparisonOperator;
import automation.library.engine.core.validator.ComparisonType;
import automation.library.engine.mainframe.BaseMFSteps;
import automation.library.leanft.core.mainframe.LeanFTField;
import automation.library.leanft.core.mainframe.LeanFTTable;
import automation.library.leanft.exec.DesktopContext;
import automation.library.reporting.Reporter;
import com.hp.lft.sdk.GeneralLeanFtException;
import io.cucumber.java.en.Then;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

public class AutoEngMainframeValidate extends BaseMFSteps {

    private static final String HARD_STOP_ON_FAILURE = "HardStopOnFailure";
    private static final String VALIDATION_TAG = "VALIDATION.";
    private static final String STATUS_FAIL = "FAIL";
    private static final String VALIDATION_FAILED = "Validation Failed: ";

    @Then("^the user validates \"([^\"]*)\" that the value of the \"([^\"]*)\" field on the \"([^\"]*)\" TE screen is \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void theUserValidatesThatTheValueOfTheFieldOnTheTEScreenIs(String comparisonType,
                                                                      String fieldName,
                                                                      String screenName,
                                                                      String comparisonOperator,
                                                                      String expectedValue,
                                                                      String validationID,
                                                                      String onFailureFlag) throws GeneralLeanFtException {
        DesktopContext.getInstance().setCurrentLeanFTScreen(getMainframeScreen(screenName));
        String actualValue = getValueFromField(fieldName, screenName);
        expectedValue = parseValue(expectedValue);

        AssertHelper validator = new AssertHelper(comparisonType, comparisonOperator, onFailureFlag);
        validator.performValidation(actualValue, expectedValue,
                                    validationID,
                                    String.format("'%s' field value validation on the TE screen", fieldName));
    }

    @Then("^the user validates that the value \"([^\"]*)\" is not present in the \"([^\"]*)\" field on the \"([^\"]*)\" TE screen  \"([^\"]*)\" \"([^\"]*)\"$")
    public void theUserValidatesThatTheValueIsNotPresentInTheFieldOnTheTEScreen(String expectedValue,
                                                                                String fieldName,
                                                                                String screenName,
                                                                                String validationID,
                                                                                String onFailureFlag) throws GeneralLeanFtException {
        DesktopContext.getInstance().setCurrentLeanFTScreen(getMainframeScreen(screenName));
        String actualValue = getValueFromField(fieldName, screenName);
        expectedValue = parseValue(expectedValue);

        AssertHelper validator = new AssertHelper(ComparisonType.COMPARE_STRINGS, ComparisonOperator.NE, onFailureFlag);
        validator.performValidation(actualValue, expectedValue,
                                    validationID,
                                    String.format("Value not present in '%s' on the TE screen", fieldName));
    }

    @Then("^the user validates that the value of the \"([^\"]*)\" field on the \"([^\"]*)\" TE screen is not blank \"([^\"]*)\" \"([^\"]*)\"$")
    public void theUserValidatesThatTheValueOfTheFieldOnTheTEScreenIsNotBlank(String fieldName,
                                                                              String screenName,
                                                                              String validationID,
                                                                              String onFailureFlag) throws GeneralLeanFtException {
        DesktopContext.getInstance().setCurrentLeanFTScreen(getMainframeScreen(screenName));
        final boolean isElementEmpty = getMainframeObject(fieldName, screenName).getText().isEmpty();

        final String compareDesc = String.format("Expecting the '%s' field to not be empty. ", fieldName);
        TestContext.getInstance().testdataPut(VALIDATION_TAG + validationID, compareDesc);

        if (onFailureFlag.equals(HARD_STOP_ON_FAILURE)) {
            assertThat(isElementEmpty).as(compareDesc).isFalse();
        } else {
            sa().assertThat(isElementEmpty).as(compareDesc).isFalse();
            if (!TestContext.getInstance().sa().wasSuccess()) {
                Reporter.addStepLog("FAIL", compareDesc);
            }
        }
    }

    @Then("^the user validates that \"([^\"]*)\" is ((?:found|not found)?) in the \"([^\"]*)\" column of the \"([^\"]*)\" table on the \"([^\"]*)\" TE screen \"([^\"]*)\" \"([^\"]*)\"$")
    public void theUserValidatesThatIsFoundInTheColumnInTheTableOnTheTEScreen(String expectedValue,
                                                                              String option,
                                                                              String columnName,
                                                                              String tableName,
                                                                              String screenName,
                                                                              String validationID,
                                                                              String onFailureFlag) throws GeneralLeanFtException {
        DesktopContext.getInstance().setCurrentLeanFTScreen(getMainframeScreen(screenName));
        expectedValue = parseValue(expectedValue);

        LeanFTTable table = getMainframeTable(tableName, screenName);
        String actualFieldText = table.checkForMatchInTable(columnName, expectedValue);

        AssertHelper validator = new AssertHelper(ComparisonType.COMPARE_STRINGS, option.equals("found") ? ComparisonOperator.EQ : ComparisonOperator.NE, onFailureFlag);
        validator.performValidation(actualFieldText, expectedValue,
                                    validationID,
                                    String.format("Value lookup in the '%s' column of the '%s' table", columnName, tableName));

    }

    @Then("^the user validates that the \"([^\"]*)\" column contains \"([^\"]*)\" where the \"([^\"]*)\" column is \"([^\"]*)\" in the \"([^\"]*)\" table on the \"([^\"]*)\" TE screen \"([^\"]*)\" \"([^\"]*)\"$")
    public void theUserValidatesTwoColumnMatch(String colNameToFind1,
                                               String expectedVal1,
                                               String keyColName,
                                               String keyColVal,
                                               String tableName,
                                               String screenName,
                                               String validationID,
                                               String onFailureFlag) throws GeneralLeanFtException {
        DesktopContext.getInstance().setCurrentLeanFTScreen(getMainframeScreen(screenName));
        String expectedValue = String.join(LIST_DELIMITER, parseValue(expectedVal1));

        LeanFTTable table = getMainframeTable(tableName, screenName);
        String actualFieldText = table.checkForMatchInTable(keyColName, parseValue(keyColVal),
                                                            colNameToFind1, parseValue(expectedVal1));

        AssertHelper validator = new AssertHelper(ComparisonType.COMPARE_STRINGS, ComparisonOperator.EQ, onFailureFlag);
        validator.performValidation(actualFieldText, expectedValue,
                                    validationID,
                                    String.format("'%s' column value in the '%s' table", colNameToFind1, tableName));
    }

    @Then("^the user validates that the \"([^\"]*)\" column contains \"([^\"]*)\" and the \"([^\"]*)\" column contains \"([^\"]*)\" where the \"([^\"]*)\" column is \"([^\"]*)\" in the \"([^\"]*)\" table on the \"([^\"]*)\" TE screen \"([^\"]*)\" \"([^\"]*)\"$")
    public void theUserValidatesThreeColumnMatch(String colNameToFind1,
                                                 String expectedVal1,
                                                 String colNameToFind2,
                                                 String expectedVal2,
                                                 String keyColName,
                                                 String keyColVal,
                                                 String tableName,
                                                 String screenName,
                                                 String validationID,
                                                 String onFailureFlag) throws GeneralLeanFtException {
        DesktopContext.getInstance().setCurrentLeanFTScreen(getMainframeScreen(screenName));
        String expectedValue = String.join(LIST_DELIMITER, parseValue(expectedVal1), parseValue(expectedVal2));

        LeanFTTable table = getMainframeTable(tableName, screenName);
        String actualFieldText = table.checkForMatchInTable(keyColName, parseValue(keyColVal),
                                                            colNameToFind1, parseValue(expectedVal1),
                                                            colNameToFind2, parseValue(expectedVal2));

        AssertHelper validator = new AssertHelper(ComparisonType.COMPARE_STRINGS, ComparisonOperator.EQ, onFailureFlag);
        validator.performValidation(actualFieldText, expectedValue,
                                    validationID,
                                    String.format("'%s' column and '%s' column in the '%s' table", colNameToFind1, colNameToFind2, tableName));
    }

    @Then("^the user validates that the \"([^\"]*)\" column contains \"([^\"]*)\" and the \"([^\"]*)\" column contains \"([^\"]*)\" and the \"([^\"]*)\" column contains \"([^\"]*)\" where the \"([^\"]*)\" column is \"([^\"]*)\" in the \"([^\"]*)\" table on the \"([^\"]*)\" TE screen \"([^\"]*)\" \"([^\"]*)\"$")
    public void theUserValidatesFourColumnMatch(String colNameToFind1,
                                                String expectedVal1,
                                                String colNameToFind2,
                                                String expectedVal2,
                                                String colNameToFind3,
                                                String expectedVal3,
                                                String keyColName,
                                                String keyColVal,
                                                String tableName,
                                                String screenName,
                                                String validationID,
                                                String onFailureFlag) throws GeneralLeanFtException {
        DesktopContext.getInstance().setCurrentLeanFTScreen(getMainframeScreen(screenName));
        String expectedValue = String.join(LIST_DELIMITER, parseValue(expectedVal1), parseValue(expectedVal2), parseValue(expectedVal3));

        LeanFTTable table = getMainframeTable(tableName, screenName);
        String actualFieldText = table.checkForMatchInTable(keyColName, parseValue(keyColVal),
                                                            colNameToFind1, parseValue(expectedVal1),
                                                            colNameToFind2, parseValue(expectedVal2),
                                                            colNameToFind3, parseValue(expectedVal3));

        AssertHelper validator = new AssertHelper(ComparisonType.COMPARE_STRINGS, ComparisonOperator.EQ, onFailureFlag);
        validator.performValidation(actualFieldText, expectedValue,
                                    validationID,
                                    String.format("'%s' column and '%s' column and '%s' column in the '%s' table", colNameToFind1, colNameToFind2, colNameToFind3, tableName));
    }

    @Then("^the user validates that the \"([^\"]*)\" column is not blank where the \"([^\"]*)\" column contains \"([^\"]*)\" in the \"([^\"]*)\" table on the \"([^\"]*)\" TE screen \"([^\"]*)\" \"([^\"]*)\"$")
    public void theUservalidatesCellInTheTableIsNotBlank(String colToRetrieve,
                                                         String columnToMatch,
                                                         String valueToMatch,
                                                         String tableName,
                                                         String screenName,
                                                         String validationID,
                                                         String onFailureFlag) throws GeneralLeanFtException {

        DesktopContext.getInstance().setCurrentLeanFTScreen(getMainframeScreen(screenName));
        valueToMatch = parseValue(valueToMatch);

        LeanFTTable table = getMainframeTable(tableName, screenName);
        final boolean isElementEmpty = table.retrieveColumnVal(colToRetrieve, columnToMatch, valueToMatch).isEmpty();

        final String compareDesc = String.format("Expecting the '%s' field to not be empty. ", colToRetrieve);
        TestContext.getInstance().testdataPut(VALIDATION_TAG + validationID, compareDesc);

        if (onFailureFlag.equals(HARD_STOP_ON_FAILURE)) {
            assertThat(isElementEmpty).as(compareDesc).isFalse();
        } else {
            sa().assertThat(isElementEmpty).as(compareDesc).isFalse();
            if (!TestContext.getInstance().sa().wasSuccess()) {
                Reporter.addStepLog("FAIL", compareDesc);
            }
        }
    }
    
    @Then("^the user validates \"([^\"]*)\" value is present across the \"([^\"]*)\" TE screens \"([^\"]*)\" \"([^\"]*)\"$")
    public void theUserValidatesValueIsPresentAcrossTheTEScreens(String valueToSearch, String screenName, 
																String validationID, String onFailureFlag) throws GeneralLeanFtException, InterruptedException {    	
    	valueToSearch = parseValue(valueToSearch);
    	String valueLength = String.valueOf(valueToSearch.length()-1);    	
        DesktopContext.getInstance().setCurrentLeanFTScreen(getMainframeScreen(screenName));
        
        String actualValue = "";
        List<String> actualValueList = searchUniqueTextInAllScreens(valueLength, valueToSearch, true);        
        if(actualValueList == null) {
        	log.error(String.format("Unable to find the value : %s in the current screen", valueToSearch));
        } else {
        	actualValue = actualValueList.get(0);	
        }        
        
        AssertHelper validator = new AssertHelper(ComparisonType.COMPARE_STRINGS, ComparisonOperator.EQ, onFailureFlag);
        validator.performValidation(actualValue, valueToSearch,
                                    validationID,
                                   String.format("'%s' : is present on the screen", valueToSearch));
    }
    
    @Then("^the user validates that the field \"([^\"]*)\" is \"([^\"]*)\" on the \"([^\"]*)\" TE screen \"([^\"]*)\" \"([^\"]*)\"$")
    public void theUserValidatesThatFieldIsOnTheTEScreen(String fieldName,
	                                                     String validationtype,
	                                                     String screenName,
	                                                     String validationID,
	                                                     String onFailureFlag) throws GeneralLeanFtException {
    	
    	DesktopContext.getInstance().setCurrentLeanFTScreen(getMainframeScreen(screenName));
        LeanFTField field = getMainframeObject(fieldName, screenName);
        boolean isProtected = field.isProtected();
        switch(validationtype)
        {
        case "EDITABLE":
        	String compareDescription = String.format("Expecting the field %s to be editable at the %s screen", fieldName, screenName);
        	TestContext.getInstance().testdata().put(VALIDATION_TAG + validationID, compareDescription + ": " + isProtected);
        	if (onFailureFlag.equals(HARD_STOP_ON_FAILURE)) {
                assertThat(isProtected).as(compareDescription).isFalse();
            } else {
                sa().assertThat(isProtected).as(compareDescription).isFalse();
                if (isProtected) {
                    Reporter.addStepLog(STATUS_FAIL, VALIDATION_FAILED + compareDescription);
                }
            }
        	break;
        case "NONEDITABLE":
        	compareDescription = String.format("Expecting the field %s to be non editable at the %s screen", fieldName, screenName);
        	TestContext.getInstance().testdata().put(VALIDATION_TAG + validationID, compareDescription + ": " + isProtected);
        	if (onFailureFlag.equals(HARD_STOP_ON_FAILURE)) {
                assertThat(isProtected).as(compareDescription).isTrue();
            } else {
                sa().assertThat(isProtected).as(compareDescription).isTrue();
                if (isProtected) {
                    Reporter.addStepLog(STATUS_FAIL, VALIDATION_FAILED + compareDescription);
                }
            }
        	break;
        }
    }
    
}