package automation.library.engine.core.validator.managers;

import automation.library.api.test.utils.JSONFormatter;
import automation.library.common.TestContext;
import automation.library.engine.api.BaseAPISteps;
import automation.library.engine.core.validator.FailureFlag;
import automation.library.engine.core.validator.ValidatorManager;
import automation.library.reporting.Reporter;
import com.intuit.karate.exception.KarateException;

import java.util.HashMap;
import java.util.Map;

import static automation.library.engine.core.validator.FailureFlag.HARD_STOP_ON_FAILURE;
import static automation.library.engine.core.validator.FailureFlag.valueOfLabel;
import static org.assertj.core.api.Assertions.*;

public class APIValidator extends ValidatorManager {
    private static final String KARATE_ASSERT_MSG = "Assertion details";
    private static final String PAYLOAD_VALIDATION = "Response Payload Validated";
    private static final String ROOT_ATTRIBUTE = "root";
    private BaseAPISteps baseAPISteps;
    private FailureFlag onFailureFlag;

    public APIValidator(String onFailureFlag) {
        this.onFailureFlag = valueOfLabel(onFailureFlag);
        baseAPISteps = new BaseAPISteps();
    }

    @Override
    protected void assertEquals(Object actual, Object expected, String assertMsg) {
        runAPIValidation("validateAttributeEquals");
    }

    @Override
    protected void assertEqualsIgnoreCase(Object actual, Object expected, String assertMsg) {
        throw new UnsupportedOperationException("assertEqualsIgnoreCase is not supported for Compare_API_Response");
    }

    @Override
    protected void assertNotEquals(Object actual, Object expected, String assertMsg) {
        runAPIValidation("validateAttributeNotEquals");
    }

    @Override
    protected void assertLessThan(Object actual, Object expected, String assertMsg) {
        throw new UnsupportedOperationException("assertLessThan is not supported for Compare_API_Response");
    }

    @Override
    protected void assertLessThanOrEqual(Object actual, Object expected, String assertMsg) {
        throw new UnsupportedOperationException("assertLessThanOrEqual is not supported for Compare_API_Response");
    }

    @Override
    protected void assertGreaterThan(Object actual, Object expected, String assertMsg) {
        throw new UnsupportedOperationException("assertGreaterThan is not supported for Compare_API_Response");
    }

    @Override
    protected void assertGreaterThanOrEqual(Object actual, Object expected, String assertMsg) {
        throw new UnsupportedOperationException("assertGreaterThanOrEqual is not supported for Compare_API_Response");
    }

    @Override
    protected void assertContains(Object actual, Object expected, String assertMsg) {
        runAPIValidation("validateAttributeContains");
    }

    @Override
    protected void assertDoesNotContain(Object actual, Object expected, String assertMsg) {
        throw new UnsupportedOperationException("assertDoesNotContain is not supported for Compare_API_Response");
    }

    private void runAPIValidation(String featureToRun) {
        Map<String, Object> args = new HashMap<>();
        args.put("response", TestContext.getInstance().testdataGet("fw.lastAPIResponse"));
        Map<String, Object> argsToAdd = TestContext.getInstance().testdataToClass("fw.argList", Map.class);
        argsToAdd.forEach(args::put);
        featureToRun = featureToRun + getFeatureEnd(args.get("parentAttributeName").toString());

        try {
            Map<String, Object> result = baseAPISteps.runAPIFeatureFile("classpath:services/validate/" + featureToRun, args);
            Reporter.addTextLogContent(PAYLOAD_VALIDATION, JSONFormatter.formatJSON(result.get("response")));
        } catch (KarateException ke) {
            Reporter.addTextLogContent(KARATE_ASSERT_MSG, ke.getMessage());

            if (onFailureFlag.equals(HARD_STOP_ON_FAILURE)) {
                assertThat(ke).doesNotThrowAnyException();
            } else {
                TestContext.getInstance().sa().assertThat(ke).doesNotThrowAnyException();
            }
        }
    }

    private String getFeatureEnd(String parentAttributeName) {
        if(parentAttributeName.equalsIgnoreCase((ROOT_ATTRIBUTE))) {
            return ".feature";
        } else {
            return "WithParent.feature";
        }
    }
}