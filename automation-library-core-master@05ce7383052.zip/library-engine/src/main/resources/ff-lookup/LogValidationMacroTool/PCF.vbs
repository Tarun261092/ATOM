Option Explicit
Dim operation,mailBody
Dim SID, api, field, value, arg, tool_location, log_file_location
Dim char1,char2
Dim xl, wb, sheet
Dim receivedDate
set arg = WScript.Arguments

tool_location = arg(0)
log_file_location = arg(1)
SID= arg(2)
api = arg(3)
field= arg(4)
value = arg(5)
'field2 = arg(6)
'value2 = arg(7)

tool_location = replace(tool_location,"~"," ")
log_file_location = replace(log_file_location,"~"," ")
SID = replace(SID,"~","/")
api = replace(api,"~"," ")
field = replace(field,"~"," ")
value = replace(value,"~"," ")


set xl = CreateObject("Excel.Application")
xl.DisplayAlerts = False
set wb = xl.Workbooks.Open(tool_location)
set sheet = wb.Worksheets("Input")
sheet.Cells(5,26).Value = log_file_location
sheet.Cells(5,4).Value = SID
sheet.Cells(5,5).Value = api
sheet.Cells(5,6).Value = field
sheet.Cells(5,7).Value = value
xl.Run("validate_req")
set xl = Nothing

