SELECT ff_id, ff_app_id, ff_domain, app_name, ff_function, ff_feature, ff_business_criticality,
       ff_business_rules_validations, ff_interfaces_data_sources, ff_no_of_batches, ff_complexity,
       ff_no_of_systems_involved, ff_dependency_on_multiple_teams, ff_test_data_complexity
FROM dev.function_feature, dev.applications
WHERE ff_app_id = app_id
