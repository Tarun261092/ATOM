Option Explicit
Dim operation,mailBody
Dim location,subject,name,outlook_folder,arg,file_location,mailStatus
Dim char1,char2
Dim xl, wb, sheet
Dim receivedDate
set arg = WScript.Arguments

location= arg(0)
mailStatus = arg(1)
subject= arg(2)
mailBody = arg(3)
receivedDate = arg(4)
name = arg(5)
outlook_folder = arg(6)
file_location = arg(7)


'location= "I:\Office"
'subject= "Risk and Controls Framework Coverage for PBWM"
'name = "xy"
'outlook_folder = "inbox"
'file_location = "C:\Users\Hk66755\Desktop\Mail_to_PDF\PDF_Conversion_V6.22.xlsm"


subject = replace(subject,"~"," ")
mailBody = replace(mailBody,"~"," ")
receivedDate = replace(receivedDate,"~","/")
location = replace(location,"~"," ")
name = replace(name,"~"," ")
outlook_folder = replace(trim(outlook_folder),"~"," ")
'outlook_folder = replace(trim(outlook_folder),">","\")
file_location = replace(trim(file_location),"~"," ")

char2 = Left(outlook_folder,1)
outlook_folder = Replace(outlook_folder,char2,UCase(char2),1,1)

'If(Right(outlook_folder,5) <> "Inbox") Then
'	outlook_folder = "Inbox\" & outlook_folder
'End If

'If(mailBody <> " " Or subject <> " " Or receivedDate <> " ") Then
'	operation = "AND"
'Else
'	operation = "NA"
'End If

If(receivedDate = "/") Then
	receivedDate = " "
End If

If (subject <> " " And mailBody <> " " And receivedDate <> " ") Or (subject <> " " And mailBody <> " " And receivedDate = " ") Or (subject <> " " And mailBody = " " And receivedDate <> " ") Then
	operation = "AND"
Else
	operation = "NA"
End If

set xl = CreateObject("Excel.Application")
xl.DisplayAlerts = False
set wb = xl.Workbooks.Open(file_location)
set sheet = wb.Worksheets("PDF Converter")
sheet.Cells(13,1).Value = mailStatus
sheet.Cells(13,2).Value = Trim(subject)
sheet.Cells(13,3).Value = Trim(mailBody)
sheet.Cells(13,4).Value = Trim(receivedDate)
sheet.Cells(13,5).Value = operation
sheet.Cells(13,6).Value = name
sheet.TextBox1.Value = location
sheet.ComboBox1.Value = trim(outlook_folder)
xl.Run("Button1_Click")

set xl = Nothing

