package automation.library.common;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonSyntaxException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.*;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class JSONHelper {
    private JSONHelper() { //Utility class
    }

    private static Logger getLogger() {
        return LogManager.getLogger(JSONHelper.class);
    }


    /**
     * Reads JSON file and returns a specific json object from that file based on the root element value
     */
    public static JSONObject getJSONData(String filepath, String... key) {
        try {
            FileReader reader = new FileReader(filepath);
            JSONTokener token = new JSONTokener(reader);
            return (JSONObject) (key.length > 0 ? new JSONObject(token).get(key[0]) : new JSONObject(token));
        } catch (FileNotFoundException e) {
            getLogger().error(e);
            return null;
        }

    }

    /**
     * Reads JSON file and returns a specific json object from that file based on the root element value
     */
    public static JSONArray getJSONArray(String filepath, String... key) {
        try {
            FileReader reader = new FileReader(filepath);
            JSONTokener token = new JSONTokener(reader);
            return (JSONArray) (key.length > 0 ? new JSONObject(token).get(key[0]) : new JSONArray(token));
        } catch (FileNotFoundException e) {
            getLogger().error("file not found", e);
            return null;
        }
    }

    /**
     * reads data from json files and casts to supplied pojo format
     */
    public static <T> T getDataPOJO(String filepath, Class<T> clazz) throws IOException {
        Gson gson = new Gson();
        File file = new File(filepath);
        T dataObj = null;
        try {
            BufferedReader br = new BufferedReader(new FileReader(file));
            dataObj = gson.fromJson(br, clazz);
        } catch (FileNotFoundException e) {
            getLogger().error(e);
        }

        return dataObj;

    }

    public static Map<String, String> getJSONToMap(JSONObject json) {

        Map<String, String> map = new HashMap<>();
        String[] keys = JSONObject.getNames(json);
        for (String key : keys) {
            map.put(key, json.get(key).toString());
        }

        return map;

    }

    /**
     * Performs a recursive merge between 2 json objects.
     * When the json includes an array then will loop through this as
     * part of the recursive merge.
     */
    public static JSONObject jsonMerge(JSONObject source, JSONObject target) {
        String[] keys = JSONObject.getNames(source);
        if (keys != null) {
            for (String key : keys) {
                Object value = source.get(key);
                if (!target.has(key)) {
                    target.put(key, value);
                } else if (value instanceof JSONArray) {
                    JSONArray array = (JSONArray) value;
                    JSONArray targetarray = (JSONArray) target.get(key);
                    for (int i = 0; i < array.length(); i++) {
                        Object arrayvalue = array.get(i);
                        Object targetarrayvalue = targetarray.get(i);
                        if (arrayvalue instanceof JSONObject) {
                            JSONObject valueJson = (JSONObject) arrayvalue;
                            JSONObject targetvalueJson = (JSONObject) targetarrayvalue;
                            jsonMerge(valueJson, targetvalueJson);
                        } else {
                            target.put(key, value);
                        }
                    }
                } else if (value instanceof JSONObject) {
                    JSONObject valueJson = (JSONObject) value;
                    jsonMerge(valueJson, target.getJSONObject(key));
                } else {
                    target.put(key, value);
                }
            }
        }

        return target;
    }

    public static List<Map<String, String>> getJSONAsListOfMaps(String path) {
        Gson gson = new GsonBuilder().create();

        try {
            return gson.fromJson(new FileReader(path), List.class);
        } catch (FileNotFoundException e) {
            return Collections.emptyList();
        }

    }

    public static String convertMapToJSON(Map<String, Object> map, String path) {
        Gson gson = new GsonBuilder().setPrettyPrinting().create();

        try (FileWriter jsonWrite = new FileWriter(path)) {
            gson.toJson(map, Map.class, jsonWrite);
            File jsonFile = new File(path);
            if (jsonFile.exists()) {
                return jsonFile.getAbsolutePath();
            } else {
                return null;
            }
        } catch (IOException e) {
            getLogger().error("Unable to write to file at path: {}", path);
            return null;
        } catch (JsonSyntaxException e) {
            getLogger().debug("Not a valid JSON: {}. Unable to create file.", map);
            return null;
        }
    }

    public static String mapToJSONArrayString(Map<String, String> myObject) {
        Gson gson = new Gson();
        return gson.toJson(myObject);
    }

    /**
     * Reads JSON file and returns a specific json string from that file based on the root element value
     */
    public static Map<String, String> getJSONDatasMap(String filepath) {

        Gson gson = new Gson();
        try {
            FileReader reader = new FileReader(filepath);
            return gson.fromJson(reader, Map.class);
        } catch (FileNotFoundException e) {
            getLogger().error(e);
        }
        return null;
    }
}
