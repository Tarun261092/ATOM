package automation.library.common;

import java.util.Arrays;

public class StringHelper {

    private StringHelper() {
        //Utility class
    }

    /**
     * @param stringWithSpecialChars
     * @return String with spaces and special characters removed
     */
    public static String removeSpecialChars(String stringWithSpecialChars) {
        stringWithSpecialChars = stringWithSpecialChars.replaceAll("\\s+", "");
        return stringWithSpecialChars.replaceAll("[^a-zA-Z0-9_-]+", "");
    }

    public static String removeAllWhitespace(String stringWithSpaces) {
        return stringWithSpaces.replaceAll("\\s+", "");
    }

    public static String getClassShortName(String classLocation) {
        return Arrays.asList(classLocation.split("\\.")).get(0);
    }
}
