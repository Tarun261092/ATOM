package automation.library.common;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

public class DateHelper {

    private static String matchRegax = "[0-9].+";
    protected static final String DATE = "DATE";
    protected static final String DATETIME = "DATE-TIME";
    protected static final String DATETIMEZONE = "DATE-TIME-ZONE";
    protected static final String TIME = "TIME";
    private DateHelper() {
        //utility class
    }

    public static LocalDateTime formatAsDate(Object dateToFormat) {
        DateTimeFormatter format;
        Map<String, String> dateFormat = getDateTimeFormat(dateToFormat);

        if (dateFormat.containsKey("DATE")) {
            format = DateTimeFormatter.ofPattern(dateFormat.get(DATE)).withLocale(Locale.ENGLISH);
            return LocalDate.parse(dateToFormat.toString(), format).atStartOfDay();
        } else if (dateFormat.containsKey(DATETIME)) {
            format = DateTimeFormatter.ofPattern(dateFormat.get(DATETIME)).withLocale(Locale.ENGLISH);
            return LocalDateTime.parse(dateToFormat.toString(), format);
        } else {
            format = DateTimeFormatter.ofPattern(String.valueOf(dateFormat.get(DATETIMEZONE).split(" z")[0])).withLocale(Locale.ENGLISH);
            return LocalDateTime.parse(dateToFormat.toString().split(" ZONE_")[0].trim(), format);
        }

    }

    public static LocalTime formatAsTime(Object timeToFormat) {    	
        DateTimeFormatter format;
        Map<String, String> timeFormat;
        Map<String, String> timeFormatMap = getTimeFormatMap();
        List<String> matchingFormat = timeFormatMap.entrySet().stream()
                .filter(entry -> timeToFormat.toString().matches(entry.getKey()))
                .map(Map.Entry::getValue)
                .collect(Collectors.toList());     
        
        	if (!matchingFormat.isEmpty()) {
        		timeFormat= Collections.singletonMap(TIME, matchingFormat.get(0));
            } else {
            	throw new IllegalArgumentException(String.format("Unknown date format: '%s'", timeToFormat));
            }

       
     	format = DateTimeFormatter.ofPattern(timeFormat.get(TIME)).withLocale(Locale.ENGLISH);
         return LocalTime.parse(timeToFormat.toString(), format);      
     }

    public static String convertEpochToNormal(String epochDateTime) {
    	Long epochDateTimeInSeconds = Long.parseLong(epochDateTime)/1000;
    	return LocalDateTime.ofEpochSecond(epochDateTimeInSeconds, 0, ZoneOffset.UTC).toString().replace("T", " ");
    }
    
    public static long convertNormalToEpochInSeconds(String normalDateTime) {
    	
    	LocalDateTime localDateTime = LocalDateTime.parse(normalDateTime);
    	long LocalTimeInSeconds = localDateTime.toEpochSecond(ZoneOffset.UTC);
    	return LocalTimeInSeconds;
    	
    }
    
    public static Map<String, String> getDateTimeFormat(Object dateToFormat) {
        Map<String, String> dateFormatMap = getDateFormatMap();
        Map<String, String> dateTimeFormatMap = getDateTimeFormatMap();
        Map<String, String> dateTimeZoneFormatMap = getDateTimeZoneFormatMap();

        List<String> matchingFormat = dateFormatMap.entrySet().stream()
                .filter(entry -> dateToFormat.toString().matches(entry.getKey()))
                .map(Map.Entry::getValue)
                .collect(Collectors.toList());

        if (!matchingFormat.isEmpty()) {
            return Collections.singletonMap("DATE", matchingFormat.get(0));
        } else {
            matchingFormat = dateTimeFormatMap.entrySet().stream()
                    .filter(entry -> dateToFormat.toString().matches(entry.getKey()))
                    .map(Map.Entry::getValue)
                    .collect(Collectors.toList());

            if (!matchingFormat.isEmpty()) {
                return Collections.singletonMap(DATETIME, matchingFormat.get(0));
            } else {
                matchingFormat = dateTimeZoneFormatMap.entrySet().stream()
                        .filter(entry -> dateToFormat.toString().matches(entry.getKey()))
                        .map(Map.Entry::getValue)
                        .collect(Collectors.toList());

                if (!matchingFormat.isEmpty()) {
                    return Collections.singletonMap(DATETIMEZONE, matchingFormat.get(0));
                } else {
                    throw new IllegalArgumentException(String.format("Unknown date format: '%s'", dateToFormat));
                }
            }
        }
    }



    private static Map<String, String> getDateTimeZoneFormatMap() {
            Map<String, String> dateTimeFormatMap = new HashMap<>();

            dateTimeFormatMap.put("^\\d{1,2}-\\d{1,2}-\\d{4}\\s\\d{1,2}:\\d{2}:\\d{2}.*$", "MM-dd-yyyy HH:mm:ss z Zone");
            dateTimeFormatMap.put("^\\d{1,2}/\\d{1,2}/\\d{4}\\s\\d{1,2}:\\d{2}:\\d{2}.*$", "MM/dd/yyyy HH:mm:ss z Zone");
            return dateTimeFormatMap;
        }


        private static Map<String, String> getDateFormatMap() {
        Map<String, String> dateFormatMap = new HashMap<>();

        dateFormatMap.put("^\\d{2}([0][1-9]|[1][0-2])([0][1-9]|[1-2][0-9]|[3][0-1])$", "yyMMdd");
        dateFormatMap.put("^(\\d{4})([0][1-9]|[1][0-2])([0][1-9]|[1-2][0-9]|[3][0-1])$", "yyyyMMdd");
        dateFormatMap.put("^([0][1-9]|[1][0-2])([0][1-9]|[1-2][0-9]|[3][0-1])\\d{2}$", "MMddyy");
        dateFormatMap.put("^\\d{8}$", "MMddyyyy");
        dateFormatMap.put("^\\d{1,2}-\\d{1,2}-\\d{4}$", "MM-dd-yyyy");
        dateFormatMap.put("^\\d{1,2}-\\d{1,2}-\\d{2}$", "MM-dd-yy");
        dateFormatMap.put("^\\d{4}-\\d{1,2}-\\d{1,2}$", "yyyy-MM-dd");
        dateFormatMap.put("^\\d{4}-\\s[a-zA-Z]{3}-\\d{1,2}$", "YYYY-MMM-DD");
        dateFormatMap.put("^\\d{2}-\\s[a-zA-Z]{3}-\\d{1,2}$", "YY-MMM-DD");
        dateFormatMap.put("^\\d{1}\\/\\d{1}\\/\\d{4}$", "M/d/yyyy");
        dateFormatMap.put("^\\d{2}\\/\\d{2}\\/\\d{4}$", "MM/dd/yyyy");
        dateFormatMap.put("^\\d{1}\\/\\d{1}\\/\\d{2}$", "M/d/yy");
        dateFormatMap.put("^\\d{2}\\/\\d{2}\\/\\d{2}$", "MM/dd/yy");
        dateFormatMap.put("^\\d{4}\\/\\d{1,2}\\/\\d{1,2}$", "yyyy/MM/dd");
        dateFormatMap.put("^\\d{1,2}\\s[a-zA-Z]{3}\\s\\d{4}$", "dd MMM yyyy");
        dateFormatMap.put("^\\d{1,2}\\s[a-zA-Z]{4,}\\s\\d{4}$", "dd MMMM yyyy");
        dateFormatMap.put("^[a-zA-Z]{3}\\s\\d{1,2},{0,1}\\s\\d{4}$", "MMM dd yyyy");
        dateFormatMap.put("^[a-zA-Z]{4,}\\s\\d{1,2},{0,1}\\s\\d{4}$", "MMMM dd yyyy");
        dateFormatMap.put("^\\d{2}-\\d{1,2}-\\d{1,2}$", "YY-MM-DD");

        return dateFormatMap;
    }

    private static Map<String, String> getDateTimeFormatMap() {
        Map<String, String> dateTimeFormatMap = new HashMap<>();

        dateTimeFormatMap.put("^\\d{4}-\\d{1,2}-\\d{1,2}\\s\\d{1,2}:\\d{2}:\\d{2}.\\d{3}$", "yyyy-MM-dd HH:mm:ss.SSS");
        dateTimeFormatMap.put("^\\d{12}$", "yyyyMMddHHmm");
        dateTimeFormatMap.put("^\\d{8}\\s\\d{4}$", "yyyyMMdd HHmm");
        dateTimeFormatMap.put("^\\d{1,2}-\\d{1,2}-\\d{4}\\s\\d{1,2}:\\d{2}$", "MM-dd-yyyy HH:mm");
        dateTimeFormatMap.put("^\\d{1,2}-\\d{1,2}-\\d{4}\\s\\d{1,2}:\\d{2}[a-zA-Z]{2}$", "MM-dd-yyyy [hh][h]:mma");
        dateTimeFormatMap.put("^\\d{4}-\\d{1,2}-\\d{1,2}\\s\\d{1,2}:\\d{2}$", "yyyy-MM-dd HH:mm");
        dateTimeFormatMap.put("^\\d{1,2}\\/\\d{1,2}\\/\\d{4}\\s\\d{1,2}:\\d{2}$", "MM/dd/yyyy HH:mm");
        dateTimeFormatMap.put("^\\d{1,2}\\/\\d{1,2}\\/\\d{2}\\s\\d{1,2}:\\d{2}[a-zA-Z]{2}$", "MM/dd/yy [hh][h]:mma");
        dateTimeFormatMap.put("^\\d{1,2}\\/\\d{1,2}\\/\\d{4}\\s\\d{1,2}:\\d{2}[a-zA-Z]{2}$", "MM/dd/yyyy [hh][h]:mma");
        dateTimeFormatMap.put("^\\d{4}\\/\\d{1,2}\\/\\d{1,2}\\s\\d{1,2}:\\d{2}$", "yyyy/MM/dd HH:mm");
        dateTimeFormatMap.put("^\\d{1,2}\\s[a-z]{3}\\s\\d{4}\\s\\d{1,2}:\\d{2}$", "dd MMM yyyy HH:mm");
        dateTimeFormatMap.put("^\\d{1,2}\\s[a-z]{4,}\\s\\d{4}\\s\\d{1,2}:\\d{2}$", "dd MMMM yyyy HH:mm");
        dateTimeFormatMap.put("^\\s[a-z]{3}\\d{1,2}\\s\\d{4}\\s\\d{1,2}:\\d{2}$", "MMM dd yyyy HH:mm");
        dateTimeFormatMap.put("^\\s[a-z]{3}\\d{1,2}\\s\\d{4}\\s\\d{1,2}:\\d{2}[a-zA-Z]{2}$", "MMM dd yyyy [hh][h]:mma");
        dateTimeFormatMap.put("^\\s[a-z]{4,}\\d{1,2}\\s\\d{4}\\s\\d{1,2}:\\d{2}$", "MMMM dd yyyy HH:mm");
        dateTimeFormatMap.put("^\\s[a-z]{4,}\\d{1,2}\\s\\d{4}\\s\\d{1,2}:\\d{2}[a-zA-Z]{2}$", "MMMM dd yyyy [hh][h]:mma");
        dateTimeFormatMap.put("^\\d{14}$", "yyyyMMddHHmmss");
        dateTimeFormatMap.put("^\\d{8}\\s\\d{6}$", "yyyyMMdd HHmmss");
        dateTimeFormatMap.put("^\\d{1,2}-\\d{1,2}-\\d{4}\\s\\d{1,2}:\\d{2}:\\d{2}$", "MM-dd-yyyy HH:mm:ss");
        dateTimeFormatMap.put("^\\d{4}-\\d{1,2}-\\d{1,2}\\s\\d{1,2}:\\d{2}:\\d{2}$", "yyyy-MM-dd HH:mm:ss");
        dateTimeFormatMap.put("^\\d{1,2}\\/\\d{1,2}\\/\\d{4}\\s\\d{1,2}:\\d{2}:\\d{2}$", "MM/dd/yyyy HH:mm:ss");
        dateTimeFormatMap.put("^\\d{1,2}\\/\\d{1,2}\\/\\d{4}\\s\\d{1,2}:\\d{2}:\\d{2}[a-zA-Z]{2}$", "MM/dd/yyyy hh:mm:ssa");
        dateTimeFormatMap.put("^\\d{4}\\/\\d{1,2}\\/\\d{1,2}\\s\\d{1,2}:\\d{2}:\\d{2}$", "yyyy/MM/dd HH:mm:ss");
        dateTimeFormatMap.put("^\\d{1,2}\\s[a-zA-Z]{3}\\s\\d{4}\\s\\d{1,2}:\\d{2}:\\d{2}$", "dd MMM yyyy HH:mm:ss");
        dateTimeFormatMap.put("^\\d{1,2}\\s[a-zA-Z]{4,}\\s\\d{4}\\s\\d{1,2}:\\d{2}:\\d{2}$", "dd MMMM yyyy HH:mm:ss");
        dateTimeFormatMap.put("^[a-zA-Z]{3}\\s\\d{1,2},{0,1}\\s\\d{4}\\s\\d{1,2}:\\d{2}:\\d{2}$", "MMM dd[,] yyyy HH:mm:ss");
        dateTimeFormatMap.put("^[a-zA-Z]{3}\\s\\d{1,2},{0,1}\\s\\d{4}\\s\\d{1,2}:\\d{2}:\\d{2}\\s{0,1}[a-zA-Z]{2}$", "MMM dd[,] yyyy [hh][h]:mm:ss[ ]a");
        dateTimeFormatMap.put("^[a-zA-Z]{4,}\\s\\d{1,2},{0,1}\\s\\d{4}\\s\\d{1,2}:\\d{2}:\\d{2}$", "MMMM dd[,] yyyy HH:mm:ss");
        dateTimeFormatMap.put("^[a-zA-Z]{4,}\\s\\d{1,2},{0,1}\\s\\d{4}\\s\\d{1,2}:\\d{2}:\\d{2}[a-zA-Z]\\s{0,1}{2}$", "MMMM[,] dd yyyy [hh][h]:mm:ss[ ]a");
        dateTimeFormatMap.put("^\\d{1}\\/\\d{1,2}\\/\\d{2}\\s\\d{1,2}:\\d{2}[a-zA-Z]{2}$", "M/dd/yy [hh][h]:mma");
        dateTimeFormatMap.put("^\\d{1,2}\\/\\d{1,2}\\/\\d{4}\\s\\d{1,2}:\\d{2}:\\d{2}\\s[a-zA-Z]{2}$", "MM/dd/yyyy hh:mm:ss a");
        dateTimeFormatMap.put("^\\d{1,2}\\-\\d{1,2}\\-\\d{4}\\s\\d{1,2}:\\d{2}:\\d{2}\\s[a-zA-Z]{2}$", "MM-dd-yyyy hh:mm:ss a");

        return dateTimeFormatMap;
    }
    
    private static Map<String, String> getTimeFormatMap() {
        Map<String, String> timeFormatMap = new HashMap<>();

        timeFormatMap.put("^\\d{1,2}:\\d{2}:\\d{2}.\\d{3}$", "HH:mm:ss.SSS");
        timeFormatMap.put("^\\d{4}$", "HHmm");
        timeFormatMap.put("^\\d{1,2}:\\d{2}$", "HH:mm");
        timeFormatMap.put("^\\d{1,2}:\\d{2}[a-zA-Z]{2}$", "[hh][h]:mma");
        timeFormatMap.put("^\\d{6}$", "HHmmss");
        timeFormatMap.put("^\\d{1,2}:\\d{2}:\\d{2}$", "HH:mm:ss");
        timeFormatMap.put("^\\d{1,2}:\\d{2}:\\d{2}[a-zA-Z]{2}$", "hh:mm:ssa");       
        timeFormatMap.put("^\\d{1,2}:\\d{2}:\\d{2}\\s{0,1}[a-zA-Z]{2}$", "[hh][h]:mm:ss[ ]a");
        timeFormatMap.put("^\\d{1,2}:\\d{2}:\\d{2}[a-zA-Z]\\s{0,1}{2}$", "[hh][h]:mm:ss[ ]a");
        timeFormatMap.put("^\\d{1,2}:\\d{2}[a-zA-Z]{2}$", "[hh][h]:mma");
        timeFormatMap.put("^\\d{1,2}:\\d{2}:\\d{2}\\s[a-zA-Z]{2}$", "hh:mm:ss a");
       

        return timeFormatMap;
    }

    public static String getClosestTimeFromList(List<String> listOfValues, String valueToCompare) {
        String closest = listOfValues.get(0);
        int diffrence = Math.abs((getTimeInSeconds(closest, "\\.")) - getTimeInSeconds(valueToCompare, "\\."));
        for (String value : listOfValues) {

            int differenceNew = Math.abs(getTimeInSeconds(value, "\\.") - getTimeInSeconds(valueToCompare, "\\."));
            if (diffrence > differenceNew) {
                closest = value;
                diffrence = differenceNew;
            }
        }
        return closest;
    }

    public static String getAboveClosestTimeFromList(List<String> listOfValues, String valueToCompare) {
        List<String> closetAboveValue = new ArrayList<>();
        for (String value : listOfValues) {
            if (value.matches(matchRegax)) {
                int difference = getTimeInSeconds(value, "\\.") - getTimeInSeconds(valueToCompare, "\\.");
                if (difference > 0) {
                    closetAboveValue.add(value);
                }

            }
        }
        if (closetAboveValue.isEmpty()) {
            return valueToCompare;
        } else {
            return getClosestTimeFromList(closetAboveValue, valueToCompare);
        }
    }

    public static String getBelowClosestTimeFromList(List<String> listOfValues, String valueToCompare) {
        List<String> closetBelowValue = new ArrayList<>();
        for (String value : listOfValues) {
            if (value.matches(matchRegax)) {

                int difference = getTimeInSeconds(value, "\\.") - getTimeInSeconds(valueToCompare, "\\.");
                if (difference < 0) {
                    closetBelowValue.add(value);
                }
            }
        }
        if (closetBelowValue.isEmpty()) {
            return valueToCompare;
        } else {
            return getClosestTimeFromList(closetBelowValue, valueToCompare);
        }
    }

    protected static int getTimeInSeconds(String value, String seperator) {
        int timeInSecond = 0;
        if (value.matches(matchRegax)) {
            String[] timeParts = value.split(seperator);
            timeInSecond = Integer.parseInt(timeParts[0]) * 3600 + Integer.parseInt(timeParts[1]) * 60 + Integer.parseInt(timeParts[2]);
        }
        return timeInSecond;
    }

}
