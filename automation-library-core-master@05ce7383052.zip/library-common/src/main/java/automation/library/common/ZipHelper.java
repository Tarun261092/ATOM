package automation.library.common;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

public class ZipHelper {
    private ZipHelper() {
        //Utility class
    }

    private static Logger getLogger() {
        return LogManager.getLogger(ZipHelper.class);
    }

    public static void zipit(String sourcePath, String targetPath) throws IOException {

        FileOutputStream fos = new FileOutputStream(targetPath);
        ZipOutputStream zipOut = new ZipOutputStream(fos);

        File fileToZip = new File(sourcePath);

        zip(fileToZip, fileToZip.getName(), zipOut);
        zipOut.close();
        fos.close();
    }

    public static void unzipit(String sourcePath, String targetPath) throws IOException {

        File dir = new File(targetPath);
        if (!dir.exists()) dir.mkdirs();

        FileInputStream fis = new FileInputStream(sourcePath);
        ZipInputStream zipIn = new ZipInputStream(fis);

        unzip(targetPath, zipIn);
        zipIn.close();
        fis.close();
    }

    private static void zip(File fileToZip, String fileName, ZipOutputStream zipOut) throws IOException {

        if (fileToZip.isHidden()) {
            return;
        }
        if (fileToZip.isDirectory()) {
            File[] files = fileToZip.listFiles();
            for (File file : files) {
                zip(file, fileName + "/" + file.getName(), zipOut);
            }
            return;
        }
        try (FileInputStream fis = new FileInputStream(fileToZip)) {
            ZipEntry zipEntry = new ZipEntry(fileName);
            zipOut.putNextEntry(zipEntry);
            byte[] bytes = new byte[1024];
            int length;
            while ((length = fis.read(bytes)) >= 0) {
                zipOut.write(bytes, 0, length);
            }
        }
    }

    private static void unzip(String targetPath, ZipInputStream zipIn) {

        //buffer for read and write data to file
        byte[] buffer = new byte[1024];
        try {
            ZipEntry ze = zipIn.getNextEntry();
            while (ze != null) {
                String fileName = ze.getName();
                File newFile = new File(targetPath + File.separator + fileName);
                String canonicalDestinationPath = newFile.getCanonicalPath();

                if (!canonicalDestinationPath.startsWith(targetPath)) {
                  throw new IOException("Entry is outside of the target directory");
                }
                new File(newFile.getParent()).mkdirs();
                try (FileOutputStream fos = new FileOutputStream(newFile)) {
                    int len;
                    while ((len = zipIn.read(buffer)) > 0) {
                        fos.write(buffer, 0, len);
                    }
                }
                //close this ZipEntry
                zipIn.closeEntry();
                ze = zipIn.getNextEntry();
            }
            //close last ZipEntry
            zipIn.closeEntry();
        } catch (IOException e) {
            getLogger().error(e);
        }

    }

}



