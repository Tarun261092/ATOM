package automation.library.common.exception;

public class InvalidExcellFileOperationException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1407159327179064195L;

	public InvalidExcellFileOperationException() {
		// TODO Auto-generated constructor stub
	}

	public InvalidExcellFileOperationException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public InvalidExcellFileOperationException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public InvalidExcellFileOperationException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public InvalidExcellFileOperationException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}
