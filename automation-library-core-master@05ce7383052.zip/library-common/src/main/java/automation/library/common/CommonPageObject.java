package automation.library.common;

public class CommonPageObject {
}
