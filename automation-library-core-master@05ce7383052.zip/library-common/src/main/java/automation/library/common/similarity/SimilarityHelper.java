package automation.library.common.similarity;

import info.debatty.java.stringsimilarity.JaroWinkler;

public class SimilarityHelper {

    private SimilarityHelper() {
        //utility class
    }

    public static double getSimilarityScore(String string1, String string2) {
        JaroWinkler jw = new JaroWinkler();
        return jw.similarity(string1, string2);
    }
}
