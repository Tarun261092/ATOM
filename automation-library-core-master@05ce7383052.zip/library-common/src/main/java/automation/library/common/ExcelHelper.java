package automation.library.common;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.util.ZipSecureFile;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.DataValidation;
import org.apache.poi.ss.usermodel.DataValidationConstraint;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.ss.util.CellRangeAddressList;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import automation.library.common.exception.InvalidExcellFileOperationException;

public class ExcelHelper {
	protected static final Logger log =  LogManager.getLogger(ExcelHelper.class);

	private static final String EXCEPTION_PROCESSING_FILE = "exception processing file";
	private static final String EXCEPTION_DATA_RETREVAL= "No Matching Rows to Compare";

	private ExcelHelper() { //Utility class
	}

	private static Logger getLogger() {
		return LogManager.getLogger(ExcelHelper.class);
	}

	/**
	 * reads data from a given sheet in excel returning all rows and columns matching the supplied recordset (col A)
	 */
	public static List<ArrayList<Object>> getDataAsArrayList(String filepath, String worksheet, String... recordSet) {

		ArrayList<ArrayList<Object>> data = new ArrayList<>();
		try (FileInputStream file = new FileInputStream(filepath);
				XSSFWorkbook workbook = new XSSFWorkbook(file)) {
			XSSFSheet sheet = workbook.getSheet(worksheet);
			FormulaEvaluator evaluator = workbook.getCreationHelper().createFormulaEvaluator();

			int maxDataCount = 0;
			// Iterate through each rows one by one


			Iterator<Row> rowIterator = sheet.iterator();

			while (rowIterator.hasNext()) {

				Row row = rowIterator.next();

				//Skip the first row beacause it will be header and also get column count
				if (row.getRowNum() == 0) {
					maxDataCount = row.getLastCellNum();
				}

				//if row is empty then break the loop,do not go further
				if (isRowEmpty(row)) {
					break;
				}

				ArrayList<Object> singleRows = new ArrayList<>();

				// For each row, iterate through all the columns

				for (int c = 0; c < maxDataCount; c++) {

					Cell cell = row.getCell(c);

					singleRows.add(getCellData(cell, evaluator));

				}

				if (recordSet.length > 0) {
					if (singleRows.get(0).toString().equalsIgnoreCase(recordSet[0])) {
						data.add(singleRows);
					}
				} else {
					data.add(singleRows);
				}
			}
		} catch (Exception e) {
			getLogger().error(EXCEPTION_PROCESSING_FILE, e);
		}

		return data;

	}

	public static Map<String, LinkedHashMap<String, Object>> getDataAsMap(String filepath, String worksheet) {

		Map<String, LinkedHashMap<String, Object>> dataMap = new LinkedHashMap<>();
		LinkedHashMap<String, Object> mapTemp = null;

		String dataSetKey = null;
		Row headerRow = null;
		Object key = null;
		Object value = null;

		try (FileInputStream file = new FileInputStream(filepath);
				XSSFWorkbook workbook = new XSSFWorkbook(file)) {

			XSSFSheet sheet = workbook.getSheet(worksheet);
			FormulaEvaluator evaluator = workbook.getCreationHelper().createFormulaEvaluator();

			int lastRow = sheet.getLastRowNum();


			int currentRowNum = 0;
			while (currentRowNum < lastRow) {
				if (isRowEmpty(sheet.getRow(currentRowNum))) {
					currentRowNum++;
					continue;
				}

				headerRow = sheet.getRow(currentRowNum);

				for (int j = currentRowNum + 1; j <= lastRow; j++) {
					if (isRowEmpty(sheet.getRow(j))) {
						currentRowNum = j + 1;
						break;
					}

					dataSetKey = getCellData(sheet.getRow(headerRow.getRowNum()).getCell(0), evaluator) + "." + getCellData(sheet.getRow(sheet.getRow(j).getRowNum()).getCell(0), evaluator);
					mapTemp = new LinkedHashMap<>();
					for (int cellCounter = 1; cellCounter < sheet.getRow(j).getLastCellNum(); cellCounter++) {

						key = getCellData(sheet.getRow(headerRow.getRowNum()).getCell(cellCounter), evaluator);
						value = getCellData(sheet.getRow(j).getCell(cellCounter), evaluator);

						if (value != null && key != null) {
							mapTemp.put(key.toString(), value);

						}
					}

					currentRowNum++;
					dataMap.put(dataSetKey, mapTemp);
				}
			}
		} catch (Exception e) {
			getLogger().error(EXCEPTION_PROCESSING_FILE, e);
		}
		return dataMap;
	}

	public static List<Map<String, Object>> getExcelDataAsMapWithoutIndex(String filepath, String worksheet, boolean... flag) {

		List<Map<String, Object>> dataMap = new ArrayList<>();
		Map<String, Object> mapTemp = null;

		Row headerRow = null;
		Object key = null;
		Object value = null;

		try (FileInputStream file = new FileInputStream(filepath);
				XSSFWorkbook workbook = new XSSFWorkbook(file)) {

			XSSFSheet sheet = workbook.getSheet(worksheet);
			FormulaEvaluator evaluator = workbook.getCreationHelper().createFormulaEvaluator();

			int lastRow = sheet.getLastRowNum();

			int currentRowNum = 0;
			while (currentRowNum < lastRow) {
				if (isRowEmpty(sheet.getRow(currentRowNum))) {
					currentRowNum++;
					continue;
				}

				headerRow = sheet.getRow(currentRowNum);

				for (int j = currentRowNum + 1; j <= lastRow; j++) {
					if (isRowEmpty(sheet.getRow(j))) {
						currentRowNum = j + 1;
						break;
					}

					mapTemp = new HashMap<>();
					for (int cellCounter = 0; cellCounter < sheet.getRow(j).getLastCellNum(); cellCounter++) {

						key = getCellData(sheet.getRow(headerRow.getRowNum()).getCell(cellCounter), evaluator);
						value = getCellData(sheet.getRow(j).getCell(cellCounter), evaluator);

						if (flag.length > 0 && value != null && key != null) {
							int rowNum = currentRowNum + 2;
							//only for FDR
							int ori = value.toString().lastIndexOf("OR");
							List<String> valueList = new ArrayList<>(Arrays.asList(value.toString().split("\n")));

							boolean hasOR = valueList.removeIf(value1 -> value1.startsWith("OR"));

							if (hasOR) {
								StringBuffer str = new StringBuffer(value.toString());
								str.insert(ori - 1, "\nROW_NUM = " + rowNum + " ");
								value = str.toString();
							}

							value = value.toString() + "\nROW_NUM = " + rowNum + "";
							//only for FDR
						}

						if (value != null && key != null) {
							mapTemp.put(key.toString(), value);
						}
					}
					currentRowNum++;
					dataMap.add(mapTemp);
				}
			}
		} catch (Exception e) {
			return Collections.emptyList();
		}
		return dataMap;
	}

	private static Object getCellData(Cell cell, FormulaEvaluator evaluator) {
		Object obj = null;

		if (cell == null) return null;

		switch (evaluator.evaluateInCell(cell).getCellType()) {
		case NUMERIC:
			if (DateUtil.isCellDateFormatted(cell)) {
				obj = (new SimpleDateFormat("yyyy-MM-dd").format(cell.getDateCellValue()));
			} else {
				obj = (cell.getNumericCellValue());
			}
			break;
		case STRING:
			obj = (cell.getStringCellValue());
			break;
		case BLANK:
			obj = null;
			break;
		case BOOLEAN:
			obj=(cell.getBooleanCellValue());//kirhtika added
			break;
		default:
			obj = (cell.getStringCellValue());
		}
		return obj;
	}

	private static boolean isRowEmpty(Row row) {

		if (row == null) return true;

		for (int c = row.getFirstCellNum(); c < row.getLastCellNum(); c++) {
			Cell cell = row.getCell(c);
			if (cell != null && cell.getCellType() != CellType.BLANK) {
				return false;
			}
		}
		return true;
	}
	public static Map<String, HashMap<String, Object>> getExcelDataAsHashMapwithPrimaryColumnAsKey(File inputFile, String worksheet ,List<String> columnHeaderNames , String primaryKeyColName, String primaryKeyValue, File outputFile,boolean isHeaderHighlightNeeded , boolean isValueHighlightNeeded ){
		Map<String, HashMap<String, Object>> dataMap = new HashMap<>();
		HashMap<String, Object> mapTemp = null;
		if(primaryKeyColName!=null && primaryKeyColName.contains("#(")) {
			primaryKeyColName =  	primaryKeyColName.substring(primaryKeyColName.indexOf("#(")+2, primaryKeyColName.indexOf(")"));
		}
		String dataSetKey = null;
		Row headerRow = null;
		Object key = null;
		Object value = null;
		ZipSecureFile.setMinInflateRatio(0);

		try (FileInputStream fileINStream = new FileInputStream(inputFile);
				XSSFWorkbook workbook = new XSSFWorkbook(fileINStream)) {
			CellStyle highlightCellStyle = workbook.createCellStyle();  
			// Setting Background color  
			highlightCellStyle.setFillForegroundColor(IndexedColors.YELLOW.getIndex());  
			highlightCellStyle.setFillPattern(FillPatternType.BRICKS); 
			XSSFSheet sheet = workbook.getSheet(worksheet);
			FormulaEvaluator evaluator = workbook.getCreationHelper().createFormulaEvaluator();
			boolean columnNameFound =false;//kirthika

			int lastRow = sheet.getLastRowNum();
			int currentRowNum = 0;
			while (currentRowNum < lastRow) {
				if (isRowEmpty(sheet.getRow(currentRowNum))) {
					currentRowNum++;
					continue;
				}

				headerRow = sheet.getRow(currentRowNum);
				int primaryKeyInd = 0;
				for(int ind = headerRow.getFirstCellNum() ; ind <headerRow.getLastCellNum() ; ind++) {
					//if (headerRow.getCell(ind).getStringCellValue().equalsIgnoreCase(primaryKeyColName)){//kirthika
							if(headerRow.getCell(ind)!=null && headerRow.getCell(ind).getStringCellValue().equalsIgnoreCase(primaryKeyColName) ) {
								primaryKeyInd = ind;
								columnNameFound=true;//kirthika
								
							}
						
					
					if(headerRow.getCell(ind)!=null && isHeaderHighlightNeeded
							&& (columnHeaderNames.contains(headerRow.getCell(ind).getStringCellValue()) || primaryKeyColName.equals(headerRow.getCell(ind).getStringCellValue()))) {
						headerRow.getCell(ind).setCellStyle(highlightCellStyle);

					}
				}
				for (int j = currentRowNum + 1; j <= lastRow; j++) {
					if (isRowEmpty(sheet.getRow(j))) {
						currentRowNum = j + 1;
						break;
					}
					
					//int ColumnIndex= primaryKeyInd;
					//write logic to iterate entire column of the mysheet
					int totalColumn = sheet.getRow(j).getLastCellNum();
					int startColumnIndex = primaryKeyInd;
					while(startColumnIndex<totalColumn) {
						if( getCellData(sheet.getRow(j).getCell(startColumnIndex), evaluator)!=null) {
							dataSetKey = getCellData(sheet.getRow(j).getCell(startColumnIndex), evaluator).toString();
						}
						else {
							dataSetKey=null;
						}
						if( primaryKeyValue.equalsIgnoreCase(dataSetKey)) {
							mapTemp = new LinkedHashMap<>();
							for (int cellCounter = sheet.getRow(j).getFirstCellNum(); cellCounter < sheet.getRow(j).getLastCellNum(); cellCounter++) {

								key = getCellData(sheet.getRow(headerRow.getRowNum()).getCell(cellCounter), evaluator);
								Cell cell =   sheet.getRow(j).getCell(cellCounter);
								value = getCellData(cell, evaluator);

								if (value != null && key != null) {
									if(isValueHighlightNeeded && 
											columnHeaderNames!=null 
											&&primaryKeyColName !=null
											&& primaryKeyValue != null 
											&& (columnHeaderNames.contains(key.toString()) || primaryKeyColName.equals(key.toString()))
											&&  primaryKeyValue.equalsIgnoreCase(dataSetKey)) {
										cell.setCellStyle(highlightCellStyle);
										mapTemp.put(key.toString(), value);
									}

								}
							}
							dataMap.put(dataSetKey, mapTemp);
							FileOutputStream out = new FileOutputStream(outputFile);
							workbook.write(out);
							out.flush();
							out.close();
							return dataMap;
						}
						if(!columnNameFound)
							startColumnIndex++;
						else 
							break;
						
					}
					
					

					currentRowNum++;
				}
			}
			FileOutputStream out = new FileOutputStream(outputFile);
			workbook.write(out);
			out.flush();
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
			getLogger().error(EXCEPTION_PROCESSING_FILE, e);

		}

		return dataMap;
	}

	public static Map<String, List<HashMap<String, Object>>> getExcelDataAsHashMapListwithPrimaryColumnAsKey(File inputFile, String worksheet ,List<String> columnHeaderNames , String primaryKeyColName, String primaryKeyValue, File outputFile,boolean isHeaderHighlightNeeded , boolean isValueHighlightNeeded ){
		Map<String, List<HashMap<String, Object>>> dataMap = new HashMap<>();
		List<HashMap<String, Object>> listTemp  = new ArrayList<HashMap<String,Object>>(); 
		HashMap<String, Object> mapTemp = null;
		if(primaryKeyColName!=null && primaryKeyColName.contains("#(")) {
			primaryKeyColName =  	primaryKeyColName.substring(primaryKeyColName.indexOf("#(")+2, primaryKeyColName.indexOf(")"));
		}
		String dataSetKey = null;
		Row headerRow = null;
		Object key = null;
		Object value = null;
		ZipSecureFile.setMinInflateRatio(0);

		try (FileInputStream fileINStream = new FileInputStream(inputFile);
				XSSFWorkbook workbook = new XSSFWorkbook(fileINStream)) {
			CellStyle highlightCellStyle = workbook.createCellStyle();  
			// Setting Background color  
			highlightCellStyle.setFillForegroundColor(IndexedColors.YELLOW.getIndex());  
			highlightCellStyle.setFillPattern(FillPatternType.BRICKS); 
			XSSFSheet sheet = workbook.getSheet(worksheet);
			FormulaEvaluator evaluator = workbook.getCreationHelper().createFormulaEvaluator();

			int lastRow = sheet.getLastRowNum();
			int currentRowNum = 0;
			while (currentRowNum < lastRow) {
				if (isRowEmpty(sheet.getRow(currentRowNum))) {
					currentRowNum++;
					continue;
				}

				headerRow = sheet.getRow(currentRowNum);
				int primaryKeyInd = 0;
				for(int ind = headerRow.getFirstCellNum() ; ind <headerRow.getLastCellNum() ; ind++) {
					if (headerRow.getCell(ind).getStringCellValue().equalsIgnoreCase(primaryKeyColName)){
						primaryKeyInd = ind;
					} 
					if(isHeaderHighlightNeeded
							&& (columnHeaderNames.contains(headerRow.getCell(ind).getStringCellValue()) || primaryKeyColName.equals(headerRow.getCell(ind).getStringCellValue()))) {
						headerRow.getCell(ind).setCellStyle(highlightCellStyle);

					}
				}
				for (int j = currentRowNum + 1; j <= lastRow; j++) {
					if (isRowEmpty(sheet.getRow(j))) {
						currentRowNum = j + 1;
						break;
					}

					dataSetKey = getCellData(sheet.getRow(j).getCell(primaryKeyInd), evaluator).toString();
					if( primaryKeyValue.equalsIgnoreCase(dataSetKey)) {
						mapTemp = new LinkedHashMap<>();
						for (int cellCounter = sheet.getRow(j).getFirstCellNum(); cellCounter < sheet.getRow(j).getLastCellNum(); cellCounter++) {

							key = getCellData(sheet.getRow(headerRow.getRowNum()).getCell(cellCounter), evaluator);
							Cell cell =   sheet.getRow(j).getCell(cellCounter);
							value = getCellData(cell, evaluator);

							if (value != null && key != null) {
								if(isValueHighlightNeeded && 
										columnHeaderNames!=null 
										&&primaryKeyColName !=null
										&& primaryKeyValue != null 
										&& (columnHeaderNames.contains(key.toString()) || primaryKeyColName.equals(key.toString()))
										&&  primaryKeyValue.equalsIgnoreCase(dataSetKey)) {
									cell.setCellStyle(highlightCellStyle);

									mapTemp.put(key.toString(), value);
									listTemp.add(mapTemp);
								}

							}
						}
					}

					currentRowNum++;
				}
			}
			dataMap.put(dataSetKey, listTemp);

			FileOutputStream out = new FileOutputStream(outputFile);
			workbook.write(out);
			out.flush();
			out.close();
		} catch (Exception e) {
			getLogger().error(EXCEPTION_PROCESSING_FILE, e);

		}

		return dataMap;
	}


	public static List<String> getExcelInputWorkBookandMatchedRows(String userInputFilePath, String keyCol,
			String keyColValue, List<String> colNames, String sheetName,TreeMap<String, String> inputMap) {

		List<String> expectedColumnList = new ArrayList<String>();
		if(keyCol!=null && keyCol.contains("#(")) {
			keyCol =  	keyCol.substring(keyCol.indexOf("#(")+2, keyCol.indexOf(")"));
		}
		String dataSetKey = null;
		Row headerRow = null;
		Object key = null;
		Object value = null;
		ZipSecureFile.setMinInflateRatio(0);

		try (FileInputStream fileINStream = new FileInputStream(userInputFilePath);
				XSSFWorkbook workbook = new XSSFWorkbook(fileINStream)) {
			XSSFSheet sheet = workbook.getSheet(sheetName);
			FormulaEvaluator evaluator = workbook.getCreationHelper().createFormulaEvaluator();
			int lastRow = sheet.getLastRowNum();
			int currentRowNum = 0;
			while (currentRowNum < lastRow) {
				if (isRowEmpty(sheet.getRow(currentRowNum))) {
					currentRowNum++;
					continue;
				}

				headerRow = sheet.getRow(currentRowNum);
				int primaryKeyInd = 0;
				for(int ind = headerRow.getFirstCellNum() ; ind <headerRow.getLastCellNum() ; ind++) {
					if (headerRow.getCell(ind).getStringCellValue().equalsIgnoreCase(keyCol)){
						primaryKeyInd = ind;
					} 
				}
				for (int j = currentRowNum + 1; j <= lastRow; j++) {
					if (isRowEmpty(sheet.getRow(j))) {
						currentRowNum = j + 1;
						break;
					}

					dataSetKey = getCellData(sheet.getRow(j).getCell(primaryKeyInd), evaluator).toString();
					if( keyColValue.equalsIgnoreCase(dataSetKey)) {
						for (int cellCounter = sheet.getRow(j).getFirstCellNum(); cellCounter < sheet.getRow(j).getLastCellNum(); cellCounter++) {
							key = getCellData(sheet.getRow(headerRow.getRowNum()).getCell(cellCounter), evaluator);
							Cell cell =   sheet.getRow(j).getCell(cellCounter);
							value = getCellData(cell, evaluator);
							if (value != null && key != null && (colNames.contains(key.toString())|| keyCol.equalsIgnoreCase(key.toString()))) {
								if(value.toString().contains("."))
								{
									int intTemp = Float.valueOf(value.toString()).intValue();
									value=String.valueOf(intTemp);
								}
								expectedColumnList.add("("+(key) +" : "+(value!=null ? value.toString() :"")+")");
								inputMap.put((String)key, (value!=null ? value.toString() :""));
							}
						}

						return expectedColumnList;
					}

					currentRowNum++;
				}
			}
		} catch (Exception e) {
			getLogger().error(EXCEPTION_PROCESSING_FILE, e);

		}

		return expectedColumnList;

	}

	public static Map<String, String> compareTwoExcelSheet(String userInputFilePath , String programInputFilePath, String userInputSheetName ,String programInputSheetName,List<String> colListToCompare  ) throws InvalidExcellFileOperationException
	{
		int statusCode = -1;
		ZipSecureFile.setMinInflateRatio(0);

		try (FileInputStream file = new FileInputStream(userInputFilePath); 
				XSSFWorkbook workbook = new XSSFWorkbook(userInputFilePath) ;
				FileInputStream programFile = new FileInputStream(programInputFilePath); 
				XSSFWorkbook programWorkbook = new XSSFWorkbook(programInputFilePath)) {
			XSSFSheet sheet = workbook.getSheet(userInputSheetName);
			CellStyle successStyle = workbook.createCellStyle();  
			// Setting Background color  
			successStyle.setFillForegroundColor(IndexedColors.GREEN.getIndex());  
			successStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

			CellStyle errorStyle = workbook.createCellStyle();  
			// Setting Background color  
			errorStyle.setFillForegroundColor(IndexedColors.RED.getIndex());  
			errorStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

			FormulaEvaluator evaluator = workbook.getCreationHelper().createFormulaEvaluator();
			// Iterate through each rows one by one
			Row rowHeader = sheet.getRow(sheet.getFirstRowNum());

			for (int rowInd = sheet.getFirstRowNum()+1; rowInd <sheet.getLastRowNum(); rowInd++) {
				Row row = sheet.getRow(rowInd);
				boolean isRowMachFound =	compareRowWithExcel(evaluator, rowHeader,row,programWorkbook,programInputSheetName,colListToCompare);
				if(isRowMachFound) {
					if(statusCode==2 || statusCode ==3) {
						statusCode =3;
					}else {
						statusCode = 1;
					}
					setcolorToCells(row, rowHeader, evaluator, colListToCompare, successStyle);
				}else {
					if(statusCode==1 || statusCode ==3) {
						statusCode =3;
					}else {
						statusCode = 2;
					}
					setcolorToCells(row, rowHeader, evaluator, colListToCompare, errorStyle);

				}
			}
			Map<String, String> pathMap = new HashMap<String, String>();
			pathMap.put("statusCode",statusCode+"");
			pathMap.put("userInputFilePath",writeWorkBook(workbook));
			pathMap.put("programInputFilePath",writeWorkBook(programWorkbook));

			return pathMap;

		}catch (Exception e) {
			e.printStackTrace();
			throw new InvalidExcellFileOperationException(e.getMessage());
		}

	}

	private static String writeWorkBook(XSSFWorkbook workbook) {
		File f = new File("tempFiles");
		File file = new File (f.getAbsolutePath()+"//"+new Date().getTime()+"excel.xlsx");
		try (FileOutputStream fos = new FileOutputStream(file)){
			workbook.write(fos);
			fos.flush();
			fos.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return file.getAbsolutePath();
	}

	private static boolean compareRowWithExcel(FormulaEvaluator rowEvaluator,Row rowHeader,Row row, XSSFWorkbook workbook,String sheetName, List<String> colListToCompare) {
		// TODO Auto-generated method stub
		XSSFSheet sheet = workbook.getSheet(sheetName);

		CellStyle highlightCellStyle = workbook.createCellStyle();  
		// Setting Background color  
		highlightCellStyle.setFillForegroundColor(IndexedColors.YELLOW.getIndex());  
		highlightCellStyle.setFillPattern(FillPatternType.BRICKS);
		FormulaEvaluator currentRowEvaluator = workbook.getCreationHelper().createFormulaEvaluator();
		Row currentRowHeader = sheet.getRow(sheet.getFirstRowNum());
		boolean isMatched = false;
		for (int rowInd = sheet.getFirstRowNum()+1; rowInd < sheet.getLastRowNum(); rowInd++) {
			Row currentRow = sheet.getRow(rowInd);
			isMatched = compareRowData(rowEvaluator, rowHeader, row, currentRowEvaluator, currentRowHeader, currentRow, colListToCompare);
			if(isMatched) {
				setcolorToCells(currentRow,currentRowHeader,currentRowEvaluator,colListToCompare,highlightCellStyle);
				break;
			}
		}
		return isMatched;
	}

	private static void setcolorToCells(Row currentRow, Row currentRowHeader, FormulaEvaluator currentRowEvaluator,
			List<String> colList, CellStyle highlightCellStyle) {
		for (int colInd = currentRow.getFirstCellNum(); colInd < currentRow.getLastCellNum(); colInd++) {
			String headerCellValue =  getCellData(currentRowHeader.getCell(colInd), currentRowEvaluator).toString();
			if(colList.contains(headerCellValue)) {
				currentRow.getCell(colInd).setCellStyle(highlightCellStyle);
			}
		}

	}

	private static boolean compareRowData(FormulaEvaluator rowEvaluator, Row rowHeader, Row row, FormulaEvaluator currentRowEvaluator,
			Row currentRowHeader ,  Row currentRow, List<String> colListToCompare) {
		TreeMap<String, String> rowData = getRowdataAsMap(row, rowHeader, rowEvaluator, colListToCompare);
		TreeMap<String, String> currentRowData = getRowdataAsMap(currentRow, currentRowHeader, currentRowEvaluator, colListToCompare);		
		return rowData.equals(currentRowData);

	}
	public static TreeMap<String, String  > getRowdataAsMap (Row currentRow ,Row currentRowHeader, FormulaEvaluator currentRowEvaluator, List colList){

		TreeMap<String, String> currentRowData = new TreeMap<String, String>();
		for (int colInd = currentRow.getFirstCellNum(); colInd < currentRow.getLastCellNum(); colInd++) {
			String headerCellValue =  getCellData(currentRowHeader.getCell(colInd), currentRowEvaluator).toString();
			String rowCellValue = getCellData(currentRow.getCell(colInd), currentRowEvaluator).toString();
			if(colList.contains(headerCellValue)) {
				currentRowData.put(headerCellValue, rowCellValue);
			}
		}
		return currentRowData;
	}

	public static Map<String, String> compareTwoExcelSheetAllcolumns(String userInputFilePath , String programInputFilePath, String userInputSheetName ,String programInputSheetName) throws InvalidExcellFileOperationException
	{
		int statusCode = -1;
		ZipSecureFile.setMinInflateRatio(0);

		try (FileInputStream file = new FileInputStream(userInputFilePath); 
				XSSFWorkbook workbook = new XSSFWorkbook(userInputFilePath) ;
				FileInputStream programFile = new FileInputStream(programInputFilePath); 
				XSSFWorkbook programWorkbook = new XSSFWorkbook(programInputFilePath)) {
			XSSFSheet sheet = workbook.getSheet(userInputSheetName);
			CellStyle successStyle = workbook.createCellStyle();  
			// Setting Background color  
			successStyle.setFillForegroundColor(IndexedColors.GREEN.getIndex());  
			successStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

			CellStyle errorStyle = workbook.createCellStyle();  
			// Setting Background color  
			errorStyle.setFillForegroundColor(IndexedColors.RED.getIndex());  
			errorStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

			FormulaEvaluator evaluator = workbook.getCreationHelper().createFormulaEvaluator();
			// Iterate through each rows one by one
			Row rowHeader = sheet.getRow(sheet.getFirstRowNum());

			for (int rowInd = sheet.getFirstRowNum()+1; rowInd <sheet.getLastRowNum(); rowInd++) {
				Row row = sheet.getRow(rowInd);
				boolean isRowMachFound =	compareRowWithExcelForAllcolumns(evaluator, rowHeader,row,programWorkbook,programInputSheetName);
				if(isRowMachFound) {
					if(statusCode==2 || statusCode ==3) {
						statusCode =3;
					}else {
						statusCode = 1;
					}
					setcolorToCellsForAllColumns(row, rowHeader, evaluator, successStyle);
				}else {
					if(statusCode==1 || statusCode ==3) {
						statusCode =3;
					}else {
						statusCode = 2;
					}
					setcolorToCellsForAllColumns(row, rowHeader, evaluator, errorStyle);

				}
			}
			Map<String, String> pathMap = new HashMap<String, String>();
			pathMap.put("statusCode",statusCode+"");
			pathMap.put("userInputFilePath",writeWorkBook(workbook));
			pathMap.put("programInputFilePath",writeWorkBook(programWorkbook));

			return pathMap;

		}catch (Exception e) {
			e.printStackTrace();
			throw new InvalidExcellFileOperationException(e.getMessage());
		}

	}



	private static boolean compareRowWithExcelForAllcolumns(FormulaEvaluator rowEvaluator,Row rowHeader,Row row, XSSFWorkbook workbook,String sheetName) {
		// TODO Auto-generated method stub
		XSSFSheet sheet = workbook.getSheet(sheetName);

		CellStyle highlightCellStyle = workbook.createCellStyle();  
		// Setting Background color  
		highlightCellStyle.setFillForegroundColor(IndexedColors.YELLOW.getIndex());  
		highlightCellStyle.setFillPattern(FillPatternType.BRICKS);
		FormulaEvaluator currentRowEvaluator = workbook.getCreationHelper().createFormulaEvaluator();
		Row currentRowHeader = sheet.getRow(sheet.getFirstRowNum());
		boolean isMatched = false;
		for (int rowInd = sheet.getFirstRowNum()+1; rowInd < sheet.getLastRowNum(); rowInd++) {
			Row currentRow = sheet.getRow(rowInd);
			isMatched = compareRowDataForAllColumns(rowEvaluator, rowHeader, row, currentRowEvaluator, currentRowHeader, currentRow);
			if(isMatched) {
				setcolorToCellsForAllColumns(currentRow,currentRowHeader,currentRowEvaluator,highlightCellStyle);
				break;
			}
		}
		return isMatched;
	}

	private static void setcolorToCellsForAllColumns(Row currentRow, Row currentRowHeader, FormulaEvaluator currentRowEvaluator,
			CellStyle highlightCellStyle) {
		for (int colInd = currentRow.getFirstCellNum(); colInd < currentRow.getLastCellNum(); colInd++) {
			String headerCellValue =  getCellData(currentRowHeader.getCell(colInd), currentRowEvaluator).toString();
			currentRow.getCell(colInd).setCellStyle(highlightCellStyle);

		}

	}

	private static boolean compareRowDataForAllColumns(FormulaEvaluator rowEvaluator, Row rowHeader, Row row, FormulaEvaluator currentRowEvaluator,
			Row currentRowHeader ,  Row currentRow) {
		TreeMap<String, String> rowData = getRowdataAsMapForAllcolumns(row, rowHeader, rowEvaluator);
		TreeMap<String, String> currentRowData = getRowdataAsMapForAllcolumns(currentRow, currentRowHeader, currentRowEvaluator);		
		return rowData.equals(currentRowData);

	}
	public static TreeMap<String, String  > getRowdataAsMapForAllcolumns (Row currentRow ,Row currentRowHeader, FormulaEvaluator currentRowEvaluator){

		TreeMap<String, String> currentRowData = new TreeMap<String, String>();
		for (int colInd = currentRow.getFirstCellNum(); colInd < currentRow.getLastCellNum(); colInd++) {
			String headerCellValue =  getCellData(currentRowHeader.getCell(colInd), currentRowEvaluator).toString();
			String rowCellValue = getCellData(currentRow.getCell(colInd), currentRowEvaluator).toString();
			currentRowData.put(headerCellValue, rowCellValue);

		}
		return currentRowData;
	}

	public static void deleteFolderCreatedBeforeNumOfRequestedDays(String botRootPath,int noOfDaysPrior) {
		try {
			File file = new File(botRootPath);
			if(file.exists() && file.isDirectory()) {
				File[] filelist = file.listFiles();
				for (int i = 0; filelist!=null && i < filelist.length; i++) {
					File innerFile = filelist[i];

					if(innerFile.isDirectory() && innerFile.getName().matches("[0-9]{1,}") && new Date().getTime()-(new Date(innerFile.lastModified()).getTime()) >= (87000000*noOfDaysPrior) ) {

						deleteDir(innerFile);


					}
				}

			}
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static   boolean   deleteDir(File file) {
		try {
			File[] contents = file.listFiles();
			if (contents != null) {
				for (File f : contents) {
					if (! Files.isSymbolicLink(f.toPath())) {
						deleteDir(f);
					}
				}
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return file.delete();
	}

	public static void deleteTempFiles() {
		try {

			File f = new File( "tempFiles");
			if(!f.exists()) {
				f.mkdir();
			}
			if(f.isDirectory()) {
				File[] fileList =  f.listFiles();
				for (int ind = 0; fileList != null && ind < fileList.length; ind++) {
					File file = fileList[ind];
					if(file.isFile()) {
						file.delete();
					}

				}
			}
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

	}
	public static Map<String, HashMap<String, Object>> getExcelDataAsHashMapwithFirstColumnasKey(File inputFile, String worksheet ,List<String> columnHeaderNames , String primaryKeyColName, String primaryKeyValue, File outputFile,boolean isHeaderHighlightNeeded , boolean isValueHighlightNeeded ){
		Map<String, HashMap<String, Object>> dataMap = new HashMap<>();
		HashMap<String, Object> mapTemp = null;
		if(primaryKeyColName!=null && primaryKeyColName.contains("#(")) {
			primaryKeyColName =  	primaryKeyColName.substring(primaryKeyColName.indexOf("#(")+2, primaryKeyColName.indexOf(")"));
		}
		String dataSetKey = null;
		Row headerRow = null;
		Object key = null;
		Object value = null;
		ZipSecureFile.setMinInflateRatio(0);

		try (FileInputStream fileINStream = new FileInputStream(inputFile);

				XSSFWorkbook workbook = new XSSFWorkbook(fileINStream)) {

			CellStyle highlightCellStyle = workbook.createCellStyle();  
			// Setting Background color  
			highlightCellStyle.setFillForegroundColor(IndexedColors.YELLOW.getIndex());  
			highlightCellStyle.setFillPattern(FillPatternType.BRICKS); 
			XSSFSheet sheet = workbook.getSheet(worksheet);
			FormulaEvaluator evaluator = workbook.getCreationHelper().createFormulaEvaluator();

			int lastRow = sheet.getLastRowNum();
			int currentRowNum = 0;
			while (currentRowNum < lastRow) {
				if (isRowEmpty(sheet.getRow(currentRowNum))) {
					currentRowNum++;
					continue;
				}

				headerRow = sheet.getRow(currentRowNum);
				int primaryKeyInd = 0;
				for(int ind = headerRow.getFirstCellNum() ; ind <headerRow.getLastCellNum() ; ind++) {
					if (headerRow.getCell(ind).getStringCellValue().equalsIgnoreCase(primaryKeyColName)){
						primaryKeyInd = ind;
					} 
					if(isHeaderHighlightNeeded
							&& (columnHeaderNames.contains(headerRow.getCell(ind).getStringCellValue()) || primaryKeyColName.equals(headerRow.getCell(ind).getStringCellValue()))) {
						headerRow.getCell(ind).setCellStyle(highlightCellStyle);

					}
				}
				for (int j = currentRowNum + 1; j <= lastRow; j++) {
					if (isRowEmpty(sheet.getRow(j))) {
						currentRowNum = j + 1;
						break;
					}

					dataSetKey = getCellData(sheet.getRow(j).getCell(primaryKeyInd), evaluator).toString();
					if( primaryKeyValue.equalsIgnoreCase(dataSetKey)) {
						mapTemp = new LinkedHashMap<>();
						for (int cellCounter = sheet.getRow(j).getFirstCellNum(); cellCounter < sheet.getRow(j).getLastCellNum(); cellCounter++) {

							key = getCellData(sheet.getRow(headerRow.getRowNum()).getCell(cellCounter), evaluator);
							Cell cell =   sheet.getRow(j).getCell(cellCounter);
							value = getCellData(cell, evaluator);

							if (value != null && key != null) {
								if(isValueHighlightNeeded && 
										columnHeaderNames!=null 
										&&primaryKeyColName !=null
										&& primaryKeyValue != null 
										&& (columnHeaderNames.contains(key) || primaryKeyColName.equals(key))
										&&  primaryKeyValue.equalsIgnoreCase(dataSetKey)) {
									cell.setCellStyle(highlightCellStyle);
								}
								mapTemp.put(key.toString(), value);

							}
						}
						dataMap.put(dataSetKey, mapTemp);
						FileOutputStream out = new FileOutputStream(outputFile);
						workbook.write(out);
						out.flush();
						out.close();
						return dataMap;

					}

					currentRowNum++;
				}
			}
			FileOutputStream out = new FileOutputStream(outputFile);
			workbook.write(out);
			out.flush();
			out.close();
		} catch (Exception e) {
			getLogger().error(EXCEPTION_PROCESSING_FILE, e);

		}

		return dataMap;
	}

	public static Map<String, HashMap<String, Object>> getExcelDataAsHashMapwithPrimaryAndSecondaryColumnAsKey(File inputFile, String worksheet ,List<String> columnHeaderNames , String primaryKeyColName, String primaryKeyValue, String secondaryKeyColName, String secondaryKeyValue, File outputFile,boolean isHeaderHighlightNeeded , boolean isValueHighlightNeeded ){
		Map<String, HashMap<String, Object>> dataMap = new HashMap<>();
		HashMap<String, Object> mapTemp = null;
		/*if(primaryKeyColName!=null && primaryKeyColName.contains("#(")) {
		primaryKeyColName =  	primaryKeyColName.substring(primaryKeyColName.indexOf("#(")+2, primaryKeyColName.indexOf(")"));
	 }
	 if(secondaryKeyColName!=null && secondaryKeyColName.contains("#(")) {
		 secondaryKeyColName =  	secondaryKeyColName.substring(secondaryKeyColName.indexOf("#(")+2, secondaryKeyColName.indexOf(")"));
	 }*/
		String dataSetKey = null;
		String dataSetSecondKey = null;
		Row headerRow = null;
		Object key = null;
		Object value = null;
		ZipSecureFile.setMinInflateRatio(0);

		try (FileInputStream fileINStream = new FileInputStream(inputFile);
				XSSFWorkbook workbook = new XSSFWorkbook(fileINStream)) {
			CellStyle highlightCellStyle = workbook.createCellStyle();  
			// Setting Background color  
			highlightCellStyle.setFillForegroundColor(IndexedColors.YELLOW.getIndex());  
			highlightCellStyle.setFillPattern(FillPatternType.BRICKS); 
			XSSFSheet sheet = workbook.getSheet(worksheet);
			FormulaEvaluator evaluator = workbook.getCreationHelper().createFormulaEvaluator();

			int lastRow = sheet.getLastRowNum();
			int currentRowNum = 0;
			while (currentRowNum < lastRow) {
				if (isRowEmpty(sheet.getRow(currentRowNum))) {
					currentRowNum++;
					continue;
				}

				headerRow = sheet.getRow(currentRowNum);
				int primaryKeyInd = 0;
				for(int ind = headerRow.getFirstCellNum() ; ind <headerRow.getLastCellNum() ; ind++) {
					if (headerRow.getCell(ind).getStringCellValue().equalsIgnoreCase(primaryKeyColName)){
						primaryKeyInd = ind;
					} 
					if(isHeaderHighlightNeeded
							&& (columnHeaderNames.contains(headerRow.getCell(ind).getStringCellValue()) || primaryKeyColName.equals(headerRow.getCell(ind).getStringCellValue()))) {
						headerRow.getCell(ind).setCellStyle(highlightCellStyle);

					}
				}

				int secondaryKeyInd = 0;
				for(int ind = headerRow.getFirstCellNum() ; ind <headerRow.getLastCellNum() ; ind++) {
					if (headerRow.getCell(ind).getStringCellValue().equalsIgnoreCase(secondaryKeyColName)){
						secondaryKeyInd = ind;
					} 
					if(isHeaderHighlightNeeded
							&& (columnHeaderNames.contains(headerRow.getCell(ind).getStringCellValue()) || secondaryKeyColName.equals(headerRow.getCell(ind).getStringCellValue()))) {
						headerRow.getCell(ind).setCellStyle(highlightCellStyle);

					}
				}

				for (int j = currentRowNum + 1; j <= lastRow; j++) {
					if (isRowEmpty(sheet.getRow(j))) {
						currentRowNum = j + 1;
						break;
					}

					dataSetKey = getCellData(sheet.getRow(j).getCell(primaryKeyInd), evaluator).toString();
					if (dataSetKey.contains(".0")) {
						int intTemp = Float.valueOf(dataSetKey).intValue();
						dataSetKey=String.valueOf(intTemp);
					}
					dataSetSecondKey = getCellData(sheet.getRow(j).getCell(secondaryKeyInd), evaluator).toString();
					if (dataSetSecondKey.contains(".0")) {
						int intTemp = Float.valueOf(dataSetSecondKey).intValue();
						dataSetSecondKey=String.valueOf(intTemp);
					}

					if(primaryKeyValue.equalsIgnoreCase(dataSetKey) 
							&& secondaryKeyValue.equalsIgnoreCase(dataSetSecondKey)) {
						mapTemp = new LinkedHashMap<>();
						for (int cellCounter = sheet.getRow(j).getFirstCellNum(); cellCounter < sheet.getRow(j).getLastCellNum(); cellCounter++) {
							key = getCellData(sheet.getRow(headerRow.getRowNum()).getCell(cellCounter), evaluator);
							Cell cell =   sheet.getRow(j).getCell(cellCounter);
							value = getCellData(cell, evaluator);

							if (value != null && key != null) {
								if(isValueHighlightNeeded && 
										columnHeaderNames!=null 
										&&primaryKeyColName !=null
										&& primaryKeyValue != null 
										&& (columnHeaderNames.contains(key.toString()) || primaryKeyColName.equals(key.toString()) || secondaryKeyColName.equals(key.toString()))
										&& primaryKeyValue.equalsIgnoreCase(dataSetKey)
										&& secondaryKeyValue.equalsIgnoreCase(dataSetSecondKey)){
									cell.setCellStyle(highlightCellStyle);

									mapTemp.put(key.toString(), value);
								}

							}
						}
						dataMap.put(dataSetKey, mapTemp);
						FileOutputStream out = new FileOutputStream(outputFile);
						workbook.write(out);
						out.flush();
						out.close();
						return dataMap;
					}

					currentRowNum++;
				}
			}
			FileOutputStream out = new FileOutputStream(outputFile);
			workbook.write(out);
			out.flush();
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
			getLogger().error(EXCEPTION_PROCESSING_FILE, e);

		}

		return dataMap;
	}

	/** gets list values from a column from a given sheet in excel **/
	public static String[] getCellListValues(int rowNumber, String fileName, String sheetName, String columnHeader){
		String[] fileNameValue = fileName.split("\\.");
		File file = new File(fileName);
		String[] listValues=new String[]{};

		if(fileNameValue[1].equalsIgnoreCase("xls")) {

			try (FileInputStream inputStream = new FileInputStream(file);
					Workbook workbook = new HSSFWorkbook(inputStream);) {
				log.info(Arrays.toString(fileNameValue));
				Sheet sheet = workbook.getSheet(sheetName);		
				Row row = sheet.getRow(rowNumber);
				int columnNumber = getColumnNumber(rowNumber,columnHeader,sheet);
				if(columnNumber!=-1)
					listValues = getDataValidationListValues(sheet,row.getCell(columnNumber));
				else
					listValues = new String[] {"ColumnName not found"}; 

			} catch (Exception e) {
				getLogger().error(EXCEPTION_PROCESSING_FILE, e);
			}

		} else {

			try (FileInputStream inputStream = new FileInputStream(file);
					Workbook workbook = new XSSFWorkbook(inputStream);) {
				log.info(Arrays.toString(fileNameValue));
				Sheet sheet = workbook.getSheet(sheetName);		
				Row row = sheet.getRow(rowNumber);
				int columnNumber = getColumnNumber(rowNumber,columnHeader,sheet);
				if(columnNumber!=-1)
					listValues = getDataValidationListValues(sheet,row.getCell(columnNumber));
				else
					listValues = new String[] {"ColumnName not found"}; 

			} catch (Exception e) {
				getLogger().error(EXCEPTION_PROCESSING_FILE, e);
			} 
		}
		return listValues;
	}

	/** gets all data validation values from a column from a given sheet **/	 
	public static String[] getDataValidationListValues(Sheet sheet, Cell cell) {
		String[] explicitListValues=new String[]{};
		List<? extends DataValidation> dataValidations = sheet.getDataValidations(); // get sheet's data validations
		for (DataValidation dataValidation : dataValidations) {
			CellRangeAddressList addressList = dataValidation.getRegions(); // get Excel cell ranges the data validation applies to
			CellRangeAddress[] addresses = addressList.getCellRangeAddresses();
			for (CellRangeAddress address : addresses) {
				if (address.isInRange(cell)) { // if the cell is in that cell range
					DataValidationConstraint constraint = dataValidation.getValidationConstraint();
					if (constraint.getValidationType() == DataValidationConstraint.ValidationType.LIST) 
						explicitListValues = constraint.getExplicitListValues(); 
				}
			}
		}
		return explicitListValues;
	}

	/** enters given data in the given row and column of excel sheet **/ 
	public static String enterCellValue(int rowNumber, String fileName, String sheetName, String columnName, String valuetobeEntered) {
		String[] fileNameValue = fileName.split("\\.");
		File file = new File(fileName);

		if(fileNameValue[1].equalsIgnoreCase("xls")) {
			try (FileInputStream inputStream = new FileInputStream(file);
					Workbook workbook = new HSSFWorkbook(inputStream);){
				log.info(Arrays.toString(fileNameValue));
				Sheet sheet = workbook.getSheet(sheetName);		
				//int columnNumber = getColumnNumber(0,columnName,sheet);//kirthika changes why hard coded here,again assuming first row is header row
				int columnNumber = getColumnNumberForExcel(columnName,sheet);//kirthika changes why hard coded here,again assuming first row is header row
				if(columnNumber!=-1) {
					Row row = sheet.getRow(rowNumber);
					if(row==null)
						row = sheet.createRow(rowNumber);
					Cell cell = row.createCell(columnNumber);	           
					cell.setCellValue(valuetobeEntered);					  				  
					inputStream.close();
					FileOutputStream outputStream = new FileOutputStream(new File(fileName));
					workbook.write(outputStream);
					workbook.close();
					outputStream.close();
				}
				else {
					inputStream.close();
					workbook.close();
					return "ColumnName not found"; 					 
				}		 		
			} catch (Exception e) {
				// TODO Auto-generated catch block
				getLogger().error(EXCEPTION_PROCESSING_FILE, e);
			}

		} else {
			try (FileInputStream inputStream = new FileInputStream(file);
					Workbook workbook = new XSSFWorkbook(inputStream);){

				log.info(Arrays.toString(fileNameValue));

				Sheet sheet = workbook.getSheet(sheetName);		
				int columnNumber = getColumnNumberForExcel(columnName,sheet);//kirthika changes why hard coded here,again assuming first row is header row
				if(columnNumber!=-1) {
					Row row = sheet.getRow(rowNumber);
					if(row==null)
						row = sheet.createRow(rowNumber);
					Cell cell = row.createCell(columnNumber);	
					cell.setCellValue(valuetobeEntered);
					inputStream.close();
					FileOutputStream outputStream = new FileOutputStream(new File(fileName));
					workbook.write(outputStream);
					workbook.close();
					outputStream.close();
				}
				else {
					inputStream.close();
					workbook.close();
					return "ColumnName not found"; 					 
				}		 		
			} catch (Exception e) {
				// TODO Auto-generated catch block
				getLogger().error(EXCEPTION_PROCESSING_FILE, e);
			}
		}
		return "1";
	}
// 
	private static int getColumnNumberForExcel(String colHeader, Sheet mySheet) {
		int colNum = -1;
		int lastRow = mySheet.getLastRowNum();
  		int currentRowNum = 0;
  		Row headerRow = null;
    	while (currentRowNum < lastRow) {
			if (isRowEmpty(mySheet.getRow(currentRowNum))) {
				currentRowNum++;
				continue;
			}
			headerRow = mySheet.getRow(currentRowNum);
			int primaryKeyInd = 0;
			for(int ind = headerRow.getFirstCellNum() ; ind <headerRow.getLastCellNum() ; ind++) {
				if (headerRow.getCell(ind).getStringCellValue().equalsIgnoreCase(colHeader)){
					primaryKeyInd = ind;
					return primaryKeyInd;
				} 
			}
					currentRowNum++;
    	}

		return colNum;
	}
	/** selects given data from the column list of excel sheet **/
	public static String selectCellValue(int rowNumber, String fileName, String sheetName, String columnName, String valuetobeSelected) {
		String[] fileNameValue = fileName.split("\\.");
		String result ="1";
		File file = new File(fileName);

		if(fileNameValue[1].equalsIgnoreCase("xls")) {
			try (FileInputStream inputStream = new FileInputStream(file);
					Workbook workbook = new HSSFWorkbook(inputStream);){
				log.info(Arrays.toString(fileNameValue));

				Sheet sheet = workbook.getSheet(sheetName);		
				int columnNumber = getColumnNumber(0,columnName,sheet);
				if(columnNumber!=-1) {
					Row row = sheet.getRow(rowNumber);
					if(row==null)
						row = sheet.createRow(rowNumber);
					int flag=0;						  	
					Cell cell = row.createCell(columnNumber);
					String[] dataValidationListValues = getDataValidationListValues(sheet, cell);				            
					for (String dataValidationListValue : dataValidationListValues) {
						log.info(dataValidationListValue);
						if(dataValidationListValue.equalsIgnoreCase(valuetobeSelected)) {
							cell.setCellValue(valuetobeSelected);
							flag=1;
							break;
						}
					}
					if(flag==0)
						result= "Value not part of the Column's list: "+dataValidationListValues.toString(); 	

					inputStream.close();
					FileOutputStream outputStream = new FileOutputStream(new File(fileName));
					workbook.write(outputStream);
					workbook.close();
					outputStream.close();
				}
				else {
					inputStream.close();
					workbook.close();
					result= "ColumnName not found"; 					 
				}		     		 		
			} catch (Exception e) {
				// TODO Auto-generated catch block
				getLogger().error(EXCEPTION_PROCESSING_FILE, e);
			}
		} else {
			{
				try (FileInputStream inputStream = new FileInputStream(file);
						Workbook workbook = new XSSFWorkbook(inputStream);){
					log.info(Arrays.toString(fileNameValue));

					Sheet sheet = workbook.getSheet(sheetName);		
					int columnNumber = getColumnNumber(0,columnName,sheet);
					if(columnNumber!=-1) {
						Row row = sheet.getRow(rowNumber);
						if(row==null)
							row = sheet.createRow(rowNumber);
						int flag=0;						  	
						Cell cell = row.createCell(columnNumber);
						String[] dataValidationListValues = getDataValidationListValues(sheet, cell);				            
						for (String dataValidationListValue : dataValidationListValues) {
							log.info(dataValidationListValue);
							if(dataValidationListValue.equalsIgnoreCase(valuetobeSelected)) {
								cell.setCellValue(valuetobeSelected);
								flag=1;
								break;
							}
						}
						if(flag==0)
							result= "Value not part of the Column's list: "+dataValidationListValues.toString(); 	

						inputStream.close();
						FileOutputStream outputStream = new FileOutputStream(new File(fileName));
						workbook.write(outputStream);
						workbook.close();
						outputStream.close();
					}
					else {
						inputStream.close();
						workbook.close();
						result= "ColumnName not found"; 					 
					}		     		 		
				} catch (Exception e) {
					// TODO Auto-generated catch block
					getLogger().error(EXCEPTION_PROCESSING_FILE, e);
				}
			}
		}
		return result;
	}

	/**
	 * reads data from a given sheet in excel returning all column Headers
	 * @throws IOException 
	 * @throws FileNotFoundException 
	 */
	public static List<String> getHdrDataAsArrayList(String filepath, String worksheet, int hdrrownum) {
		String[] fileNameValue = filepath.split("\\.");		
		List<String> hdrdata = new ArrayList<String>();

		if(fileNameValue[1].equalsIgnoreCase("xls")) {

			try (FileInputStream file = new FileInputStream(filepath);
					Workbook workbook = new HSSFWorkbook(file);){
				Sheet sheet = workbook.getSheet(worksheet);
				Row row = sheet.getRow(hdrrownum); 
				for(int i =0; i<row.getLastCellNum();i++)
				{
					Cell cell =row.getCell(i);
					DataFormatter formatter = new DataFormatter();
					String str = formatter.formatCellValue(cell);
					//singleRows.add(getHdrCellData(cell, evaluator));		         	
					hdrdata.add(str.trim());
				}
			} catch (Exception e) {
				getLogger().error(EXCEPTION_PROCESSING_FILE, e);
			}
		} else {
			try (FileInputStream file = new FileInputStream(filepath);
					Workbook workbook = new XSSFWorkbook(file);){
				Sheet sheet = workbook.getSheet(worksheet);
				Row row = sheet.getRow(hdrrownum); 
				for(int i =0; i<row.getLastCellNum();i++)
				{
					Cell cell =row.getCell(i);
					DataFormatter formatter = new DataFormatter();
					String str = formatter.formatCellValue(cell);
					//singleRows.add(getHdrCellData(cell, evaluator));		         	
					hdrdata.add(str.trim());
				}
			} catch (Exception e) {
				getLogger().error(EXCEPTION_PROCESSING_FILE, e);
			}
		}
		return hdrdata;

	}

	private static Integer getColumnNumber(int rowNumber,String colHeader, Sheet strSheetName) {
		int colNum = -1;

		Row myRowCols = strSheetName.getRow(rowNumber);
		for (int j = 0; j < myRowCols.getLastCellNum(); j++) {
			String curColName = myRowCols.getCell(j).getStringCellValue();
			if (curColName.contentEquals(colHeader)) {
				colNum = j;
				break;
			}
		}
		return colNum;
	}

	/**
	 * Reads Data from CSV and retrieve specified row data based on column- filters -2
	 */

	public static String getCellValuecsvTwoFilters(String strFilePath, String strSheetName,String strColName, String clmFilter1, String clmValue1, String clmFilter2, String clmValue2) throws IOException {

		String compareoutput = null;
		Scanner scanner = new Scanner(new File(strFilePath),"UTF-16");
		boolean flag=false;
		ArrayList<String> columnHeaders = new ArrayList<String>();
		ArrayList<HashMap<String,String>> csvDetails = new ArrayList<HashMap<String,String>>();

		String[] firstRow =scanner.nextLine().split("\t");
		for(String value: firstRow)
			columnHeaders.add(value.toString());	
		while (scanner.hasNextLine()) {  
			HashMap<String,String> columnValues = new HashMap<String,String>();
			String[] colValues =scanner.nextLine().split("\t");
			for(int i=0;i<colValues.length;i++) {

				String Colact = colValues[i].replace("\"", "");
				columnValues.put(columnHeaders.get(i),Colact);
			}

			csvDetails.add(columnValues);
		}

		scanner.close();
		for(int j=0;j<csvDetails.size();j++) {
			if(csvDetails.get(j).get(clmFilter1).equalsIgnoreCase(clmValue1)&&csvDetails.get(j).get(clmFilter2).equalsIgnoreCase(clmValue2)) {
				compareoutput = csvDetails.get(j).get(strColName);
				System.out.println("The filed value of  "+strColName+" is " +compareoutput);
				flag=true;
			}
		}

		if(!flag)
			getLogger().error(EXCEPTION_DATA_RETREVAL);
		return compareoutput;

	}

	/**
	 * Reads Data from CSV and retrieve specified row data based on column- filters -3
	 */
	public static String getCellValuecsvThreeFilters(String strFilePath, String strSheetName,String strColName, String clmFilter1, String clmValue1, String clmFilter2, String clmValue2,String clmFilter3, String clmValue3) throws IOException {

		String compareoutput = null;
		Scanner scanner = new Scanner(new File(strFilePath),"UTF-16");
		boolean flag=false;
		ArrayList<String> columnHeaders = new ArrayList<String>();
		ArrayList<HashMap<String,String>> csvDetails = new ArrayList<HashMap<String,String>>();

		String[] firstRow =scanner.nextLine().split("\t");
		for(String value: firstRow)
			columnHeaders.add(value.toString());	
		while (scanner.hasNextLine()) {  
			HashMap<String,String> columnValues = new HashMap<String,String>();
			String[] colValues =scanner.nextLine().split("\t");
			for(int i=0;i<colValues.length;i++) {

				String Colact = colValues[i].replace("\"", "");
				columnValues.put(columnHeaders.get(i),Colact);
			}

			csvDetails.add(columnValues);
		}

		scanner.close();
		for(int j=0;j<csvDetails.size();j++) {
			if(csvDetails.get(j).get(clmFilter1).equalsIgnoreCase(clmValue1)&&csvDetails.get(j).get(clmFilter2).equalsIgnoreCase(clmValue2)&&csvDetails.get(j).get(clmFilter3).equalsIgnoreCase(clmValue3)) {
				compareoutput = csvDetails.get(j).get(strColName);
				System.out.println("The filed value of  "+strColName+" is " +compareoutput);
				flag=true;
			}
		}

		if(!flag)
			getLogger().error(EXCEPTION_DATA_RETREVAL);
		return compareoutput;

	}


}