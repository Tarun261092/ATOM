package automation.library.common.similarity;

public enum SimilarityLevel {
    EXACT_THRESHOLD(1),
    NEAR_MATCH(0.9),
    ABOVE_THRESHOLD(0.85),
    BELOW_THRESHOLD(0.7);

    private double similarityVal;

    SimilarityLevel(double similarityVal) {
        this.similarityVal = similarityVal;
    }

    public double getValue() {
        return similarityVal;
    }
}
