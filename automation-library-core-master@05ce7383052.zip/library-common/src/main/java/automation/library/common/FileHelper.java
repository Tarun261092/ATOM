package automation.library.common;

import com.google.gson.Gson;
import org.apache.commons.configuration2.PropertiesConfiguration;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.comparator.LastModifiedFileComparator;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.maven.model.Model;
import org.apache.maven.model.io.xpp3.MavenXpp3Reader;
import org.codehaus.plexus.util.xml.pull.XmlPullParserException;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class FileHelper {
    private static final int MAX_DEPTH = 10;
    private static final String EXCEPTION_PROCESSING_FILE = "exception processing file";
    public static String LastModifiedFinal;

    private FileHelper() { //Utility class
    }

    private static Logger getLogger() {
        return LogManager.getLogger(FileHelper.class);
    }

    public static String findFileInPath(String rootDir, String fileName) {
        Path filePath = Paths.get(rootDir);
        String fullPath = null;
        String fileNameWithTrailingWhiteSpace = allowWhiteSpaceInFileName(fileName);

        try (Stream<Path> files = Files.find(filePath, MAX_DEPTH,
                                             (path, attributes) -> {
                                                 File file = path.toFile();
                                                 return !file.isDirectory() &&
                                                        file.getName().matches(fileNameWithTrailingWhiteSpace);
                                             })) {

            final List<Path> filesList = files.collect(Collectors.toList());

            if (!filesList.isEmpty()) {
                fullPath = filesList.get(0).toString();

                if (filesList.size() > 1) {
                    getLogger().warn("Found more than one file match. Returning first match");
                }
            }
        } catch (IOException e) {
            return null;
        }

        return fullPath;
    }

    private static String allowWhiteSpaceInFileName(String fileName) {
        return String.join("\\s*\\.",
                           escapeCaptureGroups(FilenameUtils.getBaseName(fileName)),
                           FilenameUtils.getExtension(fileName));
    }

    private static String escapeCaptureGroups(String baseName) {
        return baseName.replace("(", "\\(")
                       .replace(")", "\\)");
    }

    public static String getFileNameWithoutExtension(String path) {
        if (path != null) {
            String fileName = Paths.get(path).getFileName().toString();
            fileName = FilenameUtils.removeExtension(fileName);

            return fileName;
        } else {
            return null;
        }
    }

    public static String getFileNameExtension(String path) {
        if (path != null) {
            String fileName = Paths.get(path).getFileName().toString();
            fileName = FilenameUtils.getExtension(fileName);

            return fileName;
        } else {
            return null;
        }
    }


    public static String getFileAsString(String jsFilePath, String delimeter) throws IOException {
        String stringToReturn = null;

        //remove line breaks
        try (BufferedReader br = Files.newBufferedReader(Paths.get(jsFilePath), StandardCharsets.ISO_8859_1)) {
            stringToReturn = br.lines().collect(Collectors.joining(delimeter));
        } catch (IOException | NullPointerException e) {
            getLogger().error(e.getMessage());
        }

        return stringToReturn;
    }

    public static String getFileAsString(InputStream in, String delimiter) throws IOException {
        String stringToReturn = null;

        //remove line breaks
        try (BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.ISO_8859_1))) {
            stringToReturn = br.lines().collect(Collectors.joining(delimiter));
        } catch (IOException e) {
            getLogger().error(e.getMessage());
        }

        return stringToReturn;
    }

    public static String findMostRecentFileByExtension(String rootDir, String fileExtension) {
        Path filePath = Paths.get(rootDir);
        String fullPath = null;

        try (Stream<Path> files = Files.find(filePath, MAX_DEPTH,
                                             (path, attributes) -> {
                                                 File file = path.toFile();
                                                 return !file.isDirectory() &&
                                                        FilenameUtils.getExtension(file.getName()).matches(fileExtension);
                                             })) {

            final List<File> filesList = files.map(Path::toFile)
                                              .sorted(LastModifiedFileComparator.LASTMODIFIED_REVERSE)
                                              .collect(Collectors.toList());

            if (!filesList.isEmpty()) {
                fullPath = filesList.get(0).toString();

                if (filesList.size() > 1) {
                    getLogger().warn("Found more than one file match. Returning first match");
                }
            }
        } catch (IOException e) {
            return null;
        }

        return fullPath;
    }

    public static Set<String> getMatchingFilesFromDirectory(String inputDir, String extension) {
        try (Stream<Path> stream = Files.walk(Paths.get(inputDir))) {
            return stream.filter(file -> !Files.isDirectory(file))
                         .filter(f -> (f.toString().endsWith(extension) || f.toString().endsWith(extension.toUpperCase())))
                         .map(Path::getFileName)
                         .map(Path::toString)
                         .collect(Collectors.toSet());
        } catch (IOException e) {
            getLogger().error(e);
            return Collections.emptySet();
        }
    }

    public static Set<Path> getMatchingFilePathsFromDirectory(String inputDir, String extension) {
        try (Stream<Path> stream = Files.walk(Paths.get(inputDir))) {
            return stream.filter(file -> !Files.isDirectory(file))
                         .filter(f -> (f.toString().endsWith(extension) || f.toString().endsWith(extension.toUpperCase())))
                         .collect(Collectors.toSet());
        } catch (IOException e) {
            getLogger().error(e);
            return Collections.emptySet();
        }
    }

    public static Map<String, Object> convertPropertyFileToMap(String path) {
        Properties properties = new Properties();
        Map<String, Object> propMap = new HashMap<>();
        try (FileInputStream stream = new FileInputStream(path)){
            properties.load(stream);
            propMap.putAll(properties.entrySet().stream()
                                     .collect(Collectors.toMap(e -> e.getKey().toString(),
                                                               Map.Entry::getValue)));
        } catch (IOException e) {
            getLogger().error(EXCEPTION_PROCESSING_FILE, e);
        } 
        return propMap;
    }


    public static Map<String, String> loadJsonMapFromResources(Class clazz, String fullPathToFile) {
        InputStream is = clazz.getClassLoader().getResourceAsStream(fullPathToFile);

        if(is != null) {
            return new Gson().fromJson(new InputStreamReader(is), Map.class);
        } else {
            return null;
        }
    }

    public static Map<String, Object> loadJsonMapOfObjectsFromResources(Class clazz, String fullPathToFile) {
        InputStream is = clazz.getClassLoader().getResourceAsStream(fullPathToFile);

        if(is != null) {
            return new Gson().fromJson(new InputStreamReader(is), Map.class);
        } else {
            return null;
        }
    }

    public static void writeDataToFile(String filePath, String valToWrite) {
        try (BufferedWriter bw = Files.newBufferedWriter(Paths.get(filePath))) {
            bw.write(valToWrite);
        } catch (IOException e) {
            getLogger().error(e);
        }
    }
    
    public static String getFirstTwoLines(String filePath) {
        try(BufferedReader br = Files.newBufferedReader(Paths.get(filePath))) {
            StringBuilder line = new StringBuilder();

            for (int i = 0; i < 2; i++) {
                line.append(br.readLine());
                line.append("\n");
            }

            return line.toString();
        } catch (IOException e) {
            getLogger().error(e);
            return "";
        }
    }

    public static Path writeTempFile(String prefix, String extension, String fileContents) {
        try {
            if(!extension.contains(".")) { extension = "." + extension; }

            Path tempFile = Files.createTempFile(prefix, extension);
            tempFile.toFile().deleteOnExit();

            Files.write(tempFile, fileContents.getBytes(StandardCharsets.UTF_8));

            return tempFile;
        } catch (IOException e) {
            getLogger().error(e);
            return null;
        }
    }

    public static void loadDataParametersFromPropsFile(String propFilePath, String paramPrefix) {
        PropertiesConfiguration props = Property.getProperties(propFilePath);
        if(props != null) {
            Iterator<String> e = props.getKeys();
            while (e.hasNext()) {
                String param = e.next();
                if (param != null && param.matches("^" + Pattern.quote(paramPrefix) + "\\.\\w+$")) {
                    TestContext.getInstance().testdataPut(param.split("\\.")[1], Property.getProperty(propFilePath, param));
                }
            }
        }
    }

    public static List<File> getListOfFolders(String path){
        File dir = new File(path);
        File[] files = dir.listFiles();
        List<File> listFolders = new ArrayList<>();
        if (files != null) {
            for (File file : files) {
                if (file.isDirectory()) {
                    listFolders.add(file);
                }
            }
            return listFolders;
        } else {
            return listFolders;
        }
    }

    public static List<String> getListOfFoldersName(String path){
        File dir = new File(path);
        File[] files = dir.listFiles();
        List<String> listFolders = new ArrayList<>();
        if (files != null) {
            for (File file : files) {
                if (file.isDirectory()) {
                    listFolders.add(file.getName());
                }
            }
            return listFolders;
        } else {
            return listFolders;
        }
    }


    public static Map<String, String> getPropertiesAsMap(String propFilePath) {
        PropertiesConfiguration props = Property.getProperties(propFilePath);
        Map<String, String> properties = new HashMap<>();
        if (props != null) {
            Iterator<String> iterator = props.getKeys();
            while (iterator.hasNext()) {
                String key = iterator.next();
                if (key != null) {
                    properties.put(key, props.getProperty(key).toString());
                }
            }
        }
        return properties;
    }

    public static String getLibraryEngineVersion() throws IOException, XmlPullParserException {
        MavenXpp3Reader reader = new MavenXpp3Reader();
        Model model = null;
        if ((new File("pom.xml")).exists())
            model = reader.read(new FileReader("pom.xml"));
        return Objects.requireNonNull(model).getProperties().getProperty("library.engine.version");
    }
    
    public static String getLatestFilefromDir(String dirPath) 
   	{
   		File dir = new File(dirPath);
   		File[] files = dir.listFiles();
   		if (files == null || files.length == 0) {
   			return null;
   		}
   		
   		File lastModifiedFile = files[0];
   		for (int i = 1; i < files.length; i++) {
   			if (lastModifiedFile.lastModified() < files[i].lastModified()) {
   				lastModifiedFile = files[i];
   			}
   		}
   		LastModifiedFinal = lastModifiedFile.getName();
   		return LastModifiedFinal;
   	}
    
    public static String getLatestFileWithNamefromDir(String dirPath,String partialFileName) 
    {	
    	
    	File dir = new File(dirPath);
    	File[] files = dir.listFiles(new FilenameFilter(){
            @Override
            public boolean accept(File dir, String name) {
                return name.contains(partialFileName);
            }}); 
    	if (files == null || files.length == 0) {
    		System.out.print("No files Found");
    	}
    	 
    	File lastModifiedFile = files[0];	
    	System.out.print(files.length);	
    	for (int k = 1; k < files.length; k++) 
    	{
    		if (lastModifiedFile.lastModified() < files[k].lastModified()) 
    		{
    			String fileName = files[k].getName();
    			if(fileName.contains(partialFileName))
    			{
    				lastModifiedFile = files[k];
    			}
    		}
    	}
    	LastModifiedFinal = lastModifiedFile.getName();
    	TestContext.getInstance().testdataPut("latestFilePath", dirPath+LastModifiedFinal);
    	return LastModifiedFinal;
    }
    
    public static void copyFileFromInputStream(InputStream sourceInputStream , String destinationPath ) {
    	try(FileOutputStream fos = new FileOutputStream(destinationPath);){
				while (sourceInputStream.available()>0) {
					fos.write(sourceInputStream.read());
				}
				fos.flush();
				fos.close();
				sourceInputStream.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
   		 
		
	}
    
    /*Copy file from one location to another*/
    
public static void copyFileFromOneLocationToAnother(String fileName, String sourcePath, String targetPath) {
    	
    	File source = new File(sourcePath+fileName);
    	File dest = new File(targetPath);
    	
    	try {
    	    FileUtils.copyFileToDirectory(source, dest);
    	    
    	} catch (IOException e) {
    	    e.printStackTrace();
    	}
    	
    }

}