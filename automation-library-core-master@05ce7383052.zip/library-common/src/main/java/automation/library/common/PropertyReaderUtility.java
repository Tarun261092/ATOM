package automation.library.common;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

public class PropertyReaderUtility {
	private  Map<String, Properties> fileProperties = new HashMap<>();
	private static PropertyReaderUtility instance = null;
	private PropertyReaderUtility() {
		
	}
	
	private static PropertyReaderUtility getInstance() {
		if(instance == null) {
			instance = new PropertyReaderUtility();
		}
		return instance;
	}
	
	public static Properties getProperties(String pathToPropertyFile) {
	PropertyReaderUtility propertiesReader =	getInstance();
		Properties properties = propertiesReader.fileProperties.get(pathToPropertyFile);
		if(properties==null) {
			InputStream is = PropertyReaderUtility.class.getClassLoader().getResourceAsStream(pathToPropertyFile);
			properties = new Properties();
			try {
				properties.load(is);
				propertiesReader.fileProperties.put(pathToPropertyFile, properties);
			} catch (IOException e) {
				e.printStackTrace();
				properties = null;
			}
		}
		return properties;
		
	}
	public static  String getPropertyValue(String pathToPropertyFile , String propertyKey) throws Exception {
		
		Properties properties =  getProperties(pathToPropertyFile);
		if(properties!=null) {
			return (String) properties.get(propertyKey);
		}
		throw new Exception(propertyKey+" property not found");
	}

}