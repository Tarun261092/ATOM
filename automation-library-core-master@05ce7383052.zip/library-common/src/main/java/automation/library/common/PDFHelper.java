package automation.library.common;

import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.UUID;
import java.util.Arrays;

import org.apache.http.client.methods.HttpPost;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;

import javax.imageio.ImageIO;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.util.Strings;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageTree;
import org.apache.pdfbox.rendering.PDFRenderer;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.pdfbox.text.PDFTextStripperByArea;

import com.google.gson.JsonObject;

public class PDFHelper {
	private static final String ERROR_EXTRACT_MSG = "error: extract not possible";
	private static final String FILENAME_PATTERN = "%s%s-page%s%s";

	private PDFHelper() {
		// Utility class
	}

	private static Logger getLogger() {
		return LogManager.getLogger(PDFHelper.class);
	}

	public static PDDocument getDoc(String path) {
		PDDocument doc = null;
		try {
			doc = PDDocument.load(new File(path));
		} catch (IOException e) {
			getLogger().error(e);
		}
		return doc;
	}

	public static PDDocument getDoc(byte[] contents) {
		PDDocument doc = null;
		try {
			doc = PDDocument.load(contents);
		} catch (IOException e) {
			getLogger().error(e);
		}
		return doc;
	}

	public static PDPage getPDFPage(PDDocument doc, int num) {
		return doc.getPage(num);
	}

	public static PDPageTree getPDFPages(PDDocument doc) {
		return doc.getPages();
	}

	public static String getPDFText(PDDocument doc) {
		String extractText = null;
		try {
			PDFTextStripper pdfStripper = new PDFTextStripper();
			extractText = pdfStripper.getText(doc);
		} catch (IOException e) {
			getLogger().error(e);
			extractText = ERROR_EXTRACT_MSG;
		}

		return extractText;
	}

	public static String getPDFText(PDDocument doc, int startPage, int... endPage) {
		String extractText = null;
		try {
			PDFTextStripper pdfStripper = new PDFTextStripper();
			pdfStripper.setStartPage(startPage);
			if (endPage.length > 0) {
				pdfStripper.setEndPage(endPage[0]);
			} else {
				pdfStripper.setEndPage(startPage);
			}
			extractText = pdfStripper.getText(doc);
		} catch (IOException e) {
			getLogger().error(e);
			extractText = ERROR_EXTRACT_MSG;
		}

		return extractText;
	}

	public static String[] getPDFText(PDDocument doc, String token, int startPage, int... endPage) {
		String extractText = null;

		try {
			PDFTextStripper pdfStripper = new PDFTextStripper();
			pdfStripper.setSortByPosition(true);
			pdfStripper.setStartPage(startPage);
			if (endPage.length > 0) {
				pdfStripper.setEndPage(endPage[0]);
			} else {
				pdfStripper.setEndPage(startPage);
			}

			extractText = pdfStripper.getText(doc);
		} catch (IOException var6) {
			getLogger().error(var6);
			extractText = ERROR_EXTRACT_MSG;
		}

		return extractText.split(token);
	}

	public static String getPDFText(PDDocument doc, int pageNum, Rectangle rectangle) {
		String extractText = null;
		try {
			PDPage page = doc.getPage(pageNum - 1);
			PDFTextStripperByArea pdfStripper = new PDFTextStripperByArea();
			pdfStripper.setSortByPosition(true);
			pdfStripper.addRegion("area", rectangle);
			pdfStripper.extractRegions(page);
			extractText = pdfStripper.getTextForRegion("area");
		} catch (IOException e) {
			getLogger().error(e);
			extractText = ERROR_EXTRACT_MSG;
		}

		return extractText;
	}

	public static String scanFile(String pathname) throws IOException {

		File file = new File(pathname);
		StringBuilder fileContents = new StringBuilder((int) file.length());
		Scanner scanner = new Scanner(file);
		String lineSeparator = System.getProperty("line.separator");

		try {
			System.out.println("BeforeReading");
			while (scanner.hasNextLine()) {
				System.out.println("reading");
				fileContents.append(scanner.nextLine() + lineSeparator);
			}

			return fileContents.toString().trim();
		} finally {
			scanner.close();
		}

	}

	public static void closePDFDoc(PDDocument document) {
		try {
			document.close();
		} catch (IOException e) {
			getLogger().error(e);
		}
	}

	public static List<File> takeScreenshotOfFullDoc(PDDocument document, String filePath) {
		PDFRenderer pdfRenderer = new PDFRenderer(document);
		File file = null;
		List<File> listOfScreenshots = new ArrayList<>();

		for (int pageNum = 0; pageNum < document.getNumberOfPages(); pageNum++) {
			try {
				file = new File(String.format(FILENAME_PATTERN, filePath,
						StringHelper.removeSpecialChars(getPDFFileName(document)), pageNum + 1, ".png"));
				file.getParentFile().mkdirs();
				ImageIO.write(pdfRenderer.renderImage(pageNum), "PNG", file);
				listOfScreenshots.add(file);
			} catch (IOException e) {
				getLogger().error(e);
			}
		}

		return listOfScreenshots;
	}

	public static List<File> takeScreenshotInBetweenPagesOfDoc(PDDocument document, String filePath, int pageNumStart,
			int pageNumEnd) {
		PDFRenderer pdfRenderer = new PDFRenderer(document);
		File file = null;
		List<File> listOfScreenshots = new ArrayList<>();

		for (int pageNum = pageNumStart; pageNum <= pageNumEnd; pageNum++) {
			try {
				file = new File(String.format(FILENAME_PATTERN, filePath,
						StringHelper.removeSpecialChars(getPDFFileName(document)), pageNum, ".png"));
				file.getParentFile().mkdirs();
				ImageIO.write(pdfRenderer.renderImage(pageNum - 1), "PNG", file);
				listOfScreenshots.add(file);
			} catch (IOException e) {
				getLogger().error(e);
			}
		}

		return listOfScreenshots;
	}

	public static File takeScreenshotOfPage(PDDocument document, String filePath, int pageNum) {
		PDFRenderer pdfRenderer = new PDFRenderer(document);
		File file = null;
		pageNum = pageNum > 0 ? pageNum : 1;

		try {
			file = new File(String.format(FILENAME_PATTERN, filePath,
					StringHelper.removeSpecialChars(getPDFFileName(document)), pageNum, ".png"));
			file.getParentFile().mkdirs();
			ImageIO.write(pdfRenderer.renderImage(pageNum - 1), "PNG", file);
		} catch (IOException | NullPointerException e) {
			getLogger().error(e);
		}

		return file;
	}

	private static String getPDFFileName(PDDocument document) {
		String title = document.getDocumentInformation().getTitle();
		if (title == null || title.isEmpty()) {
			title = "PDF";
		}

		return String.format("%s%s", title, UUID.randomUUID());
	}

	public static int getPDFPageNumber(PDDocument document, String valToFind) {
		String extractText = null;
		int pgNo = 0;
		for (int i = 0; i < document.getNumberOfPages(); i++) {
			try {
				PDFTextStripper pdfStripper = new PDFTextStripper();
				pdfStripper.setStartPage(i);
				pdfStripper.setEndPage(i + 1);
				extractText = pdfStripper.getText(document);
				if (Boolean.parseBoolean(System.getProperty("fw.ignoreWhitespaceOnPDFCompare"))) {
					extractText = String.join(" ", Arrays.asList(extractText.split("\\s+")));
				}
				if (extractText.contains(valToFind.trim())) {
					pgNo = i + 1;
					break;
				}
			} catch (IOException e) {
				getLogger().error(e);
			}
		}
		return pgNo;
	}

	public static int getPDFPageNumberInBetweenDoc(PDDocument document, String valToFind, int pdfNumStart,
			int pdfNumEnd) {
		String extractText = null;
		int pgNo = 0;

		for (int i = pdfNumStart; i <= pdfNumEnd; i++) {
			try {
				PDFTextStripper pdfStripper = new PDFTextStripper();
				pdfStripper.setStartPage(i - 1);
				pdfStripper.setEndPage(i);
				extractText = pdfStripper.getText(document);
				if (Boolean.parseBoolean(System.getProperty("fw.ignoreWhitespaceOnPDFCompare"))) {
					extractText = String.join(" ", Arrays.asList(extractText.split("\\s+")));
				}
				if (extractText.contains(valToFind.trim())) {
					pgNo = i;
					break;
				}
			} catch (IOException e) {
				getLogger().error(e);
			}
		}
		return pgNo;
	}

	public static File combinePDFPageScreenshotsIntoOne(PDDocument document, List<File> pdfDocAsList, String filePath) {
		File finalImgFile = null;
		try {
			File[] arr = pdfDocAsList.stream().toArray(File[]::new);

			BufferedImage sample = ImageIO.read(arr[0]);
			BufferedImage finalImg = new BufferedImage(sample.getWidth() * 1, sample.getHeight() * pdfDocAsList.size(),
					sample.getType());

			int index = 0;
			for (int i = 0; i < pdfDocAsList.size(); i++) {
				for (int j = 0; j < 1; j++) {
					BufferedImage temp = ImageIO.read(arr[index]);
					finalImg.createGraphics().drawImage(temp, sample.getWidth() * j, sample.getHeight() * i, null);
					index++;
				}
			}

			finalImgFile = new File(String.format("%s%s%s", filePath,
					StringHelper.removeSpecialChars(getPDFFileName(document)), ".png"));
			finalImgFile.getParentFile().mkdirs();
			ImageIO.write(finalImg, "PNG", finalImgFile);
		} catch (IOException e) {
			getLogger().error(e);
		}
		return finalImgFile;
	}

	public static String getImageValidationFromPDFContent(String pathToFile, PDDocument pdfDoc, String downloadDir,
			String opType, String pdfTemplateName, List<String> boldTextToFind, List<String> italicTextToFind,
			String strImageSrc) throws IOException {

		getLogger().info("opType:" + opType);
		getLogger().info("pdfTemplateName:" + pdfTemplateName);
		getLogger().info("boldTexts:" + boldTextToFind.toString());
		getLogger().info("italics:" + italicTextToFind.toString());
		getLogger().info("srcurls:" + strImageSrc);
		// HttpPost post = new
		// HttpPost("http://10.44.151.230:9820/PDFValidation/LogoColorFontChk");
		HttpPost post = new HttpPost("http://sd-35d4-9d73:9820/PDFValidation/LogoColorFontChk");
		// opType ="logo+color+font";
		// String opType="logo+color";
		// InputStream inputStream = new
		// FileInputStream("C:\\Development\\NAQE_WS_Tools\\XPath\\DOMS\\domPage.xml");
		File file = new File(pathToFile);
		String message = "Check Val";
		MultipartEntityBuilder builder = MultipartEntityBuilder.create();
		builder.setMode(HttpMultipartMode.BROWSER_COMPATIBLE);
		builder.addBinaryBody("file", file, ContentType.DEFAULT_BINARY, "");
		// builder.addBinaryBody ("upstream", inputStream,
		// ContentType.create("application/zip"), zipFileName);
		// builder.addTextBody("pdf_applicationname", message,
		// ContentType.APPLICATION_JSON);
		HttpEntity entity = builder.build();
		// post.addHeader("applicationName", Application);
		// post.addHeader("operationType", opType);
		post.addHeader("pdfTemplateName", pdfTemplateName);
		post.addHeader("operationType", opType);
		post.addHeader("boldTexts", boldTextToFind.toString());
		post.addHeader("italics", italicTextToFind.toString());
		// ImageSrc
		post.addHeader("srcurls", strImageSrc.toString());
		post.setEntity(entity);
		// added by sd34022

		String fname = new File(pathToFile).getName();
		// end sd34022
		try (DefaultHttpClient client = new DefaultHttpClient();
				FileOutputStream outputStream = new FileOutputStream(downloadDir + "//Output_" + fname);) {
			HttpResponse response = client.execute(post);
			if (response.getStatusLine() != null && response.getStatusLine().getStatusCode() == 200) {
				getLogger().info("print data in response" + response.getStatusLine().getStatusCode());
				HttpEntity httpEntity = response.getEntity();
				// String apiOutput = EntityUtils.toString(httpEntity);
				InputStream targetStream = httpEntity.getContent();
				int bytesRead = -1;

				byte[] buffer = new byte[4096];
				while ((bytesRead = targetStream.read(buffer)) != -1) {
					outputStream.write(buffer, 0, bytesRead);
				}
				// takeScreenshotOfFullDoc(getDoc(downloadDir+"//out.pdf"),downloadDir);
				outputStream.close();
				targetStream.close();

				if (opType.contains("logo") && opType.contains("color") && opType.contains("font")) {
					getLogger().info(response.getFirstHeader("Logo").getValue() + "::"
							+ response.getFirstHeader("Color").getValue() + "::"
							+ response.getFirstHeader("Fontstatus").getValue());
					return "Logo And Color and Font Validation OutPut:" + response.getFirstHeader("Logo").getValue()
							+ "\n 2) Color validation status::" + response.getFirstHeader("Color").getValue()
							+ "\n 3) Font Validation Status::" + response.getFirstHeader("Fontstatus").getValue();
				} else if (opType.contains("logo") && opType.contains("color")) {
					getLogger().info(response.getFirstHeader("Logo").getValue() + "::"
							+ response.getFirstHeader("Color").getValue());
					return "Logo And Color Validation OutPut:" + response.getFirstHeader("Logo").getValue()
							+ "\n 2) Color validation status::" + response.getFirstHeader("Color").getValue();
				} else if (opType.contains("logo") && opType.contains("font")) {
					getLogger().info(response.getFirstHeader("Logo").getValue() + "::"
							+ response.getFirstHeader("Fontstatus").getValue());
					return "Logo And Font Validation OutPut:" + response.getFirstHeader("Logo").getValue()
							+ "\n 2) Font Validation Status::" + response.getFirstHeader("Fontstatus").getValue();
				} else if (opType.contains("color") && opType.contains("font")) {
					getLogger().info(response.getFirstHeader("Color").getValue() + "::"
							+ response.getFirstHeader("Fontstatus").getValue());
					return "Color And Font Validation OutPut:" + " Color validation status::"
							+ response.getFirstHeader("Color").getValue() + "\n 2) Font Validation Status::"
							+ response.getFirstHeader("Fontstatus").getValue();
				} else if (opType.contains("logo")) {
					getLogger().info(response.getFirstHeader("Logo").getValue());
					return "Logo Validation OutPut:" + response.getFirstHeader("Logo").getValue();
				} else if (opType.contains("color")) {
					getLogger().info(response.getFirstHeader("Color").getValue());
					return "Color Validation OutPut:" + " Color validation status::"
							+ response.getFirstHeader("Color").getValue();
				} else if (opType.contains("layout")) {
					getLogger().info(response.getFirstHeader("Color").getValue());
					return "PDF Layout Validation OutPut:" + "PDF Layout validation status::"
							+ response.getFirstHeader("Color").getValue();
				}
				// zs75946 thankyou
				else if (opType.contains("webimage")) {
					getLogger().info(response.getFirstHeader("Color").getValue());
					return "Thankyou webpage image(s) Validation OutPut:" + "Thankyou webpage validation status::"
							+ response.getFirstHeader("Color").getValue();
				}
				// zs75946 thankyou
				else if (opType.contains("font")) {
					getLogger().info(response.getFirstHeader("Fontstatus").getValue());
					return "Font Validation OutPut:" + response.getFirstHeader("Fontstatus").getValue();
				}
				// PDDocument document = PDDocument.load(targetStream);
				// String apiOutput = EntityUtils.toString(httpEntity);
				// System.out.println("value--"+apiOutput);

			} else if (response.getStatusLine() != null && response.getStatusLine().getStatusCode() == 400) {
				getLogger().info("no match found" + response.getStatusLine().getStatusCode());
				HttpEntity httpEntity = response.getEntity();
				String apiOutput = "No match found";
				return apiOutput;
			} else {
				getLogger().info("print data in response error" + response.getStatusLine().getStatusCode());
				getLogger().info("data in response is blank");
				String apiOutput = "Internal processing error";
				return apiOutput;
			}
		}
		return "";
	}
	// ED40177 Nov 12, 2021. PDf Highlight Code Starts

	public static String highlightTextOnPDFPage(String filePath, String textToFind, String pageNum, String validationID,
			String onFailureFlag) {

		File file = new File(filePath);
		// HttpPost post = new
		// HttpPost("http://10.209.8.188:7000/pdfhighlighttext/getfile");
		HttpPost post = new HttpPost("http://sd-35d4-9d73:7000/pdfhighlighttext/getfile");
		MultipartEntityBuilder builder = MultipartEntityBuilder.create();
		builder.setMode(HttpMultipartMode.BROWSER_COMPATIBLE);
		builder.addBinaryBody("file", file, ContentType.DEFAULT_BINARY, "");
		HttpEntity entity = builder.build();
		post.addHeader("textToFind", textToFind);
		post.addHeader("pageNum", pageNum);
		post.setEntity(entity);

		HttpResponse response;
		try (DefaultHttpClient client = new DefaultHttpClient();) {
			response = client.execute(post);

			if (response.getStatusLine() != null && response.getStatusLine().getStatusCode() == 200) {
				getLogger().info("Print Data in Response: " + response.getStatusLine().getStatusCode());
				HttpEntity httpEntity = response.getEntity();

				String appendedName = "_highlighted_output_";
				Integer appendIndex = 1;
				filePath = filePath.replace(".pdf", "");
				String finalFilePath = filePath + appendedName + appendIndex.toString() + ".pdf";
				while (new File(finalFilePath).exists()) {
					appendIndex = appendIndex + 1;
					finalFilePath = filePath + appendedName + appendIndex.toString() + ".pdf";
				}
				finalFilePath = filePath + appendedName + appendIndex.toString() + ".pdf";

				try (FileOutputStream outputStream = new FileOutputStream(finalFilePath);
						InputStream targetStream = httpEntity.getContent();) {

					int bytesRead = -1;

					byte[] buffer = new byte[4096];
					while ((bytesRead = targetStream.read(buffer)) != -1) {
						outputStream.write(buffer, 0, bytesRead);
					}
				} catch (FileNotFoundException e) {
				} catch (IOException e) {
				}

				String theText = response.getFirstHeader("textToFind").getValue();
				return theText;
			}

		} catch (ClientProtocolException e1) {
			e1.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		return "ERROR:  Failed to contact python server";
	}

	public static String validatePdfFont(String filePath, String fontText, String fontSize, String fontName)
			throws IOException {

		File file = new File(filePath);
		// HttpPost post = new
		// HttpPost(http://10.209.8.188:7000/pdfhighlighttext/getfile);
		HttpPost post = new HttpPost("http://sd-35d4-9d73:5700/pdffontsizenameValidation/DCFLettergetFile");
		MultipartEntityBuilder builder = MultipartEntityBuilder.create();
		builder.setMode(HttpMultipartMode.BROWSER_COMPATIBLE);
		builder.addBinaryBody("file", file, ContentType.DEFAULT_BINARY, "");
		HttpEntity entity = builder.build();
		post.addHeader("text", fontText);
		post.addHeader("fontsize", fontSize.toString());
		post.addHeader("fontname", fontName);
		post.setEntity(entity);
		try (DefaultHttpClient client = new DefaultHttpClient();) {

			HttpResponse response = client.execute(post);

			if (response.getStatusLine() != null && response.getStatusLine().getStatusCode() == 200) {
				getLogger().info("Print Data in Response: " + response.getStatusLine().getStatusCode());
				String theText = response.getFirstHeader("fontstatus").getValue().toString();
				getLogger().info("Received API Response: " + theText);
				return theText;
			}
		}
		return "ERROR:  Failed to contact python server";
	}
	// Added by ED40177 March 31st, 2022
		public static ArrayList<String> validatePdfImagesAgainstTemplate(String filePath, String templatePath) throws IOException {

			// HttpPost post = new HttpPost("http://10.44.151.230:9820/PDFValidation/LogoColorFontChk");
			// HttpPost post = new HttpPost("http://sd-35d4-9d73:9820/PDFValidation/LogoColorFontChk");
			HttpPost post = new HttpPost("http://sd-35d4-9d73:5050/pdfValidation/dynamicFullImageTemplate");

			File file = new File(filePath);
			File template = new File(templatePath);

			MultipartEntityBuilder builder = MultipartEntityBuilder.create();
			builder.setMode(HttpMultipartMode.BROWSER_COMPATIBLE);
			builder.addBinaryBody("file", file, ContentType.DEFAULT_BINARY, "");
			builder.addBinaryBody("template", template, ContentType.DEFAULT_BINARY, "");
			// builder.addBinaryBody ("upstream", inputStream,
			// ContentType.create("application/zip"), zipFileName);
			// builder.addTextBody("pdf_applicationname", message,
			// ContentType.APPLICATION_JSON);
			HttpEntity entity = builder.build();
			// post.addHeader("applicationName", Application);
			// post.addHeader("operationType", opType);
			// ImageSrc
			post.setEntity(entity);

			String fname = new File(filePath).getName();

			try (DefaultHttpClient client = new DefaultHttpClient()){
				HttpResponse response = client.execute(post);
				
				if (response.getStatusLine() == null) {
					getLogger().info("Response was null");
				} else {
					getLogger().info("Response Status: " + response.getStatusLine().getStatusCode());
				}
				
				if (response.getStatusLine() != null && response.getStatusLine().getStatusCode() == 200) {
					ArrayList<String> results = new ArrayList<>();
					results.add(response.getFirstHeader("status").getValue());
					results.add(response.getFirstHeader("reason").getValue());
					getLogger().info("Status: " + results.get(0));
					getLogger().info("Reason: " + results.get(1));
					return results;
				}
				else {
					ArrayList<String> results = new ArrayList<>();
					results.add("print data in response error\" + response.getStatusLine().getStatusCode()");
					results.add("Internal processing error");
					getLogger().info("print data in response error" + response.getStatusLine().getStatusCode());
					getLogger().info("data in response is blank");
					String apiOutput = "Internal processing error";
					return results;
				}

			}
		}
}
