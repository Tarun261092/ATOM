package automation.library.common;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

import java.lang.reflect.Method;

public class EncryptionHelperTest {
	
	@Test
    public void parseSecureTextTest() {	  	 		  
		assertThat(EncryptionHelper.parseSecureText("securetext")).isNotNull();
    }
	
	@Test
    public void parseSecureTextNullTest() {	  	 		  
		assertThat(EncryptionHelper.parseSecureText(null)).isNull();
    }

    @Test
    public void decryptTest() {
        try {
            Class c = Class.forName("EncryptionHelper");
            Object o = c.newInstance();
            Method m = c.getDeclaredMethod("decrypt", new Class[]{String.class});
            m.setAccessible(true);
            String val = m.invoke(o, "S29sa2F0YUAzNQ\\=\\=").toString();
            assertThat(val).isEqualTo("Kolkata@36");
        } catch(Exception ex) {

        }
    }

    @Test
    public void parseSecureTextPropTest() {
        assertThat(EncryptionHelper.parseSecureText("src/test/resources/test10.properties","securetext")).isNull();
    }

}
