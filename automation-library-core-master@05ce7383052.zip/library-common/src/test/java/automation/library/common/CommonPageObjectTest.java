package automation.library.common;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

public class CommonPageObjectTest {
		
		@Test
	    public void commonPageObjectTest() {
	    	try {
	    			assertThat(Class.forName("automation.library.common.CommonPageObject")).isEqualTo(automation.library.common.CommonPageObject.class);
				} catch (ClassNotFoundException e) {					
				} 
	    }
}
