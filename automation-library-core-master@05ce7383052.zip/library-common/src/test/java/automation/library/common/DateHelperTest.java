package automation.library.common;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;

public class DateHelperTest {
   
	private String testDateStr = "12/21/1990";
	private String testDateStr2 = "12/21/1990 10:50:30";
	private String testDateStr3 = "12-21-1990 10:50:30 ZONE_Asia/Kolkata INSTANT";
	
	@Test
    public void formatAsDateTest() {
		String str = "1990-12-21T00:00";
		assertThat(str).isEqualTo(DateHelper.formatAsDate(testDateStr).toString());
    }
	
	@Test
    public void formatAsDateTimeTest() {
		String str = "1990-12-21T10:50:30";
		assertThat(str).isEqualTo(DateHelper.formatAsDate(testDateStr2).toString());
    }
	
	@Test
    public void formatAsDateTimeZoneTest() {
		String str = "1990-12-21T10:50:30";
		assertThat(str).isEqualTo(DateHelper.formatAsDate(testDateStr3).toString());
    }
    
	@Test
    public void getDateTimeFormatTest() {		
		Map<String,String> map = new HashMap<String, String>(){ { put("DATE","MM/dd/yyyy");} };   	
		assertThat(map).isEqualTo(DateHelper.getDateTimeFormat(testDateStr));    
    }
	
	@Test
    public void getDateTimeFormatWithTimeTest() {		
		Map<String,String> map = new HashMap<String, String>(){ { put("DATE-TIME","MM/dd/yyyy HH:mm:ss");} };   	
		assertThat(map).isEqualTo(DateHelper.getDateTimeFormat(testDateStr2));    
    }
	
	@Test
    public void getDateTimeFormatWithZoneTest() {		
		Map<String,String> map = new HashMap<String, String>(){ { put("DATE-TIME-ZONE","MM-dd-yyyy HH:mm:ss z Zone");} };   	
		assertThat(map).isEqualTo(DateHelper.getDateTimeFormat(testDateStr3));    
    }
	
	@Test
    public void getDateTimeFormatExceptionTest() {	
		Exception exception = assertThrows(IllegalArgumentException.class, () -> {
			DateHelper.getDateTimeFormat("testDateStr2");
	    });
		assertThat(exception.getMessage()).isNotNull();
    }
	
	@Test
    public void getClosestTimeFromListTest() {
		List<String> times = Arrays.asList(new String[]{"11.00.10", "11.15.20"});
		assertThat(DateHelper.getClosestTimeFromList(times, "11.20.10")).isEqualTo("11.15.20");    
	}
	
	@Test
    public void getAboveClosestTimeFromListTest() {    
        List<String> times = Arrays.asList(new String[]{"11.00.10", "11.15.20"});
        assertThat(DateHelper.getAboveClosestTimeFromList(times, "11.20.10")).isEqualTo("11.20.10"); 
        List<String> times1 = Arrays.asList(new String[]{"11.00.10", "13.15.20"});
		assertThat(DateHelper.getAboveClosestTimeFromList(times1, "11.20.10")).isEqualTo("13.15.20");
	}
	
	@Test
    public void getBelowClosestTimeFromListTest() {
		List<String> times = Arrays.asList(new String[]{"11.00.10", "11.15.20"});
		assertThat(DateHelper.getBelowClosestTimeFromList(times, "11.20.10")).isEqualTo("11.15.20");  
		List<String> times1 = Arrays.asList(new String[]{"11.00.10", "09.15.20"});
		assertThat(DateHelper.getBelowClosestTimeFromList(times1, "09.15.20")).isEqualTo("09.15.20");
	}
  
}