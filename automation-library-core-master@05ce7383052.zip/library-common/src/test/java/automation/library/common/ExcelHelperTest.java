package automation.library.common;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.File;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.core.config.Configurator;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

public class ExcelHelperTest {
   
	 private static String path, path1, path2;
	 private static String sheetName;
	 
	 @BeforeAll
	 public static void beforeAllTestMethods() {
		 path = new File("src/test/resources/test.xlsx").getAbsolutePath();
		 path1 = new File("src/test/resources1/test.xlsx").getAbsolutePath();
		 path2 = new File("src/test/resources/test1.xlsx").getAbsolutePath();
		 sheetName = "Sheet1";
		 Configurator.setLevel("automation.library.common", Level.OFF);
	 }
	
	@Test
    public void getDataAsArrayListTest() {
    	assertThat(ExcelHelper.getDataAsArrayList(path, sheetName)).isNotNull();
		assertThat(ExcelHelper.getDataAsArrayList(path1, sheetName)).isEmpty();
		assertThat(ExcelHelper.getDataAsArrayList(path2, sheetName)).isEmpty();
    }

	@Test
    public void getDataAsMapTest() {
		assertThat(ExcelHelper.getDataAsMap(path, sheetName).size()).isGreaterThan(0);
		assertThat(ExcelHelper.getDataAsMap(path1, sheetName)).isEmpty();
		assertThat(ExcelHelper.getDataAsMap(path2, sheetName)).isEmpty();
    }

	@Test
    public void getExcelDataAsMapWithoutIndexTest() {
		assertThat(ExcelHelper.getExcelDataAsMapWithoutIndex(path, sheetName).size()).isGreaterThan(0);
		assertThat(ExcelHelper.getExcelDataAsMapWithoutIndex(path1, sheetName)).isEmpty();
		assertThat(ExcelHelper.getExcelDataAsMapWithoutIndex(path2, sheetName)).isEmpty();
    }
	
	@Test
    public void getExcelDataAsMapWithoutIndexFDRTest() {
		assertThat(ExcelHelper.getExcelDataAsMapWithoutIndex(path, sheetName, true).size()).isGreaterThan(0);
		assertThat(ExcelHelper.getExcelDataAsMapWithoutIndex(path1, sheetName,true)).isEmpty();
		assertThat(ExcelHelper.getExcelDataAsMapWithoutIndex(path2, sheetName,true)).isEmpty();
    }

}
