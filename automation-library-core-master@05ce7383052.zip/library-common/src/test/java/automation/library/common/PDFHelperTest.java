package automation.library.common;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.fail;

import java.awt.Rectangle;
import java.io.File;
import java.io.IOException;
import java.util.List;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

public class PDFHelperTest {
    
    private static PDDocument doc, doc1;
    private static String path, path2;
    
    @BeforeAll
	public static void beforeAllTestMethods() {
    	 doc = PDFHelper.getDoc("src/test/resources/test.pdf");
         doc1 = PDFHelper.getDoc("src/test/resources/test10.pdf");
         path = new File("src/test/resources/test.pdf").getAbsolutePath();
         path2 = new File("target/test-classes/test.pdf").getAbsolutePath();
         new File("src/test/resources/test10.pdf").getAbsolutePath();
         
         System.setProperty("fw.ignoreCaseOnPDFCompare", "true");
		 System.setProperty("fw.numLeadingCharactersforPDFCompare", "0");
		 System.setProperty("fw.ignoreWhitespaceOnPDFCompare", "true");
		 System.getProperty("line.separator","\\n");
	 }
  
    @Test
    public void getDocTest() {
    	assertThat(doc).isNotNull();
        assertThat(doc1).isNull();
    }

    @Test
    public void getDocByteTest() {
        byte[] bytes=new byte[2];
        bytes[0]= (byte) 1;
        bytes[1]= (byte) 2;
        assertThat(PDFHelper.getDoc(bytes)).isNull();
    }

    @Test
    public void getPDFPageTest() {
    	 assertThat(PDFHelper.getPDFPage(doc,0)).isNotNull();
    }

    @Test
    public void getPDFPagesTest() {  		  	 		  
    	assertThat(PDFHelper.getPDFPages(doc)).isNotNull();
    }

    @Test
    public void getPDFTextTest() {		  	 		  
    	assertThat(PDFHelper.getPDFText(doc)).isNotNull();
    }

     @Test
    public void getPDFTextPagesTest() {	  	 		  
    	 assertThat(PDFHelper.getPDFText(doc,1,1)).isNotNull();
    }

    @Test
    public void getPDFTextPagesTokenTest() {	  	 		  
    	assertThat(PDFHelper.getPDFText(doc,"\\n",1,1)).isNotNull();
    }

   @Test
    public void getPDFTextRectTest() {
    	Rectangle rect = new Rectangle(10,10,100,100);	  	 		  
    	assertThat(PDFHelper.getPDFText(doc,1,rect)).isNotNull();
    } 

    @Test
    public void scanFileTest() {
       
		try {				
				assertThat(PDFHelper.scanFile(path)).isNotNull();
			} catch (IOException e) {
				fail(e.getMessage());
			}		  	 		  		
    }

    @Test
    public void takeScreenshotOfFullDocTest() {
    	List<File> list = PDFHelper.takeScreenshotOfFullDoc(doc,path2);  	
		assertThat(list.size()).isGreaterThan(0);
    }

    @Test
    public void takeScreenshotOfPageOfDocTest() {
    	File file = PDFHelper.takeScreenshotOfPage(doc,path2,0);
  		assertThat(file).isNotNull();
        assertThat(PDFHelper.takeScreenshotOfPage(doc1,path2,0)).isNull();
    }

   @Test
    public void takeScreenshotInBetweenPagesOfDocTest() {
	   List<File> list = PDFHelper.takeScreenshotInBetweenPagesOfDoc(doc,path2,1,1);  			  	 		  
	   assertThat(list.size()).isGreaterThan(0);
    }

    @Test
    public void getPDFPageNumberTest() {   	 	 		  
    	assertThat(PDFHelper.getPDFPageNumber(doc,"test")).isGreaterThan(0);
    }

    @Test
    public void getPDFPageNumberInBetweenDocTest() {		  	 		  
    	assertThat(PDFHelper.getPDFPageNumberInBetweenDoc(doc,"test",1,1)).isGreaterThan(0);
    }

    @Test
    public void combinePDFPageScreenshotsIntoOne() {
        List<File> list = PDFHelper.takeScreenshotOfFullDoc(doc,path2);
        assertThat(PDFHelper.combinePDFPageScreenshotsIntoOne(doc, list, path2)).isNotNull();
    }

}