package automation.library.common;

import java.io.File;
import java.io.IOException;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class ZipHelperTest {
    
	@Test
    public void zipitTest()  {
    	try {
    		  String source = new File("src/test/resources/test.properties").getAbsolutePath();
    		  String target = new File("target/test-classes/test.zip").getAbsolutePath();
    		  String source1 = new File("src/test/resources/TestDir").getAbsolutePath();
    		  String target1 = new File("target/test-classes/TestDir.zip").getAbsolutePath();
    		  ZipHelper.zipit(source, target);
    		  ZipHelper.zipit(source1, target1);
    		  assertThat(target).isNotNull();
			} catch (IOException e) {
			}       
    }
}