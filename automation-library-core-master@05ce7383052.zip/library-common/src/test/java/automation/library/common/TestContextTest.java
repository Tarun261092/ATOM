package automation.library.common;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

public class TestContextTest {

    private TestContext testContext = TestContext.getInstance();
    private final String TEST_KEY = "testKey";
    private final String TEST_VALUE = "testValue";

    @Test
    public void saTest() {
    	assertThat(testContext.sa()).isNotNull();       
    }

    @Test
    public void testdataTest() {
    	assertThat(testContext.testdata()).isNotNull();  
    }

    @Test
    public void testdataGetTest() {
    	testContext.testdataPut(TEST_KEY,TEST_VALUE);    	
    	assertThat(testContext.testdataGet(TEST_KEY)).isEqualTo(TEST_VALUE);      
    }
    
    @Test
    public void testdataGetCaseTest() {
    	testContext.testdataPut("testkey",TEST_VALUE);    	
    	assertThat(testContext.testdataGet(TEST_KEY)).isEqualTo(TEST_VALUE);      
    }
    
    @Test
    public void testdataGetNullTest() {
    	assertThat(testContext.testdataGet("TESTKEY1")).isNull();      
    }
    
    @Test
    public void testdataToClassTest() {
    	testContext.testdataPut(TEST_KEY,TEST_VALUE);
    	assertThat(testContext.testdataToClass("testKey", String.class)).isNotNull();
    }
 
    @Test
    public void testdataPutTest() {
    	testContext.testdataPut(TEST_KEY,TEST_VALUE);
    }

    @Test
    public void setOfPOTest() {
    	assertThat(testContext.setOfPO()).isNotNull();
    }

    @Test
    public void setOfFeatureFilesTest() {
    	assertThat(testContext.setOfFeatureFiles()).isNotNull();
    }

    @Test
    public void setOfAPITest() {
    	assertThat(testContext.setOfAPI()).isNotNull();
    }

    @Test
    public void setOfDBTest() {
    	assertThat(testContext.setOfDB()).isNotNull();       
    }
    
    @Test
    public void pushPopWindowHandleTest() {
    	testContext.pushWindowHandle("windowHandleName");
    	assertThat(testContext.popWindowHandle()).isNotNull();
    }

    @Test
    public void getWindowHandlesCountTest() {
    	assertThat(testContext.getWindowHandlesCount()).isGreaterThanOrEqualTo(0);
    }

    @Test
    public void windowHandleExistsTest() {
    	assertThat(testContext.windowHandleExists("windowHandleName")).isNotNull();    
    }

    @Test
    public void peekLastWindowHandleTest() {
        testContext.pushWindowHandle("windowHandleName");
    	assertThat(testContext.peekLastWindowHandle()).isNotNull();
    }

    @Test
    public void getSetActiveWindowTypeTest() {
        testContext.setActiveWindowType("activeWindowType");
        assertThat(testContext.getActiveWindowType()).isNotNull();
    }

}