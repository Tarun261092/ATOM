package automation.library.common;

import static org.assertj.core.api.Assertions.assertThat;
import java.io.File;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeAll;

public class PropertyTest {

	private static String path;
	private final String TEST_PROPERTY = "testproperty1";
	
	@BeforeAll
	 public static void beforeAllTestMethods() {
		 path = new File("src/test/resources/test.properties").getAbsolutePath();
	 }
	
	@Test
	public void getPropertiesTest() { 	  	 		  
		assertThat(Property.getProperties(path)).isNotNull();			
	}
	
	@Test
	public void getPropertiesNullTest() { 	  	 		  
		assertThat(Property.getProperties("path")).isNull();			
	}
		
	@Test
	public void getVariableTest(){			  	 		  
		assertThat(Property.getVariable("JAVA_HOME")).isNotNull();
	}
	
	@Test
	public void getSetPropertyTest() {
		Property.setProperty(path, TEST_PROPERTY, "value1");
		assertThat(Property.getProperty(path, TEST_PROPERTY)).isNotNull();
	}

	@Test
	public void getPropertyArrayTest() { 	  	 		  
		assertThat(Property.getPropertyArray(path, "key")).isNotNull();			
	}
	
}
