package automation.library.common;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;

public class DataTableFormatterTest {

	  private static Map<String, String> map = Stream.of(new String[][] {
		  { "Key1", "Value1" }, 
		  { "Key2", "Value2" }, 
		}).collect(Collectors.toMap(data -> data[0], data -> data[1]));
	
	  private static Map<String, Object> map1 = Stream.of(new String[][] {
		  { "Key1", "Value1" }, 
		  { "Key2", "Value2" }, 
		}).collect(Collectors.toMap(data -> data[0], data -> data[1]));
	
	  @Test
	  public void getDataDictionaryAsFormattedTableTest() {
	  	assertThat(DataTableFormatter.getDataDictionaryAsFormattedTable()).isNotNull();
	  	assertThat(DataTableFormatter.getPropertiesAsFormattedTable(map)).isNotNull();
	  }
	
	  @Test
	  public void getFilteredDataTableAsMapTest() {
	  	assertThat(DataTableFormatter.getFilteredDataTableAsMap()).isNotNull();
	  }
	
	  @Test
	  public void getFilteredPriorDataTableAsMapTest() {
	  	assertThat(DataTableFormatter.getFilteredPriorDataTableAsMap()).isNotNull();
	  }
	
	  @Test
	  public void getValidationTableAsMapTest() {
	  	assertThat(DataTableFormatter.getValidationTableAsMap()).isNotNull();
	  }
	  
	  @Test
	  public void getPropertiesAsFormattedTableTest() {
	  	assertThat(DataTableFormatter.getPropertiesAsFormattedTable(map)).isNotNull();
	  }
	  
	  @Test
	  public void getMapAsFormattedDataTableTest() {
	  	assertThat(DataTableFormatter.getMapAsFormattedDataTable(map1)).isNotNull();
	  }
}
