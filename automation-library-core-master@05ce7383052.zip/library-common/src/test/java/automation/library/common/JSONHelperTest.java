package automation.library.common;

import static org.assertj.core.api.Assertions.assertThat;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.core.config.Configurator;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

public class JSONHelperTest {
   
	private static String path, path1;
	
	@BeforeAll
	 public static void beforeAllTestMethods() {
		 path = new File("src/test/resources/test.json").getAbsolutePath();
		 path1 = new File("src/test1/resources/test.json").getAbsolutePath();
		 Configurator.setLevel("automation.library.common", Level.OFF);
	 }

    @Test
    public void getJSONDataTest() {    	
    	assertThat(JSONHelper.getJSONData(path)).isNotNull();
		assertThat(JSONHelper.getJSONData(path1)).isNull();
    }

    @Test
    public void getJSONArrayTest() { 	
    	assertThat(JSONHelper.getJSONArray(path,"Retail")).isNotNull();
		assertThat(JSONHelper.getJSONArray(path1,"Retail")).isNull();
    }
         
    @Test
    public void getDataPOJOTest() { 	
    	try {
    			assertThat(JSONHelper.getDataPOJO(path,Object.class)).isNotNull();
				assertThat(JSONHelper.getDataPOJO(path1,Object.class)).isNull();
			} catch (IOException e) {
			}
    }
        
    @Test
    public void getJSONToMapTest() {
    	JSONObject jsonObject = new JSONObject().put("JSON", "Hello, World!");
		assertThat(JSONHelper.getJSONToMap(jsonObject).size()).isGreaterThan(0);		
    }
        
    @Test
    public void jsonMergeTest() {
    	JSONObject source = new JSONObject().put("JSON1", "Hello, World1!");
    	JSONObject target = new JSONObject().put("JSON2", "Hello, World2!");
    	
    	JSONArray srcArray= new JSONArray();
    	srcArray.put("JSON3");
		srcArray.put("JSON4");
		
		JSONArray tarArray= new JSONArray();
		tarArray.put("JSON5");
		tarArray.put("JSON6");
		
		JSONArray sourceArray= new JSONArray();
		sourceArray.put(source);
		sourceArray.put(target);
		
		JSONArray targetArray= new JSONArray();
		targetArray.put(source);
		targetArray.put(target);
		
		JSONObject arrSrc=new JSONObject().put("Keyword1",srcArray);
		JSONObject arrTar=new JSONObject().put("Keyword1",tarArray);
		
		JSONObject arrSrc1=new JSONObject().put("Keyword2",source);
		JSONObject arrTar1=new JSONObject().put("Keyword2",target);
		
		JSONObject arrSrc2=new JSONObject().put("Keyword2",sourceArray);
		JSONObject arrTar2=new JSONObject().put("Keyword2",targetArray);
    	
    	assertThat(JSONHelper.jsonMerge(source, target)).isNotNull();
		assertThat(JSONHelper.jsonMerge(arrSrc, arrTar)).isNotNull();
		assertThat(JSONHelper.jsonMerge(arrSrc1, arrTar1)).isNotNull();
		assertThat(JSONHelper.jsonMerge(arrSrc2, arrTar2)).isNotNull();
    }
    
    @Test
    public void getJSONAsListOfMapsTest() {   	
	   	String path = new File("src/test/resources/test3.json").getAbsolutePath();
	   	assertThat(JSONHelper.getJSONAsListOfMaps(path).size()).isGreaterThan(0);
		assertThat(JSONHelper.getJSONAsListOfMaps(path1)).isEmpty();
    }

    @Test
    public void convertMapToJSONTest() {    	
	    Map<String, Object> map = new HashMap<String, Object>();
	   	map.put("key1","value1");
	   	map.put("key2","value2");

		assertThat(JSONHelper.convertMapToJSON(map, path1)).isNull();
    }
      
    @Test
    public void mapToJSONArrayStringTest() {    	
    	Map<String, String> map = new HashMap<String, String>();
	   	map.put("key1","value1");
	   	map.put("key2","value2");
	   	
	   	assertThat(JSONHelper.mapToJSONArrayString(map)).isNotNull();
    } 

    @Test
    public void getJSONDatasMapTest() {    	
    	assertThat(JSONHelper.getJSONDatasMap(path)).isNotNull();
		assertThat(JSONHelper.getJSONDatasMap(path1)).isNull();
    }
    
}