package automation.library.common;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

public class StringHelperTest  {
	
	  private String testString = "Test !@";
	
	  @Test
	  public void removeSpecialCharsTest() {
		String newStr = StringHelper.removeSpecialChars(testString);
		assertThat(newStr).isEqualTo("Test");				 	
	  }
	  
	  @Test
	  public void removeAllWhitespaceTest() {
		String newStr = StringHelper.removeAllWhitespace(testString);
		assertThat(newStr).isEqualTo("Test!@");				 	
	  }
	  
	  @Test
	  public void getClassShortNameTest() {
		String newStr = StringHelper.getClassShortName(testString);
		assertThat(newStr).isNotNull();				 	
	  }
}
