package automation.library.common;

import static org.assertj.core.api.Assertions.assertThat;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.core.config.Configurator;
import org.codehaus.plexus.util.xml.pull.XmlPullParserException;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

public class FileHelperTest {

	private String path = new File("src/test/resources/test.json").getAbsolutePath();
    private String path1 = new File("src/test1/resources/test.json").getAbsolutePath();
    private String file = "src/test/resources/test.json";
    
    @BeforeAll
	public static void beforeAll() {
    	Configurator.setLevel("automation.library.common", Level.OFF);
	}
    
    @Test
    public void findFileInPathTest() {         	
	   assertThat(FileHelper.findFileInPath(Mockito.anyString(), "test.json")).isNotNull();
       assertThat(FileHelper.findFileInPath(Mockito.anyString(), "test10.json")).isNull();
    }

   @Test
    public void getFileNameWithoutExtensionTest() {
	   assertThat(FileHelper.getFileNameWithoutExtension(file)).isEqualTo("test");
    }

   @Test
   public void getFileNameWithoutExtensionNullTest() {
	   assertThat(FileHelper.getFileNameWithoutExtension(null)).isNull();;		
   }
   
    @Test
    public void getFileNameExtensionTest() {
    	assertThat(FileHelper.getFileNameExtension(file)).isEqualTo("json");
    }
    
    @Test
    public void getFileNameExtensionNullTest() {
    	assertThat(FileHelper.getFileNameExtension(null)).isNull();
    }


    @Test
    public void getFileAsStringTest() {
    	
		try {
				assertThat(FileHelper.getFileAsString(file,"\\n")).isNotNull();
			} catch (IOException e) {
			}		   	     
    }

    @Test
    public void getFileAsStringInputStreamTest()  {
    	    	
		try {
				InputStream inputStream = new FileInputStream(file);
				assertThat(FileHelper.getFileAsString(inputStream, "\\n")).isNotNull();				
			} catch (IOException e) {
			}		          
    }

    @Test
    public void findMostRecentFileByExtensionTest() {	
    	assertThat(FileHelper.findMostRecentFileByExtension(path,"json")).isNotNull();        
    }
    
    @Test
    public void getMatchingFilesFromDirectoryTest() {   	
    	assertThat(FileHelper.getMatchingFilesFromDirectory(path,"json").size()).isGreaterThan(0);
        assertThat(FileHelper.getMatchingFilesFromDirectory(path1,"json")).isEmpty();
    }

    @Test
    public void getMatchingFilePathsFromDirectoryTest() {
    	assertThat(FileHelper.getMatchingFilePathsFromDirectory(path,"json").size()).isGreaterThan(0);
        assertThat(FileHelper.getMatchingFilePathsFromDirectory(path1,"json")).isEmpty();
    }

    @Test
    public void convertPropertyFileToMapTest() {
    	String propsPath = new File("src/test/resources/test.properties").getAbsolutePath(); 	
    	assertThat(FileHelper.convertPropertyFileToMap(propsPath).size()).isGreaterThan(0);
        assertThat(FileHelper.convertPropertyFileToMap(path1)).isEmpty();
    }

    @Test
    public void loadJsonMapFromResourcesTest() {	   
    	
    	try {   	
    			assertThat(FileHelper.loadJsonMapFromResources(FileHelperTest.class,path)).isNull();  				
			} catch (Exception e) {
			}	   
    }
    
    @Test
     public void loadJsonMapOfObjectsFromResourcesTest() {	   
     	
     	try {	   	
     			assertThat(FileHelper.loadJsonMapOfObjectsFromResources(FileHelperTest.class,path)).isNull();  				
 			} catch (Exception e) {
 			}	   
     }

   @Test
   public void writeDataToFileTest() {
	   String propsPath = new File("src/test/resources/test2.properties").getAbsolutePath();
       String propsPath1 = new File("src/test/resources1/test2.properties").getAbsolutePath();
	   FileHelper.writeDataToFile(propsPath,"test");
       FileHelper.writeDataToFile(propsPath1,"test");
       assertThat(propsPath).isNotNull();
    }
   
   @Test
   public void getFirstTwoLinesTest() {
	   String propsPath = new File("src/test/resources/test.properties").getAbsolutePath();
       String propsPath1 = new File("src/test/resources1/test2.properties").getAbsolutePath();
	   assertThat(FileHelper.getFirstTwoLines(propsPath)).isNotNull();
       assertThat(FileHelper.getFirstTwoLines(propsPath1)).isEmpty();
   }

    @Test
    public void writeTempFileTest() {
        new File("src/test/resources/test.properties").getAbsolutePath();
        new File("src/test/resources1/test2.properties").getAbsolutePath();
        assertThat(FileHelper.writeTempFile("test","pdf","testing")).isNotNull();
    }
    
    @Test
    public void loadDataParametersFromPropsFileTest() {
        String propsPath = new File("src/test/resources/test.properties").getAbsolutePath();
        assertThat(propsPath).isNotNull();
        FileHelper.loadDataParametersFromPropsFile(propsPath,"db");
    }
    
    @Test
    public void getPropertiesAsMapTest() {
        String propsPath = new File("src/test/resources/test.properties").getAbsolutePath();
        assertThat(FileHelper.getPropertiesAsMap(propsPath)).isNotNull();
    }

    @Test
    public void getLibraryEngineVersionTest() {
        try {
			assertThat(FileHelper.getLibraryEngineVersion()).isNull();
		} catch (IOException e) {
		} catch (XmlPullParserException e) {
		}
    }
    
    @Test
    public void getListOfFoldersTest() {
    	String propsPath = new File("src/test/resources").getAbsolutePath();
    	assertThat(FileHelper.getListOfFolders(propsPath)).isNotNull();
    	assertThat(FileHelper.getListOfFolders(path)).isNotNull();
    }
    
    @Test
    public void getListOfFoldersNameTest() {
    	String propsPath = new File("src/test/resources").getAbsolutePath();
    	assertThat(FileHelper.getListOfFoldersName(propsPath)).isNotNull();
    	assertThat(FileHelper.getListOfFoldersName(path)).isNotNull();
    }
}