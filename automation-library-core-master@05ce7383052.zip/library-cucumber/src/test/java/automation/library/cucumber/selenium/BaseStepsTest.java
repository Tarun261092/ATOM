package automation.library.cucumber.selenium;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

public class BaseStepsTest {

	static BaseSteps baseSteps;
	
	@BeforeAll
	public static void beforeAllTestMethods() {
		baseSteps = new BaseSteps();	
	}

	@Test
    public void BaseStepsTest1() {
    	assertThat(baseSteps).isNotNull();
    }
	
	@Test
    public void saTest() {
		assertThat(baseSteps.sa()).isNotNull();
    }

}