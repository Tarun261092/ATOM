package automation.library.cucumber.core;

import automation.library.common.TestContext;
import automation.library.reporting.Reporter;
import automation.library.selenium.exec.driver.factory.DriverContext;
import io.cucumber.core.api.Scenario;
import io.cucumber.java8.En;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class Hooks implements En{

	protected final Logger log = LogManager.getLogger(Hooks.class);

	public Hooks(){
		Before(10, (Scenario scenario) -> {
			
			String browserName = DriverContext.getInstance().getBrowserName();
			if (browserName.equalsIgnoreCase("internet explorer")) {
				Process process;
				process = Runtime.getRuntime().exec("taskkill /F /IM IEDriverServer.exe");
				process = Runtime.getRuntime().exec("taskkill /f /im iexplore.exe");
				process = Runtime.getRuntime().exec("RunDll32.exe InetCpl.cpl,ClearMyTracksByProcess 255");

				process.waitFor();
			}
			
			String featureName = (scenario.getId().split(";")[0].replace("-", " "));
			String scenarioName = scenario.getName();
			TestContext.getInstance().testdataPut("fw.testDescription", featureName + "-" + scenarioName);
			TestContext.getInstance().testdataPut("fw.cucumberTest","true");
		});

		After(20, (Scenario scenario) -> checkForSAFailure());
	}

	private void checkForSAFailure() {
		try {
			TestContext.getInstance().sa().assertAll();
		} catch (AssertionError e) {
			Reporter.failScenario(e.fillInStackTrace());
			log.error(e.getMessage());
			TestContext.getInstance().resetSoftAssert();
			throw e;
		}
	}
}
