package automation.library.cucumber.selenium;

import automation.library.common.Property;
import automation.library.common.TestContext;
import automation.library.selenium.core.Constants;
import automation.library.selenium.exec.driver.factory.DriverContext;
import io.cucumber.core.api.Scenario;
import io.cucumber.java8.En;
import org.apache.commons.configuration2.PropertiesConfiguration;

import java.io.File;
import java.util.Arrays;
import java.util.List;

import static automation.library.selenium.core.Screenshot.grabScreenshot;
import static automation.library.selenium.core.Screenshot.saveScreenshot;


public class Hooks implements En {

    private static final String SCREENSHOT_ON_FAILURE = "screenshotOnFailure";

    public Hooks() {
        Before(30, (Scenario scenario) -> setRuntimeProperties());

        After(30, (Scenario scenario) -> {
            if (DriverContext.getInstance().getTechStack() != null) {
                if (scenario.isFailed()) {
                    takeScreenShotOnFailure();
                }

                if (!DriverContext.getInstance().getKeepBrowserOpen()) {
                    DriverContext.getInstance().quit();
                }

                if(DriverContext.getInstance().driverManager() != null) {
                    DriverContext.getInstance().driverManager().updateResults(scenario.isFailed() ? "failed" : "passed");
                }
            }
        });
    }



    private void setRuntimeProperties() {
        PropertiesConfiguration props = Property.getProperties(Constants.SELENIUMRUNTIMEPATH);

        if (props != null) {
            String tableCompareAttribute = props.getString("attributeForTableCellCompare");
            String tableHeaderCompareAttribute = props.getString("attributeForTableHeaderCompare");
            String tableHeaderTDattribute = props.getString("tableUseTDForHeader");
            List<String> xPathForLabels = Arrays.asList(props.getStringArray("xPathForLabels"));
            String screenshotOnValidations = props.getString("screenshotOnValidation");
            String screenshotOnFailure = props.getString(SCREENSHOT_ON_FAILURE);
            String screenshotOnEveryStep = props.getString("screenshotOnEveryStep");
            String highlightElementOnScreenshot = props.getString("highlightElementOnScreenshot");
            String browserOpenOnFailure = props.getString("browserOpenOnFailure");
            String seleniumGridURL = props.getString("seleniumGridURL");
            String trimTextFlag = props.getString("trimTextOnRetrieval");
            String executeAXEPerStep = props.getString("executeAXEPerStep");
            String scrollingScreenshot = props.getString("scrollingScreenshot");  
            String stepTextKeyRefresh = props.getString("stepTextKeyRefresh");
            String mobileWebAutomation = props.getString("mobileWebAutomation");
            String browserHistoryAndCacheClearForEdge = props.getString("browserHistoryAndCacheClearForEdge");
            String windowSwitchDelay = props.getString("windowSwitchDelay") == null ? "1000" : props.getString("windowSwitchDelay");
            System.setProperty("fw.windowSwitchDelay", windowSwitchDelay);
            String keyToPressDelay = props.getString("keyToPressDelay") == null ? "1000" : props.getString("keyToPressDelay");
            System.setProperty("fw.keyToPressDelay", keyToPressDelay);

            System.setProperty("fw.ignoreHostNameMismatch", String.valueOf(Boolean.parseBoolean(props.getString("ignoreHostNameMismatch"))));
            System.setProperty("fw.tableUseTDForHeader", String.valueOf(Boolean.parseBoolean(props.getString("tableUseTDForHeader"))));

            int maxWaitTime = props.getString("maxWaitTime") == null ? 12000 : props.getInt("maxWaitTime") * 1000;
            System.setProperty("fw.maxWaitTime", String.valueOf(maxWaitTime));

            int waitBetweenConnectionRequest = props.getString("waitBetweenPoll") == null ? 3000 : props.getInt("waitBetweenPoll") * 1000;
            System.setProperty("fw.waitBetweenConnectionRequest", String.valueOf(waitBetweenConnectionRequest));

            TestContext.getInstance().testdataPut("fw.waitForPageLoad", Boolean.parseBoolean((props.getString("waitForPageLoad"))));           
            TestContext.getInstance().testdataPut("fw.waitForSFDCPageLoad", Boolean.parseBoolean((props.getString("waitForSFDCPageLoad"))));
            TestContext.getInstance().testdataPut("fw.disableAutoScroll", Boolean.parseBoolean((props.getString("disableAutoScroll"))));

            if (tableCompareAttribute != null) {
                System.setProperty(Constants.ATTRIBUTE_FOR_TABLE_CELL_COMPARE, tableCompareAttribute);
            }

            if (tableHeaderCompareAttribute != null) {
                System.setProperty(Constants.ATTRIBUTE_FOR_TABLE_HEADER_COMPARE, tableHeaderCompareAttribute);
            }

            if (tableHeaderTDattribute != null) {
                System.setProperty(Constants.ATTRIBUTE_FOR_TABLE_TD_HEADER_COMPARE, tableHeaderTDattribute);
            }

            if (!xPathForLabels.isEmpty()) {
                System.setProperty(Constants.XPATH_FOR_LABELS, String.join(Constants.XPATH_FOR_LABELS_DELIMITER, xPathForLabels));
            }

            if (screenshotOnValidations != null) {
                System.setProperty("fw.screenshotOnValidation", screenshotOnValidations);
            }

            if (screenshotOnFailure != null) {
                System.setProperty("fw.screenshotOnFailure", screenshotOnFailure);
            }

            if (screenshotOnEveryStep != null) {
                System.setProperty("fw.screenshotOnEveryStep", screenshotOnEveryStep);
            }

            if (highlightElementOnScreenshot != null) {
                System.setProperty("fw.highlightElementOnScreenshot", highlightElementOnScreenshot);
            }
            
            if (mobileWebAutomation != null) {
                System.setProperty("fw.mobileWebAutomation", mobileWebAutomation);
            } else {
            	System.setProperty("fw.mobileWebAutomation", "false");
            }
            
            if (scrollingScreenshot != null) {
                System.setProperty("fw.scrollingScreenshot", scrollingScreenshot);
            }
            
            if (stepTextKeyRefresh != null) {
                TestContext.getInstance().testdataPut("fw.stepTextKeyRefresh", stepTextKeyRefresh);
                }

            if (browserOpenOnFailure != null) {
                DriverContext.getInstance().setKeepBrowserOpen(Boolean.valueOf(browserOpenOnFailure));
            }

            if (seleniumGridURL != null) {
                System.setProperty("fw.seleniumGrid", seleniumGridURL);
            }

            if (trimTextFlag != null) {
                System.setProperty("fw.trimTextOnRetrieval", trimTextFlag);
            }

            if (executeAXEPerStep != null) {
                System.setProperty("fw.ExecuteAttestPerStep", executeAXEPerStep);
            }
            
            if (browserHistoryAndCacheClearForEdge != null) {
                System.setProperty("fw.browserHistoryAndCacheClearForEdge", browserHistoryAndCacheClearForEdge);
            }
        }
    }

    private void takeScreenShotOnFailure() {
        PropertiesConfiguration props = Property.getProperties(Constants.SELENIUMRUNTIMEPATH);
        String screenshotOnFailure = props.getString(SCREENSHOT_ON_FAILURE);

        if (Boolean.parseBoolean(screenshotOnFailure) && TestContext.getInstance().getActiveWindowType().equalsIgnoreCase("Selenium")) {
            System.setProperty(SCREENSHOT_ON_FAILURE, screenshotOnFailure);
            File file = saveScreenshot(grabScreenshot(DriverContext.getInstance().getDriver()), getScreenshotPath());
            String relativePath = "." + File.separator + "Screenshots" + File.separator + file.getName();
            String absolutePath = file.getAbsolutePath();
            TestContext.getInstance().testdata().put("fw.screenshotRelativePath", relativePath);
            TestContext.getInstance().testdata().put("fw.screenshotAbsolutePath", absolutePath);
        }
    }

    private static String getReportPath() {
        String defaultReportPath = System.getProperty("user.dir") + File.separator + "target" + File.separator + "allure-results" + File.separator;
        String reportPath = Property.getVariable("reportPath");
        return (reportPath == null ? defaultReportPath : reportPath);
    }

    private static String getScreenshotPath() {
        return getReportPath() + "screenshots" + File.separator;
    }

}