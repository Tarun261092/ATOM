package automation.library.cucumber.selenium;

import automation.library.common.Property;
import automation.library.common.TestContext;
import automation.library.selenium.core.Constants;
import automation.library.selenium.exec.BasePO;
import automation.library.selenium.exec.driver.factory.DriverContext;
import io.cucumber.java8.En;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;


public class BaseSteps implements En {

    protected Logger log = LogManager.getLogger(this.getClass().getName());
    protected BasePO po;

    public BaseSteps() {
        //default constructor
    }


    public BasePO getPO() {
        log.debug("obtaining an instance of the base page objects");
        if (po == null)
            po = new BasePO();
        return po;
    }

    public WebDriver getDriver() {
        log.debug("obtaining the driver for current thread");
        return DriverContext.getInstance().getDriver();
    }

    public WebDriverWait getWait() {
        log.debug("obtaining the wait for current thread");
        return DriverContext.getInstance().getWait();
    }

    /**
     * Returns duration for specified waits
     */
    @SuppressWarnings("unused")
    private int getWaitDuration() {
        final int defaultWait = 10;
        int duration;
        try {
            duration = Integer.parseInt(Property.getProperty(Constants.SELENIUMRUNTIMEPATH, "defaultWait"));
            log.debug("selenium driver wait time set from environment properties");
        } catch (Exception e) {
            duration = defaultWait;
            log.debug("selenium driver wait time not available from environment properties...default applied={}", defaultWait);
        }
        return duration;
    }

    public SoftAssertions sa() {
        return TestContext.getInstance().sa();
    }

}