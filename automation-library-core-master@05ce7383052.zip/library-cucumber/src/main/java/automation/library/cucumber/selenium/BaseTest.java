package automation.library.cucumber.selenium;

import com.google.common.collect.Lists;
import io.cucumber.testng.CucumberFeatureWrapper;
import io.cucumber.testng.CucumberOptions;
import io.cucumber.testng.PickleEventWrapper;
import io.cucumber.testng.TestNGCucumberRunner;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.io.IOException;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static automation.library.tlm.common.TlmConstants.TLM_DEFECT_PROPERTIES_PATH_REPORT;

@CucumberOptions(
        strict = true,
        glue = {"automation.library"}
)

public class BaseTest extends automation.library.selenium.exec.BaseTest {

    private TestNGCucumberRunner testNGCucumberRunner = new TestNGCucumberRunner(this.getClass());

    @BeforeClass(alwaysRun = true)
    public void setUpClass() {
        try {
            if (Paths.get(TLM_DEFECT_PROPERTIES_PATH_REPORT).toFile().exists()) {
                Files.deleteIfExists(Paths.get(String.format("%s%s.%s", TLM_DEFECT_PROPERTIES_PATH_REPORT, "Defect", "json")));
                Files.write(Paths.get(String.format("%s%s.%s", TLM_DEFECT_PROPERTIES_PATH_REPORT, "Defect", "json")), "[]".getBytes());
            }
        } catch (IOException e) {
            log.error(e.getMessage(), e);
        }
    }

    @Test(groups = "cucumber", description = "Run Cucumber Scenarios", dataProvider = "techStackWithScenarioList")
    public void scenario(Map<String, String> map, PickleEventWrapper pickle, CucumberFeatureWrapper cucumberFeature) throws Throwable {
        testNGCucumberRunner.runScenario(pickle.getPickleEvent());
    }

    @DataProvider(name = "techStackWithScenarioList", parallel = true)
    public Object[][] combineDataProvider(Method method) {
        List<Object[]> techStackList = Lists.newArrayList();
        List<Object[]> scenarios = Lists.newArrayList();
        List<List<Object>> comboList = Lists.newArrayList();

        try {
            techStackList.addAll(Arrays.asList(techStackJSON()));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        scenarios.addAll(Arrays.asList(testNGCucumberRunner.provideScenarios()));

        techStackList.forEach(techStack ->
                                      scenarios.forEach(scenario ->
                                                                comboList.add(Arrays.asList(techStack[0],
                                                                                            scenario[0],
                                                                                            scenario[1]))));

        Object[][] comboArray = new Object[comboList.size()][3];

        for (int i = 0; i < comboList.size(); i++) {
            comboArray[i][0] = comboList.get(i).get(0);
            comboArray[i][1] = comboList.get(i).get(1);
            comboArray[i][2] = comboList.get(i).get(2);
        }

        return comboArray;
    }

    @AfterClass(alwaysRun = true)
    public void tearDownClass() {
        testNGCucumberRunner.finish();
    }
}
