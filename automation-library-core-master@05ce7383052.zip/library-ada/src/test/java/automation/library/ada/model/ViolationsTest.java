package automation.library.ada.model;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

public class ViolationsTest {
	
	private static String help = "help";
	private static List<Nodes> nodes = new ArrayList<Nodes>();
	private static String impact =  "impact";
	private static String description = "description";
	private static String helpUrl = "helpUrl";
	private static String id = "id";
	private static List<String> tags =  new ArrayList<String>();
	
	static Violations violations = null;
	
	@BeforeAll
	public static void setUp()
	{
		violations = new Violations();
	}
	
	@Test
	public void impactTest() {
		 violations.setImpact(impact);
		 assertThat(violations.getImpact()).isNotNull();
	}
	
	@Test
	public void helpTest() {
		 violations.setHelp(help);
		 assertThat(violations.getHelp()).isNotNull();
	}
	
	@Test
	public void descriptionTest() {
		 violations.setDescription(description);
		 assertThat(violations.getDescription()).isNotNull();
	}
	
	@Test
	public void helpUrlTest() {
		 violations.setHelpUrl(helpUrl);
		 assertThat(violations.getHelpUrl()).isNotNull();
	}
	
	@Test
	public void idTest() {
		 violations.setId(id);
		 assertThat(violations.getId()).isNotNull();
	}
	 
	@Test
	public void nodesTest() {
		 violations.setNodes(nodes);
		 assertThat(violations.getNodes()).isNotNull();
	}
	
	@Test
	public void tagsTest() {
		 violations.setTags(tags);
		 assertThat(violations.getTags()).isNotNull();
	}
}
