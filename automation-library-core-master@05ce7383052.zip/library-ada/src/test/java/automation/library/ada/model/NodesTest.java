package automation.library.ada.model;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

public class NodesTest {
	
	private static List<All> all =  new ArrayList<All>();
    private String impact = "impact";
    private String html = "html";
    private List<None> none = new ArrayList<None>();
    private List<Any> any = new ArrayList<Any>();
    
    static Nodes nodes = null;
    
    @BeforeAll
	public static void setUp()
	{
    	nodes = new Nodes();
	}
    
    @Test
	public void impactTest() {
		 nodes.setImpact(impact);
		 assertThat(nodes.getImpact()).isNotNull();
	}
    
    @Test
	public void htmlTest() {
		 nodes.setHtml(html);
		 assertThat(nodes.getHtml()).isNotNull();
	}
    
    @Test
	public void allTest() {
		 nodes.setAll(all);
		 assertThat(nodes.getAll()).isNotNull();
	}
    
    @Test
	public void noneTest() {
		 nodes.setNone(none);
		 assertThat(nodes.getNone()).isNotNull();
	}
    
    @Test
	public void anyTest() {
		 nodes.setAny(any);
		 assertThat(nodes.getAny()).isNotNull();
	}
	 

}
