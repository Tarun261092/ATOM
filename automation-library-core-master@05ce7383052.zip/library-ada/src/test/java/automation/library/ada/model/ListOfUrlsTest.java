package automation.library.ada.model;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

public class ListOfUrlsTest {
	
	 private static List<Violations> violations = new ArrayList<Violations>();
	 private static List<Passes> passes = new ArrayList<Passes>();
	 private static String url = "url";
	
	 static ListOfUrls listOfUrls = null;
	
	 @BeforeAll
	 public static void setUp()
	 {
		 listOfUrls = new ListOfUrls();
	 }
	 
	 @Test
	 public void violationsTest() {
		 listOfUrls.setViolations(violations);
		 assertThat(listOfUrls.getViolations()).isNotNull();
	 }
	 
	 @Test
	 public void passesTest() {
		 listOfUrls.setPasses(passes);
		 assertThat(listOfUrls.getPasses()).isNotNull();
	 }
	 
	 @Test
	 public void urlTest() {
		 listOfUrls.setUrl(url);
		 assertThat(listOfUrls.getUrl()).isNotNull();
	 }

}
