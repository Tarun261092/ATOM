package automation.library.ada.model;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

public class NoneTest {
	
	 private static String impact = "impact";
     private static List<RelatedNodes> relatedNodes = new ArrayList<RelatedNodes>();
     private static String id = "id";
     private static String message = "message";
     private static String html = "html";
    
     static None none = null;
     static RelatedNodes rn1 = null;
	 
	 @BeforeAll
	 public static void setUp()
	 {
		 none = new None();
		 rn1 = new RelatedNodes();
	 }

	 @Test
	 public void impactTest() {
		 none.setImpact(impact);
		 assertThat(none.getImpact()).isNotNull();
	 }
	 
	 @Test
	 public void relatedNodesTest() {
		 rn1.setHtml(html);
		 relatedNodes.add(rn1);
		 none.setRelatedNodes(relatedNodes);
		 assertThat(none.getRelatedNodes()).isNotNull();
		 assertThat(none.toString()).isNotNull();
	 }
	 
	 @Test
	 public void idTest() {
		 none.setId(id);
		 assertThat(none.getId()).isNotNull();
	 }
	 
	 @Test
	 public void messageTest() {
		 none.setMessage(message);
		 assertThat(none.getMessage()).isNotNull();	 
	 }

}
