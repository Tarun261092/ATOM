package automation.library.ada.model;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

public class PassesTest {
	
	private static String help = "help";
	private static List<Nodes> nodes = new ArrayList<Nodes>();
	private static String impact =  "impact";
	private static String description = "description";
	private static String helpUrl = "helpUrl";
	private static String id = "id";
	private static List<String> tags =  new ArrayList<String>();
	
	static Passes passes = null;
	
	@BeforeAll
	public static void setUp()
	{
		passes = new Passes();
	}
	
	@Test
	public void impactTest() {
		 passes.setImpact(impact);
		 assertThat(passes.getImpact()).isNotNull();
	}
	
	@Test
	public void helpTest() {
		 passes.setHelp(help);
		 assertThat(passes.getHelp()).isNotNull();
	}
	
	@Test
	public void descriptionTest() {
		 passes.setDescription(description);
		 assertThat(passes.getDescription()).isNotNull();
	}
	
	@Test
	public void helpUrlTest() {
		 passes.setHelpUrl(helpUrl);
		 assertThat(passes.getHelpUrl()).isNotNull();
	}
	
	@Test
	public void idTest() {
		 passes.setId(id);
		 assertThat(passes.getId()).isNotNull();
	}
	 
	@Test
	public void nodesTest() {
		 passes.setNodes(nodes);
		 assertThat(passes.getNodes()).isNotNull();
	}
	
	@Test
	public void tagsTest() {
		 passes.setTags(tags);
		 assertThat(passes.getTags()).isNotNull();
	}
}
