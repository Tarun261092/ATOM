package automation.library.ada.model;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

public class DataTest {
	
	private static List<String> dat;
	
	static Data data = null;
	
	@BeforeAll
	public static void setUp()
	{
		 data = new Data();
		 dat = new ArrayList<String>();
	}
	
	@Test
	 public void datTest() {
		 data.setDat(dat);
		 assertThat(data.getDat()).isNotNull();
	 }

}
