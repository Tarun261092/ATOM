package automation.library.ada.model;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

public class ResponseTest {
	
	private static List<ListOfUrls> listOfURLS =  new ArrayList<ListOfUrls>();
	static Response response =  null;
	
	@BeforeAll
	public static void setUp()
	{
    	response = new Response();
	}
	
	@Test
	public void helpTest() {
		response.setListOfURLS(listOfURLS);
		assertThat(response.getListOfURLS()).isNotNull();
	}

}
