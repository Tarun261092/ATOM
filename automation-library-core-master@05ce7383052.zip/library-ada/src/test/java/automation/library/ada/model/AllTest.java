package automation.library.ada.model;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

public class AllTest {
	
	 private static String impact = "impact";
     private static List<RelatedNodes> relatedNodes = new ArrayList<RelatedNodes>();
     private static String id = "id";
     private static String message = "message";
     private static String html = "html";
    
     static All all = null;
     static RelatedNodes rn1 = null;
	 
	 @BeforeAll
	 public static void setUp()
	 {
		 all = new All();
		 rn1 = new RelatedNodes();
	 }

	 @Test
	 public void impactTest() {
		 all.setImpact(impact);
		 assertThat(all.getImpact()).isNotNull();
	 }
	 
	 @Test
	 public void relatedNodesTest() {
		 rn1.setHtml(html);
		 relatedNodes.add(rn1);
		 all.setRelatedNodes(relatedNodes);
		 assertThat(all.getRelatedNodes()).isNotNull();
		 assertThat(all.toString()).isNotNull();
	 }
	 
	 @Test
	 public void idTest() {
		 all.setId(id);
		 assertThat(all.getId()).isNotNull();
	 }
	 
	 @Test
	 public void messageTest() {
		 all.setMessage(message);
		 assertThat(all.getMessage()).isNotNull();	 
	 }

}
