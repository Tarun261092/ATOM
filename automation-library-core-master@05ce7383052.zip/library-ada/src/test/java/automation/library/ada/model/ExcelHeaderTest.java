package automation.library.ada.model;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

public class ExcelHeaderTest {
	
	 private static String url = "url";
	 private static String type = "type";
	 private static String vio = "vio";
	 private static String pass = "pass";
	 private static String id = "id";
	 private static String help = "help";
	 private static String impact = "impact";
	 private static String description = "description";
	 private static String tags = "tags";
	 private static String nodeHtml = "nodeHtml";
	 private static String nodeTarget = "nodeTarget";
	 private static String nodeImpact = "nodeImpact";
	 private static String nodeAny = "nodeAny";
	 private static String nodeNone = "nodeNone";
	 private static String nodeAll = "nodeAll";
	 private static String helpUrl = "helpUrl";
	 
	 static ExcelHeader excelHeader = null;
	 
	 @BeforeAll
	 public static void setUp()
	 {
		 excelHeader = new ExcelHeader();
	 }

	 @Test
	 public void urlTest() {
		 excelHeader.setUrl(url);
		 assertThat(excelHeader.getUrl()).isNotNull();
	 }
	 
	 @Test
	 public void typeTest() {
		 excelHeader.setType(type);
		 assertThat(excelHeader.getType()).isNotNull();
	 }
	 
	 @Test
	 public void vioTest() {
		 excelHeader.setVio(vio);
		 assertThat(excelHeader.getVio()).isNotNull();
	 }
	 
	 @Test
	 public void passTest() {
		 excelHeader.setPass(pass);
		 assertThat(excelHeader.getPass()).isNotNull();
	 }
	 
	 @Test
	 public void idTest() {
		 excelHeader.setId(id);
		 assertThat(excelHeader.getId()).isNotNull();
	 }
	 
	 @Test
	 public void helpTest() {
		 excelHeader.setHelp(help);
		 assertThat(excelHeader.getHelp()).isNotNull();
	 }
	 
	 @Test
	 public void impactTest() {
		 excelHeader.setImpact(impact);
		 assertThat(excelHeader.getImpact()).isNotNull();
	 }
	 
	 @Test
	 public void descriptionTest() {
		 excelHeader.setDescription(description);
		 assertThat(excelHeader.getDescription()).isNotNull();
	 }
	 
	 @Test
	 public void tagsTest() {
		 excelHeader.setTags(tags);
		 assertThat(excelHeader.getTags()).isNotNull();
	 }
	 
	 @Test
	 public void nodeHtmlTest() {
		 excelHeader.setNodeHtml(nodeHtml);
		 assertThat(excelHeader.getNodeHtml()).isNotNull();
	 }
	 
	 @Test
	 public void nodeTargetTest() {
		 excelHeader.setNodeTarget(nodeTarget);
		 assertThat(excelHeader.getNodeTarget()).isNotNull();
	 }
	 
	 @Test
	 public void nodeImpactTest() {
		 excelHeader.setNodeImpact(nodeImpact);
		 assertThat(excelHeader.getNodeImpact()).isNotNull();
	 }
	 
	 @Test
	 public void nodeNoneTest() {
		 excelHeader.setNodeNone(nodeNone);
		 assertThat(excelHeader.getNodeNone()).isNotNull();
	 }
	 
	 @Test
	 public void nodeAnyTest() {
		 excelHeader.setNodeAny(nodeAny);
		 assertThat(excelHeader.getNodeAny()).isNotNull();
	 }
	 
	 @Test
	 public void nodeAllTest() {
		 excelHeader.setNodeAll(nodeAll);
		 assertThat(excelHeader.getNodeAll()).isNotNull();
	 }
	 
	 @Test
	 public void helpUrlTest() {
		 excelHeader.setHelpUrl(helpUrl);
		 assertThat(excelHeader.getHelpUrl()).isNotNull();
	 }
}
