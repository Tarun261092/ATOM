package automation.library.ada.model;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

public class AnyTest {
	
	 private static String impact = "impact";
     private static List<RelatedNodes> relatedNodes = new ArrayList<RelatedNodes>();
     private static String id = "id";
     private static String message = "message";
     private static String html = "html";
    
     static Any any = null;
     static RelatedNodes rn1 = null;
	 
	 @BeforeAll
	 public static void setUp()
	 {
		 any = new Any();
		 rn1 = new RelatedNodes();
	 }

	 @Test
	 public void impactTest() {
		 any.setImpact(impact);
		 assertThat(any.getImpact()).isNotNull();
	 }
	 
	 @Test
	 public void relatedNodesTest() {
		 rn1.setHtml(html);
		 relatedNodes.add(rn1);
		 any.setRelatedNodes(relatedNodes);
		 assertThat(any.getRelatedNodes()).isNotNull();
		 assertThat(any.toString()).isNotNull();
	 }
	 
	 @Test
	 public void idTest() {
		 any.setId(id);
		 assertThat(any.getId()).isNotNull();
	 }
	 
	 @Test
	 public void messageTest() {
		 any.setMessage(message);
		 assertThat(any.getMessage()).isNotNull();	 
	 }

}
