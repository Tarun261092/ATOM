package automation.library.ada;

import automation.library.common.Property;
import automation.library.selenium.exec.driver.factory.DriverContext;
import com.deque.html.axedevtools.selenium.AxeConfiguration;
import io.cucumber.core.api.Scenario;
import io.cucumber.java8.En;
import org.apache.commons.configuration2.PropertiesConfiguration;

import static automation.library.ada.Constants.ADAREPORTPATH;


public class AutoEngHooksADA implements En {
    public AutoEngHooksADA() {

        Before(40, (Scenario scenario) ->
                setADAProperties());
    }

    private void setADAProperties() {
        PropertiesConfiguration props = Property.getProperties(Constants.SELENIUMRUNTIMEPATH);
        if (props != null) {
            String suiteName = props.getString("TestSuiteName");
            String testMachine = props.getString("MachineType") == null ? "Test Machine" : props.getString("MachineType");
            String browserName = DriverContext.getInstance().getBrowserName();
            AxeConfiguration.configure().testSuiteName(suiteName).
                                         forRuleset("wcag2.1").
                                         userAgent(browserName).
                                         testMachine(testMachine).
                                         outputDirectory(ADAREPORTPATH);
        }
    }

}
