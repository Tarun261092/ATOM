package automation.library.ada;


public class Constants {
    private static final String USER_DIR = System.getProperty("user.dir");
    public static final String BASEPATH = USER_DIR + "/src/test/resources/";
    public static final String ADACSSJSON = BASEPATH + "ADACSS.json";
    public static final String ADAREPORTPATH = USER_DIR + "/dequeResults/";
    public static final String SELENIUMRUNTIMEPATH = BASEPATH + "config/selenium/" + "runtime.properties";
    public static final String IMAGESPATH = "src/resources/images/";
    public static final String PASSES = "Passes";
    public static final String VIOLATIONS = "Violations";
    public static final String HEADERTXT = "Deque AXE Report Summary";
    public static final String SUMMARY = "This document provides the test results for the WCAG 2.1 Success Criteria using different accessibility tools.";
    public static final String NAQELOGO ="images/NAQE.JPG";
    public static final String CITILOGO ="images/Citi.JPG";
    public static final String TSNAME ="Test Scenario Name";
    public static final String EXEDATE ="Execution Date";
    public static final String SNO ="S.no.";
    public static final String URL ="URL";
    public static final String TC ="Total Criteria";
    public static final String FC ="Failed Criteria";
    public static final String HTMLELE ="HTML Elements";
    public static final String TOTAL ="Total";
    public static final String VIOIMPACT ="Violation Impact";
    public static final String CRITERIA ="Criteria";
    public static final String TESTSUITE ="Test Suite";
    public static final String TESTURL ="Tested URLs";
    public static final String NOOFCRIT ="Number of Criteria Validated for each URL";
    public static final String VIOIMCR ="Violation Impact on Criteria";
    public static final String HTMLLIST ="List of HTML Elements impacted";

    private Constants() {
        //Utility class
    }
}
