package automation.library.ada.model;

import java.util.List;

public class Response {
	private List<ListOfUrls> listOfURLS;

	public List<ListOfUrls> getListOfURLS() {
		return listOfURLS;
	}

	public void setListOfURLS(List<ListOfUrls> listOfURLS) {
		this.listOfURLS = listOfURLS;
	}

	
	
}
