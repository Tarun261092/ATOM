package automation.library.ada.model;

import java.util.List;

public class Data {
	List<String> dat;

	public List<String> getDat() {
		return dat;
	}

	public void setDat(List<String> dat) {
		this.dat = dat;
	}
	
	
}
