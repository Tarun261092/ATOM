package automation.library.ada;


import com.deque.html.axecore.results.Results;
import com.deque.html.axedevtools.reporter.AxeDevtoolsReporter;
import com.deque.html.axedevtools.selenium.AxeDriver;
import com.deque.html.axedevtools.selenium.AxeSelenium;
import com.deque.html.axedevtools.selenium.reporter.AxeReportingOptions;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;


public class AXEAccessibilitySteps {
    private static final String REPORTEXTENSION = ".log";
    private static final String FILESEPARATER = "/";

    private static Logger getLogger() {
        return LogManager.getLogger(AXEAccessibilitySteps.class);
    }

    private Results testAccessibility(WebDriver driver) {

        AxeSelenium axeSelenium = new AxeSelenium();
        AxeDriver axeDriver = new AxeDriver(driver);
        Results result = null;
        try {
            getLogger().info("ADA process started on the step");
            result = axeSelenium.run(axeDriver);
            if (!result.violationFree()) {
                int violationCount = result.getViolations().size();
                getLogger().info("Found {} Violations!", violationCount);
            } else {
                getLogger().info("No Violations Found");
            }
            getLogger().info("ADA process finished");
            return result;
        } catch (Exception e) {
            getLogger().warn(e.getMessage());
        }
        return result;
    }

    public String generateAxeReport(WebDriver driver, String scenario, int stepLine) {
        AxeDevtoolsReporter reporter = new AxeDevtoolsReporter();
        AxeReportingOptions options = new AxeReportingOptions();
        String fileName = String.valueOf(stepLine);
        options.outputDirectory(options.getOutputDirectory() + FILESEPARATER + scenario).uiState(fileName);
        Results result = testAccessibility(driver);
        if (result != null) {
            reporter.report(options, result, "");
        }
        return String.format("%s-%s%s", options.getSuiteTestName(), fileName, REPORTEXTENSION);
    }

}