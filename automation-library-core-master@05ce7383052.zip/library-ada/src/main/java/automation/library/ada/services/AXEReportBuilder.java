package automation.library.ada.services;


import automation.library.ada.model.Response;

import automation.library.common.JSONHelper;
import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.IOException;
import java.nio.file.Path;
import java.util.*;

import static automation.library.ada.Constants.ADAREPORTPATH;
import static automation.library.common.FileHelper.getFileAsString;
import static automation.library.common.FileHelper.getListOfFoldersName;
import static automation.library.common.FileHelper.getMatchingFilePathsFromDirectory;


public class AXEReportBuilder {
    private static Logger getLogger() {
        return LogManager.getLogger(AXEReportBuilder.class);
    }

    private static final String FINDINGS = "findings";
    private static final String NODES = "nodes";
    private Map<String, List<String>> stepViolation;
    private JSONArray vio;
    private JSONArray finalArray = new JSONArray();
    private JSONObject finalob = new JSONObject();

    public void dequeReportGeneration() {

        List<String> testNames = new ArrayList<>();
        String reportFolder = null;
        String folderName = System.getProperty("folderName");

        if (folderName != null) {
            testNames.add(folderName);
            reportFolder = ADAREPORTPATH + "/" + folderName;
            getLogger().info("Creating Deque Axe report for folder {}", folderName);
            aggregateADAReport(reportFolder);
        } else {
            testNames.addAll(getListOfFoldersName(ADAREPORTPATH));
            getLogger().info("Creating Deque Axe report for test set");
            aggregateADAReport(ADAREPORTPATH);
            folderName = "final";
        }
        String filePath = ADAREPORTPATH + folderName + ".json";
        JSONHelper.convertMapToJSON(finalob.toMap(), filePath);
        createADASummaryreport(filePath, testNames);
    }

    private void aggregateADAReport(String reportFolder) {
        Set<Path> path = getMatchingFilePathsFromDirectory(reportFolder, ".json");
        path.removeIf(path1 -> path1.getFileName().toString().equals("final.json"));
        List<String> testNames = getListOfFoldersName(reportFolder);
        List<String> listOfURLs = getPagesURL(path);
        JSONObject finalObject;
        String[] type = {"violations", "passes"};

        for (String url : listOfURLs) {
            finalObject = new JSONObject();
            finalObject.put("url", url);
            for (String subtype : type) {
                stepViolation = new HashMap<>();
                vio = new JSONArray();
                for (Path s : path) {
                    fetchDataFromJSON(s.toAbsolutePath().toString(), url, subtype);
                }
                finalObject.put(subtype, vio);
            }
            finalob.put("listOfURLS", finalArray.put(finalObject));
            finalob.put("TestRun", testNames);
        }
    }

    private void fetchDataFromJSON(String s, String expectedURL, String type) {
        List<String> nodesViolations = null;
        JSONObject subNode = null;
        JSONArray violationArray = (JSONArray) Objects.requireNonNull(JSONHelper.getJSONData(s, FINDINGS)).get(type);
        String url = Objects.requireNonNull(JSONHelper.getJSONData(s, FINDINGS)).getString("url");

        if (url.equalsIgnoreCase(expectedURL)) {
            for (int i = 0; i < violationArray.length(); i++) {
                nodesViolations = new ArrayList<>();
                JSONObject ob = violationArray.getJSONObject(i);
                JSONArray nodes = ob.getJSONArray(NODES);
                String id = ob.getString("id");
                for (int y = 0; y < nodes.length(); y++) {
                    subNode = (JSONObject) nodes.get(y);
                    String nodeHTML = (subNode.getString("html"));
                    if (stepViolation.containsKey(id)) {
                        if (!stepViolation.get(id).contains(nodeHTML)) {
                            stepViolation.get(id).add(nodeHTML);
                            for (int z = 0; z < vio.length(); z++) {
                                if (vio.getJSONObject(z).getString("id").equalsIgnoreCase(id) && vio.getJSONObject(z).getJSONArray(NODES).toString().contains(nodeHTML)) {
                                    vio.getJSONObject(z).getJSONArray(NODES).put(subNode);
                                }
                            }
                        }
                    } else {
                        nodesViolations.add(nodeHTML);
                        stepViolation.put(id, nodesViolations);
                        vio.put(ob);
                    }
                }
            }
        }
    }

    private List<String> getPagesURL(Set<Path> files) {
        List<String> urls = new ArrayList<>();
        for (Path f : files
        ) {
            String l = Objects.requireNonNull(JSONHelper.getJSONData(f.toAbsolutePath().toString(), FINDINGS)).getString("url");
            if (!urls.contains(l)) urls.add(l);
        }
        return urls;
    }

    private void createADASummaryreport(String filePath, List<String> testNames) {
        Gson gson = new Gson();
        String json = null;
        try {
            json = getFileAsString(filePath, "");
            Response response = gson.fromJson(json, Response.class);
            ADAExcelService excelService = new ADAExcelService();
            excelService.populateExcelHeader(response);
            PDFService pdf = new PDFService();
            pdf.createPdf(response, testNames);
        } catch (JsonSyntaxException | IOException e) {
            e.getMessage();
        }
    }

}