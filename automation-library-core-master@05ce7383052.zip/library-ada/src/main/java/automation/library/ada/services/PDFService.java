package automation.library.ada.services;


import automation.library.ada.model.ExcelHeader;
import automation.library.ada.model.Response;
import com.itextpdf.awt.PdfGraphics2D;
import com.itextpdf.text.Font;
import com.itextpdf.text.*;
import com.itextpdf.text.Image;
import com.itextpdf.text.Font.FontFamily;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.*;
import com.itextpdf.text.Chunk;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.labels.PieSectionLabelGenerator;
import org.jfree.chart.labels.StandardCategoryItemLabelGenerator;
import org.jfree.chart.labels.StandardPieSectionLabelGenerator;
import org.jfree.chart.plot.PiePlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;



import java.awt.*;
import java.awt.geom.Rectangle2D;
import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

import static automation.library.ada.Constants.*;


public class PDFService {
	Font regular = new Font(FontFamily.HELVETICA, 10);
	Font font = new Font(FontFamily.HELVETICA, 15, Font.BOLD);
	Font boldFont = new Font(FontFamily.HELVETICA, 12, Font.BOLD);
	Font font14pt = new Font(FontFamily.HELVETICA, 14, Font.BOLD, BaseColor.DARK_GRAY);
	private final Logger log = LogManager.getLogger(PDFService.class);


	public void createPdf(Response res, List<String> testScenariosLst) {
		List<ExcelHeader> headerLst = convertToOneToOneMapping(res);
		PdfWriter writer;
		int urlSize = res.getListOfURLS().size();
		List<List<Integer>> barchart = new ArrayList<>();
		int passesCount = 0;
		int vioCount = 0;
		int totalCount = 0;
		Document doc;
		Set<String> impactSet = new HashSet<>();
		Map<String, Integer> pieChartMap = new HashMap<>();

		try {
			OutputStream fos = new FileOutputStream(new File(ADAREPORTPATH + "DequeAxeReportSummary.pdf"));
			doc = new Document(PageSize.A4, 20f, 20f, 20f, 20f);
			writer = PdfWriter.getInstance(doc, fos);
			HeaderFooterPageEvent event = new HeaderFooterPageEvent();
			writer.setPageEvent(event);
			doc.open();
			doc.newPage();

			//Logo's
			PdfPTable table = new PdfPTable(2);
			table.setWidthPercentage(100);
			table.setWidths(new int[]{1, 1});
			table.addCell(createImageCell(Objects.requireNonNull(PDFService.class.getClassLoader().getResource(NAQELOGO)).toString(), 0));
			table.addCell(createImageCell(Objects.requireNonNull(PDFService.class.getClassLoader().getResource(CITILOGO)).toString(), 2));

			//Initial Header
			Paragraph heading = new Paragraph(HEADERTXT, font);
			heading.setAlignment(1);
			heading.setSpacingAfter(10f);
			Paragraph summary = new Paragraph(SUMMARY, regular);
			summary.setSpacingAfter(10);

			//tableTS test suit
			PdfPTable tableTS = createTable(new float[]{5, 5}, 60, new String[]{TSNAME, EXEDATE});
			LocalDateTime localDate = LocalDateTime.now();
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy HH:mm:ss");
			String formattedString = localDate.format(formatter);

			testScenariosLst.forEach(tst -> {
				tableTS.addCell(tst);
				tableTS.addCell(formattedString);
			});

			//tableUrl Url's,tableTC Total Criteria,tableHtml Html objects
			PdfPTable tableUrl = createTable(new float[]{1, 10}, 100, new String[]{SNO, URL});
			PdfPTable tableTC = createTable(new float[]{2, 12, 3, 3, 4}, 100, new String[]{SNO, URL, PASSES, VIOLATIONS, TC});
			PdfPTable tableHtml = createTable(new float[]{10, 2}, 100, new String[]{HTMLELE, FC});

			for (int i = 0; i < urlSize; i++) {
				tableUrl.addCell(Integer.toString(i + 1));
				tableUrl.addCell(res.getListOfURLS().get(i).getUrl());
				tableTC.addCell(Integer.toString(i + 1));
				tableTC.addCell(res.getListOfURLS().get(i).getUrl());

				int passeCount = 0;
				int viCount = 0;
				List<String> html = new ArrayList<>();

				for (ExcelHeader excelHeader : headerLst) {
					if (excelHeader.getUrl().equalsIgnoreCase(res.getListOfURLS().get(i).getUrl()) && excelHeader.getType().equalsIgnoreCase(PASSES)) {
						passeCount++;
					} else if (excelHeader.getUrl().equalsIgnoreCase(res.getListOfURLS().get(i).getUrl()) && excelHeader.getType().equalsIgnoreCase(VIOLATIONS)) {
						viCount++;
						html.add(excelHeader.getNodeHtml());
					}
				}
				tableTC.addCell(Integer.toString(passeCount));
				tableTC.addCell(Integer.toString(viCount));
				tableTC.addCell(Integer.toString(passeCount + viCount));

				List<Integer> barchartVals2 = new ArrayList<>();
				barchartVals2.add(passeCount);
				barchartVals2.add(viCount);
				barchartVals2.add(passeCount + viCount);
				barchart.add(barchartVals2);
				passesCount = passesCount + passeCount;
				vioCount = vioCount + viCount;
				totalCount = totalCount + passeCount + viCount;

				// table Html..
				PdfPCell cell = new PdfPCell();
				cell.setPhrase(new Phrase(res.getListOfURLS().get(i).getUrl()));
				cell.setBackgroundColor(new BaseColor(253, 213, 177));
				cell.setColspan(2);
				tableHtml.addCell(cell);
				Map<String, Long> htmlMap = html.stream().collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));

				htmlMap.forEach((k, v) -> {
					tableHtml.addCell(k);
					tableHtml.addCell(Long.toString(v));
				});
			}
			//adding total count in table 2
			addTableHeader(tableTC, new ArrayList<>(Arrays.asList("", TC, Integer.toString(passesCount), Integer.toString(vioCount), Integer.toString(totalCount))));

			//table Violation starts
			PdfPTable tableV = createTable(new float[]{5, 5}, 50, new String[]{VIOIMPACT, CRITERIA});
			Map<String, Long> countForId = headerLst.stream().collect(Collectors.groupingBy(ExcelHeader::getId, Collectors.counting()));
			countForId.remove(null);
			headerLst.forEach(dr -> {
				if (dr.getType().equalsIgnoreCase(VIOLATIONS)) {
					impactSet.add(dr.getImpact());
				}
			});

			impactSet.remove(null);
			Map<String, Map<String, Long>> impactMap = new HashMap<>();
			long crCount = 0L;
			for (String impact : impactSet) {
				List<String> impactIds = getImpactList(headerLst, impact);
				int idsSize = (int) impactIds.stream().distinct().count();
				Map<String, Long> imMap = impactIds.stream().collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
				impactMap.put(impact, imMap);

				PdfPCell imCell = new PdfPCell();
				imCell.addElement(new Paragraph(impact, boldFont));
				imCell.setColspan(2);
				tableV.addCell(imCell);
				crCount = crCount + imMap.values().stream().reduce((long) 0, Long::sum);
				imMap.forEach((k, v) -> {
					tableV.addCell(k);
					tableV.addCell(Long.toString(v));
				});
				pieChartMap.put(impact, idsSize);
			}
			addTableHeader(tableV, new ArrayList<>(Arrays.asList(TOTAL, Long.toString(crCount))));

			//Pie chart for Violations
			DefaultPieDataset defaultCategoryDataset = new DefaultPieDataset();
			pieChartMap.forEach(defaultCategoryDataset::setValue);
			List<Image> imagesLst = new ArrayList<>();
			impactMap.forEach((k, v) -> {
				DefaultPieDataset defaultCategoryDataset2 = new DefaultPieDataset();
				v.forEach(defaultCategoryDataset2::setValue);
				imagesLst.add(createPieChart(defaultCategoryDataset2, writer, k));
			});

			//Adding all elements to document
			doc.add(table);
			doc.add(heading);
			doc.add(summary);
			doc.add(new Phrase(TESTSUITE, font14pt));
			doc.add(tableTS);
			doc.add(new Phrase(TESTURL, font14pt));
			doc.add(tableUrl);
			doc.add(new Phrase(NOOFCRIT, font14pt));
			doc.add(tableTC);
			doc.add(createBarChart(barchart, writer));
			doc.newPage();
			doc.add(Chunk.NEWLINE);
			doc.add(new Phrase(VIOIMCR, font14pt));
			doc.add(tableV);
			doc.add(createPieChart(defaultCategoryDataset, writer, CRITERIA));
			addImagesToDoc(imagesLst, doc);

			doc.newPage();
			doc.add(Chunk.NEWLINE);
			doc.add(new Phrase(HTMLLIST, font14pt));
			doc.add(tableHtml);
			doc.close();
		} catch (Exception e) {
			e.getMessage();
		}
	}

	// Convert JSONObject to One to One relation
	private List<ExcelHeader> convertToOneToOneMapping(Response res) {
		List<ExcelHeader> headerLst = new ArrayList<>();
		int urlSize = res.getListOfURLS().size();
		for (int i = 0; i < urlSize; i++) {
			//violation iteration
			for (int j = 0; j < res.getListOfURLS().get(i).getViolations().size(); j++) {

				for (int k = 0; k < res.getListOfURLS().get(i).getViolations().get(j).getNodes().size(); k++) {
					ExcelHeader header = new ExcelHeader();
					header.setUrl(res.getListOfURLS().get(i).getUrl());
					header.setType(VIOLATIONS);
					header.setId(res.getListOfURLS().get(i).getViolations().get(j).getId());
					header.setHelp(res.getListOfURLS().get(i).getViolations().get(j).getHelp());
					header.setImpact(res.getListOfURLS().get(i).getViolations().get(j).getImpact());
					header.setDescription(res.getListOfURLS().get(i).getViolations().get(j).getDescription());
					header.setTags(res.getListOfURLS().get(i).getViolations().get(j).getTags().toString());
					header.setNodeHtml(res.getListOfURLS().get(i).getViolations().get(j).getNodes().get(k).getHtml());
					header.setNodeAll(res.getListOfURLS().get(i).getViolations().get(j).getNodes().get(k).getAll().toString());
					header.setNodeAny(res.getListOfURLS().get(i).getViolations().get(j).getNodes().get(k).getAny().toString());
					header.setNodeImpact(res.getListOfURLS().get(i).getViolations().get(j).getNodes().get(k).getImpact());
					header.setNodeNone(res.getListOfURLS().get(i).getViolations().get(j).getNodes().get(k).getNone().toString());
					header.setHelpUrl(res.getListOfURLS().get(i).getViolations().get(j).getHelpUrl());
					headerLst.add(header);
				}
			}
			//Passes iteration
			for (int n = 0; n < res.getListOfURLS().get(i).getPasses().size(); n++) {

				for (int o = 0; o < res.getListOfURLS().get(i).getPasses().get(n).getNodes().size(); o++) {
					ExcelHeader header = new ExcelHeader();
					header.setUrl(res.getListOfURLS().get(i).getUrl());
					header.setType(PASSES);
					header.setId(res.getListOfURLS().get(i).getPasses().get(n).getId());
					header.setHelp(res.getListOfURLS().get(i).getPasses().get(n).getHelp());
					header.setImpact(res.getListOfURLS().get(i).getPasses().get(n).getImpact());
					header.setDescription(res.getListOfURLS().get(i).getPasses().get(n).getDescription());
					header.setTags(res.getListOfURLS().get(i).getPasses().get(n).getTags().toString());
					header.setNodeHtml(res.getListOfURLS().get(i).getPasses().get(n).getNodes().get(o).getHtml());
					header.setNodeAll(res.getListOfURLS().get(i).getPasses().get(n).getNodes().get(o).getAll().toString());
					header.setNodeAny(res.getListOfURLS().get(i).getPasses().get(n).getNodes().get(o).getAny().toString());
					header.setNodeImpact(res.getListOfURLS().get(i).getPasses().get(n).getNodes().get(o).getImpact());
					header.setNodeNone(res.getListOfURLS().get(i).getPasses().get(n).getNodes().get(o).getNone().toString());
					header.setHelpUrl(res.getListOfURLS().get(i).getPasses().get(n).getHelpUrl());
					headerLst.add(header);
				}
			}
		}
		return headerLst.stream()
				.collect(Collectors.collectingAndThen(
						Collectors.toMap(c -> Arrays.asList(c.getUrl(), c.getType(), c.getId(), c.getHelp(),
								c.getImpact(), c.getDescription(), c.getTags(), c.getHelpUrl(),
								c.getNodeHtml(), c.getNodeImpact(), c.getNodeAny(),
								c.getNodeNone(), c.getNodeAll()),
								Function.identity(), (a, b) -> a, LinkedHashMap::new),
						m -> new ArrayList<>(m.values())));
	}

	// Add table headerRows
	private void addTableHeader(PdfPTable table, List<String> lst) {
		// Adding cells to the table
		for (String str : lst) {
			PdfPCell cell1 = new PdfPCell();
			cell1.setPhrase(new Phrase(str, boldFont));
			cell1.setBackgroundColor(new BaseColor(174, 214, 241));
			table.addCell(cell1);
		}
	}

	//create dataset
	private CategoryDataset createDataset(List<List<Integer>> val) {
		final DefaultCategoryDataset dataset =
				new DefaultCategoryDataset();
		int size = val.size();
		for (int i = 0; i < size; i++) {
			dataset.addValue(val.get(i).get(0), PASSES, "URL" + (i + 1));
			dataset.addValue(val.get(i).get(1), VIOLATIONS, "URL" + (i + 1));
			dataset.addValue(val.get(i).get(2), TC, "URL" + (i + 1));
		}
		return dataset;
	}

	//create pie chart
	private Image createPieChart(DefaultPieDataset defaultCategoryDataset, PdfWriter writer, String name) {
		JFreeChart jFreeChart = ChartFactory.createPieChart(
				name,  //pie chart title
				defaultCategoryDataset, //pie chart dataset
				true, true, false);  //pie chart> legend, tooltips and urls
		PiePlot plot = (PiePlot) jFreeChart.getPlot();
		PieSectionLabelGenerator labelGenerator = new StandardPieSectionLabelGenerator("{1}");
		plot.setLabelGenerator(labelGenerator);

		PdfContentByte pdfContentByte = writer.getDirectContent();
		int width = 350; //width of PieChart
		int height = 300; //height of pieChart
		PdfTemplate pdfTemplate = pdfContentByte.createTemplate(width, height);
		Graphics2D graphics2d = new PdfGraphics2D(pdfTemplate, width, height);
		Rectangle2D rectangle2d = new Rectangle2D.Double(0, 0, width, height);
		jFreeChart.draw(graphics2d, rectangle2d);

		graphics2d.dispose();
		Image chartImage = null;
		try {
			chartImage = Image.getInstance(pdfTemplate);
		} catch (BadElementException e) {
			log.error(e.getMessage());
		}
		return chartImage;
	}

	//create Barchart
	private Image createBarChart(List<List<Integer>> dataset, PdfWriter writer) {
		JFreeChart barChart = ChartFactory.createBarChart(
				"Test Result Summary Report",
				"",
				"",
				createDataset(dataset),
				PlotOrientation.VERTICAL,
				true, true, false);
		java.awt.Font customFont = new java.awt.Font("Helvetica", java.awt.Font.BOLD, 14);
		barChart.getTitle().setFont(customFont);
		int height = 370;
		PdfContentByte addChartContent = writer.getDirectContent();
		PdfTemplate templateChartHolder = addChartContent.createTemplate(700, height);
		Graphics2D graphicsChart = new PdfGraphics2D(templateChartHolder, 700, height);
		Rectangle2D chartRegion = new Rectangle2D.Double(0, 0, 500, height);
		CategoryItemRenderer renderer = barChart.getCategoryPlot().getRenderer();
		for (int i = 0; i < 3; i++) {
			renderer.setSeriesItemLabelGenerator(i, new StandardCategoryItemLabelGenerator());
		}
		renderer.setSeriesItemLabelsVisible(1, true);
		renderer.setBaseItemLabelsVisible(true);
		renderer.setBaseSeriesVisible(true);
		barChart.getCategoryPlot().setRenderer(renderer);
		barChart.draw(graphicsChart, chartRegion);
		graphicsChart.dispose();
		Image barchartImage = null;
		try {
			barchartImage = Image.getInstance(templateChartHolder);
		} catch (BadElementException e) {
			log.error(e.getMessage());
		}
		return barchartImage;
	}

	//create cell with image
	private PdfPCell createImageCell(String path, int alignment) throws DocumentException, IOException {
		Image img = Image.getInstance(path);
		PdfPCell cell = new PdfPCell(img);
		cell.setHorizontalAlignment(alignment);
		cell.setBorder(Rectangle.NO_BORDER);
		return cell;
	}

	//create table
	private PdfPTable createTable(float[] pointColumnWidths, float widthPer, String[] arr) {
		PdfPTable table = new PdfPTable(pointColumnWidths);
		table.setWidthPercentage(widthPer);
		table.setSpacingAfter(20f);
		table.setHorizontalAlignment(0);
		addTableHeader(table, new ArrayList<>(Arrays.asList(arr)));
		return table;
	}

	private void addImagesToDoc(List<Image> imagesLst, Document doc) {
		imagesLst.forEach(img -> {
			try {
				doc.add(img);
			} catch (DocumentException e) {
				log.error(e.getMessage());
			}
		});
	}

	private List<String> getImpactList(List<ExcelHeader> headerLst, String impact) {
		List<String> impactIds = new ArrayList<>();
		for (ExcelHeader lst : headerLst) {
			if (lst.getType().equalsIgnoreCase(VIOLATIONS) && lst.getImpact().equalsIgnoreCase(impact)) {
				impactIds.add(lst.getId());
			}
		}
		return impactIds;
	}
}
