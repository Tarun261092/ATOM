package automation.library.ada.model;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class All {

    private String impact;
    private List<RelatedNodes> relatedNodes;
    private String id;
    private String message;

    public String getImpact() {
        return impact;
    }

    public void setImpact(String impact) {
        this.impact = impact;
    }

    public List<RelatedNodes> getRelatedNodes() {
        return relatedNodes;
    }

    public void setRelatedNodes(List<RelatedNodes> relatedNodes) {
        this.relatedNodes = relatedNodes;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    @Override
    public String toString() {
        ArrayList<String> ar = new ArrayList<>();
        for (RelatedNodes rl : relatedNodes) {
            ar.add("html: " + rl.getHtml());
        }
        return "[impact=" + impact + ", relatedNodes=" + Arrays.toString(ar.toArray()) + ", id=" + id + ", message=" + message + "]";
    }
}
