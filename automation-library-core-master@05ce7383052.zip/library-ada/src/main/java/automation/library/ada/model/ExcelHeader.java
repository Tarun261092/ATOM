package automation.library.ada.model;

public class ExcelHeader {
 private String url;
 private String type;
 private String vio;
 private String pass;
 private String id;
 private String help;
 private String impact;
 private String description;
 private String tags;
 private String nodeHtml;
 private String nodeTarget;
 private String nodeImpact;
 private String nodeAny;
 private String nodeNone;
 private String nodeAll;
 private String helpUrl;
public String getUrl() {
	return url;
}
public void setUrl(String url) {
	this.url = url;
}
public String getId() {
	return id;
}
public void setId(String id) {
	this.id = id;
}
public String getHelp() {
	return help;
}
public void setHelp(String help) {
	this.help = help;
}
public String getImpact() {
	return impact;
}
public void setImpact(String impact) {
	this.impact = impact;
}
public String getDescription() {
	return description;
}
public void setDescription(String description) {
	this.description = description;
}
public String getTags() {
	return tags;
}
public void setTags(String tags) {
	this.tags = tags;
}
public String getNodeHtml() {
	return nodeHtml;
}
public void setNodeHtml(String nodeHtml) {
	this.nodeHtml = nodeHtml;
}
public String getNodeTarget() {
	return nodeTarget;
}
public void setNodeTarget(String nodeTarget) {
	this.nodeTarget = nodeTarget;
}
public String getNodeImpact() {
	return nodeImpact;
}
public void setNodeImpact(String nodeImpact) {
	this.nodeImpact = nodeImpact;
}
public String getNodeAny() {
	return nodeAny;
}
public void setNodeAny(String nodeAny) {
	this.nodeAny = nodeAny;
}
public String getNodeNone() {
	return nodeNone;
}
public void setNodeNone(String nodeNone) {
	this.nodeNone = nodeNone;
}
public String getNodeAll() {
	return nodeAll;
}
public void setNodeAll(String nodeAll) {
	this.nodeAll = nodeAll;
}
public String getType() {
	return type;
}
public void setType(String type) {
	this.type = type;
}
public String getVio() {
	return vio;
}
public void setVio(String vio) {
	this.vio = vio;
}
public String getPass() {
	return pass;
}
public void setPass(String pass) {
	this.pass = pass;
}

	public String getHelpUrl() {
		return helpUrl;
	}

	public void setHelpUrl(String helpUrl) {
		this.helpUrl = helpUrl;
	}
}
