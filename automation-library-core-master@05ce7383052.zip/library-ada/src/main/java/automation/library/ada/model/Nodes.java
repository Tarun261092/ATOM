package automation.library.ada.model;

import java.util.List;

public class Nodes {
    private List<All> all;
    private String impact;
    private String html;
    private List<None> none;
    private List<Any> any;

    public List<All> getAll() {
        return all;
    }

    public void setAll(List<All> all) {
        this.all = all;
    }

    public String getImpact() {
        return impact;
    }

    public void setImpact(String impact) {
        this.impact = impact;
    }

    public String getHtml() {
        return html;
    }

    public void setHtml(String html) {
        this.html = html;
    }

    public List<None> getNone() {
        return none;
    }

    public void setNone(List<None> none) {
        this.none = none;
    }

    public List<Any> getAny() {
        return any;
    }

    public void setAny(List<Any> any) {
        this.any = any;
    }

}
