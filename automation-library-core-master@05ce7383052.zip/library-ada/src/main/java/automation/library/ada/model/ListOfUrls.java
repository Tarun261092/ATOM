package automation.library.ada.model;

import java.util.List;


public class ListOfUrls {
	private List<Violations> violations;
	private List<Passes> passes;
	private String url;
	public List<Violations> getViolations() {
		return violations;
	}
	public void setViolations(List<Violations> violations) {
		this.violations = violations;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public List<Passes> getPasses() {
		return passes;
	}
	public void setPasses(List<Passes> passes) {
		this.passes = passes;
	}
	
	
}
