package automation.library.ada.services;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class HeaderFooterPageEvent extends PdfPageEventHelper {
    Font font = new Font(Font.FontFamily.UNDEFINED, 10, Font.ITALIC);

    @Override
    public void onEndPage(PdfWriter writer, Document document) {
        PdfContentByte cb = writer.getDirectContent();
        LocalDateTime localDate = LocalDateTime.now();//For reference
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy HH:mm:ss");
        String formattedString = localDate.format(formatter);
        Phrase header = new Phrase("Report generated on " + formattedString, font);
        ColumnText.showTextAligned(cb, Element.ALIGN_RIGHT,
                header,
                document.right() - 10,
                document.top() + 10, 0);

    }
}
