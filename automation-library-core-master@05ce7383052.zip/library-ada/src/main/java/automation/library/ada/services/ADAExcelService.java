package automation.library.ada.services;



import automation.library.ada.Constants;
import automation.library.ada.model.ExcelHeader;
import automation.library.ada.model.Response;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;






public class ADAExcelService {
    private final Logger log = LogManager.getLogger(ADAExcelService.class);

    public void populateExcelHeader(Response res) {
        //getting unique list
        List<ExcelHeader> headerLst = convertToOneToOneMapping(res).stream()
                .collect(Collectors.collectingAndThen(
                        Collectors.toMap(c -> Arrays.asList(c.getUrl(), c.getType(), c.getId(), c.getHelp(),
                                c.getImpact(), c.getDescription(), c.getTags(), c.getHelpUrl(),
                                c.getNodeHtml(), c.getNodeImpact(), c.getNodeAny(),
                                c.getNodeNone(), c.getNodeAll()),
                                Function.identity(), (a, b) -> a, LinkedHashMap::new),
                        m -> new ArrayList<>(m.values())));

        //Create blank workbook
        try (XSSFWorkbook workbook = new XSSFWorkbook()) {
            XSSFSheet spreadsheet = workbook.createSheet(" Deque AXE Report");

            // Create header CellStyle
            XSSFFont headerFont = workbook.createFont();
            headerFont.setColor(IndexedColors.WHITE.index);
            CellStyle headerCellStyle = spreadsheet.getWorkbook().createCellStyle();
            headerCellStyle.setFillForegroundColor(IndexedColors.LIGHT_BLUE.index);
            headerCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            headerCellStyle.setFont(headerFont);

            //setting width of each column
            spreadsheet.setColumnWidth(0, 10000);
            spreadsheet.setColumnWidth(1, 3000);
            spreadsheet.setColumnWidth(2, 3000);
            spreadsheet.setColumnWidth(3, 10000);
            spreadsheet.setColumnWidth(4, 3000);
            spreadsheet.setColumnWidth(5, 5000);
            spreadsheet.setColumnWidth(6, 10000);
            spreadsheet.setColumnWidth(7, 10000);
            spreadsheet.setColumnWidth(8, 8000);
            spreadsheet.setColumnWidth(9, 8000);
            spreadsheet.setColumnWidth(10, 8000);
            spreadsheet.setColumnWidth(11, 8000);
            spreadsheet.setColumnWidth(12, 8000);


            // Create Other rows and cells with  data
            XSSFRow row1 = spreadsheet.createRow(0);
            String[] columns = {"URL", "Type", "Id", "Help", "Impact", "Description", "Tags", "HelpUrl", "Node Html", "Node Impact", "Node Any", "Node None", "Node All"};
            int colSize = columns.length;
            // Create cells
            for (int i = 0; i < colSize; i++) {
                Cell cell = row1.createCell(i);
                cell.setCellValue(columns[i]);
                cell.setCellStyle(headerCellStyle);
            }
            int rowNum = 1;
            for (ExcelHeader hdr : headerLst) {
                XSSFRow row = spreadsheet.createRow(rowNum++);

                row.createCell(0).setCellValue(hdr.getUrl());
                row.createCell(1).setCellValue(hdr.getType());
                row.createCell(2).setCellValue(hdr.getId());
                row.createCell(3).setCellValue(hdr.getHelp());
                row.createCell(4).setCellValue(hdr.getImpact());
                row.createCell(5).setCellValue(hdr.getDescription());
                row.createCell(6).setCellValue(hdr.getTags());
                row.createCell(7).setCellValue(hdr.getHelpUrl());
                row.createCell(8).setCellValue(hdr.getNodeHtml());
                row.createCell(9).setCellValue(hdr.getNodeImpact());
                row.createCell(10).setCellValue(hdr.getNodeAny());
                row.createCell(11).setCellValue(hdr.getNodeNone());
                row.createCell(12).setCellValue(hdr.getNodeAll());
            }

            spreadsheet.createFreezePane(0, 1);
            //Write the workbook in file system
            FileOutputStream out;
            out = new FileOutputStream(new File(Constants.ADAREPORTPATH + "DequeAXEReport.xlsx"));
            workbook.write(out);
            out.close();
        } catch (IOException e) {
            log.error(e.getMessage());
        }
    }

    //Convert JSONObject to One to One relation
    private List<ExcelHeader> convertToOneToOneMapping(Response res) {
        List<ExcelHeader> headerLst = new ArrayList<>();

        for (int i = 0; i < res.getListOfURLS().size(); i++) {
            //violation iteration
            for (int j = 0; j < res.getListOfURLS().get(i).getViolations().size(); j++) {

                for (int k = 0; k < res.getListOfURLS().get(i).getViolations().get(j).getNodes().size(); k++) {
                    ExcelHeader header = new ExcelHeader();
                    header.setUrl(res.getListOfURLS().get(i).getUrl());
                    header.setType("Violations");
                    header.setId(res.getListOfURLS().get(i).getViolations().get(j).getId());
                    header.setHelp(res.getListOfURLS().get(i).getViolations().get(j).getHelp());
                    header.setImpact(res.getListOfURLS().get(i).getViolations().get(j).getImpact());
                    header.setDescription(res.getListOfURLS().get(i).getViolations().get(j).getDescription());
                    header.setTags(res.getListOfURLS().get(i).getViolations().get(j).getTags().toString());
                    header.setNodeHtml(res.getListOfURLS().get(i).getViolations().get(j).getNodes().get(k).getHtml());
                    header.setNodeAll(res.getListOfURLS().get(i).getViolations().get(j).getNodes().get(k).getAll().toString());
                    header.setNodeAny(res.getListOfURLS().get(i).getViolations().get(j).getNodes().get(k).getAny().toString());
                    header.setNodeImpact(res.getListOfURLS().get(i).getViolations().get(j).getNodes().get(k).getImpact());
                    header.setNodeNone(res.getListOfURLS().get(i).getViolations().get(j).getNodes().get(k).getNone().toString());
                    header.setHelpUrl(res.getListOfURLS().get(i).getViolations().get(j).getHelpUrl());
                    headerLst.add(header);
                }
            }
            //Passes iteration
            for (int n = 0; n < res.getListOfURLS().get(i).getPasses().size(); n++) {

                for (int o = 0; o < res.getListOfURLS().get(i).getPasses().get(n).getNodes().size(); o++) {
                    ExcelHeader header = new ExcelHeader();
                    header.setUrl(res.getListOfURLS().get(i).getUrl());
                    header.setType("Passes");
                    header.setId(res.getListOfURLS().get(i).getPasses().get(n).getId());
                    header.setHelp(res.getListOfURLS().get(i).getPasses().get(n).getHelp());
                    header.setImpact(res.getListOfURLS().get(i).getPasses().get(n).getImpact());
                    header.setDescription(res.getListOfURLS().get(i).getPasses().get(n).getDescription());
                    header.setTags(res.getListOfURLS().get(i).getPasses().get(n).getTags().toString());
                    header.setNodeHtml(res.getListOfURLS().get(i).getPasses().get(n).getNodes().get(o).getHtml());
                    header.setNodeAll(res.getListOfURLS().get(i).getPasses().get(n).getNodes().get(o).getAll().toString());
                    header.setNodeAny(res.getListOfURLS().get(i).getPasses().get(n).getNodes().get(o).getAny().toString());
                    header.setNodeImpact(res.getListOfURLS().get(i).getPasses().get(n).getNodes().get(o).getImpact());
                    header.setNodeNone(res.getListOfURLS().get(i).getPasses().get(n).getNodes().get(o).getNone().toString());
                    header.setHelpUrl(res.getListOfURLS().get(i).getPasses().get(n).getHelpUrl());
                    headerLst.add(header);
                }
            }
        }
        return headerLst;
    }
}