package automation.library.leanft.core.desktop;

import com.hp.lft.sdk.GeneralLeanFtException;

public abstract class DesktopListView extends DesktopObject {

    public abstract DesktopListView select(String name,int... retries) throws GeneralLeanFtException;
    public abstract DesktopListView selectColRow(String colDes,String rowVal,int... retries) throws GeneralLeanFtException;
    public abstract DesktopListView doubleClick(String name,int... retries) throws GeneralLeanFtException;
    public abstract DesktopListView exists(int... retries) throws GeneralLeanFtException;
    public abstract DesktopListView selectByIndex(int name,int... retries) throws GeneralLeanFtException;
    public abstract DesktopListView activateItem(String value,int... retries) throws GeneralLeanFtException;
    public abstract String getText(int... retries) throws GeneralLeanFtException;
    public abstract boolean isEnabled(int... retries) throws GeneralLeanFtException;
    public abstract boolean isEmpty(int... retries) throws GeneralLeanFtException;

}
