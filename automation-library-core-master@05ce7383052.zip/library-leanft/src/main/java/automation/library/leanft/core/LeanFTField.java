package automation.library.leanft.core;

import automation.library.leanft.core.mainframe.LeanFTScreen;
import com.hp.lft.sdk.GeneralLeanFtException;
/**
 * @deprecated This class is replaced by automation.library.leanft.core.mainframe.LeanFTField
 */
@Deprecated
public class LeanFTField extends automation.library.leanft.core.mainframe.LeanFTField{


    public LeanFTField(String name, String label, int id) throws GeneralLeanFtException {
        super(name, label, id);
    }

    public LeanFTField(LeanFTScreen parentScreen, int id) throws GeneralLeanFtException {
        super(parentScreen, id);
    }

    public LeanFTField(String name, int screenId, int id) throws GeneralLeanFtException {
        super(name, screenId, id);
    }

    public LeanFTField(LeanFTScreen parentScreen, int columnNum, int rowNum) throws GeneralLeanFtException {
        super(parentScreen, columnNum, rowNum);
    }
}
