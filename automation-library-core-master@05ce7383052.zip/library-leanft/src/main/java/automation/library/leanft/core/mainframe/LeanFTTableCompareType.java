package automation.library.leanft.core.mainframe;

public enum LeanFTTableCompareType {
    FIELD_ONLY("Field_Only"),
    FULL_ROW("Full_Row"),
    FULL_TABLE("Full_Table"),
    MULTI_LINE_ROW("Multi_Line_Row");

    public final String label;

    LeanFTTableCompareType(String label) {
        this.label = label;
    }

    public static LeanFTTableCompareType valueOfLabel(String label) {
        for (LeanFTTableCompareType o : values()) {
            if (o.label.equals(label)) {
                return o;
            }
        }
        throw new IllegalArgumentException(String.format("Comparison Type of '%s' not supported", label));
    }
}