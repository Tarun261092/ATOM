package automation.library.leanft.core.mainframe;

import automation.library.leanft.core.Constants;
import automation.library.leanft.exec.DesktopContext;
import automation.library.reporting.Reporter;

import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.Keyboard;
import com.hp.lft.sdk.RegExpProperty;
import com.hp.lft.sdk.te.Area;
import com.hp.lft.sdk.te.Screen;
import com.hp.lft.sdk.te.ScreenDescription;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.List;

import static com.hp.lft.sdk.WaitUntilTestObjectState.waitUntil;

public class LeanFTScreen {

    private Screen screen;
    private String label;
    private int id;
	public int startX;
	public int startY;
	public int endX;
	public int endY;
	public Keyboard.Keys keyToAdvanceScreen;
	public Keyboard.Keys keyToPriorScreen;
	public ScreenFieldIndicator endOfScreenIndicator;
	public ScreenFieldIndicator begOfScreenIndicator;
	private LeanFTWindow parentWindow;

    protected final Logger log = LogManager.getLogger(this.getClass().getName());

    public static class ScreenFieldIndicator {
		private LeanFTField fieldName;
		private String textToFind;

		private ScreenFieldIndicator(LeanFTField fieldName, String textToFind) {
			this.fieldName = fieldName;
			this.textToFind = textToFind;
		}

		public boolean foundIndicator() throws GeneralLeanFtException {
			return fieldName.getField().exists() && fieldName.getText().contains(textToFind);
		}
	}

    public LeanFTScreen(String name, String label) throws GeneralLeanFtException {
        this.label = label;
        this.parentWindow = new LeanFTWindow(name);
        this.screen = this.parentWindow.getWindow().describe(Screen.class,
                                                             new ScreenDescription.Builder().label(label).build());
    }

    public LeanFTScreen(String name, int id) throws GeneralLeanFtException {
        this.id = id;
        this.parentWindow = new LeanFTWindow(name);
        this.screen = this.parentWindow.getWindow().describe(Screen.class,
                                                             new ScreenDescription.Builder().id(id).build());
    }

    public LeanFTScreen(String name, List<Integer> idList) throws GeneralLeanFtException {
        this.parentWindow = new LeanFTWindow(name);
        this.screen = findMatchingScreen(idList, getFindRetries());

        if(this.screen == null) {
            log.error("Unable to find screen with list of IDs provided. ID list: {}", idList);
        }
    }

    public LeanFTScreen(String name, String label, Boolean useRegex) throws GeneralLeanFtException {
        this.label = label;
        this.parentWindow = new LeanFTWindow(name);
        this.screen = this.parentWindow.getWindow().describe(Screen.class,
                new ScreenDescription.Builder().label(new RegExpProperty(label)).build());
    }

    private Screen findMatchingScreen(List<Integer> idList, int retries) throws GeneralLeanFtException {
        Screen localScreen;

        if(retries > 0) {
            for (int screenID : idList) {
                this.id = screenID;
                localScreen = this.parentWindow.getWindow().describe(Screen.class,
                                                                     new ScreenDescription.Builder().id(screenID).build());
                if (localScreen.exists()) {
                    return localScreen;
                }
            }

            try {
                long screenRefindDelay = Integer.parseInt(System.getProperty("fw.screenRefindDelay"));
                log.debug("Screen not found. Waiting {}ms and trying again. Number of retries left: {}", screenRefindDelay, retries);
                Thread.sleep(screenRefindDelay);
                findMatchingScreen(idList, retries - 1);
            } catch (InterruptedException e) {
                log.error(e.getMessage());
                Thread.currentThread().interrupt();
            }
        }

        return null;
    }

    public Screen getScreen() {
        return this.screen;
    }

    public LeanFTWindow getParentWindow() {
        return parentWindow;
    }

    public int getId() {
        return id;
    }


    /**
     *
     * @return
     */
    public static int getFindRetries() {
        final int defaultFindRetries = 10;
        int refind;
        try {
            refind = Integer.parseInt(System.getProperty(Constants.DEFAULT_RETRIES));
        } catch (Exception e) {
            refind = defaultFindRetries;
        }
        return refind;
    }


    /**
     * searches again for the field using the by
     */
    public LeanFTScreen refind(int... retries) {
        log.info("Attempting to refind the field with label: {}", label);
        int attempts = 0;
        Boolean retry = true;
        int maxRetry = retries.length > 0 ? retries[0] : getFindRetries();
        while (attempts < maxRetry && retry) {
            try {
                log.debug("retry number {}", attempts);
                waitUntil(this.screen, testObject -> screen.exists());
                this.screen.getLabel();
                retry = false;
            } catch (Exception e) {
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e1) {
                    log.debug(e1.getMessage());
                    Thread.currentThread().interrupt();
                }
            }
            attempts++;
        }
        return this;
    }

    public LeanFTScreen sendKeys(String keys, int... retries) throws GeneralLeanFtException {
        try {
            this.screen.sendTEKeys(keys);
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.sendKeys(keys,0);
            } else {
                throw e;
            }
        }
        return this;
    }


	public void pressKeyboardKey(Keyboard.Keys keyToPress) throws GeneralLeanFtException {
        if (DesktopContext.getInstance().runOnGrid()) {
            DesktopContext.getInstance()
                     .getEnv()
                     .getKeyboard()
                     .pressKey(keyToPress);
        } else {
            Keyboard.pressKey(keyToPress);
        }
    }

	public void setRangeOfTheScreen(int startX, int startY, int endX, int endY) {
		this.startX = startX;
		this.startY = startY;
		this.endX = endX;
		this.endY = endY;
	}

	public String getTextFromCoordinates(int startX, int startY, int endX, int endY) throws GeneralLeanFtException {
		Area area = new Area(startX, startY, endX, endY);
		return this.screen.getText(area);
	}

	public void setBeginningOfScreenIndicator(LeanFTField begOfScreenIndicator, String begOfScreenText,
			Keyboard.Keys keyToPriorScreen) {
		this.begOfScreenIndicator = new ScreenFieldIndicator(begOfScreenIndicator, begOfScreenText);
		this.keyToPriorScreen = keyToPriorScreen;
	}

	public void setEndOfScreenIndicator(LeanFTField endOfScreenIndicator, String endOfScreenText,
			Keyboard.Keys keyToAdvanceScreen) {
		this.endOfScreenIndicator = new ScreenFieldIndicator(endOfScreenIndicator, endOfScreenText);
		this.keyToAdvanceScreen = keyToAdvanceScreen;
	}
	
	public void goToFirstPage() throws GeneralLeanFtException {
        if (this.begOfScreenIndicator != null) {
            while (!this.begOfScreenIndicator.foundIndicator()) {
                goToPriorScreen();
            }
        } else {
            String errorMsg = "Beginning of screen indicator not defined. Please update screen definition with setBeginningOfScreenIndicator(). Only searching current screen.";
            log.warn(errorMsg);
            Reporter.addStepLog(errorMsg);
        }
    }
    
    private void goToPriorScreen() throws GeneralLeanFtException {
        waitUntil(this.getScreen(), testObject -> this.getScreen().exists());
        this.getParentWindow().getWindow().activate();
        this.pressKeyboardKey(this.keyToPriorScreen);
    }
    
    public boolean atEndOfScreen() throws GeneralLeanFtException {
        if (endOfScreenIndicator != null) {
            return endOfScreenIndicator.foundIndicator();
        } else {
            String errorMsg = "End of screen indicator not defined. Please update screen definition with setEndOfScreenIndicator(). Only searching first screen.";
            log.warn(errorMsg);
            Reporter.addStepLog(errorMsg);
            return true;
        }
    }
    
    public boolean advanceToNextScreen(boolean foundMatch) throws GeneralLeanFtException {
        if (!foundMatch) {
            try {
                this.getParentWindow().activate();
                pressKeyboardKey(keyToAdvanceScreen);
                return true;
            } catch (GeneralLeanFtException e) {
                log.warn("Unable to advance screen. Stopping search at current screen. {}", e.getMessage());
                return false;
            }
        }

        return false;
    }
}
