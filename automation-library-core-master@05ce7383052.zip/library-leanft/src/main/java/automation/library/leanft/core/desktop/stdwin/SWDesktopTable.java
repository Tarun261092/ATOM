package automation.library.leanft.core.desktop.stdwin;

import automation.library.leanft.core.desktop.DesktopTable;
import com.hp.lft.sdk.GeneralLeanFtException;

public class SWDesktopTable extends DesktopTable {
    @Override
    public DesktopTable click(int... a) throws GeneralLeanFtException {
        return null;
    }

    @Override
    public String getCellText(int row, int col, int... a) throws GeneralLeanFtException {
        return null;
    }

    @Override
    public String selectMatchingRow(int secondColumn, int firstColumn, String firstRow, int... retries) throws GeneralLeanFtException {
        return null;
    }


    @Override
    public DesktopTable exists(int... retries) throws GeneralLeanFtException {
        return null;
    }

    /**
     * @param retries
     * @return
     * @throws GeneralLeanFtException
     */
    public boolean isEnabled(int... retries) throws GeneralLeanFtException {
        return false;
    }

    @Override
    public DesktopTable clickCell(int row, int col, int... a) throws GeneralLeanFtException {
        return null;
    }
}
