package automation.library.leanft.core.desktop;

import com.hp.lft.sdk.GeneralLeanFtException;

import java.io.IOException;

public abstract class DesktopWindow{

    public abstract DesktopWindow sendKeys(String keys, String modifierKey, int... retries) throws GeneralLeanFtException;
    public abstract DesktopWindow sendKeys(String keys, int... retries) throws GeneralLeanFtException;
    public abstract void clickImage(String imagePath, int... retries) throws GeneralLeanFtException, IOException;
}
