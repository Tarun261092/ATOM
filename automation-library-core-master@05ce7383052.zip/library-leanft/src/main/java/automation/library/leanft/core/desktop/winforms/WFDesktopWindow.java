package automation.library.leanft.core.desktop.winforms;

import automation.library.leanft.core.desktop.DesktopWindow;
import automation.library.leanft.exec.DesktopContext;
import com.hp.lft.sdk.Desktop;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.KeyModifier;
import com.hp.lft.sdk.insight.InsightDescription;
import com.hp.lft.sdk.insight.InsightObject;
import com.hp.lft.sdk.winforms.Window;
import com.hp.lft.sdk.winforms.WindowDescription;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.imageio.ImageIO;
import java.awt.image.RenderedImage;
import java.io.File;
import java.io.IOException;
import java.util.EnumSet;

public class WFDesktopWindow extends DesktopWindow {

    private Window window;
    protected final Logger log = LogManager.getLogger(this.getClass().getName());

    public WFDesktopWindow(String objectName,
                           String fullType) throws GeneralLeanFtException {
        if (DesktopContext.getInstance().runOnGrid()) {
            this.window = DesktopContext.getInstance()
                                        .getEnv()
                                        .describe(Window.class, new WindowDescription.Builder()
                                                .fullType(fullType)
                                                .objectName(objectName).build());
        } else {
            this.window = Desktop.describe(Window.class, new WindowDescription.Builder()
                    .fullType(fullType)
                    .objectName(objectName).build());
        }
    }

    public WFDesktopWindow(String objectName,
                           String windowTitleRegExp,
                           String fullType) throws GeneralLeanFtException {
        if (DesktopContext.getInstance().runOnGrid()) {
            this.window = DesktopContext.getInstance()
                                        .getEnv()
                                        .describe(Window.class, new WindowDescription.Builder()
                                                .fullType(fullType)
                                                .windowTitleRegExp(windowTitleRegExp)
                                                .objectName(objectName).build());
        } else {
            this.window = Desktop.describe(Window.class, new WindowDescription.Builder()
                    .fullType(fullType)
                    .windowTitleRegExp(windowTitleRegExp)
                    .objectName(objectName).build());
        }
    }

    public WFDesktopWindow sendKeys(String keys, String modifierKey, int... retries) throws GeneralLeanFtException {
        try {
            EnumSet<KeyModifier> modifier = EnumSet.of(KeyModifier.valueOf(modifierKey));
            this.getWindow().sendKeys(keys, modifier);
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.sendKeys(keys, modifierKey, 0);
            } else {
                throw e;
            }
        }
        return this;
    }

    public WFDesktopWindow sendKeys(String keys, int... retries) throws GeneralLeanFtException {
        try {
            this.getWindow().sendKeys(keys);
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.sendKeys(keys, 0);
            } else {
                throw e;
            }
        }
        return this;
    }

    @Override
    public void clickImage(String imagePath, int... retries) throws GeneralLeanFtException, IOException {
        File imgFile = new File(imagePath);
        RenderedImage imageF = null;
        try {
            imageF = ImageIO.read(imgFile);
            InsightObject imageObject = this.getWindow().describe(InsightObject.class, new InsightDescription(imageF));
            imageObject.click();
        } catch (Exception e){
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.getWindow().describe(InsightObject.class, new InsightDescription(imageF)).click();
            } else {
                throw e;
            }
        }
    }

    public Window getWindow() {
        return this.window;
    }

}