package automation.library.leanft.core.desktop;

import com.hp.lft.sdk.GeneralLeanFtException;

import java.util.List;

public abstract class DesktopComboBox extends DesktopObject {

    public abstract DesktopComboBox select(String name, int... retries) throws GeneralLeanFtException;

    public abstract DesktopComboBox select(int name, int... retries) throws GeneralLeanFtException;

    public abstract String getSelectedItem(int... retries) throws GeneralLeanFtException;

    public abstract DesktopComboBox exists(int... retries) throws GeneralLeanFtException;

    public abstract DesktopComboBox click(int... a) throws GeneralLeanFtException;

    public abstract boolean isEnabled(int... retries) throws GeneralLeanFtException;

    public abstract List<String> getComboboxValue(int... retries) throws GeneralLeanFtException;

}
