package automation.library.leanft.core.desktop;

import automation.library.leanft.core.desktop.web.DesktopWebEditField;
import com.hp.lft.sdk.GeneralLeanFtException;

public abstract class DesktopEditField extends DesktopObject {
    public abstract DesktopEditField setText(String text,int... retries) throws GeneralLeanFtException;
    public abstract DesktopEditField setString(String text, int... retries) throws GeneralLeanFtException;
    public abstract DesktopEditField exists(int... retries) throws GeneralLeanFtException;
    public abstract String getText(int... retries) throws GeneralLeanFtException;
    public abstract boolean isEnabled(int... retries) throws GeneralLeanFtException;
    public abstract DesktopEditField click(int... retries) throws GeneralLeanFtException;
}
