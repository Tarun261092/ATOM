package automation.library.leanft.core.mainframe;

import com.hp.lft.sdk.GeneralLeanFtException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class LeanFTTableColumn {
    private LeanFTField columnField;
    private int valOffset;
    private int startingColNum;
    private int rowStartIndex;
    private int length;
    private final Logger log = LogManager.getLogger(LeanFTTableColumn.class);
    private static final int NOT_FOUND = -1;
    private ColumnType typeOfColumn;
    private LeanFTTableCompareType tableCompareType;
    private LeanFTTable.MultiRow rowNum;

    private enum ColumnType {
        FIELD, FULL_ROW, MULTI_LINE_ROW;
    }

    public LeanFTTableColumn(LeanFTField columnField, int valOffset, LeanFTTableCompareType tableCompareType) {
        this.columnField = columnField;
        this.valOffset = valOffset;
        this.startingColNum = getActualColStartNum();
        this.typeOfColumn = ColumnType.FIELD;
        this.rowNum = LeanFTTable.MultiRow.ROW1;
        this.tableCompareType = tableCompareType;
    }

    public LeanFTTableColumn(int colStartCoord,
                             int colEndCoord,
                             LeanFTField fullRowField,
                             int valOffset,
                             LeanFTTableCompareType tableCompareType) {
        this.startingColNum = colStartCoord - valOffset;
        this.length = colEndCoord - colStartCoord;
        this.columnField = fullRowField;
        this.typeOfColumn = ColumnType.FULL_ROW;
        this.rowNum = LeanFTTable.MultiRow.ROW1;
        this.tableCompareType = tableCompareType;
        this.valOffset = valOffset;
    }

    public LeanFTTableColumn(
            int rowStartIndex,
            int colStartCoord,
            int colEndCoord,
            LeanFTField fullRowField,
            int valOffset,
            LeanFTTable.MultiRow rowNum,
            LeanFTTableCompareType tableCompareType) {
            this.rowStartIndex = rowStartIndex;
        this.startingColNum = colStartCoord - valOffset;
        this.length = colEndCoord - colStartCoord;
        this.columnField = fullRowField;
        this.typeOfColumn = ColumnType.MULTI_LINE_ROW;
        this.rowNum = rowNum;
        this.tableCompareType = tableCompareType;
    }

    public LeanFTField getColumnField() {
        return columnField;
    }

    public int getRowNumOfMultiRow() {
        switch(rowNum) {
            case ROW1:
                return 0;
            case ROW2:
                return 1;
            case ROW3:
                return 2;
            default:
                return 0;
        }
    }

    public int getLogicalColStartNum() {
        if(tableCompareType.equals(LeanFTTableCompareType.FULL_ROW) || tableCompareType.equals(LeanFTTableCompareType.FULL_TABLE)) {
            //subtract 1, given LeanFT column index (1-based) and substring to get text (0-based)
            return startingColNum - 1;
        } else {
            return startingColNum;
        }
    }

    public int getActualColStartNum() {
        try {
            return this.columnField.getField().getStartPosition().getColumn() - this.valOffset;
        } catch (GeneralLeanFtException e) {
            log.error("Unable to retrieve column coordinate for the current column: {}", e.getMessage());
            return NOT_FOUND;
        }
    }

    public int getColLength() throws GeneralLeanFtException {
        if(typeOfColumn.equals(ColumnType.FIELD)) {
            return columnField.getField().getLength();
        } else {
            return this.length;
        }
    }

    public int getColRow() {
        try {
            return this.columnField.getField().getStartPosition().getRow();
        } catch (GeneralLeanFtException e) {
            log.error("Unable to retrieve row coordinate for the current column: {}", e.getMessage());
            return NOT_FOUND;
        }
    }

    public void exists(int... retries) throws GeneralLeanFtException {
        try {
            columnField.exists(retries);
        } catch (GeneralLeanFtException e) {
            log.error("Unable to wait on column: {}", e.getMessage());
        }
    }

    public int getColStartNum() {
        return rowStartIndex;
    }
    
}