package automation.library.leanft.core.desktop.web;

import static com.hp.lft.sdk.WaitUntilTestObjectState.waitUntil;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.web.*;

import automation.library.common.Property;
import automation.library.leanft.core.Constants;
import automation.library.leanft.core.desktop.DesktopCheckbox;

public class DesktopWebCheckbox extends DesktopCheckbox {

    private WebDesktopBrowserWindow parentWindow;
    private CheckBox checkBox;
    private String objectName;
    private DesktopWebPageEmbedded desktopWebPage;
    private DesktopWebFrame desktopWebFrame;
    private String locatorText;

    protected final Logger log = LogManager.getLogger(this.getClass().getName());

    
    public DesktopWebCheckbox() {
	}

	public DesktopWebCheckbox(String title, String browser, String name, String xPath) throws GeneralLeanFtException {
        this.parentWindow = new WebDesktopBrowserWindow(title, browser);
        this.objectName = xPath;
        this.checkBox = parentWindow.getWindow().describe(CheckBox.class, new CheckBoxDescription.Builder()
                .xpath(objectName).name(name).build());
    }

    public DesktopWebCheckbox(WebDesktopBrowserWindow window, String locatorText,LocatorType locatorType) throws GeneralLeanFtException {
        this.parentWindow = window;
        this.checkBox = parentWindow.getWindow().
                describe(CheckBox.class,getLocatorObject(locatorText, locatorType));
    }

    public DesktopWebCheckbox(DesktopWebFrame desktopWebFrame, String locatorText, LocatorType locatorType) throws GeneralLeanFtException {
        this.desktopWebFrame = desktopWebFrame;
        this.checkBox = desktopWebFrame.getFrame().describe(CheckBox.class, getLocatorObject(locatorText, locatorType));
    }

    public DesktopWebCheckbox(DesktopWebPageEmbedded desktopWebPage, String locatorText, LocatorType locatorType) throws GeneralLeanFtException {
        this.desktopWebPage = desktopWebPage;
        this.checkBox = desktopWebPage.getEmbeddedPage().describe(CheckBox.class, getLocatorObject(locatorText, locatorType));
    }
    
    public WebElement checkVisiblityOfCheckboxInFrame(String title, String browserType, String frameName, String xpath)
			throws GeneralLeanFtException {
		String numberOfRetries = "";
		int count = 1;
		locatorText = xpath;
		boolean visible = false;
		numberOfRetries = Property.getProperty(Constants.LEANFTRUNTIMEPATH, "defaultWait");
		if(numberOfRetries==null || numberOfRetries.equals("0")) {
			numberOfRetries = "40";
		}
		log.info("Trying to find the element with LocaterText: {}", locatorText);
		while(count<Integer.parseInt(numberOfRetries))
		{
			try {
				this.parentWindow = new WebDesktopBrowserWindow(title, browserType);
				 this.checkBox = parentWindow.getWindow().
			                describe(Frame.class, new FrameDescription.Builder()
			               .name(frameName).build()).
			                describe(CheckBox.class,new CheckBoxDescription.Builder().xpath(xpath).build());
	            waitUntil(this.getDesktopCheckbox(), testObject -> getDesktopCheckbox().exists());
                this.getDesktopCheckbox().getId();
				visible = true;
				log.info("Element Located successfully with LocaterText: {}", locatorText);			
			
			} catch (Exception e) {
				try {
					Thread.sleep(1000);
					count = count + 1;
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
				
			}
			if(visible == true) {
				log.info("The element was found in "+count+" attempts");
				break;
			}
		}		
		if(visible==false)
		{
			log.info("Unable to find the element with LocaterText: {}", locatorText);
		}
		return this.checkBox;
		
	}
    
    public WebElement checkVisiblityOfCheckbox(String title, String browserType, String xpath)
			throws GeneralLeanFtException {
		String numberOfRetries = "";
		int count = 1;
		locatorText = xpath;
		boolean visible = false;
		numberOfRetries = Property.getProperty(Constants.LEANFTRUNTIMEPATH, "defaultWait");
		if(numberOfRetries==null || numberOfRetries.equals("0")) {
			numberOfRetries = "40";
		}
		log.info("Trying to find the element with LocaterText: {}", locatorText);
		while(count<Integer.parseInt(numberOfRetries))
		{
			try {
				this.parentWindow = new WebDesktopBrowserWindow(title, browserType);
				this.checkBox = this.parentWindow.getWindow().describe(CheckBox.class,new CheckBoxDescription.Builder().xpath(xpath).build());
				waitUntil(this.getDesktopCheckbox(), testObject -> getDesktopCheckbox().exists());
                this.getDesktopCheckbox().getName();
				visible = true;
				log.info("Element Located successfully with LocaterText: {}", locatorText);			
			
			} catch (Exception e) {
				try {
					Thread.sleep(1000);
					count = count + 1;
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
				
			}
			if(visible == true) {
				log.info("The element was found in "+count+" attempts");
				break;
			}
		}		
		if(visible==false)
		{
			log.info("Unable to find the element with LocaterText: {}", locatorText);
		}
		return this.checkBox;
		
	}

    private CheckBoxDescription getLocatorObject(String locatorText, LocatorType locatorType) {
        switch (locatorType) {
            case CSS:
                return new CheckBoxDescription.Builder()
                        .cssSelector(locatorText)
                        .build();
            case XPATH:
                return new CheckBoxDescription.Builder()
                        .xpath(locatorText)
                        .build();
            case ID:
                return new CheckBoxDescription.Builder()
                        .id(locatorText)
                        .build();
            case TAGNAME:
                return new CheckBoxDescription.Builder()
                        .tagName(locatorText)
                        .build();
            case NAME:
                return new CheckBoxDescription.Builder()
                        .name(locatorText)
                        .build();
            default:
                throw new IllegalArgumentException("Unrecognized locator type: " + locatorType.getLocatorTagName());

        }

    }

    public CheckBox getDesktopCheckbox() {
        return this.checkBox;
    }

    /**
     * @param retries
     * @return
     * @throws GeneralLeanFtException
     */
    public DesktopCheckbox click(int... retries) throws GeneralLeanFtException {
        try {
            this.getDesktopCheckbox().click();
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.click(0);
            } else {
                throw e;
            }
        }
        return this;
    }

    /**
     * searches again for the field using the by
     */
    public DesktopWebCheckbox refind(int... retries) {
        log.info("Attempting to refind the field: {}", objectName);
        int attempts = 0;
        boolean retry = true;
        int maxRetry = retries.length > 0 ? retries[0] : getFindRetries();
        while (attempts < maxRetry && retry) {
            try {
                log.debug("retry number {}", attempts);
                waitUntil(this.getDesktopCheckbox(), testObject -> getDesktopCheckbox().exists());
                this.getDesktopCheckbox().getName();
                retry = false;
            } catch (Exception e) {
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e1) {
                    log.debug(e1.getMessage());
                    Thread.currentThread().interrupt();
                }
            }
            attempts++;
        }
        return this;
    }

    public static int getFindRetries() {
        final int defaultFindRetries = 10;
        int refind;
        try {
            refind = Integer.parseInt(System.getProperty(Constants.DEFAULT_RETRIES));
        } catch (Exception e) {
            refind = defaultFindRetries;
        }
        return refind;
    }

    /**
     * @param retries
     * @return
     * @throws GeneralLeanFtException
     */
    public DesktopWebCheckbox exists(int... retries) throws GeneralLeanFtException {
        try {
            waitUntil(this.checkBox, testObject -> checkBox.exists());
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                return this.exists(0);
            } else {
                throw e;
            }
        }
        return this;
    }

    /**
     * @param retries
     * @return
     * @throws GeneralLeanFtException
     */
    public boolean isEnabled(int... retries) throws GeneralLeanFtException {
        boolean status = false;
        try {
            status = this.getDesktopCheckbox().isEnabled();
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.isEnabled(0);
            } else {
                throw e;
            }
        }
        return status;
    }

    /**
     * @param retries
     * @return
     * @throws GeneralLeanFtException
     */
    public boolean isChecked(int... retries) throws GeneralLeanFtException {
        boolean status = false;
        try {
            status = this.getDesktopCheckbox().isChecked();
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.isChecked(0);
            } else {
                throw e;
            }
        }
        return status;
    }
}
