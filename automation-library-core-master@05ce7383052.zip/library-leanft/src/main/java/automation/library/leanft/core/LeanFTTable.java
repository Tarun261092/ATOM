package automation.library.leanft.core;

import automation.library.leanft.core.LeanFTScreen;
import automation.library.leanft.core.LeanFTTableCompareType;
import com.hp.lft.sdk.GeneralLeanFtException;

/**
 * @deprecated This class is replaced by automation.library.leanft.core.mainframe.LeanFTTable
 */
@Deprecated
public class LeanFTTable extends automation.library.leanft.core.mainframe.LeanFTTable {

    public LeanFTTable(LeanFTScreen parentScreen, int maxRowsPerScreen, LeanFTTableCompareType tableCompareType, boolean searchCurrentScreenOnly) {
        super(parentScreen, maxRowsPerScreen, automation.library.leanft.core.mainframe.LeanFTTableCompareType.valueOfLabel(tableCompareType.label), searchCurrentScreenOnly);
    }

    public LeanFTTable(LeanFTScreen parentScreen, int maxRowsPerScreen, LeanFTTableCompareType tableCompareType) {
        super(parentScreen, maxRowsPerScreen, automation.library.leanft.core.mainframe.LeanFTTableCompareType.valueOfLabel(tableCompareType.label));
    }

    public LeanFTTable(String name, String label, int maxRowsPerScreen, LeanFTTableCompareType tableCompareType) throws GeneralLeanFtException {
        super(name, label, maxRowsPerScreen, automation.library.leanft.core.mainframe.LeanFTTableCompareType.valueOfLabel(tableCompareType.label));
    }

    public LeanFTTable(String name, String label, int maxRowsPerScreen, LeanFTTableCompareType tableCompareType, boolean searchCurrentScreenOnly) throws GeneralLeanFtException {
        super(name, label, maxRowsPerScreen, automation.library.leanft.core.mainframe.LeanFTTableCompareType.valueOfLabel(tableCompareType.label), searchCurrentScreenOnly);
    }
}