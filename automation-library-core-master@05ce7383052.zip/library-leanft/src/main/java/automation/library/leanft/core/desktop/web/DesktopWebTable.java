package automation.library.leanft.core.desktop.web;

import automation.library.common.Property;
import automation.library.leanft.core.Constants;
import automation.library.leanft.core.desktop.DesktopTable;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.internal.web.WebTable;
import com.hp.lft.sdk.web.*;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import static com.hp.lft.sdk.WaitUntilTestObjectState.waitUntil;

public class DesktopWebTable extends DesktopTable {

    private Table webTable;
    private String locatorText;
    private WebDesktopBrowserWindow parentWindow;
    private DesktopWebFrame desktopWebFrame;
    private DesktopWebPageEmbedded desktopWebPage;

    protected final Logger log = LogManager.getLogger(this.getClass().getName());

    
    public DesktopWebTable() {
	}

	public DesktopWebTable(String title,
                           String browser,
                           String locatorText,
                           LocatorType locatorType) throws GeneralLeanFtException {
        this.parentWindow = new WebDesktopBrowserWindow(title, browser);
        this.locatorText = locatorText;
        this.webTable = parentWindow.getWindow()
                                    .describe(Table.class,
                                              getLocatorObject(locatorText, locatorType));
    }

    public DesktopWebTable(WebDesktopBrowserWindow parentWindow,
                           String locatorText,
                           LocatorType locatorType) throws GeneralLeanFtException {
        this.parentWindow = parentWindow;
        this.locatorText = locatorText;
        this.webTable = parentWindow.getWindow()
                                    .describe(Table.class,
                                              getLocatorObject(locatorText, locatorType));
    }

    public DesktopWebTable(String title, String browserType, String name, String xpath) throws GeneralLeanFtException {
        this.parentWindow = new WebDesktopBrowserWindow(title, browserType);
        this.webTable = parentWindow.getWindow().describe(Table.class, new TableDescription.Builder()
                .name(name).xpath(xpath).build());

    }

    public DesktopWebTable(WebDesktopBrowserWindow parentWindow, String name, String xpath) throws GeneralLeanFtException {
        this.parentWindow = parentWindow;
        this.webTable = parentWindow.getWindow().describe(Table.class, new TableDescription.Builder()
                .name(name).xpath(xpath).build());

    }

    public DesktopWebTable(DesktopWebFrame desktopWebFrame, String locatorText, LocatorType locatorType) throws GeneralLeanFtException {
        this.desktopWebFrame = desktopWebFrame;
        this.webTable = desktopWebFrame.getFrame().describe(Table.class, getLocatorObject(locatorText, locatorType));
    }

    public DesktopWebTable(DesktopWebPageEmbedded desktopWebPage, String locatorText, LocatorType locatorType) throws GeneralLeanFtException {
        this.desktopWebPage = desktopWebPage;
        this.webTable = desktopWebPage.getEmbeddedPage().describe(Table.class, getLocatorObject(locatorText, locatorType));
    }
    
    public WebElement checkVisiblityOfWebTableInFrame(String title, String browserType, String frameName, String xpath)
			throws GeneralLeanFtException {
		String numberOfRetries = "";
		int count = 1;
		locatorText = xpath;
		boolean visible = false;
		numberOfRetries = Property.getProperty(Constants.LEANFTRUNTIMEPATH, "defaultWait");
		if(numberOfRetries==null || numberOfRetries.equals("0")) {
			numberOfRetries = "40";
		}
		log.info("Trying to find the element with LocaterText: {}", locatorText);
		while(count<Integer.parseInt(numberOfRetries))
		{
			try {
				this.parentWindow = new WebDesktopBrowserWindow(title, browserType);
				 this.webTable = parentWindow.getWindow().
			                describe(Frame.class, new FrameDescription.Builder()
			               .name(frameName).build()).
			                describe(Table.class,new TableDescription.Builder().xpath(xpath).build());
				waitUntil(this.getWebTable(), testObject -> getWebTable().exists());
	            this.getWebTable().getId();
				visible = true;
				log.info("Element Located successfully with LocaterText: {}", locatorText);			
			
			} catch (Exception e) {
				try {
					Thread.sleep(1000);
					count = count + 1;
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
				
			}
			if(visible == true) {
				log.info("The element was found in "+count+" attempts");
				break;
			}
		}		
		if(visible==false)
		{
			log.info("Unable to find the element with LocaterText: {}", locatorText);
		}
		return this.webTable;
		
	}
    
    public WebElement checkVisiblityOfWebTable(String title, String browserType, String xpath)
			throws GeneralLeanFtException {
		String numberOfRetries = "";
		int count = 1;
		locatorText = xpath;
		boolean visible = false;
		numberOfRetries = Property.getProperty(Constants.LEANFTRUNTIMEPATH, "defaultWait");
		if(numberOfRetries==null || numberOfRetries.equals("0")) {
			numberOfRetries = "40";
		}
		log.info("Trying to find the element with LocaterText: {}", locatorText);
		while(count<Integer.parseInt(numberOfRetries))
		{
			try {
				this.parentWindow = new WebDesktopBrowserWindow(title, browserType);
				this.webTable = this.parentWindow.getWindow().describe(Table.class,new TableDescription.Builder().xpath(xpath).build());
				waitUntil(this.getWebTable(), testObject -> getWebTable().exists());
                this.getWebTable().getId();
				visible = true;
				log.info("Element Located successfully with LocaterText: {}", locatorText);			
			
			} catch (Exception e) {
				try {
					Thread.sleep(1000);
					count = count + 1;
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
				
			}
			if(visible == true) {
				log.info("The element was found in "+count+" attempts");
				break;
			}
		}		
		if(visible==false)
		{
			log.info("Unable to find the element with LocaterText: {}", locatorText);
		}
		return this.webTable;
		
	}

    private TableDescription getLocatorObject(String locatorText, LocatorType locatorType) {
        switch (locatorType) {
            case CSS:
                return new TableDescription.Builder()
                        .cssSelector(locatorText)
                        .build();
            case XPATH:
                return new TableDescription.Builder()
                        .xpath(locatorText)
                        .build();
            case ID:
                return new TableDescription.Builder()
                        .id(locatorText)
                        .build();
            case TAGNAME:
                return new TableDescription.Builder()
                        .tagName(locatorText)
                        .build();
            default:
                throw new IllegalArgumentException("Unrecognized locator type: " + locatorType.getLocatorTagName());

        }
    }

    public Table getWebTable() {
        return this.webTable;
    }

    @Override
    public DesktopTable exists(int... retries) throws GeneralLeanFtException {
        try {
            waitUntil(this.webTable, testObject -> webTable.exists());
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                return this.exists(0);
            } else {
                throw e;
            }
        }
        return this;
    }

    @Override
    public boolean isEnabled(int... retries) throws GeneralLeanFtException {
        return false;
    }


    public DesktopWebTable refind(int... retries) {
        log.info("Attempting to refind the field: {}", locatorText);
        int attempts = 0;
        boolean retry = true;
        int maxRetry = retries.length > 0 ? retries[0] : getFindRetries();
        while (attempts < maxRetry && retry) {
            try {
                log.debug("retry number {}", attempts);
                waitUntil(this.getWebTable(), testObject -> getWebTable().exists());
                this.getWebTable().getId();
                retry = false;
            } catch (Exception e) {
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e1) {
                    log.debug(e1.getMessage());
                    Thread.currentThread().interrupt();
                }
            }
            attempts++;
        }
        return this;
    }

    public static int getFindRetries() {
        final int defaultFindRetries = 10;
        int refind;
        try {
            refind = Integer.parseInt(System.getProperty(Constants.DEFAULT_RETRIES));
        } catch (Exception e) {
            refind = defaultFindRetries;
        }
        return refind;
    }

    public DesktopTable click(int... retries) throws GeneralLeanFtException {
        try {
            this.getWebTable().click();
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.click(0);
            } else {
                throw e;
            }
        }
        return this;
    }

    @Override
    public String getCellText(int row, int col, int... retries) throws GeneralLeanFtException {
        String str = null;
        try {
            str = String.valueOf(this.getWebTable().getRows().get(row).getCells().get(col).getText());
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.getCellText(row, col, 0);
            } else {
                throw e;
            }
        }
        return str;
    }

    @Override
    public String selectMatchingRow(int secondColumn, int firstColumn, String firstRow, int... retries) throws GeneralLeanFtException {
        throw new UnsupportedOperationException("Not implemented for web tables");
    }

    public DesktopTable clickCell(int row, int col, int... retries) throws GeneralLeanFtException {
        try {
            this.getWebTable().getRows().get(row).getCells().get(col).asWebElement().click();
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.clickCell(row, col, 0);
            } else {
                throw e;
            }
        }
        return this;
    }

    public DesktopTable doubleClick(int... retries) throws GeneralLeanFtException {
        try {
            this.getWebTable().doubleClick();
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.doubleClick(0);
            } else {
                throw e;
            }
        }
        return this;
    }
}

