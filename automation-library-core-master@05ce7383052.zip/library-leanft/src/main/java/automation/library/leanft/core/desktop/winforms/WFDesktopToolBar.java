package automation.library.leanft.core.desktop.winforms;

import automation.library.leanft.core.Constants;
import automation.library.leanft.core.desktop.DesktopToolBar;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.winforms.ToolBar;
import com.hp.lft.sdk.winforms.ToolBarDescription;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import static com.hp.lft.sdk.WaitUntilTestObjectState.waitUntil;

public class WFDesktopToolBar extends DesktopToolBar {

    private ToolBar object;
    private WFDesktopWindow parentWindow;
    private String objectName;

    protected final Logger log = LogManager.getLogger(this.getClass().getName());

    public WFDesktopToolBar(String windowObjectName, String windowTitleRegExp,String fulltype, String objectName) throws GeneralLeanFtException {
        this.parentWindow = new WFDesktopWindow(windowObjectName, windowTitleRegExp,fulltype);
        this.objectName=objectName;
        this.object = parentWindow.getWindow().describe(ToolBar.class, new ToolBarDescription.Builder()
                .objectName(objectName).build());

    }
    public WFDesktopToolBar(WFDesktopWindow window, String objectName) throws GeneralLeanFtException {
        this.parentWindow = window;
        this.objectName=objectName;
        this.object = parentWindow.getWindow().describe(ToolBar.class, new ToolBarDescription.Builder()
                .objectName(objectName).build());

    }
    public ToolBar getDesktopToolBar() {
        return this.object;
    }

    @Override
    public DesktopToolBar select(String value, int... retries) throws GeneralLeanFtException {
        try {
            this.getDesktopToolBar().select(value);
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.select(value,0);
            } else {
                throw e;
            }
        }
        return this;
    }

    public WFDesktopToolBar refind(int... retries) {
        log.info("Attempting to refind the field: {}", objectName);
        int attempts = 0;
        boolean retry = true;
        int maxRetry = retries.length > 0 ? retries[0] : getFindRetries();
        while (attempts < maxRetry && retry) {
            try {
                log.debug("retry number {}", attempts);
                waitUntil(this.getDesktopToolBar(), testObject -> getDesktopToolBar().exists());
                this.getDesktopToolBar().getObjectName();
                retry = false;
            } catch (Exception e) {
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e1) {
                    log.debug(e1.getMessage());
                    Thread.currentThread().interrupt();
                }
            }
            attempts++;
        }
        return this;
    }
    public static int getFindRetries() {
        final int defaultFindRetries = 10;
        int refind;
        try {
            refind = Integer.parseInt(System.getProperty(Constants.DEFAULT_RETRIES));
        } catch (Exception e) {
            refind = defaultFindRetries;
        }
        return refind;
    }

    /**
     * @param retries
     * @return
     * @throws GeneralLeanFtException
     */
    public WFDesktopToolBar exists(int... retries) throws GeneralLeanFtException {
        try {
            waitUntil(this.object, testObject -> object.exists());
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                return this.exists(0);
            } else {
                throw e;
            }
        }
        return this;
    }
    /**
     * @param retries
     * @return
     * @throws GeneralLeanFtException
     */
    public boolean isEnabled(int... retries) throws GeneralLeanFtException {
        boolean status = false;
        try {
            status= this.getDesktopToolBar().isEnabled();
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.isEnabled(0);
            } else {
                throw e;
            }
        }
        return status;
    }
}
