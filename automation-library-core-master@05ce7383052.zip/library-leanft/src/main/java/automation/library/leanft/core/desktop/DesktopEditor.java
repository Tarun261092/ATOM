package automation.library.leanft.core.desktop;

import com.hp.lft.sdk.GeneralLeanFtException;

public abstract class DesktopEditor extends DesktopObject {
    public abstract String getText(int... retries) throws GeneralLeanFtException;
    public abstract boolean isEnabled(int... retries) throws GeneralLeanFtException;
    public abstract DesktopEditor sendKeys(String text,int... retries) throws GeneralLeanFtException;

}
