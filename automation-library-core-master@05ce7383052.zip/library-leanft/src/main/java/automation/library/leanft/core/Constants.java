package automation.library.leanft.core;


import automation.library.common.Property;

public class Constants {
    private static final String BASEPATH = System.getProperty("user.dir") + "/src/test/resources/";
    public static final String LEANFTCONFIGPATH = BASEPATH + "config/leanft/";
    public static final String PAGEOBJECTJAVAPATH = System.getProperty("user.dir") + "/src/test/java/pageobjects/";
    public static final String KEYBOARDMAINFRAMEJSON = BASEPATH + "config/custom/" + "keyboardMainframe.json";
    public static final String LEANFTRUNTIMEPATH = LEANFTCONFIGPATH + "runtime.properties";
    public static final String LEANFTSTACKSPATH = LEANFTCONFIGPATH + "stacks/" + getLeanFTTechStack() + ".json";
    public static final String LEANFTPROPERTIESPATH = LEANFTCONFIGPATH + "leanft.properties";

    //Framework attributes
    public static final String DEFAULT_RETRIES = "fw.defaultFindRetries";

    private static String getLeanFTTechStack() {
        String techStack =  Property.getVariable("fw.leanFTStack");
        return techStack == null ? "LOCAL" : techStack;
    }
}
