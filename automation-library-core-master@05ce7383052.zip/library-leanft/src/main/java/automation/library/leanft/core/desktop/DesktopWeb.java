package automation.library.leanft.core.desktop;

import com.hp.lft.sdk.GeneralLeanFtException;

public abstract class DesktopWeb extends DesktopObject {
    public abstract DesktopWeb setText(String text, int... retries) throws GeneralLeanFtException;
    public abstract DesktopWeb select(String value, int... retries) throws GeneralLeanFtException;
    public abstract DesktopWeb select(int index, int... retries) throws GeneralLeanFtException;
    public abstract DesktopWeb doubleClick(int... retries) throws GeneralLeanFtException;
    public abstract DesktopWeb click(int... retries) throws GeneralLeanFtException;
    public abstract DesktopWeb hover(int... retries) throws GeneralLeanFtException;
    public abstract String getText(int... retries) throws GeneralLeanFtException;
}
