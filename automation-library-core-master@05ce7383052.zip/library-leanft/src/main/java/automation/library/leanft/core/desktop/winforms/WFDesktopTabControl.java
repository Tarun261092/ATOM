package automation.library.leanft.core.desktop.winforms;

import automation.library.leanft.core.Constants;
import automation.library.leanft.core.desktop.DesktopTabControl;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.winforms.TabControl;
import com.hp.lft.sdk.winforms.TabControlDescription;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import static com.hp.lft.sdk.WaitUntilTestObjectState.waitUntil;

public class WFDesktopTabControl extends DesktopTabControl {

    private TabControl object;
    private WFDesktopWindow parentWindow;
    private String objectName;

    protected final Logger log = LogManager.getLogger(this.getClass().getName());

    public WFDesktopTabControl(String windowObjectName, String windowTitleRegExp,String fulltype, String objectName) throws GeneralLeanFtException {
        this.parentWindow = new WFDesktopWindow(windowObjectName, windowTitleRegExp,fulltype);
        this.objectName=objectName;
        this.object = parentWindow.getWindow().describe(TabControl.class, new TabControlDescription.Builder()
                .objectName(objectName).build());

    }
    public WFDesktopTabControl(WFDesktopWindow window, String objectName) throws GeneralLeanFtException {
        this.parentWindow = window;
        this.objectName=objectName;
        this.object = parentWindow.getWindow().describe(TabControl.class, new TabControlDescription.Builder()
                .objectName(objectName).build());

    }
    public TabControl getDesktopTabControl() {
        return this.object;
    }

    @Override
    public DesktopTabControl select(String value, int... retries) throws GeneralLeanFtException {
        try {
            this.getDesktopTabControl().select(value);
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.select(value,0);
            } else {
                throw e;
            }
        }
        return this;
    }

    public WFDesktopTabControl refind(int... retries) {
        log.info("Attempting to refind the field: {}", objectName);
        int attempts = 0;
        boolean retry = true;
        int maxRetry = retries.length > 0 ? retries[0] : getFindRetries();
        while (attempts < maxRetry && retry) {
            try {
                log.debug("retry number {}", attempts);
                waitUntil(this.getDesktopTabControl(), testObject -> getDesktopTabControl().exists());
                this.getDesktopTabControl().getObjectName();
                retry = false;
            } catch (Exception e) {
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e1) {
                    log.debug(e1.getMessage());
                    Thread.currentThread().interrupt();
                }
            }
            attempts++;
        }
        return this;
    }
    public static int getFindRetries() {
        final int defaultFindRetries = 10;
        int refind;
        try {
            refind = Integer.parseInt(System.getProperty(Constants.DEFAULT_RETRIES));
        } catch (Exception e) {
            refind = defaultFindRetries;
        }
        return refind;
    }

    /**
     * @param retries
     * @return
     * @throws GeneralLeanFtException
     */
    public WFDesktopTabControl exists(int... retries) throws GeneralLeanFtException {
        try {
            waitUntil(this.object, testObject -> object.exists());
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                return this.exists(0);
            } else {
                throw e;
            }
        }
        return this;
    }

    /**
     * @param retries
     * @return
     * @throws GeneralLeanFtException
     */
    public boolean isEnabled(int... retries) throws GeneralLeanFtException {
        boolean status = false;
        try {
            status= this.getDesktopTabControl().isEnabled();
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.isEnabled(0);
            } else {
                throw e;
            }
        }
        return status;
    }
}
