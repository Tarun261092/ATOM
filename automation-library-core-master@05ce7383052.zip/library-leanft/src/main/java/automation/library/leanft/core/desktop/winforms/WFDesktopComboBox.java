package automation.library.leanft.core.desktop.winforms;

import automation.library.leanft.core.Constants;
import automation.library.leanft.core.desktop.DesktopComboBox;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.GeneralReplayException;
import com.hp.lft.sdk.winforms.ComboBox;
import com.hp.lft.sdk.winforms.ComboBoxDescription;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.List;

import static com.hp.lft.sdk.WaitUntilTestObjectState.waitUntil;

public class WFDesktopComboBox extends DesktopComboBox {

    private ComboBox object;
    private WFDesktopWindow parentWindow;
    private String objectName;

    protected final Logger log = LogManager.getLogger(this.getClass().getName());

    public WFDesktopComboBox(String windowObjectName, String windowTitleRegExp, String fullType, String objectName) throws GeneralLeanFtException {
        this.parentWindow = new WFDesktopWindow(windowObjectName, windowTitleRegExp, fullType);
        this.objectName = objectName;
        this.object = parentWindow.getWindow().describe(ComboBox.class, new ComboBoxDescription.Builder()
                .objectName(objectName).build());

    }

    public WFDesktopComboBox(WFDesktopWindow window, String objectName) throws GeneralLeanFtException {
        this.parentWindow = window;
        this.objectName = objectName;
        this.object = parentWindow.getWindow().describe(ComboBox.class, new ComboBoxDescription.Builder()
                .objectName(objectName).build());

    }


    public ComboBox getDesktopComboBox() {
        return this.object;
    }

    /**
     * @param retries
     * @return
     * @throws GeneralLeanFtException
     */

    public DesktopComboBox select(String value, int... retries) throws GeneralLeanFtException {
        try {
            this.getDesktopComboBox().select(value);
        } catch (GeneralReplayException e) {
            this.getDesktopComboBox().click();
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.select(value, 0);
            } else {
                throw e;
            }
        }
        return this;
    }

    public String getSelectedItem(int... retries) throws GeneralLeanFtException {
        String selectedItem = null;
        try {
            selectedItem = getDesktopComboBox().getSelectedItem();
        } catch (GeneralReplayException e) {
            this.getDesktopComboBox().click();
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.getSelectedItem();
            } else {
                throw e;
            }
        }
        return selectedItem;
    }


    /**
     * @param retries
     * @return
     * @throws GeneralLeanFtException
     */
    public DesktopComboBox select(int value, int... retries) throws GeneralLeanFtException {
        try {
            this.getDesktopComboBox().select(value);
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.select(value, 0);
            } else {
                throw e;
            }
        }
        return this;
    }

    public DesktopComboBox click(int... retries) throws GeneralLeanFtException {
        try {
            this.getDesktopComboBox().click();
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.click(0);
            } else {
                throw e;
            }
        }
        return this;
    }

    /**
     * searches again for the field using the by
     */
    public WFDesktopComboBox refind(int... retries) {
        log.info("Attempting to refind the field: {}", objectName);
        int attempts = 0;
        boolean retry = true;
        int maxRetry = retries.length > 0 ? retries[0] : getFindRetries();
        while (attempts < maxRetry && retry) {
            try {
                log.debug("retry number {}", attempts);
                waitUntil(this.getDesktopComboBox(), testObject -> getDesktopComboBox().exists());
                this.getDesktopComboBox().getObjectName();
                retry = false;
            } catch (Exception e) {
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e1) {
                    log.debug(e1.getMessage());
                    Thread.currentThread().interrupt();
                }
            }
            attempts++;
        }
        return this;
    }

    public static int getFindRetries() {
        final int defaultFindRetries = 10;
        int refind;
        try {
            refind = Integer.parseInt(System.getProperty(Constants.DEFAULT_RETRIES));
        } catch (Exception e) {
            refind = defaultFindRetries;
        }
        return refind;
    }

    /**
     * @param retries
     * @return
     * @throws GeneralLeanFtException
     */
    public WFDesktopComboBox exists(int... retries) throws GeneralLeanFtException {
        try {
            waitUntil(this.object, testObject -> object.exists());
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                return this.exists(0);
            } else {
                throw e;
            }
        }
        return this;
    }

    /**
     * @param retries
     * @return
     * @throws GeneralLeanFtException
     */
    public boolean isEnabled(int... retries) throws GeneralLeanFtException {
        boolean status = false;
        try {
            status = this.getDesktopComboBox().isEnabled();
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.isEnabled(0);
            } else {
                throw e;
            }
        }
        return status;
    }

    /**
     * @param retries
     * @return
     * @throws GeneralLeanFtException
     */
    public List<String> getComboboxValue(int... retries) throws GeneralLeanFtException {
        List<String> comboboxValues = null;
        try {
            comboboxValues = this.getDesktopComboBox().getItems();
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.getComboboxValue(0);
            } else {
                throw e;
            }
        }
        return comboboxValues;
    }
}
