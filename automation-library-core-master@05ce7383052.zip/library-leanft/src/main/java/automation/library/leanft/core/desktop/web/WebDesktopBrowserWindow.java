package automation.library.leanft.core.desktop.web;

import automation.library.leanft.core.desktop.DesktopWindow;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.insight.InsightDescription;
import com.hp.lft.sdk.insight.InsightObject;
import com.hp.lft.sdk.web.Browser;
import com.hp.lft.sdk.web.BrowserDescription;
import com.hp.lft.sdk.web.BrowserFactory;
import com.hp.lft.sdk.web.BrowserType;

import java.awt.image.RenderedImage;
import java.io.File;
import java.io.IOException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.imageio.ImageIO;

public class WebDesktopBrowserWindow  extends DesktopWindow {

    private Browser window;
    protected final Logger log = LogManager.getLogger(this.getClass().getName());

    public WebDesktopBrowserWindow(String title,
                           String browser) throws GeneralLeanFtException {
        this.window = BrowserFactory.attach(new BrowserDescription.Builder().title(title).type(BrowserType.valueOf(browser)).build());
    }
	public WebDesktopBrowserWindow(String browser) throws GeneralLeanFtException {
		this.window = BrowserFactory
				.attach(new BrowserDescription.Builder().type(BrowserType.valueOf(browser)).build());
	}
    public Browser getWindow() {
        return this.window;
    }

    @Override
    public DesktopWindow sendKeys(String keys, String modifierKey, int... retries) throws GeneralLeanFtException {
        return null;
    }

    @Override
    public DesktopWindow sendKeys(String keys, int... retries) throws GeneralLeanFtException {
         return null;
    }

    @Override
    public void clickImage(String imagePath, int... retries) throws GeneralLeanFtException, IOException {

        File imgFile = new File(imagePath);
        RenderedImage imageF = null;
        try {
            imageF = ImageIO.read(imgFile);
            InsightObject imageObject = this.getWindow().describe(InsightObject.class, new InsightDescription(imageF));
            imageObject.click();
        } catch (Exception e){
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.getWindow().describe(InsightObject.class, new InsightDescription(imageF)).click();
            } else {
                throw e;
            }
        }
    }
}
