package automation.library.leanft.core.desktop.web;

import java.util.Arrays;
import java.util.Optional;

public enum LocatorType {
    ID("id"),
    XPATH("xpath"),
    CSS("css"),
    TAGNAME("tagName"),
    NAME("Name");

    private String locatorTagName;

    LocatorType(String locatorTagName) {
        this.locatorTagName = locatorTagName;
    }

    public String getLocatorTagName() {
        return locatorTagName;
    }

    public static LocatorType get(String locatorTag) {
        Optional<LocatorType> first = Arrays.stream(LocatorType.values())
                                            .filter(locator -> locator.getLocatorTagName()
                                                                      .equalsIgnoreCase(locatorTag))
                                            .findFirst();
        return first.orElse(null);
    }
}
