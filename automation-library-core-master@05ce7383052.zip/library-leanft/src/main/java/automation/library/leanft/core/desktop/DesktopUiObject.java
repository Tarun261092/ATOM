package automation.library.leanft.core.desktop;

import com.hp.lft.sdk.GeneralLeanFtException;

public abstract class DesktopUiObject extends DesktopObject{

    public abstract DesktopUiObject click(int... retries) throws GeneralLeanFtException;
    public abstract DesktopUiObject exists(int... retries) throws GeneralLeanFtException;
    public abstract boolean isEnabled(int... retries) throws GeneralLeanFtException;
    public abstract DesktopUiObject sendKeys(String text,int... retries) throws GeneralLeanFtException;

}
