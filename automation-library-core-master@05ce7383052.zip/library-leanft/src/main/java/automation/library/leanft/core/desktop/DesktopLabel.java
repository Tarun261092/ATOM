package automation.library.leanft.core.desktop;

import com.hp.lft.sdk.GeneralLeanFtException;

public abstract class DesktopLabel extends DesktopObject {

    public abstract DesktopLabel click(int... retries) throws GeneralLeanFtException;
    public abstract DesktopLabel exists(int... retries) throws GeneralLeanFtException;
    public abstract String getText(int... retries) throws GeneralLeanFtException;
    public abstract boolean isEnabled(int... retries) throws GeneralLeanFtException;



}