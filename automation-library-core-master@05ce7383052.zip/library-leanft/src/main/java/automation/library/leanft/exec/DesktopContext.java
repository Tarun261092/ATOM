package automation.library.leanft.exec;

import automation.library.leanft.core.Constants;
import automation.library.leanft.exec.managers.BrowserManager;
import automation.library.leanft.core.desktop.DesktopDialog;
import automation.library.leanft.core.desktop.DesktopWindow;
import automation.library.leanft.core.desktop.stdwin.SWDesktopDialog;
import automation.library.leanft.core.desktop.stdwin.SWDesktopWindow;
import automation.library.leanft.core.desktop.web.WebDesktopBrowserWindow;
import automation.library.leanft.core.desktop.winforms.WFDesktopDialog;
import automation.library.leanft.core.desktop.winforms.WFDesktopWindow;
import automation.library.leanft.core.mainframe.LeanFTScreen;
import automation.library.leanft.exec.maps.App;
import automation.library.leanft.exec.maps.LeanFTAppConfig;
import com.google.gson.Gson;
import com.hp.lft.sdk.Aut;
import com.hp.lft.sdk.DesktopEnvironment;
import com.hp.lft.sdk.GeneralLeanFtException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.HashMap;
import java.util.Map;

import static com.hp.lft.sdk.WaitUntilTestObjectState.waitUntil;

public class DesktopContext {
    private static ThreadLocal<DesktopContext> instance = ThreadLocal.withInitial(DesktopContext::new);
    private boolean keepTEOpen = false;
    private LeanFTAppConfig appLaunchData;
    private Logger log = LogManager.getLogger(this.getClass().getName());
    private Map<String, String> emulatorName = new HashMap<>();
    private boolean isLeanFTUp = false;
    private LeanFTScreen currentLeanFTScreen;
    private DesktopWindow currentLeanFTWindow;
    private DesktopDialog currentLeanFTDialog;
    private boolean runOnGrid = false;
    private Map<String, DesktopManager> desktopManagerMap = new HashMap<>();

    private DesktopContext() {
    }

    public LeanFTAppConfig getAppLaunchData() {
        return appLaunchData;
    }

    public static synchronized DesktopContext getInstance() {
        return instance.get();
    }

    public static void removeInstance() {
        instance.remove();
    }

    public void setDesktopContextWithLaunchInfo(String appName) {
        try {
            if (!desktopManagerMap.containsKey(appName)) {
                desktopManagerMap.put(appName, null);
            }

            this.appLaunchData = new Gson().fromJson(new FileReader(Constants.LEANFTCONFIGPATH + "leanftlaunch.json"),
                                                     LeanFTAppConfig.class);

            if (emulatorName.isEmpty() || !emulatorName.containsKey(appName)) {
                App currentApp = appLaunchData.getAppList().get(appName);
                if (currentApp != null) {
                    emulatorName.put(appName, currentApp.getEmulatorToUse());
                } else {
                    throw new IllegalArgumentException(String.format("App not found in leanftlaunch.json file: %s", appName));
                }

            }
        } catch (FileNotFoundException e) {
            log.error(e.getMessage());
        }
    }

    public String getEmulatorName(String appName) {
        return emulatorName.get(appName);
    }

    public void setEmulatorName(String appName, String emulatorName) {
        this.emulatorName.put(appName, emulatorName);
    }

    public boolean keepTEOpen() {
        return keepTEOpen;
    }

    public void setKeepTEOpen(boolean keepTEOpen) {
        this.keepTEOpen = keepTEOpen;
    }

    public boolean isLeanFTUp() {
        return isLeanFTUp;
    }

    public void setLeanFTUp(boolean leanFTUp) {
        isLeanFTUp = leanFTUp;
    }

    public LeanFTScreen getCurrentLeanFTScreen() {
        return currentLeanFTScreen;
    }

    public void setCurrentLeanFTScreen(LeanFTScreen currentLeanFTScreen) {
        try {
            waitUntil(currentLeanFTScreen.getScreen(), testObject -> currentLeanFTScreen.getScreen().exists());
            if (currentLeanFTScreen.getScreen().exists()) {
                this.currentLeanFTScreen = currentLeanFTScreen;
            }
        } catch (GeneralLeanFtException e) {
            log.error(e.getMessage());
        }
    }

    public void setCurrentLeanFTWindow(DesktopWindow currentLeanFTWindow) {
        if (this.currentLeanFTDialog != null)
            this.currentLeanFTDialog = null;

        try {
            if (currentLeanFTWindow instanceof WFDesktopWindow) {
                waitUntil(((WFDesktopWindow) currentLeanFTWindow).getWindow(), testObject -> ((WFDesktopWindow) currentLeanFTWindow).getWindow().exists());
                if (((WFDesktopWindow) currentLeanFTWindow).getWindow().exists()) {
                    this.currentLeanFTWindow = currentLeanFTWindow;
                }
            } else if (currentLeanFTWindow instanceof SWDesktopWindow) {
                waitUntil(((SWDesktopWindow) currentLeanFTWindow).getWindow(), testObject -> ((SWDesktopWindow) currentLeanFTWindow).getWindow().exists());
                if (((SWDesktopWindow) currentLeanFTWindow).getWindow().exists()) {
                    this.currentLeanFTWindow = currentLeanFTWindow;
                }
            } else if (currentLeanFTWindow instanceof WebDesktopBrowserWindow) {
                waitUntil(((WebDesktopBrowserWindow) currentLeanFTWindow).getWindow(), testObject -> ((WebDesktopBrowserWindow) currentLeanFTWindow).getWindow().exists());
                if (((WebDesktopBrowserWindow) currentLeanFTWindow).getWindow().exists()) {
                    this.currentLeanFTWindow = currentLeanFTWindow;
                }
            }
        } catch (GeneralLeanFtException e) {
            log.error(e.getMessage());
        }
    }


    public void setCurrentLeanFTDialog(DesktopDialog currentLeanFTDialog) {
        if (this.currentLeanFTWindow != null)
            this.currentLeanFTWindow = null;

        try {
            if (currentLeanFTDialog instanceof WFDesktopDialog) {
                waitUntil(((WFDesktopDialog) currentLeanFTDialog).getDialog(), testObject -> ((WFDesktopDialog) currentLeanFTDialog).getDialog().exists());
                if (((WFDesktopDialog) currentLeanFTDialog).getDialog().exists()) {
                    this.currentLeanFTDialog = currentLeanFTDialog;
                }
            } else if (currentLeanFTDialog instanceof SWDesktopDialog) {
                waitUntil(((SWDesktopDialog) currentLeanFTDialog).getDialog(), testObject -> ((SWDesktopDialog) currentLeanFTDialog).getDialog().exists());
                if (((SWDesktopDialog) currentLeanFTDialog).getDialog().exists()) {
                    this.currentLeanFTDialog = currentLeanFTDialog;
                }
            }
        } catch (GeneralLeanFtException e) {
            log.error(e.getMessage());
        }
    }

    public DesktopWindow getCurrentLeanFTWindow() {
        return currentLeanFTWindow;
    }

    public DesktopDialog getCurrentLeanFTDialog() {
        return currentLeanFTDialog;
    }

    public boolean runOnGrid() {
        return runOnGrid;
    }

    public void setRunOnGrid(boolean runOnGrid) {
        this.runOnGrid = runOnGrid;
    }

    public Aut getAut(String appNameToGet) {
        desktopManagerMap.computeIfAbsent(appNameToGet, k -> DesktopFactory.createDesktopDriver(appNameToGet));
        return desktopManagerMap.get(appNameToGet).getAut(appNameToGet);
    }

    public DesktopEnvironment getEnv() {
        return desktopManagerMap.entrySet().iterator().next().getValue().getEnv();
    }

    public void quitAut(String appNameToQuit) {
        try {
            desktopManagerMap.get(appNameToQuit).quitAut();
        } catch (GeneralLeanFtException e) {
            log.error(e.getMessage());
        }
    }
 
    public void quitAut() {
        desktopManagerMap.values().forEach(desktopManager -> {
            try {
                desktopManager.quitAut();
            } catch (GeneralLeanFtException e) {
                log.error(e.getMessage());
            }
        });
    }
    public void getExistingBrowser(String pageTitle, String browser) {
        new BrowserManager().getExistingBrowser(pageTitle, browser);
    }

}
