package automation.library.leanft.exec.managers;

import automation.library.common.StringHelper;
import automation.library.leanft.exec.DesktopContext;
import automation.library.leanft.exec.DesktopManager;
import automation.library.leanft.exec.maps.DesktopApplication;
import com.hp.lft.sdk.Desktop;
import com.hp.lft.sdk.GeneralLeanFtException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class PCOMManager extends DesktopManager {
    private static final String PCOM = "PCOM";
    private static final String STOP = "STOP";
    private Logger log = LogManager.getLogger(this.getClass().getName());

    @Override
    protected void createAut(String appName) {
        try {
            String sessionToLaunch = PCOM + StringHelper.removeSpecialChars(appName);
            DesktopApplication teInfo = null;

            if (DesktopContext.getInstance().getAppLaunchData().getDesktopApplications() != null) {
                teInfo = DesktopContext.getInstance().getAppLaunchData().getDesktopApplications().get(sessionToLaunch);
            } else if (DesktopContext.getInstance().getAppLaunchData().getTerminalEmulators() != null) {
                teInfo = DesktopContext.getInstance().getAppLaunchData().getTerminalEmulators().get(sessionToLaunch);
            }

            if (teInfo != null) {
                curAut = launchApplication(teInfo.getFileName(), teInfo.getArgs(), teInfo.getWorkingDirectory());
                Thread.sleep(teInfo.getDefaultApplLaunchWait());
            }

            if (curAut == null) {
                throw new IllegalArgumentException("Unable to launch application, App Info does not exist in leanFT launch config file");
            }
        } catch (GeneralLeanFtException | InterruptedException e) {
            log.error(e.getMessage());
            Thread.currentThread().interrupt();
        }

    }

    @Override
    public void quitAut() throws GeneralLeanFtException {
        if (curAut != null) {
            DesktopApplication teInfo = DesktopContext.getInstance().getAppLaunchData().getDesktopApplications().get(PCOM.concat(STOP));
            if (DesktopContext.getInstance().runOnGrid()) {
                try {
                    env.launchAut(teInfo.getFileName(), teInfo.getArgs(), teInfo.getWorkingDirectory());
                } catch (GeneralLeanFtException e) {
                    log.warn("Unable to close LeanFT grid screen");
                }
            } else {
                Desktop.launchAut(teInfo.getFileName(), teInfo.getArgs(), teInfo.getWorkingDirectory());
                curAut = null;
            }
        }
    }
}
