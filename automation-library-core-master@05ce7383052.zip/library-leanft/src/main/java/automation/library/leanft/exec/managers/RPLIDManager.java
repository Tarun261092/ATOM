package automation.library.leanft.exec.managers;

import automation.library.common.Property;
import automation.library.common.StringHelper;
import automation.library.cucumber.core.Constants;
import automation.library.leanft.core.desktop.stdwin.SWDesktopWindow;
import automation.library.leanft.core.desktop.winforms.*;
import automation.library.leanft.exec.DesktopContext;
import automation.library.leanft.exec.DesktopManager;
import automation.library.leanft.exec.maps.DesktopApplication;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.Keyboard;
import com.hp.lft.sdk.stdwin.Window;
import org.apache.commons.configuration2.PropertiesConfiguration;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class RPLIDManager extends DesktopManager {
    private static final String RPLID = "RPLID";
    private Logger log = LogManager.getLogger(this.getClass().getName());
    private Window rplidWindow;


    @Override
    protected void createAut(String appName) {
        try {
            //commenting
            WFDesktopWindow rplidexistingMainWindow = new WFDesktopWindow("RPLInitMainUI", "RPLInitMainDotNet.RPLInitMainUI");
            WFDesktopWindow rplidexistingSPWindow = new WFDesktopWindow("SoftPhoneUI", "SoftPhoneDotNet.SoftPhoneUI");
            WFDesktopWindow rplidexistingMacySPWindow = new WFDesktopWindow("MCCSoftPhoneUI", "SoftPhoneDotNet.MCCSoftPhoneUI");
            if (rplidexistingMainWindow.getWindow() != null && rplidexistingMainWindow.getWindow().exists()) {
                log.info("RPLID Main window is open, skipping launching the app");
                return;
            }
            if (rplidexistingSPWindow.getWindow() != null && rplidexistingSPWindow.getWindow().exists()) {
                log.info("RPLID SoftPhone window is open, skipping launching the app");
                return;
            }
            if (rplidexistingMacySPWindow.getWindow() != null && rplidexistingMacySPWindow.getWindow().exists()) {
                log.info("RPLID Macy SoftPhone window is open, skipping launching the app");
                return;
            }
            appName = StringHelper.removeSpecialChars(appName);
            String sessionToLaunch = RPLID;

            DesktopApplication appInfo = null;
            if (DesktopContext.getInstance().getAppLaunchData().getDesktopApplications() != null) {
                appInfo = DesktopContext.getInstance().getAppLaunchData().getDesktopApplications().get(sessionToLaunch);
            }

            if (appInfo != null) {
                curAut = launchApplication(appInfo.getFileName(), appInfo.getArgs(), appInfo.getWorkingDirectory());
                Thread.sleep(appInfo.getDefaultApplLaunchWait());
                launchRPLIDTillAccountSelection(appName);
                Thread.sleep(appInfo.getDefaultApplLaunchWait());
            } else {
                log.error("Unable to launch application, App Info does not exist in leanFT launch config file");
            }
        } catch (GeneralLeanFtException | InterruptedException e) {
            log.error(e.getMessage());
            Thread.currentThread().interrupt();
        }
    }

    private void launchRPLIDTillAccountSelection(String appName) {
        PropertiesConfiguration props = Property.getProperties(Constants.ENVIRONMENTPATH + Property.getVariable("cukes.desktopenv") + ".properties");
        if (props != null) {
            try {
                SWDesktopWindow commandPrompt = new SWDesktopWindow("ConsoleWindowClass", "cscript.exe  /nologo c:\\ssa\\RPLUATStartGate.vbs");
                commandPrompt.sendKeys(props.getString("databaseInstance"));
                Keyboard.pressKey(Keyboard.Keys.ENTER);
                commandPrompt.sendKeys(props.getString("s4Region"));

                Keyboard.pressKey(Keyboard.Keys.ENTER);
                Thread.sleep(10000);
                WFDesktopWindow ssaLogin = new WFDesktopWindow("frmLogon", "SSAGate.frmLogon");
                WFDesktopComboBox appliD = new WFDesktopComboBox(ssaLogin, "cboIBSApplID");
                appliD.select(props.getString("applid"));
                WFDesktopEditField ibsUserName = new WFDesktopEditField(ssaLogin, "fptIBSACID");
                ibsUserName.setText(props.getString("iBSUsername"));
                WFDesktopEditField ibsPassword = new WFDesktopEditField(ssaLogin, "fptIBSPassword");
                ibsPassword.setText(props.getString("iBSPassword"));
                Thread.sleep(3000);
                WFDesktopTabControl tab = new WFDesktopTabControl("frmLogon", "SSA Gatekeeper", "SSAGate.frmLogon", "tabSystem");
                tab.select("   FDR   ");
                WFDesktopEditField fdrUserName = new WFDesktopEditField(ssaLogin, "fptHostUserID");
                fdrUserName.setText(props.getString("fDRUsername"));
                WFDesktopEditField fdrPassword = new WFDesktopEditField(ssaLogin, "fptHostPassword");
                fdrPassword.setText(props.getString("fDRPassword"));
                WFDesktopButton connect = new WFDesktopButton(ssaLogin, "cmdConnect");
                connect.click();
                Thread.sleep(8000);
                WFDesktopWindow ssaENV = new WFDesktopWindow("frmApps", "SSA Environment", "SSAGate.frmApps");
                WFDesktopButton rplCHSButton = new WFDesktopButton(ssaENV, "System.Windows.Forms.Button", 1, "RPL CHS");
                rplCHSButton.click();
            } catch (GeneralLeanFtException | InterruptedException e) {
                log.error(e.getMessage());
                Thread.currentThread().interrupt();
            }
        } else {
            log.error("Desktop Environment Configuration does not exist, Make sure config file corresponding to -Dcukes.dekstopenv exists.");
        }

    }


    @Override
    public void quitAut() throws GeneralLeanFtException {
        if (curAut != null) {
            curAut.close();
            curAut = null;
        }
        if (rplidWindow != null) {
            rplidWindow.close();
        }
    }
}