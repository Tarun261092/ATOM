package automation.library.leanft.core.desktop.winforms;

import automation.library.leanft.core.Constants;
import automation.library.leanft.core.desktop.DesktopLabel;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.winforms.Label;
import com.hp.lft.sdk.winforms.LabelDescription;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import static com.hp.lft.sdk.WaitUntilTestObjectState.waitUntil;

public class WFDesktopLabel extends DesktopLabel {

    private WFDesktopWindow parentWindow;
    private WFDesktopUIObject parentUiObj;
    private Label label;
    private String objectName;


    protected final Logger log = LogManager.getLogger(this.getClass().getName());

    public WFDesktopLabel(String windowObjectName,
                          String fullType,
                          String uiObjectName,
                          String labelObjectName,
                          String text) throws GeneralLeanFtException {
        this.parentUiObj = new WFDesktopUIObject(uiObjectName, fullType, windowObjectName);
        this.objectName = labelObjectName;
        this.label = parentUiObj.getUiObject().describe(Label.class, new LabelDescription.Builder()
                .objectName(labelObjectName)
                .text(text).build());
    }

    public WFDesktopLabel(String windowObjectName,
                          String fullType,
                          String labelObjectName) throws GeneralLeanFtException {
        this.parentWindow = new WFDesktopWindow(windowObjectName, fullType);
        this.objectName = labelObjectName;
        this.label = parentWindow.getWindow().describe(Label.class, new LabelDescription.Builder()
                .objectName(labelObjectName)
                .build());
    }

    public WFDesktopLabel(WFDesktopWindow window,
                          String objectName) throws GeneralLeanFtException {
        this.parentWindow = window;
        this.objectName = objectName;
        this.label = parentWindow.getWindow().describe(Label.class, new LabelDescription.Builder()
                .objectName(objectName)
                .build());
    }

    public Label getDesktopLabel() {
        return this.label;
    }

    public WFDesktopLabel click(int... retries) throws GeneralLeanFtException {
        try {
            this.getDesktopLabel().click();
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.click(0);
            } else {
                throw e;
            }
        }
        return this;
    }

    /**
     * searches again for the field using the by
     */
    public WFDesktopLabel refind(int... retries) {
        log.info("Attempting to refind the field: {}", objectName);
        int attempts = 0;
        boolean retry = true;
        int maxRetry = retries.length > 0 ? retries[0] : getFindRetries();
        while (attempts < maxRetry && retry) {
            try {
                log.debug("retry number {}", attempts);
                waitUntil(this.getDesktopLabel(), testObject -> getDesktopLabel().exists());
                this.getDesktopLabel().getObjectName();
                retry = false;
            } catch (Exception e) {
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e1) {
                    log.debug(e1.getMessage());
                    Thread.currentThread().interrupt();
                }
            }
            attempts++;
        }
        return this;
    }

    public static int getFindRetries() {
        final int defaultFindRetries = 10;
        int refind;
        try {
            refind = Integer.parseInt(System.getProperty(Constants.DEFAULT_RETRIES));
        } catch (Exception e) {
            refind = defaultFindRetries;
        }
        return refind;
    }

    /**
     * @param retries
     * @return
     * @throws GeneralLeanFtException
     */
    public WFDesktopLabel exists(int... retries) throws GeneralLeanFtException {
        try {
            waitUntil(this.label, testObject -> label.exists());
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                return this.exists(0);
            } else {
                throw e;
            }
        }
        return this;
    }

    public String getText(int... retries) throws GeneralLeanFtException {
        String str = null;
        try {
            str = this.label.getText();
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                return this.getText(0);
            } else {
                throw e;
            }
        }
        return str;
    }

    /**
     * @param retries
     * @return
     * @throws GeneralLeanFtException
     */
    public boolean isEnabled(int... retries) throws GeneralLeanFtException {
        boolean status = false;
        try {
            status = this.getDesktopLabel().isEnabled();
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.isEnabled(0);
            } else {
                throw e;
            }
        }
        return status;
    }
}


