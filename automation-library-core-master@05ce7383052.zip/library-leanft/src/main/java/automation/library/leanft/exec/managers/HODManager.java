package automation.library.leanft.exec.managers;

import automation.library.common.StringHelper;
import automation.library.leanft.core.Constants;
import automation.library.leanft.core.desktop.stdwin.SWDesktopWindow;
import automation.library.leanft.exec.DesktopContext;
import automation.library.leanft.exec.DesktopManager;
import automation.library.leanft.exec.maps.DesktopApplication;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.Keyboard;
import com.hp.lft.sdk.insight.InsightDescription;
import com.hp.lft.sdk.insight.InsightObject;
import com.hp.lft.sdk.stdwin.Window;
import com.hp.lft.sdk.stdwin.WindowDescription;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.imageio.ImageIO;
import java.awt.image.RenderedImage;
import java.io.File;
import java.io.IOException;

public class HODManager extends DesktopManager {
    private static final String HOD = "HOD";
    private Logger log = LogManager.getLogger(this.getClass().getName());
    private static final String DESKTOP_WIN_CLASS = "SunAwtFrame";
    private Window hodWindow;

    @Override
    protected void createAut(String appName) {
        try {
            String sessionToLaunch = HOD + StringHelper.removeSpecialChars(appName);
            DesktopApplication teInfo = null;

            if (DesktopContext.getInstance().getAppLaunchData().getTerminalEmulators() != null) {
                teInfo = DesktopContext.getInstance().getAppLaunchData().getTerminalEmulators().get(sessionToLaunch);
            } else if (DesktopContext.getInstance().getAppLaunchData().getDesktopApplications() != null) {
                teInfo = DesktopContext.getInstance().getAppLaunchData().getDesktopApplications().get(HOD);
            }

            if (teInfo != null) {
                curAut = launchApplication(teInfo.getFileName(), teInfo.getArgs(), teInfo.getWorkingDirectory());
                Thread.sleep(teInfo.getDefaultApplLaunchWait());

                if (curAut != null) {
                    launchHost(appName, teInfo);
                } else {
                    log.error("HOD Window is not open, Make sure proper .JNPL file launched");
                }
            }

            if (curAut == null) {
                throw new IllegalArgumentException("Unable to launch application, App Info does not exist in leanFT " +
                                                   "launch config file or HOD window did not open");
            }

        } catch (GeneralLeanFtException | InterruptedException e) {
            log.error(e.getMessage());
            Thread.currentThread().interrupt();
        }
    }

    private void launchHost(String appName, DesktopApplication teInfo) throws GeneralLeanFtException {
        File imgFile = new File(Constants.LEANFTCONFIGPATH + appName + ".jpg");
        hodWindow = new SWDesktopWindow(DESKTOP_WIN_CLASS, teInfo.getWindowTitle()).getWindow();
        RenderedImage imageF = null;
        try {
            imageF = ImageIO.read(imgFile);
            InsightObject host = hodWindow.describe(InsightObject.class, new InsightDescription(imageF));
            host.doubleClick();
        } catch (IOException e) {
            log.error(e.getMessage());
        }
    }

    @Override
    public void quitAut() throws GeneralLeanFtException {
        if (curAut != null) {
            curAut.close();
            curAut = null;
        }
        if (hodWindow != null) {
            hodWindow.close();
            Window childWindow = hodWindow.describe(Window.class, new WindowDescription.Builder().ownedWindow(true).
                    windowClassRegExp("SunAwtDialog").windowTitleRegExp("Close").build());
            if (childWindow.exists()) {
                childWindow.activate();
                if (DesktopContext.getInstance().runOnGrid()) {
                    env.getKeyboard().pressKey(Keyboard.Keys.ENTER);
                } else
                    Keyboard.pressKey(Keyboard.Keys.ENTER);
            }
            hodWindow = null;
        }
    }
}
