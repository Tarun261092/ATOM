package automation.library.leanft.core;

import automation.library.leanft.core.mainframe.LeanFTField;
import automation.library.leanft.core.mainframe.LeanFTTable;
import automation.library.leanft.core.mainframe.LeanFTTableCompareType;

/**
 * @deprecated This class is replaced by automation.library.leanft.core.mainframe.LeanFTTableColumn
 */
@Deprecated
class LeanFTTableColumn extends automation.library.leanft.core.mainframe.LeanFTTableColumn {

    public LeanFTTableColumn(LeanFTField columnField, int valOffset, LeanFTTableCompareType tableCompareType) {
        super(columnField, valOffset, tableCompareType);
    }

    public LeanFTTableColumn(int colStartCoord, int colEndCoord, LeanFTField fullRowField, int valOffset, LeanFTTableCompareType tableCompareType) {
        super(colStartCoord, colEndCoord, fullRowField, valOffset, tableCompareType);
    }

    public LeanFTTableColumn(int rowStartIndex, int colStartCoord, int colEndCoord, LeanFTField fullRowField, int valOffset, LeanFTTable.MultiRow rowNum, LeanFTTableCompareType tableCompareType) {
        super(rowStartIndex, colStartCoord, colEndCoord, fullRowField, valOffset, rowNum, tableCompareType);
    }
}