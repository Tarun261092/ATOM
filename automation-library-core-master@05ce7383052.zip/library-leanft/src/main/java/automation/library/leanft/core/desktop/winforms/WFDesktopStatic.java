package automation.library.leanft.core.desktop.winforms;

import automation.library.leanft.core.desktop.DesktopObject;
import automation.library.leanft.core.desktop.DesktopStatic;
import com.hp.lft.sdk.GeneralLeanFtException;

public class WFDesktopStatic extends DesktopStatic {
    @Override
    public String geText(int... retries) throws GeneralLeanFtException {
        return null;
    }

    @Override
    public DesktopObject exists(int... retries) throws GeneralLeanFtException {
        return null;
    }

    @Override
    public boolean isEnabled(int... retries) throws GeneralLeanFtException {
        return false;
    }
}
