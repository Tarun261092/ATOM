package automation.library.leanft.core.desktop.winforms;

import automation.library.leanft.core.Constants;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.winforms.Button;
import com.hp.lft.sdk.winforms.ButtonDescription;

import automation.library.leanft.core.desktop.DesktopButton;

import static com.hp.lft.sdk.WaitUntilTestObjectState.waitUntil;

public class WFDesktopButton extends DesktopButton {

    private WFDesktopWindow parentWindow;
    private Button button;
    private String objectName;

    protected final Logger log = LogManager.getLogger(this.getClass().getName());

    public WFDesktopButton(String windowObjectName,String windowTitleExp, String fullType,String objectName) throws GeneralLeanFtException {
        this.parentWindow = new WFDesktopWindow(windowObjectName, windowTitleExp, fullType);
        this.objectName = objectName;
        this.button = parentWindow.getWindow().describe(Button.class, new ButtonDescription.Builder()
                .objectName(objectName).build());
    }

    public WFDesktopButton(WFDesktopWindow parentWindow, String objectName) throws GeneralLeanFtException {
        this.parentWindow = parentWindow;
        this.button = parentWindow.getWindow().describe(Button.class, new ButtonDescription.Builder()
                .objectName(objectName).build());
    }

    public WFDesktopButton(String windowObjectName, String windowFullType, String fullType, int index, String text) throws GeneralLeanFtException {
        this.parentWindow = new WFDesktopWindow(windowObjectName, windowFullType);
        this.button = parentWindow.getWindow().describe(Button.class, new ButtonDescription.Builder()
                .fullType(fullType)
                .index(index)
                .text(text).build());
    }

    public WFDesktopButton(String windowObjectName, String windowFullType, String fullNamePath) throws GeneralLeanFtException {
        this.parentWindow = new WFDesktopWindow(windowObjectName, windowFullType);
        this.button = parentWindow.getWindow().describe(Button.class, new ButtonDescription.Builder()
                .fullNamePath(fullNamePath).build());
    }

    public WFDesktopButton(WFDesktopWindow parentWindow, String fullType, int index, String text) throws GeneralLeanFtException {
        this.button = parentWindow.getWindow().describe(Button.class, new ButtonDescription.Builder()
                .fullType(fullType)
                .index(index)
                .text(text).build());
    }

    public WFDesktopButton(WFDesktopWindow parentWindow, String fullType, String objectName) throws GeneralLeanFtException {
        this.button = parentWindow.getWindow().describe(Button.class, new ButtonDescription.Builder()
                .fullType(fullType)
                .objectName(objectName).build());
    }

    public Button getDesktopButton() {
        return this.button;
    }

    public DesktopButton click(int... retries) throws GeneralLeanFtException {
        try {
            this.getDesktopButton().click();
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.click(0);
            } else {
                throw e;
            }
        }
        return this;
    }

    public boolean isEnabled(int... retries) throws GeneralLeanFtException {
        boolean status = false;
        try {
            status= this.getDesktopButton().isEnabled();
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.isEnabled(0);
            } else {
                throw e;
            }
        }
        return status;
    }


    public DesktopButton doubleClick(int... retries) throws GeneralLeanFtException {
        try {
            this.getDesktopButton().doubleClick();
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.doubleClick(0);
            } else {
                throw e;
            }
        }
        return this;
    }
    /**
     * searches again for the field using the by
     */
    public WFDesktopButton refind(int... retries) {
        log.info("Attempting to refind the field: {}", objectName);
        int attempts = 0;
        boolean retry = true;
        int maxRetry = retries.length > 0 ? retries[0] : getFindRetries();
        while (attempts < maxRetry && retry) {
            try {
                log.debug("retry number {}", attempts);
                waitUntil(this.getDesktopButton(), testObject -> getDesktopButton().exists());
                this.getDesktopButton().getObjectName();
                retry = false;
            } catch (Exception e) {
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e1) {
                    log.debug(e1.getMessage());
                    Thread.currentThread().interrupt();
                }
            }
            attempts++;
        }
        return this;
    }
    public static int getFindRetries() {
        final int defaultFindRetries = 10;
        int refind;
        try {
            refind = Integer.parseInt(System.getProperty(Constants.DEFAULT_RETRIES));
        } catch (Exception e) {
            refind = defaultFindRetries;
        }
        return refind;
    }

    /**
     * @param retries
     * @return
     * @throws GeneralLeanFtException
     */
    public WFDesktopButton exists(int... retries) throws GeneralLeanFtException {
        try {
            waitUntil(this.button, testObject -> button.exists());
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                return this.exists(0);
            } else {
                throw e;
            }
        }
        return this;
    }
    
}
