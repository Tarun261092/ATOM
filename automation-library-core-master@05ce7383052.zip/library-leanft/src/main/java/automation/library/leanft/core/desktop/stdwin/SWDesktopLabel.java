package automation.library.leanft.core.desktop.stdwin;

import automation.library.leanft.core.desktop.DesktopLabel;
import com.hp.lft.sdk.GeneralLeanFtException;

public class SWDesktopLabel extends DesktopLabel {

    @Override
    public DesktopLabel click(int... retries) throws GeneralLeanFtException {
        return null;
    }

    @Override
    public DesktopLabel exists(int... retries) throws GeneralLeanFtException {
        return null;
    }

    @Override
    public String getText(int... retries) throws GeneralLeanFtException {
        return null;
    }

    @Override
    public boolean isEnabled(int... retries) throws GeneralLeanFtException {
        return false;
    }
}
