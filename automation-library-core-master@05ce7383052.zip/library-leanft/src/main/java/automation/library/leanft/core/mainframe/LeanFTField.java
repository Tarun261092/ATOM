package automation.library.leanft.core.mainframe;

import automation.library.common.Property;
import automation.library.leanft.core.Constants;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.te.Field;
import com.hp.lft.sdk.te.FieldDescription;
import com.hp.lft.sdk.te.PositionProperty;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import static com.hp.lft.sdk.WaitUntilTestObjectState.waitUntil;

public class LeanFTField {

    private Field field;
    private LeanFTScreen parentScreen;
    private int id;
    protected final Logger log = LogManager.getLogger(this.getClass().getName());


    public LeanFTField(String name, String label, int id) throws GeneralLeanFtException {
        this(new LeanFTScreen(name, label), id);
    }

    public LeanFTField(LeanFTScreen parentScreen, int id) throws GeneralLeanFtException {
        this.parentScreen = parentScreen;
        this.field = parentScreen.getScreen().describe(Field.class,
                                                       new FieldDescription.Builder().id(id).build());
        this.id = id;
    }
  
    public LeanFTField(String name, int screenId, int id) throws GeneralLeanFtException {
        this(new LeanFTScreen(name, screenId), id);
    }

    public LeanFTField(LeanFTScreen parentScreen, int columnNum, int rowNum) throws GeneralLeanFtException {
        this.parentScreen = parentScreen;
        this.field = parentScreen.getScreen().describe(Field.class,
                                                       new FieldDescription.Builder()
                                                               .startPosition(new PositionProperty().setRow(rowNum).setColumn(columnNum))
                                                               .build());
        this.id = field.getId();
    }

    public LeanFTField findField(String name, String label, int id) throws GeneralLeanFtException {
        return new LeanFTField(name, label, id);
    }

    public Field getField() {
        return this.field;
    }

    public LeanFTScreen getParentScreen() {
        return this.parentScreen;
    }


    /**
     * Returns duration for specified waits
     */
    public static int getWaitDuration() {
        final int defaultWait = 10;
        int duration;
        try {
            duration = Property.getProperties(Constants.LEANFTRUNTIMEPATH).getInt("defaultWait");
        } catch (Exception e) {
            duration = defaultWait;
        }
        return duration;
    }

    public static int getFindRetries() {
        final int defaultFindRetries = 10;
        int refind;
        try {
            refind = Integer.parseInt(System.getProperty(Constants.DEFAULT_RETRIES));
        } catch (Exception e) {
            refind = defaultFindRetries;
        }
        return refind;
    }


    public LeanFTField setText(String text, int... retries) throws GeneralLeanFtException {
        try {
            this.field.setText(text);
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.setText(text, 0);
            } else {
                throw e;
            }
        }
        return this;
    }

    public LeanFTField setSecure(String text, int... retries) throws GeneralLeanFtException {
        try {
            this.field.setSecure(text);
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.setSecure(text, 0);
            } else {
                throw e;
            }
        }
        return this;
    }

    public LeanFTField setCursor(int... retries) throws GeneralLeanFtException {
        try {
            this.field.setCursor();
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.setCursor(0);
            } else {
                throw e;
            }
        }
        return this;
    }

    public String getText(int... retries) throws GeneralLeanFtException {
        String str = null;
        try {
            str = this.field.getText();
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                return this.getText(0);
            } else {
                throw e;
            }
        }
        return str;
    }
    
    public boolean isProtected(int... retries) throws GeneralLeanFtException {
        boolean condition;
        try {
        	condition = this.field.isProtected();
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                return this.isProtected(retries);
            } else {
                throw e;
            }
        }
        return condition;
    }

    /**
     * wait for the field to become visible
     */
    public LeanFTField visible(int... retries) throws GeneralLeanFtException {
        {
            try {
                waitUntil(this.field, testObject -> field.isVisible());
            } catch (Exception e) {
                if (!(retries.length > 0 && retries[0] == 0)) {
                    this.refind(retries);
                    return this.visible(0);
                } else {
                    throw e;
                }
            }
            return this;
        }
    }

    /**
     * wait for the field to Exist
     */
    public LeanFTField exists(int... retries) throws GeneralLeanFtException {
        {
            try {
                waitUntil(this.field, testObject -> field.exists());
            } catch (Exception e) {
                if (!(retries.length > 0 && retries[0] == 0)) {
                    this.refind(retries);
                    return this.exists(0);
                } else {
                    throw e;
                }
            }
            return this;
        }
    }

    /**
     * searches again for the field using the by
     */
    public LeanFTField refind(int... retries) {
        log.info("Attempting to refind the field with ID: {}", id);
        int attempts = 0;
        Boolean retry = true;
        int maxRetry = retries.length > 0 ? retries[0] : getFindRetries();
        while (attempts < maxRetry && retry) {
            try {
                log.debug("retry number {}", attempts);
                waitUntil(this.field, testObject -> field.exists());
                this.field.getId();
                retry = false;
            } catch (Exception e) {
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e1) {
                    log.debug(e1.getMessage());
                    Thread.currentThread().interrupt();
                }
            }
            attempts++;
        }
        return this;
    }
}
