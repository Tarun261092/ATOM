package automation.library.leanft.core.desktop.web;

import automation.library.common.Property;
import automation.library.leanft.core.Constants;
import automation.library.leanft.core.desktop.DesktopObject;
import automation.library.leanft.core.desktop.DesktopWeb;
import automation.library.leanft.core.desktop.stdwin.SWDesktopWindow;
import automation.library.leanft.core.desktop.winforms.WFDesktopWindow;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.web.Frame;
import com.hp.lft.sdk.web.FrameDescription;
import com.hp.lft.sdk.web.Image;
import com.hp.lft.sdk.web.ImageDescription;
import com.hp.lft.sdk.web.Link;
import com.hp.lft.sdk.web.LinkDescription;
import com.hp.lft.sdk.web.WebElement;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import static com.hp.lft.sdk.WaitUntilTestObjectState.waitUntil;

public class DesktopWebLink extends DesktopWeb {

    private DesktopWebPageEmbedded desktopWebPage;
    private Link link;
    private String locatorText;
    private WebDesktopBrowserWindow parentWindow;
    private DesktopWebFrame desktopWebFrame;

    protected final Logger log = LogManager.getLogger(this.getClass().getName());

    
    public DesktopWebLink() {
	}

	public DesktopWebLink(String windowObjectName,
                          String fullType,
                          String windowTitle,
                          String locatorText,
                          LocatorType locatorType) throws GeneralLeanFtException {
        this.desktopWebPage = new DesktopWebPageEmbedded(windowObjectName, windowTitle, fullType);
        this.locatorText = locatorText;
        this.link = desktopWebPage.getEmbeddedPage()
                              .describe(Link.class,
                                        getLocatorObject(locatorText, locatorType));
    }

    public DesktopWebLink(WFDesktopWindow parentWindow,
                          String locatorText,
                          LocatorType locatorType) throws GeneralLeanFtException {
        this.desktopWebPage = new DesktopWebPageEmbedded(parentWindow);
        this.locatorText = locatorText;
        this.link = desktopWebPage.getEmbeddedPage().describe(Link.class,
                                                          getLocatorObject(locatorText, locatorType));

    }

    public DesktopWebLink(String title, String browserType, String name, String xpath) throws GeneralLeanFtException {
        this.parentWindow = new WebDesktopBrowserWindow(title, browserType);
        this.link = parentWindow.getWindow().describe(Link.class, new LinkDescription.Builder()
                .name(name).xpath(xpath).build());

    }

    public DesktopWebLink(String title, String browserType, String locatorText, LocatorType locatorType) throws GeneralLeanFtException {
        this.parentWindow = new WebDesktopBrowserWindow(title, browserType);
        this.link = parentWindow.getWindow().describe(Link.class,
                                                      getLocatorObject(locatorText, locatorType));

    }

    public DesktopWebLink(WFDesktopWindow parentWindow,
                          SWDesktopWindow swDesktopWindow,
                          String locatorText,
                          LocatorType locatorType) throws GeneralLeanFtException {
        this.desktopWebPage = new DesktopWebPageEmbedded(parentWindow, swDesktopWindow);
        this.locatorText = locatorText;
        this.link = desktopWebPage.getEmbeddedPage()
                              .describe(Link.class,
                                        getLocatorObject(locatorText, locatorType));
    }

    public DesktopWebLink(WebDesktopBrowserWindow parentWindow, String name, String xpath) throws GeneralLeanFtException {
        this.parentWindow = parentWindow;
        this.link = parentWindow.getWindow().describe(Link.class, new LinkDescription.Builder()
                .name(name).xpath(xpath).build());

    }


    public DesktopWebLink(WebDesktopBrowserWindow webDesktopBrowserWindow, String pageTitle, String innerText, String tagName, String xpath) throws GeneralLeanFtException {
        this.desktopWebPage = new DesktopWebPageEmbedded(webDesktopBrowserWindow, pageTitle);
        this.link = desktopWebPage.getEmbeddedPage().describe(Link.class, new LinkDescription.Builder()
                .innerText(innerText)
                .tagName(tagName)
                .xpath(xpath).build());
    }

    public DesktopWebLink(DesktopWebFrame desktopWebFrame, String locatorText, LocatorType locatorType) throws GeneralLeanFtException {
        this.desktopWebFrame = desktopWebFrame;
        this.link = desktopWebFrame.getFrame().describe(Link.class, getLocatorObject(locatorText, locatorType));
    }

    public DesktopWebLink(WebDesktopBrowserWindow parentWindow, String locatorText, LocatorType locatorType) throws GeneralLeanFtException {
        this.parentWindow = parentWindow;
        this.link = parentWindow.getWindow().describe(Link.class, getLocatorObject(locatorText, locatorType));
    }

    public DesktopWebLink(DesktopWebPageEmbedded desktopWebPage, String locatorText, LocatorType locatorType) throws GeneralLeanFtException {
        this.desktopWebPage = desktopWebPage;
        this.link = desktopWebPage.getEmbeddedPage().describe(Link.class, getLocatorObject(locatorText, locatorType));
    }

    public DesktopWebLink(WebDesktopBrowserWindow webDesktopBrowserWindow, String pageTitle, String locatorText, LocatorType locatorType) throws GeneralLeanFtException {
        this.desktopWebPage = new DesktopWebPageEmbedded(webDesktopBrowserWindow, pageTitle);
        this.link = desktopWebPage.getEmbeddedPage().describe(Link.class, getLocatorObject(locatorText, locatorType));
    }

    public WebElement checkVisiblityOfLinkInFrame(String title, String browserType, String frameName, String xpath)
			throws GeneralLeanFtException {
		String numberOfRetries = "";
		int count = 1;
		locatorText = xpath;
		boolean visible = false;
		numberOfRetries = Property.getProperty(Constants.LEANFTRUNTIMEPATH, "defaultWait");
		if(numberOfRetries==null || numberOfRetries.equals("0")) {
			numberOfRetries = "40";
		}
		log.info("Trying to find the element with LocaterText: {}", locatorText);
		while(count<Integer.parseInt(numberOfRetries))
		{
			try {
				this.parentWindow = new WebDesktopBrowserWindow(title, browserType);
				 this.link = parentWindow.getWindow().
			                describe(Frame.class, new FrameDescription.Builder()
			               .name(frameName).build()).
			                describe(Link.class,new LinkDescription.Builder().xpath(xpath).build());
				waitUntil(this.getLink(), testObject -> getLink().exists());
	            this.getLink().getId();
				visible = true;
				log.info("Element Located successfully with LocaterText: {}", locatorText);			
			
			} catch (Exception e) {
				try {
					Thread.sleep(1000);
					count = count + 1;
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
				
			}
			if(visible == true) {
				log.info("The element was found in "+count+" attempts");
				break;
			}
		}		
		if(visible==false)
		{
			log.info("Unable to find the element with LocaterText: {}", locatorText);
		}
		return this.link;
		
	}
    
    public WebElement checkVisiblityOfLink(String title, String browserType, String xpath)
			throws GeneralLeanFtException {
		String numberOfRetries = "";
		int count = 1;
		locatorText = xpath;
		boolean visible = false;
		numberOfRetries = Property.getProperty(Constants.LEANFTRUNTIMEPATH, "defaultWait");
		if(numberOfRetries==null || numberOfRetries.equals("0")) {
			numberOfRetries = "40";
		}
		log.info("Trying to find the element with LocaterText: {}", locatorText);
		while(count<Integer.parseInt(numberOfRetries))
		{
			try {
				this.parentWindow = new WebDesktopBrowserWindow(title, browserType);
				this.link = this.parentWindow.getWindow().describe(Link.class,new ImageDescription.Builder().xpath(xpath).build());
				waitUntil(this.getLink(), testObject -> getLink().exists());
                this.getLink().getId();
				visible = true;
				log.info("Element Located successfully with LocaterText: {}", locatorText);			
			
			} catch (Exception e) {
				try {
					Thread.sleep(1000);
					count = count + 1;
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
				
			}
			if(visible == true) {
				log.info("The element was found in "+count+" attempts");
				break;
			}
		}		
		if(visible==false)
		{
			log.info("Unable to find the element with LocaterText: {}", locatorText);
		}
		return this.link;
		
	}
    
    private LinkDescription getLocatorObject(String locatorText, LocatorType locatorType) {
        switch (locatorType) {
            case CSS:
                return new LinkDescription.Builder()
                        .cssSelector(locatorText)
                        .build();
            case XPATH:
                return new LinkDescription.Builder()
                        .xpath(locatorText)
                        .build();
            case ID:
                return new LinkDescription.Builder()
                        .id(locatorText)
                        .build();
            case TAGNAME:
                return new LinkDescription.Builder()
                        .tagName(locatorText)
                        .build();
            default:
                throw new IllegalArgumentException("Unrecognized locator type: " + locatorType.getLocatorTagName());

        }
    }

    public Link getLink() {
        return link;
    }

    @Override
    public DesktopObject exists(int... retries) throws GeneralLeanFtException {
        try {
            waitUntil(this.link, testObject -> link.exists());
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                return this.exists(0);
            } else {
                throw e;
            }
        }
        return this;
    }

    @Override
    public boolean isEnabled(int... retries) throws GeneralLeanFtException {
        return false;
    }

    @Override
    public DesktopWeb doubleClick(int... retries) throws GeneralLeanFtException {
        return null;
    }

    public DesktopWeb click(int... retries) throws GeneralLeanFtException {
        try {
            this.getLink().click();
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.click(0);
            } else {
                throw e;
            }
        }
        return this;
    }

    @Override
    public DesktopWeb hover(int... retries) throws GeneralLeanFtException {
        return null;
    }

    @Override
    public String getText(int... retries) throws GeneralLeanFtException {
        return null;
    }

    @Override
    public DesktopWeb select(String value, int... retries) throws GeneralLeanFtException {
        return null;
    }

    @Override
    public DesktopWeb select(int index, int... retries) throws GeneralLeanFtException {
        return null;
    }

    @Override
    public DesktopWeb setText(String text, int... retries) throws GeneralLeanFtException {
        return null;
    }

    public DesktopWebLink refind(int... retries) {
        log.info("Attempting to refind the field: {}", locatorText);
        int attempts = 0;
        boolean retry = true;
        int maxRetry = retries.length > 0 ? retries[0] : getFindRetries();
        while (attempts < maxRetry && retry) {
            try {
                log.debug("retry number {}", attempts);
                waitUntil(this.getLink(), testObject -> getLink().exists());
                this.getLink().getId();
                retry = false;
            } catch (Exception e) {
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e1) {
                    log.debug(e1.getMessage());
                    Thread.currentThread().interrupt();
                }
            }
            attempts++;
        }
        return this;
    }

    public static int getFindRetries() {
        final int defaultFindRetries = 10;
        int refind;
        try {
            refind = Integer.parseInt(System.getProperty(Constants.DEFAULT_RETRIES));
        } catch (Exception e) {
            refind = defaultFindRetries;
        }
        return refind;
    }
}
