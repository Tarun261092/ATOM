package automation.library.leanft.core.desktop;

import com.hp.lft.sdk.GeneralLeanFtException;

public abstract class DesktopObject {
    public abstract DesktopObject exists(int... retries) throws GeneralLeanFtException;
    public abstract boolean isEnabled(int... retries) throws GeneralLeanFtException;

}
