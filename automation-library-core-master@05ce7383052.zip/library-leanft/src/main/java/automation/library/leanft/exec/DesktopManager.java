package automation.library.leanft.exec;

import automation.library.common.JSONHelper;
import com.hp.lft.sdk.web.Browser;
import automation.library.common.Property;
import automation.library.leanft.core.Constants;
import com.hp.lft.sdk.*;
import com.hp.lft.sdk.internal.ServerLaunchResult;
import com.hp.lft.sdk.internal.ServerLauncher;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Map;

public abstract class DesktopManager {
    protected Aut curAut;
    protected DesktopEnvironment env;
    protected Browser browser;
    private Logger log = LogManager.getLogger(this.getClass().getName());
    protected static final String LOCAL = "LOCAL";
    private static final String SERVER_ADDRESS = "serverAddress";
    private static final String AUTO_LAUNCH = "autoLaunch";
    private static final String LEANFT_INIT = "initSDK";
    protected List<Map<String, String>> listOfTechStacks;

    public Aut getAut(String appName) {
        if (curAut == null) {
            setRunLocation();
            checkForSDKStart();
            createAut(appName);
        }
        return curAut;
    }

    public Browser getBrowser(String appName) {
        if (browser == null) {
            createAut(appName);
        }
        return browser;
    }
    public DesktopEnvironment getEnv() {
        return env;
    }

    protected abstract void createAut(String appName);

    protected abstract void quitAut() throws GeneralLeanFtException;

    protected void clearSDK() {
        SDK.cleanup();
        if (DesktopContext.getInstance().isLeanFTUp()) {
            ServerLauncher.closeServer();
        }
    }

    protected void checkForSDKStart() {
        if (!DesktopContext.getInstance().isLeanFTUp()) {
            try {
                clearSDK();
                initSDK();
            } catch (Exception e) {
                log.error(e.getMessage());
            }
        }
    }

    private void initSDK() throws Exception {
        SDKConfiguration sdkConfiguration = getSDKConfiguration();
        Throwable launchException = launchLeanFTIfNeeded(sdkConfiguration);

        try {
            SDK.init(sdkConfiguration);
        } catch (Exception var6) {
            log.error("{}: failed to init SDK", LEANFT_INIT, var6);
            if (launchException == null) {
                throw var6;
            } else {
                throw new GeneralLeanFtException("Failed to Initialize SDK", launchException);
            }
        }
    }

    private Throwable launchLeanFTIfNeeded(SDKConfiguration sdkConfiguration) throws GeneralLeanFtException,
                                                                                     URISyntaxException,
                                                                                     InterruptedException {
        Throwable launchException = null;

        if (sdkConfiguration.getAutoLaunch() && isLocalAddress(sdkConfiguration.getServerAddress())) {
            log.info("{}: attempting to launch LeanFT Engine", LEANFT_INIT);
            ServerLaunchResult launchRes = ServerLauncher.launchIfNeeded().result;
            log.info("{}: Launch result: {}", LEANFT_INIT, launchRes);
            if (launchRes == ServerLaunchResult.SUCCESS) {
                DesktopContext.getInstance().setLeanFTUp(true);
                Thread.sleep(10000L);
            } else {
                String errMessage;
                if (launchRes == ServerLaunchResult.FAILED_CONFLICTING_PROCESS_RUNNING) {
                    errMessage = "Failed launching the runtime engine. An instance of UFT or Sprinter is already running.";
                    log.error("{}: {}", LEANFT_INIT, errMessage);
                    throw new GeneralLeanFtException(errMessage);
                }

                if (launchRes == ServerLaunchResult.FAILED) {
                    errMessage = "Failed launching the runtime engine";
                    log.warn("{}: {}, {}", LEANFT_INIT, errMessage, "will attempt to connect.");
                    launchException = new GeneralLeanFtException(errMessage);
                }
            }
        } else {
            DesktopContext.getInstance().setLeanFTUp(false);
        }

        return launchException;
    }

    private static boolean isLocalAddress(URI uri) {
        if (uri == null) {
            return false;
        } else {
            String hostname = uri.getHost();
            if (isNullOrEmpty(hostname)) {
                return false;
            } else {
                return hostname.equals("127.0.0.1") || hostname.equalsIgnoreCase("localhost");
            }
        }
    }

    private static boolean isNullOrEmpty(String str) {
        return str == null || str.isEmpty();
    }

    private static ModifiableSDKConfiguration getSDKConfiguration() throws URISyntaxException, IOException {
        return SDKConfigurationFactory.loadConfigurationFromExternalPropertiesFile(Constants.LEANFTPROPERTIESPATH);
    }

    private void setRunLocation() {
        listOfTechStacks = JSONHelper.getJSONAsListOfMaps(Constants.LEANFTSTACKSPATH);

        if (!listOfTechStacks.isEmpty() && runOnGrid(listOfTechStacks.get(0))) {
            DesktopContext.getInstance().setRunOnGrid(true);
            updateLeanFTProperties(Property.getProperty(Constants.LEANFTRUNTIMEPATH, "LeanFTGridName"));
        } else {
            DesktopContext.getInstance().setRunOnGrid(false);
            updateLeanFTProperties(LOCAL);
        }
    }

    private boolean runOnGrid(Map<String, String> techStack) {
        return techStack.get("leanFTServer") != null &&
               techStack.get("leanFTServer").equalsIgnoreCase("grid");
    }


    protected void updateLeanFTProperties(String gridName) {
        String leanFTURL = "ws://%s:5095/";

        if (gridName == null || gridName.equalsIgnoreCase(LOCAL)) {
            setLeanFTProperty(SERVER_ADDRESS, String.format(leanFTURL,"localhost"));
        } else {
            setLeanFTProperty(SERVER_ADDRESS, String.format(leanFTURL, gridName));
            setLeanFTProperty(AUTO_LAUNCH, "false");
        }
    }

    private void setLeanFTProperty(String key, String value) {
        Property.setProperty(Constants.LEANFTPROPERTIESPATH, key, value);
    }

    protected EnvironmentDescription setEnvironmentDescription(Map<String, String> techStack) throws GeneralLeanFtException {
        EnvironmentDescription environmentDescription = new EnvironmentDescription();

        environmentDescription.set("osType", techStack.get("osType"));
        environmentDescription.set("osVersion", techStack.get("osVersion"));
        return environmentDescription;
    }

    protected Aut launchApplication(String fileName, String[] args, String workingDirectory) throws GeneralLeanFtException {
        if (DesktopContext.getInstance().runOnGrid()) {
            try {
                env = EnvironmentFactory.get(setEnvironmentDescription(listOfTechStacks.get(0)));
                return env.launchAut(fileName, args, workingDirectory);
            } catch (GeneralLeanFtException e) {
                log.warn("Unable to set up LeanFT grid as specified. Defaulting to a local run");
                DesktopContext.getInstance().setRunOnGrid(false);
                updateLeanFTProperties(LOCAL);
                checkForSDKStart();
                return Desktop.launchAut(fileName, args, workingDirectory);
            }
        } else {
            checkForSDKStart();
            return Desktop.launchAut(fileName, args, workingDirectory);
        }
    }
}
