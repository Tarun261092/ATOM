package automation.library.leanft.exec.maps;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class DesktopApplication {
    @SerializedName("fileName")
    @Expose
    private String fileName;
    @SerializedName("args")
    @Expose
    private String[] args;
    @SerializedName("workingDirectory")
    @Expose
    private String workingDirectory;
    @SerializedName("defaultApplLaunchWait")
    @Expose
    private int defaultApplLaunchWait;
    @SerializedName("windowTitle")
    @Expose
    private String windowTitle;
    @SerializedName("rplidWindowTitle")
    @Expose
    private String rplidWindowTitle;
    @SerializedName("commandWindowTitle")
    @Expose
    private String commandWindowTitle;
    @SerializedName("pageTitle")
    @Expose
    private String pageTitle;
    @SerializedName("browser")
    @Expose
    private String browser;

    public String getFileName() {
        return fileName;
    }

    public String[] getArgs() {
        return args;
    }

    public String getWorkingDirectory() {
        return workingDirectory;
    }

    public int getDefaultApplLaunchWait() {
        return defaultApplLaunchWait;
    }

    public String getWindowTitle() {
        return windowTitle;
    }

    public String getRplidWindowTitle() {
        return rplidWindowTitle;
    }

    public void setRplidWindowTitle(String rplidWindowTitle) {
        this.rplidWindowTitle = rplidWindowTitle;
    }

    public String getCommandWindowTitle() {
        return commandWindowTitle;
    }

    public void setCommandWindowTitle(String commandWindowTitle) {
        this.commandWindowTitle = commandWindowTitle;
    }
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public void setArgs(String[] args) {
        this.args = args;
    }

    public void setWorkingDirectory(String workingDirectory) {
        this.workingDirectory = workingDirectory;
    }

    public void setDefaultApplLaunchWait(int defaultApplLaunchWait) {
        this.defaultApplLaunchWait = defaultApplLaunchWait;
    }
    public void setWindowTitle(String windowTitleRegExp) {
        this.windowTitle = windowTitleRegExp;
    }

    public String getPageTitle() {
        return pageTitle;
    }

    public void setPageTitle(String pageTitle) {
        this.pageTitle = pageTitle;
    }

    public String getBrowser() {
        return browser;
    }

    public void setBrowser(String browser) {
        this.browser = browser;
    }
}
