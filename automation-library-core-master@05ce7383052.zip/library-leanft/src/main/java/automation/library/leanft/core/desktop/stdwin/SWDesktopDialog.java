package automation.library.leanft.core.desktop.stdwin;

import automation.library.leanft.core.desktop.DesktopDialog;
import automation.library.leanft.core.desktop.DesktopObject;
import automation.library.leanft.exec.DesktopContext;
import com.hp.lft.sdk.Desktop;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.stdwin.Dialog;
import com.hp.lft.sdk.stdwin.WindowDescription;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import static com.hp.lft.sdk.WaitUntilTestObjectState.waitUntil;

public class SWDesktopDialog extends DesktopDialog {
    private Dialog dialog;

    protected final Logger log = LogManager.getLogger(this.getClass().getName());

    public SWDesktopDialog(String windowClassRegExp, String windowTitleRegExp) throws GeneralLeanFtException {
        if (DesktopContext.getInstance().runOnGrid()) {
            this.dialog = DesktopContext.getInstance()
                                        .getEnv()
                                        .describe(Dialog.class, new WindowDescription.Builder()
                                                .childWindow(false)
                                                .ownedWindow(true)
                                                .windowClassRegExp(windowClassRegExp)
                                                .windowTitleRegExp(windowTitleRegExp).build());
        } else {
            this.dialog = Desktop.describe(Dialog.class, new WindowDescription.Builder()
                    .childWindow(false)
                    .ownedWindow(true)
                    .windowClassRegExp(windowClassRegExp)
                    .windowTitleRegExp(windowTitleRegExp).build());
        }
    }

    public SWDesktopDialog(String windowClassRegExp, String windowTitleRegExp, boolean childWindow, boolean ownedWindow) throws GeneralLeanFtException {
        if (DesktopContext.getInstance().runOnGrid()) {
            this.dialog = DesktopContext.getInstance()
                                        .getEnv()
                                        .describe(Dialog.class, new WindowDescription.Builder()
                                                .childWindow(childWindow)
                                                .ownedWindow(ownedWindow)
                                                .windowClassRegExp(windowClassRegExp)
                                                .windowTitleRegExp(windowTitleRegExp).build());
        } else {
            this.dialog = Desktop.describe(Dialog.class, new WindowDescription.Builder()
                    .childWindow(childWindow)
                    .ownedWindow(ownedWindow)
                    .windowClassRegExp(windowClassRegExp)
                    .windowTitleRegExp(windowTitleRegExp).build());
        }
    }

    public Dialog getDialog() {
        return this.dialog;
    }

    @Override
    public DesktopObject exists(int... retries) throws GeneralLeanFtException {
        waitUntil(this.dialog, testObject -> dialog.exists());
        return this;
    }

    @Override
    public boolean isEnabled(int... retries) throws GeneralLeanFtException {
        return this.dialog.isEnabled();
    }
}
