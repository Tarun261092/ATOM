package automation.library.leanft.core.desktop.winforms;

import automation.library.leanft.core.Constants;
import automation.library.leanft.core.desktop.DesktopCalender;
import automation.library.leanft.core.desktop.DesktopObject;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.winforms.Calendar;
import com.hp.lft.sdk.winforms.CalendarDescription;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import static com.hp.lft.sdk.WaitUntilTestObjectState.waitUntil;

public class WFDesktopCalender extends DesktopCalender {

    private Calendar calender;
    private WFDesktopWindow parentUiObj;
    private String objectName;

    protected final Logger log = LogManager.getLogger(this.getClass().getName());

    public WFDesktopCalender(String windowObjectName, String windowTitleRegExp, String fullType, String objectName) throws GeneralLeanFtException {
        this.parentUiObj = new WFDesktopWindow(windowObjectName, windowTitleRegExp,fullType);
        this.objectName=objectName;
        this.calender = parentUiObj.getWindow().describe(Calendar.class, new CalendarDescription.Builder()
                .objectName(objectName).build());

    }


    public Calendar getDesktopCalender() {
        return this.calender;
    }


    public DesktopCalender click(int... retries) throws GeneralLeanFtException {
        try {
            this.getDesktopCalender().click();
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.click(0);
            } else {
                throw e;
            }
        }
        return this;
    }

    /**
     * searches again for the field using the by
     */
    public WFDesktopCalender refind(int... retries) {
        log.info("Attempting to refind the field: {}", objectName);
        int attempts = 0;
        boolean retry = true;
        int maxRetry = retries.length > 0 ? retries[0] : getFindRetries();
        while (attempts < maxRetry && retry) {
            try {
                log.debug("retry number {}", attempts);
                waitUntil(this.getDesktopCalender(), testObject -> getDesktopCalender().exists());
                this.getDesktopCalender().getObjectName();
                retry = false;
            } catch (Exception e) {
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e1) {
                    log.debug(e1.getMessage());
                    Thread.currentThread().interrupt();
                }
            }
            attempts++;
        }
        return this;
    }
    public static int getFindRetries() {
        final int defaultFindRetries = 10;
        int refind;
        try {
            refind = Integer.parseInt(System.getProperty(Constants.DEFAULT_RETRIES));
        } catch (Exception e) {
            refind = defaultFindRetries;
        }
        return refind;
    }


    @Override
    public DesktopObject exists(int... retries) throws GeneralLeanFtException {
        return null;
    }

    /**
     * @param retries
     * @return
     * @throws GeneralLeanFtException
     */
    public boolean isEnabled(int... retries) throws GeneralLeanFtException {
        boolean status = false;
        try {
            status= this.getDesktopCalender().isEnabled();
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.isEnabled(0);
            } else {
                throw e;
            }
        }
        return status;
    }
    
  }
