package automation.library.leanft.core;

import automation.library.common.CommonPageObject;

public class BasePO extends CommonPageObject {


}
