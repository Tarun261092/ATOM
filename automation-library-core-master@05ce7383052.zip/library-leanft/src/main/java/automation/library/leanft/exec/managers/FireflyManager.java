package automation.library.leanft.exec.managers;

import automation.library.common.StringHelper;
import automation.library.leanft.exec.DesktopContext;
import automation.library.leanft.exec.DesktopManager;
import automation.library.leanft.exec.maps.DesktopApplication;
import com.hp.lft.sdk.GeneralLeanFtException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class FireflyManager extends DesktopManager {
    private static final String FIREFLY = "FIREFLY";
    private Logger log = LogManager.getLogger(this.getClass().getName());

    @Override
    protected void createAut(String appName) {
        try {
            String sessionToLaunch = FIREFLY + StringHelper.removeSpecialChars(appName);
            DesktopApplication appInfo = DesktopContext.getInstance().getAppLaunchData().getDesktopApplications().get(sessionToLaunch);
            if (appInfo == null) {
                appInfo = DesktopContext.getInstance().getAppLaunchData().getDesktopApplications().get(FIREFLY);
            }
            if (appInfo != null) {
                curAut = launchApplication(appInfo.getFileName(), appInfo.getArgs(), appInfo.getWorkingDirectory());
                Thread.sleep(appInfo.getDefaultApplLaunchWait());
            } else {
                log.error("Unable to launch application, App Info does not exist in leanFT launch config file");
            }
        } catch (GeneralLeanFtException | InterruptedException e) {
            log.error(e.getMessage());
            Thread.currentThread().interrupt();
        }
    }

    @Override
    public void quitAut() throws GeneralLeanFtException {
        if (curAut != null) {
            curAut.close();
        }
    }

}