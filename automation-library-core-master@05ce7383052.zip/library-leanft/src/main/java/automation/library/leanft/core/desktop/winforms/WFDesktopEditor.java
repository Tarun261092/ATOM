package automation.library.leanft.core.desktop.winforms;

import automation.library.leanft.core.Constants;
import automation.library.leanft.core.desktop.DesktopEditor;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.winforms.Editor;
import com.hp.lft.sdk.winforms.EditorDescription;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import static com.hp.lft.sdk.WaitUntilTestObjectState.waitUntil;

public class WFDesktopEditor extends DesktopEditor {

    private Editor object;
    private WFDesktopWindow parentWindow;
    private String objectName;

    protected final Logger log = LogManager.getLogger(this.getClass().getName());

    public WFDesktopEditor(String windowObjectName, String fullType, String objectName) throws GeneralLeanFtException {
        this.parentWindow = new WFDesktopWindow(windowObjectName, fullType);
        this.objectName = objectName;
        this.object = parentWindow.getWindow().describe(Editor.class, new EditorDescription.Builder()
                .objectName(objectName).build());

    }

    public WFDesktopEditor(WFDesktopWindow parentWindow, String objectName) throws GeneralLeanFtException {
        this.parentWindow = parentWindow;
        this.objectName = objectName;
        this.object = parentWindow.getWindow().describe(Editor.class, new EditorDescription.Builder()
                .objectName(objectName).build());

    }

    public WFDesktopEditor(String windowObjectName, String windowFullType, String fullType, int index) throws GeneralLeanFtException {
        this.parentWindow = new WFDesktopWindow(windowObjectName, windowFullType);
        this.object = parentWindow.getWindow().describe(Editor.class, new EditorDescription.Builder()
                .fullType(fullType)
                .index(index).build());
    }

    public WFDesktopEditor(WFDesktopWindow parentWindow, String fullType, String objectName) throws GeneralLeanFtException {
        this.parentWindow = parentWindow;
        this.objectName = objectName;
        this.object = parentWindow.getWindow().describe(Editor.class, new EditorDescription.Builder()
                .fullType(fullType)
                .objectName(objectName).build());
    }

    public WFDesktopEditor(WFDesktopWindow parentWindow, String fullType, int index) throws GeneralLeanFtException {
        this.parentWindow = parentWindow;
        this.object = parentWindow.getWindow().describe(Editor.class, new EditorDescription.Builder()
                .fullType(fullType)
                .index(index).build());
    }

    public Editor getEditor() {
        return this.object;
    }

    /**
     * searches again for the field using the by
     */
    public WFDesktopEditor refind(int... retries) {
        log.info("Attempting to refind the field: {}", objectName);
        int attempts = 0;
        boolean retry = true;
        int maxRetry = retries.length > 0 ? retries[0] : getFindRetries();
        while (attempts < maxRetry && retry) {
            try {
                log.debug("retry number {}", attempts);
                waitUntil(this.getEditor(), testObject -> getEditor().exists());
                this.getEditor().getObjectName();
                retry = false;
            } catch (Exception e) {
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e1) {
                    log.debug(e1.getMessage());
                    Thread.currentThread().interrupt();
                }
            }
            attempts++;
        }
        return this;
    }

    /**
     * @param retries
     * @return
     * @throws GeneralLeanFtException
     */
    public WFDesktopEditor exists(int... retries) throws GeneralLeanFtException {
        try {
            waitUntil(this.object, testObject -> object.exists());
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                return this.exists(0);
            } else {
                throw e;
            }
        }
        return this;
    }

    /**
     * @param retries
     * @return
     * @throws GeneralLeanFtException
     */
    public String getText(int... retries) throws GeneralLeanFtException {
        String str = null;
        try {
            str = this.object.getText();
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                return this.getText(0);
            } else {
                throw e;
            }
        }
        return str;
    }

    /**
     * @param text
     * @param retries
     * @return
     * @throws GeneralLeanFtException
     */
    public DesktopEditor sendKeys(String text, int... retries) throws GeneralLeanFtException {
        try {
            this.getEditor().click();
            this.getEditor().sendKeys(text);
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.sendKeys(text, 0);
            } else {
                throw e;
            }
        }
        return this;
    }

    public static int getFindRetries() {
        final int defaultFindRetries = 10;
        int refind;
        try {
            refind = Integer.parseInt(System.getProperty(Constants.DEFAULT_RETRIES));
        } catch (Exception e) {
            refind = defaultFindRetries;
        }
        return refind;
    }

    /**
     * @param retries
     * @return
     * @throws GeneralLeanFtException
     */
    public boolean isEnabled(int... retries) throws GeneralLeanFtException {
        boolean status = false;
        try {
            status= this.getEditor().isEnabled();
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.isEnabled(0);
            } else {
                throw e;
            }
        }
        return status;
    }
}
