package automation.library.leanft.exec;

import java.util.Arrays;
import java.util.Optional;

public enum DesktopType {
    PCOM("pcom"),
    HOD("hod"),
    AVAYA("avaya"),
    RPLID("rplid"),
    WINFORM("winform"),
    FIRFLY("firefly"),
    CONCIERGE("concierge"),
    SALESFORCEDESKTOP("salesforcedesktop"),
    TIGRA("tigra"),
    JAVA("java"),
    WEBBROWSER("webbrowser");

    private String desktopAppName;

    DesktopType(String desktopAppName) {
        this.desktopAppName = desktopAppName;
    }

    public String getDesktopAppName() {
        return desktopAppName;
    }

    public static DesktopType get(String desktopAppName) {
        Optional<DesktopType> first = Arrays.stream(DesktopType.values())
                                            .filter(server -> server.getDesktopAppName()
                                                                    .equalsIgnoreCase(desktopAppName))
                                            .findFirst();

        return first.orElse(null);
    }
}
