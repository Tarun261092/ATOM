package automation.library.leanft.core;

import com.hp.lft.sdk.GeneralLeanFtException;

import java.util.List;

/**
 * @deprecated This class is replaced by automation.library.leanft.core.mainframe.LeanFTScreen
 */
@Deprecated
public class LeanFTScreen extends automation.library.leanft.core.mainframe.LeanFTScreen {

    public LeanFTScreen(String name, String label) throws GeneralLeanFtException {
        super(name, label);
    }

    public LeanFTScreen(String name, int id) throws GeneralLeanFtException {
        super(name, id);
    }

    public LeanFTScreen(String name, List<Integer> idList) throws GeneralLeanFtException {
        super(name, idList);
    }

    public LeanFTScreen(String name, String label, Boolean useRegex) throws GeneralLeanFtException {
        super(name, label, useRegex);
    }
}
