package automation.library.leanft.core;

import org.apache.commons.io.FileUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.File;
import java.util.UUID;

public class ScreenshotBase {

    protected ScreenshotBase() {
        //utlity class
    }

    /**
     * capture screenshot and save to specified location
     */
    public static File saveScreenshot(File screenshot, String filePath) {
        UUID uuid = UUID.randomUUID();
        File file = new File(filePath + uuid + ".png");
        file.getParentFile().mkdirs();

        if(screenshot.exists()) {
            try {
                FileUtils.moveFile(screenshot, file);
            } catch (Exception e) {
                getLogger().error(e.getMessage());
            }
        }
        return file;
    }

    private static Logger getLogger() {
        return LogManager.getLogger(ScreenshotBase.class);
    }
}
