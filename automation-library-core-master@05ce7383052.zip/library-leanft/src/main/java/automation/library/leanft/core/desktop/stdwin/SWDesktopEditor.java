package automation.library.leanft.core.desktop.stdwin;

import automation.library.leanft.core.desktop.DesktopEditor;
import automation.library.leanft.core.desktop.DesktopObject;
import com.hp.lft.sdk.GeneralLeanFtException;

public class SWDesktopEditor extends DesktopEditor {
    @Override
    public String getText(int... retries) throws GeneralLeanFtException {
        return null;
    }

    @Override
    public DesktopObject exists(int... retries) throws GeneralLeanFtException {
        return null;
    }

    @Override
    public boolean isEnabled(int... retries) throws GeneralLeanFtException {
        return false;
    }

    @Override
    public DesktopEditor sendKeys(String text, int... retries) throws GeneralLeanFtException {
        return null;
    }
}
