package automation.library.leanft.core.desktop.web;

import static com.hp.lft.sdk.WaitUntilTestObjectState.waitUntil;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.web.Button;
import com.hp.lft.sdk.web.ButtonDescription;
import com.hp.lft.sdk.web.Frame;
import com.hp.lft.sdk.web.FrameDescription;
import com.hp.lft.sdk.web.WebElement;
import com.hp.lft.sdk.web.WebElementDescription;

import automation.library.common.Property;
import automation.library.leanft.core.Constants;
import automation.library.leanft.core.desktop.DesktopWeb;
import automation.library.leanft.core.desktop.stdwin.SWDesktopWindow;
import automation.library.leanft.core.desktop.winforms.WFDesktopWindow;

public class DesktopWebElement extends DesktopWeb {
	private WebElement webElement;
	private String locatorText;
	private WebDesktopBrowserWindow parentWindow;
	private DesktopWebPageEmbedded desktopWebPage;
	private DesktopWebFrame desktopWebFrame;

	protected final Logger log = LogManager.getLogger(this.getClass().getName());
	
	public DesktopWebElement() {
		
	}

	public DesktopWebElement(String windowObjectName, String fullType, String windowTitle, String locatorText,
			LocatorType locatorType) throws GeneralLeanFtException {
		this.desktopWebPage = new DesktopWebPageEmbedded(windowObjectName, windowTitle, fullType);
		this.locatorText = locatorText;
		this.webElement = desktopWebPage.getEmbeddedPage().describe(WebElement.class,
				getLocatorObject(locatorText, locatorType));
		
	}

	public DesktopWebElement(WFDesktopWindow parentWindow, String locatorText, LocatorType locatorType)
			throws GeneralLeanFtException {
		this.desktopWebPage = new DesktopWebPageEmbedded(parentWindow);
		this.locatorText = locatorText;
		this.webElement = desktopWebPage.getEmbeddedPage().describe(WebElement.class,
				getLocatorObject(locatorText, locatorType));
		
	}

	public DesktopWebElement(SWDesktopWindow parentWindow, String locatorText, LocatorType locatorType)
			throws GeneralLeanFtException {
		this.desktopWebPage = new DesktopWebPageEmbedded(parentWindow);
		this.locatorText = locatorText;
		this.webElement = desktopWebPage.getEmbeddedPage().describe(WebElement.class,
				getLocatorObject(locatorText, locatorType));
		
	}

	public DesktopWebElement(WFDesktopWindow parentWindow, SWDesktopWindow swDesktopWindow, String locatorText,
			LocatorType locatorType) throws GeneralLeanFtException {
		this.desktopWebPage = new DesktopWebPageEmbedded(parentWindow, swDesktopWindow);
		this.locatorText = locatorText;
		this.webElement = desktopWebPage.getEmbeddedPage().describe(WebElement.class,
				getLocatorObject(locatorText, locatorType));
		
	}

	public DesktopWebElement(String title, String browserType, String locatorText, LocatorType locatorType)
			throws GeneralLeanFtException {
		this.parentWindow = new WebDesktopBrowserWindow(title, browserType);
		this.webElement = parentWindow.getWindow().describe(WebElement.class,
				getLocatorObject(locatorText, locatorType));
	
		
	}

	public DesktopWebElement(String title, String browserType, String name, String xpath)
			throws GeneralLeanFtException {
		this.parentWindow = new WebDesktopBrowserWindow(title, browserType);
		this.webElement = parentWindow.getWindow().describe(WebElement.class,
				new WebElementDescription.Builder().name(name).xpath(xpath).build());
		
	}

	public DesktopWebElement(WebDesktopBrowserWindow parentWindow, String name, String xpath)
			throws GeneralLeanFtException {
		this.parentWindow = parentWindow;
		this.webElement = parentWindow.getWindow().describe(WebElement.class,
				new WebElementDescription.Builder().name(name).xpath(xpath).build());
	
	}

	public DesktopWebElement(WebDesktopBrowserWindow parentWindow, String innerText, String tagName, String xpath)
			throws GeneralLeanFtException {

		this.parentWindow = parentWindow;
		this.webElement = parentWindow.getWindow().describe(WebElement.class,
			new WebElementDescription.Builder().innerText(innerText).tagName(tagName).xpath(xpath).build());
	
	}

	public DesktopWebElement(WebDesktopBrowserWindow webDesktopBrowserWindow, String pageTitle, String innerText,
			String tagName, String xpath) throws GeneralLeanFtException {
		this.desktopWebPage = new DesktopWebPageEmbedded(webDesktopBrowserWindow, pageTitle);
		this.webElement = desktopWebPage.getEmbeddedPage().describe(WebElement.class,
				new WebElementDescription.Builder().innerText(innerText).tagName(tagName).xpath(xpath).build());
	
	}

	public DesktopWebElement(DesktopWebFrame desktopWebFrame, String locatorText, LocatorType locatorType) throws GeneralLeanFtException {
		this.desktopWebFrame = desktopWebFrame;
		this.webElement = desktopWebFrame.getFrame().describe(WebElement.class, getLocatorObject(locatorText, locatorType));
	
	}

	public DesktopWebElement(WebDesktopBrowserWindow parentWindow, String locatorText, LocatorType locatorType) throws GeneralLeanFtException {
		this.parentWindow = parentWindow;
		this.webElement = parentWindow.getWindow().describe(WebElement.class, getLocatorObject(locatorText, locatorType));
	
	}

	public DesktopWebElement(DesktopWebPageEmbedded desktopWebPage, String locatorText, LocatorType locatorType) throws GeneralLeanFtException {
		this.desktopWebPage = desktopWebPage;
		this.webElement = desktopWebPage.getEmbeddedPage().describe(WebElement.class, getLocatorObject(locatorText, locatorType));
	
	}

	public DesktopWebElement(WebDesktopBrowserWindow webDesktopBrowserWindow, String pageTitle, String locatorText, LocatorType locatorType) throws GeneralLeanFtException {
		this.desktopWebPage = new DesktopWebPageEmbedded(webDesktopBrowserWindow, pageTitle);
		this.webElement = desktopWebPage.getEmbeddedPage().describe(WebElement.class, getLocatorObject(locatorText, locatorType));
		
	}
	public WebElement checkVisiblityOfElement(String title, String browserType, String xpath)
			throws GeneralLeanFtException {
		String numberOfRetries = "";
		int count = 1;
		locatorText = xpath;
		boolean visible = false;
		numberOfRetries = Property.getProperty(Constants.LEANFTRUNTIMEPATH, "defaultWait");
		if(numberOfRetries==null || numberOfRetries.equals("0")) {
			numberOfRetries = "40";
		}
		log.info("Trying to find the element with LocaterText: {}", locatorText);
		while(count<Integer.parseInt(numberOfRetries))
		{
			try {
				this.parentWindow = new WebDesktopBrowserWindow(title, browserType);
				this.webElement = this.parentWindow.getWindow().describe(WebElement.class,new WebElementDescription.Builder().xpath(xpath).build());
				waitUntil(this.getWebElement(), testObject -> getWebElement().exists());
				this.getWebElement().getId();
				visible = true;
				log.info("Element Located successfully with LocaterText: {}", locatorText);			
			
			} catch (Exception e) {
				try {
					Thread.sleep(1000);
					count = count + 1;
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
				
			}
			if(visible == true) {
				log.info("The element was found in "+count+" attempts");
				break;
			}
		}		
		if(visible==false)
		{
			log.info("Unable to find the element with LocaterText: {}", locatorText);
		}
		return this.webElement;
		
	}

	public WebElement checkVisiblityOfElementInFrame(String title, String browserType, String frameName, String xpath)
			throws GeneralLeanFtException {
		String numberOfRetries = "";
		int count = 1;
		locatorText = xpath;
		boolean visible = false;
		numberOfRetries = Property.getProperty(Constants.LEANFTRUNTIMEPATH, "defaultWait");
		if(numberOfRetries==null || numberOfRetries.equals("0")) {
			numberOfRetries = "40";
		}
		log.info("Trying to find the element with LocaterText: {}", locatorText);
		while(count<Integer.parseInt(numberOfRetries))
		{
			try {				
				this.parentWindow = new WebDesktopBrowserWindow(title, browserType);
				this.webElement = parentWindow.getWindow().
			                describe(Frame.class, new FrameDescription.Builder()
			               .name(frameName).build()).
			                describe(WebElement.class,new WebElementDescription.Builder().xpath(xpath).build());
				waitUntil(this.getWebElement(), testObject -> getWebElement().exists());
				this.getWebElement().getId();
				visible = true;
				log.info("Element Located successfully with LocaterText: {}", locatorText);			
			
			} catch (Exception e) {
				try {
					Thread.sleep(1000);
					count = count + 1;
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
				
			}
			if(visible == true) {
				log.info("The element was found in "+count+" attempts");
				break;
			}
		}		
		if(visible==false)
		{
			log.info("Unable to find the element with LocaterText: {}", locatorText);
		}
		return this.webElement;
		
	}
	private WebElementDescription getLocatorObject(String locatorText, LocatorType locatorType) {
		switch (locatorType) {
		case CSS:
			return new WebElementDescription.Builder().cssSelector(locatorText).build();
		case XPATH:
			return new WebElementDescription.Builder().xpath(locatorText).build();
		case ID:
			return new WebElementDescription.Builder().id(locatorText).build();
		case TAGNAME:
			return new WebElementDescription.Builder().tagName(locatorText).build();
		case NAME:
			return new WebElementDescription.Builder().name(locatorText).build();
		default:
			throw new IllegalArgumentException("Unrecognized locator type: " + locatorType.getLocatorTagName());

		}
	}

	public WebElement getWebElement() {
		return webElement;
	}

	@Override
	public DesktopWeb exists(int... retries) throws GeneralLeanFtException {
		try {
			waitUntil(this.webElement, testObject -> webElement.exists());
		} catch (Exception e) {
			if (!(retries.length > 0 && retries[0] == 0)) {
				this.refind(retries);
				return this.exists(0);
			} else {
				throw e;
			}
		}
		return this;
	}

	@Override
	public boolean isEnabled(int... retries) throws GeneralLeanFtException {
		return false;
	}

	@Override
	public DesktopWeb select(String value, int... retries) throws GeneralLeanFtException {
		return null;
	}

	@Override
	public DesktopWeb select(int index, int... retries) throws GeneralLeanFtException {
		return null;
	}

	@Override
	public DesktopWeb setText(String text, int... retries) throws GeneralLeanFtException {
		return null;
	}

	public DesktopWebElement refind(int... retries) {
		log.info("Attempting to refind the field: {}", locatorText);
		int attempts = 0;
		boolean retry = true;
		int maxRetry = retries.length > 0 ? retries[0] : getFindRetries();
		while (attempts < maxRetry && retry) {
			try {
				log.debug("retry number {}", attempts);
				waitUntil(this.getWebElement(), testObject -> getWebElement().exists());
				this.getWebElement().getId();
				retry = false;
			} catch (Exception e) {
				try {
					log.info("Attempting to refind the field: {}", locatorText);
					Thread.sleep(500);
				} catch (InterruptedException e1) {
					log.debug(e1.getMessage());
					Thread.currentThread().interrupt();
				}
			}
			attempts++;
		}
		return this;
	}

	public static int getFindRetries() {
		final int defaultFindRetries = 10;
		int refind;
		try {
			refind = Integer.parseInt(System.getProperty(Constants.DEFAULT_RETRIES));
		} catch (Exception e) {
			refind = defaultFindRetries;
		}
		return refind;
	}

	public DesktopWeb click(int... retries) throws GeneralLeanFtException {
		try {
			this.getWebElement().click();
		} catch (Exception e) {
			if (!(retries.length > 0 && retries[0] == 0)) {
				this.refind(retries);
				this.click(0);
			} else {
				throw e;
			}
		}
		return this;
	}

	public DesktopWeb hover(int... retries) throws GeneralLeanFtException {
		try {
			this.getWebElement().hoverTap();
		} catch (Exception e) {
			if (!(retries.length > 0 && retries[0] == 0)) {
				this.refind(retries);
				this.click(0);
			} else {
				throw e;
			}
		}
		return this;
	}

	public DesktopWeb doubleClick(int... retries) throws GeneralLeanFtException {
		try {
			this.getWebElement().doubleClick();
		} catch (Exception e) {
			if (!(retries.length > 0 && retries[0] == 0)) {
				this.refind(retries);
				this.doubleClick(0);
			} else {
				throw e;
			}
		}
		return this;
	}

	public String getText(int... retries) throws GeneralLeanFtException {
		String str = null;
		try {
			str = this.getWebElement().getInnerText();
		} catch (Exception e) {
			if (!(retries.length > 0 && retries[0] == 0)) {
				this.refind(retries);
				return this.getText(0);
			} else {
				throw e;
			}
		}
		return str;
	}
}
