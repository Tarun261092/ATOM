package automation.library.leanft.core.mainframe;

import automation.library.leanft.exec.DesktopContext;
import automation.library.reporting.Reporter;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.GeneralReplayException;
import com.hp.lft.sdk.Keyboard;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.*;
import java.util.stream.Collectors;

import static com.hp.lft.sdk.WaitUntilTestObjectState.waitUntil;

public class LeanFTTable {
    private static final String COMPARE = "COMPARE";
    private static final String RETRIEVE = "RETRIEVE";
    private static final String BLANK = "BLANK";
    private static final String UNDERSCORE = "UNDERSCORE";
    private static final String ALL_MATCHES = "ALL MATCHES";
    private static final String FIRST_MATCH = "FIRST MATCH";
    private Map<String, LeanFTTableColumn> tableColumns;
    private LeanFTScreen parentScreen;
    private int maxRowsPerScreen;
    private Keyboard.Keys keyToAdvanceScreen;
    private Keyboard.Keys keyToPriorScreen;
    private TableFieldIndicator endOfTableIndicator;
    private TableFieldIndicator begOfTableIndicator;
    private LeanFTTableCompareType tableCompareType;
    private Integer tableColStartNum;
    private boolean searchCurrentScreenOnly = false;
    private final Logger log = LogManager.getLogger(LeanFTTable.class);
    private static final int NOT_FOUND = -1;

    private static class TableFieldIndicator {
        private LeanFTField fieldName;
        private String textToFind;

        private TableFieldIndicator(LeanFTField fieldName, String textToFind) {
            this.fieldName = fieldName;
            this.textToFind = textToFind;
        }

        private boolean foundIndicator() throws GeneralLeanFtException {
            return fieldName.getField().exists() &&
                   fieldName.getText().contains(textToFind);
        }
    }

    private static class ColumnInfo {
        private String columnName;
        private String columnValue;

        private ColumnInfo(String columnName, String columnValue) {
            this.columnName = columnName;
            this.columnValue = columnValue;
        }

        private String getColumnName() {
            return columnName;
        }

        private String getColumnValue() {
            return columnValue;
        }

        public void setColumnValue(String columnValue) {
            this.columnValue = columnValue;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            ColumnInfo columnToMatch = (ColumnInfo) o;
            return columnName.equals(columnToMatch.columnName) &&
                   columnValue.equals(columnToMatch.columnValue);
        }

        @Override
        public int hashCode() {
            return Objects.hash(columnName, columnValue);
        }
    }

    public enum MultiRow {
        ROW1, ROW2, ROW3;
    }

    public LeanFTTable(LeanFTScreen parentScreen,
                       int maxRowsPerScreen,
                       LeanFTTableCompareType tableCompareType,
                       boolean searchCurrentScreenOnly) {
        this.tableColumns = new HashMap<>();
        this.parentScreen = parentScreen;
        this.maxRowsPerScreen = maxRowsPerScreen;
        this.tableCompareType = tableCompareType;
        this.tableColStartNum = 0;
        this.searchCurrentScreenOnly = searchCurrentScreenOnly;
    }

    public LeanFTTable(LeanFTScreen parentScreen,
                       int maxRowsPerScreen,
                       LeanFTTableCompareType tableCompareType) {
        this(parentScreen, maxRowsPerScreen, tableCompareType, false);
    }

    public LeanFTTable(String name,
                       String label,
                       int maxRowsPerScreen,
                       LeanFTTableCompareType tableCompareType) throws GeneralLeanFtException {
        this(new LeanFTScreen(name, label), maxRowsPerScreen, tableCompareType, false);
    }

    public LeanFTTable(String name,
                       String label,
                       int maxRowsPerScreen,
                       LeanFTTableCompareType tableCompareType,
                       boolean searchCurrentScreenOnly) throws GeneralLeanFtException {
        this(new LeanFTScreen(name, label), maxRowsPerScreen, tableCompareType, searchCurrentScreenOnly);
    }

    public void setBeginningOfTableIndicator(LeanFTField begOfTableIndicator,
                                             String begOfTableText,
                                             Keyboard.Keys keyToPriorScreen) {
        this.begOfTableIndicator = new TableFieldIndicator(begOfTableIndicator, begOfTableText);
        this.keyToPriorScreen = keyToPriorScreen;
    }

    public void setEndOfTableIndicator(LeanFTField endOfTableIndicator,
                                       String endOfTableText,
                                       Keyboard.Keys keyToAdvanceScreen) {
        this.endOfTableIndicator = new TableFieldIndicator(endOfTableIndicator, endOfTableText);
        this.keyToAdvanceScreen = keyToAdvanceScreen;
    }

    public LeanFTTable addColumn(String columnName, LeanFTField columnField, int valOffset) {
        tableColumns.put(columnName, new LeanFTTableColumn(columnField, valOffset, tableCompareType));
        tableColStartNum = findStartingColumnNum();
        return this;
    }

    public LeanFTTable addColumn(String columnName, LeanFTField columnField) {
        return addColumn(columnName, columnField, 0);
    }

    public LeanFTTable addColumn(String columnName, int colStartCoord, int colEndCoord, LeanFTField fullRowField) {
        return addColumn(columnName, colStartCoord, colEndCoord, fullRowField, 0);
    }

    public LeanFTTable addColumn(String columnName,
                                 int colStartCoord,
                                 int colEndCoord,
                                 LeanFTField fullRowField,
                                 int valOffset) {
        tableColumns.put(columnName, new LeanFTTableColumn(colStartCoord, colEndCoord, fullRowField, valOffset, tableCompareType));
        tableColStartNum = findStartingColumnNum();
        return this;
    }

    public LeanFTTable addColumn(String columnName,
                                 int rowStartIndex,
                                 int colStartCoord,
                                 int colEndCoord,
                                 LeanFTField fullRowField,
                                 int valOffset,
                                 MultiRow rowNum) {
        tableColumns.put(columnName, new LeanFTTableColumn(rowStartIndex, colStartCoord, colEndCoord, fullRowField, valOffset, rowNum, tableCompareType));
        tableColStartNum = findStartingColumnNum();
        return this;
    }

    public LeanFTTable addColumn(String columnName,
                                 int rowStartIndex,
                                 int colStartCoord,
                                 int colEndCoord,
                                 LeanFTField fullRowField,
                                 MultiRow rowNum) {
        return addColumn(columnName, rowStartIndex, colStartCoord, colEndCoord, fullRowField, 0, rowNum);
    }

    public LeanFTTable addColumn(String columnName,
                                 int colStartCoord,
                                 int colEndCoord,
                                 LeanFTField fullRowField,
                                 MultiRow rowNum) {
        return addColumn(columnName, tableColStartNum, colStartCoord, colEndCoord, fullRowField, 0, rowNum);
    }

    public LeanFTTable addColumn(String columnName,
                                 int rowStartIndex,
                                 int colStartCoord,
                                 int colEndCoord,
                                 LeanFTField fullRowField) {
        tableColumns.put(columnName, new LeanFTTableColumn(rowStartIndex, colStartCoord, colEndCoord, fullRowField, 0, MultiRow.ROW1, tableCompareType));
        tableColStartNum = findStartingColumnNum();
        return this;
    }

    private LeanFTTableColumn getColumn(String columnName) {
        return this.getTableColumn(columnName);
    }

    private int findMatchingRowNum(String columnName, String valToFind, int startingRow) throws GeneralLeanFtException {
        getColumn(columnName).exists(1);
        final int rowsToComplete = getRowsToComplete(columnName);

        for (int i = startingRow + 1; i < rowsToComplete; i++) {
            String textInColumn = extractColumnValFromRow(getTableColumn(columnName), i);

            if (textInColumn != null && colValMatchesExpected(textInColumn, valToFind)) {
                return i;
            }
        }

        return NOT_FOUND;
    }

    private int getRowsToComplete(String columnName) {
        if(tableCompareType == LeanFTTableCompareType.MULTI_LINE_ROW) {
            return maxRowsPerScreen + getColumn(columnName).getColRow() + getNumRowsInMultiRow();
        } else {
            return maxRowsPerScreen + getColumn(columnName).getColRow();
        }
    }

    private boolean colValMatchesExpected(String textInColumn, String valToFind) {
        switch (valToFind.toUpperCase()) {
            case "NUMBER":
                return NumberUtils.isParsable(valToFind);
            case BLANK:
                return textInColumn.isEmpty();
            case "STRING":
            case "NON-BLANK":
                return !textInColumn.isEmpty();
            default:
                return textInColumn.equalsIgnoreCase(valToFind);
        }

    }

    private String extractColumnValFromRow(LeanFTTableColumn curColumn, int rowNum) throws GeneralLeanFtException {
        int curColStartNum = curColumn.getLogicalColStartNum();
        int tableColumnLength = curColumn.getColLength();

        if (curColumn.getColStartNum() > 0) {
            this.tableColStartNum = curColumn.getColStartNum();
        }
        try {
            switch (this.tableCompareType) {
                case FIELD_ONLY:
                    LeanFTField currentRowField = new LeanFTField(parentScreen, curColStartNum, rowNum);
                    if (currentRowField.exists() != null) {
                        return currentRowField.getText().trim();
                    }
                    break;
                case FULL_ROW:
                    return getColValFromFullRow(curColStartNum, tableColumnLength, rowNum);
                case MULTI_LINE_ROW:
                    if (isFirstRowOfMultiRow(rowNum, curColumn)) {
                        return getColValFromFullRow(curColStartNum, tableColumnLength, rowNum + curColumn.getRowNumOfMultiRow());
                    } else {
                        return "";
                    }
                case FULL_TABLE:
                    String fullText = curColumn.getColumnField().getText();
                    int eachRowLength = curColumn.getColumnField().getField().getLength() / maxRowsPerScreen;
                    int startingRow = curColumn.getColumnField().getField().getStartPosition().row;
                    int counter = rowNum - startingRow - 1;
                    int endOfColumnText = curColStartNum + tableColumnLength;
                    int currRowColStart = counter == 0 ? (counter * (eachRowLength)) : (counter * (eachRowLength)) - 1;
                    int currRowColEnd = ((counter + 1) * eachRowLength) - 1;

                    if (fullText.length() > currRowColEnd - 1) {
                        return getColValFromFullText(curColStartNum,
                                                     fullText,
                                                     endOfColumnText,
                                                     currRowColStart,
                                                     currRowColEnd);
                    }
            }
        } catch (GeneralReplayException e) {
            return "";
        }

        return null;
    }

    private boolean isFirstRowOfMultiRow(int rowNum, LeanFTTableColumn curColumn) {
        int startingRow = curColumn.getColRow() - curColumn.getRowNumOfMultiRow();
        return ((rowNum - startingRow) % getNumRowsInMultiRow()) == 0;
    }

    private int getNumRowsInMultiRow() {
        final List<Integer> rowsInMultiRow = new ArrayList<>(tableColumns.values()).stream()
                                                                                   .map(LeanFTTableColumn::getRowNumOfMultiRow)
                                                                                   .sorted(Comparator.reverseOrder())
                                                                                   .collect(Collectors.toList());
        if (!rowsInMultiRow.isEmpty() && rowsInMultiRow.get(0) > 0) {
            //increase number of rows by 1 since using 0-based indexing in LeanFTColumn
            return rowsInMultiRow.get(0) + 1;
        } else {
            return 1;
        }
    }

    private String getColValFromFullRow(int curColStartNum, int tableColumnLength, int rowNum) throws GeneralLeanFtException {
        LeanFTField currentRow;
        currentRow = new LeanFTField(parentScreen, tableColStartNum, rowNum);
        String fullRowText = currentRow.getText();

        //get start and end for substring
        int startOfColumnText = curColStartNum - tableColStartNum;
        int endOfColumnText = startOfColumnText + tableColumnLength;

        if (fullRowText.length() > endOfColumnText) {
            return fullRowText.substring(startOfColumnText, endOfColumnText).trim();
        } else if (!fullRowText.isEmpty() && fullRowText.length() > startOfColumnText) {
            return fullRowText.substring(startOfColumnText).trim();
        } else {
            return "";
        }
    }

    private String getColValFromFullText(int curColStartNum,
                                         String fullText,
                                         int endOfColumnText,
                                         int currRowColStart,
                                         int currRowColEnd) {
        String currentRowText = fullText.substring(currRowColStart, currRowColEnd);
        if (currentRowText.length() > endOfColumnText) {
            return currentRowText.substring(curColStartNum, endOfColumnText + 1).trim();
        } else if (!currentRowText.isEmpty() && currentRowText.length() > curColStartNum) {
            return currentRowText.substring(curColStartNum).trim();
        } else {
            return "";
        }
    }

    private int findStartingColumnNum() {
        final List<Integer> listOfStartColumns = tableColumns.values().stream()
                                                             .map(LeanFTTableColumn::getActualColStartNum)
                                                             .sorted()
                                                             .collect(Collectors.toList());
        if (!listOfStartColumns.isEmpty()) {
            return listOfStartColumns.get(0);
        } else {
            return 0;
        }

    }

    private boolean atEndOfTable() throws GeneralLeanFtException {
        if (endOfTableIndicator != null) {
            return endOfTableIndicator.foundIndicator();
        } else {
            String errorMsg = "End of table indicator not defined. Please update table definition with setEndOfTableIndicator(). Only searching first screen.";
            log.warn(errorMsg);
            Reporter.addStepLog(errorMsg);
            return true;
        }
    }

    private boolean advanceToNextScreen(boolean atEndOfTable) throws GeneralLeanFtException {
        if (!atEndOfTable) {
            try {
                parentScreen.getParentWindow().activate();
                pressKeyboardKey(keyToAdvanceScreen);
                return true;
            } catch (GeneralLeanFtException e) {
                log.warn("Unable to advance screen. Stopping search at current screen. {}", e.getMessage());
                return false;
            }
        }

        return false;
    }

    private void goToFirstPage() throws GeneralLeanFtException {
        if (begOfTableIndicator != null) {
            while (!begOfTableIndicator.foundIndicator()) {
                goToPriorScreen();
            }
        } else {
            String errorMsg = "Beginning of table indicator not defined. Please update table definition with setBeginningOfTableIndicator(). Only searching current screen.";
            log.warn(errorMsg);
            Reporter.addStepLog(errorMsg);
        }
    }

    private void goToPriorScreen() throws GeneralLeanFtException {
        waitUntil(this.parentScreen.getScreen(), testObject -> this.parentScreen.getScreen().exists());
        parentScreen.getParentWindow().getWindow().activate();
        pressKeyboardKey(keyToPriorScreen);
    }

    public String retrieveColumnVal(String colNameToRetrieve, String colNameToMatch, String colValToMatch) throws GeneralLeanFtException {
        List<ColumnInfo> columnsToMatch = new ArrayList<>();

        columnsToMatch.add(new ColumnInfo(colNameToMatch, colValToMatch));
        columnsToMatch.add(new ColumnInfo(colNameToRetrieve, "ANY"));

        return searchTableForMatch(columnsToMatch, RETRIEVE, FIRST_MATCH);
    }


    public List<String> retrieveAllColumnVals(String colNameToRetrieve, String colNameToMatch1, String colValToMatch1,String colNameToMatch2, String colValToMatch2) throws GeneralLeanFtException {
        List<ColumnInfo> columnsToMatch = new ArrayList<>();

        columnsToMatch.add(new ColumnInfo(colNameToMatch1, colValToMatch1));
        columnsToMatch.add(new ColumnInfo(colNameToMatch2, colValToMatch2));
        columnsToMatch.add(new ColumnInfo(colNameToRetrieve, "ANY"));

        return Arrays.asList(searchTableForMatch(columnsToMatch, RETRIEVE, ALL_MATCHES).split(" \\| "));
    }

    public List<String> retrieveAllColumnVals(String colNameToRetrieve, String colNameToMatch1, String colValToMatch1) throws GeneralLeanFtException {
        List<ColumnInfo> columnsToMatch = new ArrayList<>();
        columnsToMatch.add(new ColumnInfo(colNameToMatch1, colValToMatch1));
        columnsToMatch.add(new ColumnInfo(colNameToRetrieve, "ANY"));
        getColumn(colNameToRetrieve).exists(1);
        final int rowsToComplete = getRowsToComplete(colNameToRetrieve);
        int startingRow = getColumn(columnsToMatch.get(0).getColumnName()).getColRow();
        if (searchCurrentScreenOnly) {
            return colValuesAsList(startingRow, rowsToComplete, colNameToMatch1, colValToMatch1);
        } else {
            boolean atEndOfTable = false;
            boolean advanceToNextScreen = false;

            List<String> actualColumnVals = new ArrayList<>();
            goToFirstPage();
            do {
                actualColumnVals.addAll(colValuesAsList(startingRow, rowsToComplete, colNameToMatch1, colValToMatch1));
                atEndOfTable = atEndOfTable();
                advanceToNextScreen = advanceToNextScreen(atEndOfTable);
            } while ((!atEndOfTable && advanceToNextScreen));
            return actualColumnVals;
        }
    }

    public List<String> retrieveAllColumnVals(String colNameToRetrieve) throws GeneralLeanFtException {
        List<ColumnInfo> columnsToMatch = new ArrayList<>();
        columnsToMatch.add(new ColumnInfo(colNameToRetrieve, "ANY"));
        getColumn(colNameToRetrieve).exists(1);
        final int rowsToComplete = getRowsToComplete(colNameToRetrieve);
        int startingRow = getColumn(columnsToMatch.get(0).getColumnName()).getColRow();
        if (searchCurrentScreenOnly) {
            return colValuesAsList(startingRow, rowsToComplete, colNameToRetrieve);
        } else {
            boolean atEndOfTable = false;
            boolean advanceToNextScreen = false;

            List<String> actualColumnVals = new ArrayList<>();
            goToFirstPage();
            do {
                actualColumnVals.addAll(colValuesAsList(startingRow, rowsToComplete, colNameToRetrieve));
                atEndOfTable = atEndOfTable();
                advanceToNextScreen = advanceToNextScreen(atEndOfTable);
            } while ((!atEndOfTable && advanceToNextScreen));
            return actualColumnVals;
        }
    }

    public String retrieveColumnVal(String colNameToRetrieve,
                                    String colNameToMatch1,
                                    String colValToMatch1,
                                    String colNameToMatch2,
                                    String colValToMatch2) throws GeneralLeanFtException {
        List<ColumnInfo> columnsToMatch = new ArrayList<>();

        columnsToMatch.add(new ColumnInfo(colNameToMatch1, colValToMatch1));
        columnsToMatch.add(new ColumnInfo(colNameToMatch2, colValToMatch2));
        columnsToMatch.add(new ColumnInfo(colNameToRetrieve, "ANY"));

        return searchTableForMatch(columnsToMatch, RETRIEVE, FIRST_MATCH);
    }

    public String retrieveColumnVal(String colNameToRetrieve,
                                    String colNameToMatch1,
                                    String colValToMatch1,
                                    String colNameToMatch2,
                                    String colValToMatch2,
                                    String colNameToMatch3,
                                    String colValToMatch3) throws GeneralLeanFtException {
        List<ColumnInfo> columnsToMatch = new ArrayList<>();

        columnsToMatch.add(new ColumnInfo(colNameToMatch1, colValToMatch1));
        columnsToMatch.add(new ColumnInfo(colNameToMatch2, colValToMatch2));
        columnsToMatch.add(new ColumnInfo(colNameToMatch3, colValToMatch3));
        columnsToMatch.add(new ColumnInfo(colNameToRetrieve, "ANY"));

        return searchTableForMatch(columnsToMatch, RETRIEVE, FIRST_MATCH);
    }

    public String retrieveColumnVal(String colNameToRetrieve,
                                    String colNameToMatch1,
                                    String colValToMatch1,
                                    String colNameToMatch2,
                                    String colValToMatch2,
                                    String colNameToMatch3,
                                    String colValToMatch3,
                                    String colNameToMatch4,
                                    String colValToMatch4) throws GeneralLeanFtException {
        List<ColumnInfo> columnsToMatch = new ArrayList<>();

        columnsToMatch.add(new ColumnInfo(colNameToMatch1, colValToMatch1));
        columnsToMatch.add(new ColumnInfo(colNameToMatch2, colValToMatch2));
        columnsToMatch.add(new ColumnInfo(colNameToMatch3, colValToMatch3));
        columnsToMatch.add(new ColumnInfo(colNameToMatch4, colValToMatch4));
        columnsToMatch.add(new ColumnInfo(colNameToRetrieve, "ANY"));

        return searchTableForMatch(columnsToMatch, RETRIEVE, FIRST_MATCH);
    }

    public String checkForMatchInTable(String firstColName, String firstValToMatch) throws GeneralLeanFtException {
        List<ColumnInfo> columnsToMatch = new ArrayList<>();

        columnsToMatch.add(new ColumnInfo(firstColName, firstValToMatch));

        return searchTableForMatch(columnsToMatch, COMPARE, FIRST_MATCH);
    }

    public String checkForMatchInTable(String firstColName, String firstValToMatch,
                                       String secondColName, String secondValToMatch) throws GeneralLeanFtException {
        List<ColumnInfo> columnsToMatch = new ArrayList<>();

        columnsToMatch.add(new ColumnInfo(firstColName, firstValToMatch));
        columnsToMatch.add(new ColumnInfo(secondColName, secondValToMatch));

        return searchTableForMatch(columnsToMatch, COMPARE, FIRST_MATCH);
    }

    public String checkForMatchInTable(String firstColName, String firstValToMatch,
                                       String secondColName, String secondValToMatch,
                                       String thirdColName, String thirdValToMatch) throws GeneralLeanFtException {
        List<ColumnInfo> columnsToMatch = new ArrayList<>();

        columnsToMatch.add(new ColumnInfo(firstColName, firstValToMatch));
        columnsToMatch.add(new ColumnInfo(secondColName, secondValToMatch));
        columnsToMatch.add(new ColumnInfo(thirdColName, thirdValToMatch));

        return searchTableForMatch(columnsToMatch, COMPARE, FIRST_MATCH);
    }

    public String checkForMatchInTable(String firstColName, String firstValToMatch,
                                       String secondColName, String secondValToMatch,
                                       String thirdColName, String thirdValToMatch,
                                       String fourthColName, String fourthValToMatch) throws GeneralLeanFtException {
        List<ColumnInfo> columnsToMatch = new ArrayList<>();

        columnsToMatch.add(new ColumnInfo(firstColName, firstValToMatch));
        columnsToMatch.add(new ColumnInfo(secondColName, secondValToMatch));
        columnsToMatch.add(new ColumnInfo(thirdColName, thirdValToMatch));
        columnsToMatch.add(new ColumnInfo(fourthColName, fourthValToMatch));

        return searchTableForMatch(columnsToMatch, COMPARE, FIRST_MATCH);

    }

    private String searchTableForMatch(List<ColumnInfo> columnsToMatch,
                                       String matchType,
                                       String tableSearchType) throws GeneralLeanFtException {

        int startingRow = getColumn(columnsToMatch.get(0).getColumnName()).getColRow();

        if (startingRow != NOT_FOUND) {
            if (searchCurrentScreenOnly) {
                List<ColumnInfo> actualColumnVals = searchCurrentScreenForMatch(columnsToMatch, matchType, startingRow);
                cleanActualColumnVals(actualColumnVals, columnsToMatch.size());
                return actualColumnVals.stream().map(ColumnInfo::getColumnValue).collect(Collectors.joining(" | "));
            } else {
                return searchAllScreensUntilMatchFound(startingRow, columnsToMatch, matchType, tableSearchType);
            }
        } else {
            return "";
        }
    }

    private String searchAllScreensUntilMatchFound(int startingRow,
                                                   List<ColumnInfo> columnsToMatch,
                                                   String matchType,
                                                   String tableSearchType) throws GeneralLeanFtException {
        boolean atEndOfTable = false;
        boolean foundMatch = false;
        boolean advanceToNextScreen = false;

        List<ColumnInfo> actualColumnVals;
        goToFirstPage();

        do {
            actualColumnVals = searchCurrentScreenForMatch(columnsToMatch, matchType, startingRow);

            foundMatch = !actualColumnVals.isEmpty();
            atEndOfTable = atEndOfTable();
            advanceToNextScreen = advanceToNextScreen(wasMatchFound(foundMatch, tableSearchType));
        } while (!atEndOfTable && !wasMatchFound(foundMatch, tableSearchType) && advanceToNextScreen);

        cleanActualColumnVals(actualColumnVals, columnsToMatch.size());

        return actualColumnVals.stream().map(ColumnInfo::getColumnValue).collect(Collectors.joining(" | "));
    }

    private void cleanActualColumnVals(List<ColumnInfo> actualColumnVals, int columnsToMatchSize) {
        if(!actualColumnVals.isEmpty() && actualColumnVals.size() > columnsToMatchSize) {
            log.info("Multiple rows found matching criteria. Returning first matching row.");
            actualColumnVals.subList(columnsToMatchSize, actualColumnVals.size()).clear();
        }

        if (columnsToMatchSize > 1) {
            //remove first item if multi-item compare. First item is key
            actualColumnVals.remove(0);
        }
    }

    private List<ColumnInfo> searchCurrentScreenForMatch(List<ColumnInfo> columnsToMatch,
                                                         String matchType,
                                                         int matchingRow) throws GeneralLeanFtException {

        List<ColumnInfo> tempColumnVals;
        List<ColumnInfo> actualColumnVals = new ArrayList<>();

        matchingRow = findMatchingRowNum(columnsToMatch.get(0).getColumnName(),
                                         columnsToMatch.get(0).getColumnValue(), matchingRow);

        while (matchingRow != NOT_FOUND) {
            tempColumnVals = getOtherColumnVals(columnsToMatch, matchingRow);

            if(doColumnsMatch(columnsToMatch, tempColumnVals, matchType)) {
                actualColumnVals.addAll(tempColumnVals);
            }

            tempColumnVals.clear();

            matchingRow = findMatchingRowNum(columnsToMatch.get(0).getColumnName(),
                                             columnsToMatch.get(0).getColumnValue(), matchingRow);
        }

        return actualColumnVals;
    }

    private boolean wasMatchFound(boolean foundMatch, String tableSearchType) {
        if (tableSearchType.equalsIgnoreCase(FIRST_MATCH)) {
            return foundMatch;
        } else if (tableSearchType.equalsIgnoreCase(ALL_MATCHES)) {
            return false;
        } else {
            return foundMatch;
        }
    }

    private boolean doColumnsMatch(List<ColumnInfo> columnsToMatch,
                                   List<ColumnInfo> actualColumnVals,
                                   String matchType) {

        switch (matchType.toUpperCase()) {
            case COMPARE:
                columnsToMatch.forEach(columnToMatchEntry -> {
                    if (columnToMatchEntry.getColumnValue().equalsIgnoreCase(BLANK)) {
                        columnToMatchEntry.setColumnValue("");
                    }else if  (columnToMatchEntry.getColumnValue().equalsIgnoreCase(UNDERSCORE)) {
                        columnToMatchEntry.setColumnValue("_");
                    }

                });
                return actualColumnVals.equals(columnsToMatch);
            case RETRIEVE:
                List<ColumnInfo> localColumnsToMatch = new ArrayList<>(columnsToMatch);
                List<ColumnInfo> localActuals = new ArrayList<>(actualColumnVals);

                localColumnsToMatch.remove(localColumnsToMatch.size() -  1);
                localActuals.remove(localActuals.size() - 1);

                //replace "ANY" with value found in the table
                localColumnsToMatch.forEach(columnToMatchEntry -> {
                    if (columnToMatchEntry.getColumnValue().matches("ANY|NON-BLANK|STRING")) {
                        columnToMatchEntry.setColumnValue(actualColumnVals.stream()
                                                                          .filter(actualColumnEntry -> actualColumnEntry.getColumnName()
                                                                                                                        .equalsIgnoreCase(columnToMatchEntry.getColumnName()))
                                                                          .collect(Collectors.toList())
                                                                          .get(0)
                                                                          .getColumnValue());
                    } else if (columnToMatchEntry.getColumnValue().equalsIgnoreCase(BLANK)) {
                        columnToMatchEntry.setColumnValue("");
                    }
                });
                return localActuals.equals(localColumnsToMatch);
            default:
                return false;
        }

    }

    private List<ColumnInfo> getOtherColumnVals(List<ColumnInfo> columnsToMatch, int matchingRow) throws GeneralLeanFtException {
        List<ColumnInfo> actualColumnVals = new ArrayList<>();

        if (!columnsToMatch.isEmpty()) {
            actualColumnVals.add(new ColumnInfo(columnsToMatch.get(0).getColumnName(),
                                                extractColumnValFromRow(getTableColumn(columnsToMatch.get(0).getColumnName()),
                                                                        matchingRow)));
        }

        if (columnsToMatch.size() > 1) {
            actualColumnVals.add(new ColumnInfo(columnsToMatch.get(1).getColumnName(),
                                                extractColumnValFromRow(getTableColumn(columnsToMatch.get(1).getColumnName()),
                                                                        matchingRow)));
        }

        if (columnsToMatch.size() > 2) {
            actualColumnVals.add(new ColumnInfo(columnsToMatch.get(2).getColumnName(),
                                                extractColumnValFromRow(getTableColumn(columnsToMatch.get(2).getColumnName()),
                                                                        matchingRow)));
        }

        if (columnsToMatch.size() > 3) {
            actualColumnVals.add(new ColumnInfo(columnsToMatch.get(3).getColumnName(),
                                                extractColumnValFromRow(getTableColumn(columnsToMatch.get(3).getColumnName()),
                                                                        matchingRow)));
        }

        return actualColumnVals;
    }

    private LeanFTTableColumn getTableColumn(String tableColumnName) {
        if (tableColumns.get(tableColumnName) != null) {
            return tableColumns.get(tableColumnName);
        } else {
            throw new IllegalArgumentException(String.format("The '%s' column was not found. Please check the object maps for the column names", tableColumnName));
        }
    }

    public void enterInFirstBlankRow(String valToEnter, String columnName) throws GeneralLeanFtException {
        List<ColumnInfo> columnsToMatch = new ArrayList<>();

        //advance table to the right page
        columnsToMatch.add(new ColumnInfo(columnName, BLANK));
        searchTableForMatch(columnsToMatch, COMPARE, FIRST_MATCH);

        int matchingRow = findMatchingRowNum(columnsToMatch.get(0).getColumnName(),
                                             columnsToMatch.get(0).getColumnValue(),
                                             getColumn(columnsToMatch.get(0).getColumnName()).getColRow());

        if (matchingRow != NOT_FOUND) {
            LeanFTField currentRowField = new LeanFTField(parentScreen,
                                                          getTableColumn(columnsToMatch.get(0).getColumnName()).getLogicalColStartNum(),
                                                          matchingRow);
            currentRowField.setText(valToEnter);
        }
    }

    public void enterTextInMatchingCell(String valToEnter,
                                        String columnName,
                                        String keyColumnName,
                                        String valToMatch,
                                        String columnValue) throws GeneralLeanFtException {
        List<ColumnInfo> columnsToMatch = new ArrayList<>();

        //advance table to the right page
        columnsToMatch.add(new ColumnInfo(keyColumnName, valToMatch));
        columnsToMatch.add(new ColumnInfo(columnName, columnValue));
        searchTableForMatch(columnsToMatch, COMPARE, FIRST_MATCH);

        int matchingRow = findMatchingRowNum(columnsToMatch.get(0).getColumnName(),
                                             columnsToMatch.get(0).getColumnValue(),
                                             getColumn(columnsToMatch.get(0).getColumnName()).getColRow());

        if (matchingRow != NOT_FOUND) {
            LeanFTField currentRowField = new LeanFTField(parentScreen,
                                                          getTableColumn(columnsToMatch.get(1).getColumnName()).getLogicalColStartNum(),
                                                          matchingRow);
            currentRowField.setText(valToEnter);
        }
    }

    private void pressKeyboardKey(Keyboard.Keys keyToPress) throws GeneralLeanFtException {
        if (DesktopContext.getInstance().runOnGrid()) {
            DesktopContext.getInstance()
                     .getEnv()
                     .getKeyboard()
                     .pressKey(keyToPress);
        } else {
            Keyboard.pressKey(keyToPress);
        }
    }

    public void setCursorInMatchingCell(String colToRetrive,
                                        String colToMatch,
                                        String valToMatch,
                                        String columnValue) throws GeneralLeanFtException {
        List<ColumnInfo> columnsToMatch = new ArrayList<>();

        columnsToMatch.add(new ColumnInfo(colToMatch, valToMatch));
        columnsToMatch.add(new ColumnInfo(colToRetrive, columnValue));
        searchTableForMatch(columnsToMatch, COMPARE, FIRST_MATCH);

        int matchingRow = findMatchingRowNum(columnsToMatch.get(0).getColumnName(),
                columnsToMatch.get(0).getColumnValue(),
                getColumn(columnsToMatch.get(0).getColumnName()).getColRow());

        if (matchingRow != NOT_FOUND) {
            LeanFTField currentRowField = new LeanFTField(parentScreen,
                    getTableColumn(columnsToMatch.get(1).getColumnName()).getLogicalColStartNum(),
                    matchingRow);
            currentRowField.setCursor();
        }
    }

    protected List<String> colValuesAsList(int startingRow, int rowsToComplete, String colNameToRetrieve) throws GeneralLeanFtException {
        List<String> columnValues = new ArrayList<>();
        for (int i = startingRow + 1; i < rowsToComplete; i++) {
            String textInColumn = null;
            textInColumn = extractColumnValFromRow(getTableColumn(colNameToRetrieve), i);
            if (textInColumn != null) {
                columnValues.add(textInColumn);
            }
        }
        return columnValues;
    }

    protected List<String> colValuesAsList(int startingRow, int rowsToComplete, String colNameToMatch, String colValToMatch) throws GeneralLeanFtException {
        List<String> columnValues = new ArrayList<>();
        for (int i = startingRow + 1; i < rowsToComplete; i++) {
            String textInColumn = extractColumnValFromRow(getTableColumn(colNameToMatch), i);
            if (textInColumn != null && textInColumn.equals(colValToMatch)) {
                columnValues.add(textInColumn);
            }
            LeanFTField currentRow;
            currentRow = new LeanFTField(parentScreen, tableColStartNum, i);
            String fullRowText = currentRow.getText();
            if (fullRowText.contains("End of File")) {
                break;
            }

        }
        return columnValues;
    }

    public void setCursorInMatchingCell(String colToRetrive,
                                        String colToMatch1,
                                        String valToMatch1,
                                        String colToMatch2,
                                        String valToMatch2,
                                        String columnValue) throws GeneralLeanFtException {
        List<ColumnInfo> columnsToMatch = new ArrayList<>();

        columnsToMatch.add(new ColumnInfo(colToMatch1, valToMatch1));
        columnsToMatch.add(new ColumnInfo(colToMatch2, valToMatch2));
        columnsToMatch.add(new ColumnInfo(colToRetrive, columnValue));
        searchTableForMatch(columnsToMatch, COMPARE, FIRST_MATCH);

        int matchingRow = findMatchingRowNum(columnsToMatch.get(0).getColumnName(),
                columnsToMatch.get(0).getColumnValue(),
                getColumn(columnsToMatch.get(0).getColumnName()).getColRow());

        if (matchingRow != NOT_FOUND) {
            LeanFTField currentRowField = new LeanFTField(parentScreen,
                    getTableColumn(columnsToMatch.get(2).getColumnName()).getLogicalColStartNum(),
                    matchingRow);
            currentRowField.setCursor();
        }
    }

}