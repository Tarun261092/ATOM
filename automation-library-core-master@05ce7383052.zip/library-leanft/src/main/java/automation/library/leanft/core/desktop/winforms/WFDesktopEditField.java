package automation.library.leanft.core.desktop.winforms;

import automation.library.leanft.core.Constants;
import automation.library.leanft.core.desktop.DesktopEditField;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.Keyboard;
import com.hp.lft.sdk.winforms.EditField;
import com.hp.lft.sdk.winforms.EditFieldDescription;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import static com.hp.lft.sdk.WaitUntilTestObjectState.waitUntil;

public class WFDesktopEditField extends DesktopEditField {

    private EditField object;
    private WFDesktopWindow parentWindow;
    private String objectName;

    protected final Logger log = LogManager.getLogger(this.getClass().getName());

    public WFDesktopEditField(String windowObjectName, String fullType, String objectName) throws GeneralLeanFtException {
        this.parentWindow = new WFDesktopWindow(windowObjectName, fullType);
        this.objectName = objectName;
        this.object = parentWindow.getWindow().describe(EditField.class, new EditFieldDescription.Builder()
                .objectName(objectName).build());

    }

    public WFDesktopEditField(WFDesktopWindow parentWindow, String objectName) throws GeneralLeanFtException {
        this.parentWindow = parentWindow;
        this.objectName = objectName;
        this.object = parentWindow.getWindow().describe(EditField.class, new EditFieldDescription.Builder()
                .objectName(objectName).build());

    }

    public WFDesktopEditField(String windowObjectName, String windowFullType, String fullType, int index) throws GeneralLeanFtException {
        this.parentWindow = new WFDesktopWindow(windowObjectName, windowFullType);
        this.object = parentWindow.getWindow().describe(EditField.class, new EditFieldDescription.Builder()
                .fullType(fullType)
                .index(index).build());
    }

    public WFDesktopEditField(String windowObjectName, String windowFullType, String objectName, String fullNamePath) throws GeneralLeanFtException {
        this.parentWindow = new WFDesktopWindow(windowObjectName, windowFullType);
        this.object = parentWindow.getWindow().describe(EditField.class, new EditFieldDescription.Builder()
                .objectName(objectName)
                .fullNamePath(fullNamePath).build());
    }
    public WFDesktopEditField(WFDesktopWindow parentWindow, String fullType, String objectName) throws GeneralLeanFtException {
        this.parentWindow = parentWindow;
        this.objectName = objectName;
        this.object = parentWindow.getWindow().describe(EditField.class, new EditFieldDescription.Builder()
                .fullType(fullType)
                .objectName(objectName).build());
    }

    public WFDesktopEditField(WFDesktopWindow parentWindow, String fullType, int index) throws GeneralLeanFtException {
        this.parentWindow = parentWindow;
        this.object = parentWindow.getWindow().describe(EditField.class, new EditFieldDescription.Builder()
                .fullType(fullType)
                .index(index).build());
    }

    public EditField getEditField() {
        return this.object;
    }

    /**
     * @param text
     * @param retries
     * @return
     * @throws GeneralLeanFtException
     */
    public DesktopEditField setText(String text, int... retries) throws GeneralLeanFtException {
        try {
            this.getEditField().setText(text);
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.setText(text, 0);
            } else {
                throw e;
            }
        }
        return this;
    }

    /**
     * searches again for the field using the by
     */
    public WFDesktopEditField refind(int... retries) {
        log.info("Attempting to refind the field: {}", objectName);
        int attempts = 0;
        boolean retry = true;
        int maxRetry = retries.length > 0 ? retries[0] : getFindRetries();
        while (attempts < maxRetry && retry) {
            try {
                log.debug("retry number {}", attempts);
                waitUntil(this.getEditField(), testObject -> getEditField().exists());
                this.getEditField().getObjectName();
                retry = false;
            } catch (Exception e) {
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e1) {
                    log.debug(e1.getMessage());
                    Thread.currentThread().interrupt();
                }
            }
            attempts++;
        }
        return this;
    }

    /**
     * @param retries
     * @return
     * @throws GeneralLeanFtException
     */
    public WFDesktopEditField exists(int... retries) throws GeneralLeanFtException {
        try {
            waitUntil(this.object, testObject -> object.exists());
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                return this.exists(0);
            } else {
                throw e;
            }
        }
        return this;
    }

    /**
     * @param retries
     * @return
     * @throws GeneralLeanFtException
     */
    public String getText(int... retries) throws GeneralLeanFtException {
        String str = null;
        try {
            str = this.object.getText();
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                return this.getText(0);
            } else {
                throw e;
            }
        }
        return str;
    }

    public static int getFindRetries() {
        final int defaultFindRetries = 10;
        int refind;
        try {
            refind = Integer.parseInt(System.getProperty(Constants.DEFAULT_RETRIES));
        } catch (Exception e) {
            refind = defaultFindRetries;
        }
        return refind;
    }

    /**
     * @param retries
     * @return
     * @throws GeneralLeanFtException
     */
    public boolean isEnabled(int... retries) throws GeneralLeanFtException {
        boolean status = false;
        try {
            status= this.getEditField().isEnabled();
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.isEnabled(0);
            } else {
                throw e;
            }
        }
        return status;
    }

    @Override
    public DesktopEditField click(int... retries) throws GeneralLeanFtException {
        return null;
    }
    
    @Override
    public DesktopEditField setString(String text, int... retries) throws GeneralLeanFtException {
    	try {
    	this.getEditField().click();
    	try{Thread.sleep(500);}catch(Exception e) {}
    	Keyboard.sendString(text);
    	try{Thread.sleep(500);}catch(Exception e) {}
    	Keyboard.pressKey(Keyboard.Keys.TAB);
    }catch(Exception e)
    {
    	if (!(retries.length > 0 && retries[0] == 0)) {
            this.refind(retries);
            this.setString(text, 0);
        }
    	else {
            throw e;
        }
    }
    	
    	return this;
    	
    }

}
