package automation.library.leanft.core.desktop.winforms;

import automation.library.leanft.core.Constants;
import automation.library.leanft.core.desktop.DesktopListView;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.winforms.ListView;
import com.hp.lft.sdk.winforms.ListViewDescription;
import com.hp.lft.sdk.winforms.ListViewItem;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import static com.hp.lft.sdk.WaitUntilTestObjectState.waitUntil;

import java.util.List;

public class WFDesktopListView extends DesktopListView {

        private ListView object;
        private WFDesktopWindow parentWindow;
        private String objectName;

        protected final Logger log = LogManager.getLogger(this.getClass().getName());

        public WFDesktopListView(String windowObjectName, String fulltype, String objectName) throws GeneralLeanFtException {
            this.parentWindow = new WFDesktopWindow(windowObjectName, fulltype);
            this.objectName=objectName;
            this.object = parentWindow.getWindow().describe(ListView.class, new ListViewDescription.Builder()
                    .objectName(objectName).build());

        }
        public WFDesktopListView(WFDesktopWindow window, String objectName) throws GeneralLeanFtException {
            this.parentWindow = window;
            this.objectName=objectName;
            this.object = parentWindow.getWindow().describe(ListView.class, new ListViewDescription.Builder()
                    .objectName(objectName).build());

        }
        public ListView getDesktopListView() {
            return this.object;
        }

    @Override
    public String getText(int... retries) throws GeneralLeanFtException {
        String str = null;
        try {
            if(this.getDesktopListView().getText().equals(""))  str = this.getDesktopListView().getVisibleText();
            else {
                str = this.getDesktopListView().getText();
            }
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.getText(0);
            } else {
                throw e;
            }
        }
        return str;
    }


    @Override
        public DesktopListView select(String value, int... retries) throws GeneralLeanFtException {
            try {
                this.getDesktopListView().select(value);
            } catch (Exception e) {
                if (!(retries.length > 0 && retries[0] == 0)) {
                    this.refind(retries);
                    this.select(value,0);
                } else {
                    throw e;
                }
            }
            return this;
        }

    @Override
    public DesktopListView selectByIndex(int value, int... retries) throws GeneralLeanFtException {
        try {
            this.getDesktopListView().select(value);
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.selectByIndex(value, 0);
            } else {
                throw e;
            }
        }
        return this;
    }
    
    public DesktopListView doubleClick(String value, int... retries) throws GeneralLeanFtException {
        try {
            this.getDesktopListView().doubleClick();
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.doubleClick(value,0);
            } else {
                throw e;
            }
        }
        return this;
    }
    
    public DesktopListView activateItem(String value, int... retries) throws GeneralLeanFtException {
        try {
        	this.getDesktopListView().activateItem(value);
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.activateItem(value,0);
            } else {
                throw e;
            }
        }
        return this;
    }

    @Override
    public DesktopListView selectColRow(String colDesc,String rowVal, int... retries) throws GeneralLeanFtException {
            int matchCol = 0;
        try {
            for(int i = 1; i < this.getDesktopListView().getVisibleColumnsCount(); i++){
                if(this.getDesktopListView().getColumnHeader(i).equalsIgnoreCase(colDesc)) {
                    matchCol =i;
                }else{
                    log.error("Matching Column not present");
                }
            }
            for(int j = 0; j < this.getDesktopListView().getItems().size(); j++){
                    if(this.getDesktopListView().getItems().get(j).getSubItemText(matchCol).equalsIgnoreCase(rowVal)){
                        this.getDesktopListView().select(j);
            }else{
                log.error("Matching Row Value not present");
            }
                }
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.selectColRow(colDesc,rowVal,0);
            } else {
                throw e;
            }
        }
        return this;
    }


        public WFDesktopListView refind(int... retries) {
            log.info("Attempting to refind the field: {}", objectName);
            int attempts = 0;
            boolean retry = true;
            int maxRetry = retries.length > 0 ? retries[0] : getFindRetries();
            while (attempts < maxRetry && retry) {
                try {
                    log.debug("retry number {}", attempts);
                    waitUntil(this.getDesktopListView(), testObject -> getDesktopListView().exists());
                    this.getDesktopListView().getObjectName();
                    retry = false;
                } catch (Exception e) {
                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException e1) {
                        log.debug(e1.getMessage());
                        Thread.currentThread().interrupt();
                    }
                }
                attempts++;
            }
            return this;
        }
        public static int getFindRetries() {
            final int defaultFindRetries = 10;
            int refind;
            try {
                refind = Integer.parseInt(System.getProperty(Constants.DEFAULT_RETRIES));
            } catch (Exception e) {
                refind = defaultFindRetries;
            }
            return refind;
        }

        /**
         * @param retries
         * @return
         * @throws GeneralLeanFtException
         */
        public WFDesktopListView exists(int... retries) throws GeneralLeanFtException {
            try {
                waitUntil(this.object, testObject -> object.exists());
            } catch (Exception e) {
                if (!(retries.length > 0 && retries[0] == 0)) {
                    this.refind(retries);
                    return this.exists(0);
                } else {
                    throw e;
                }
            }
            return this;
        }

    /**
     * @param retries
     * @return
     * @throws GeneralLeanFtException
     */
    public boolean isEnabled(int... retries) throws GeneralLeanFtException {
        boolean status = false;
        try {
            status= this.getDesktopListView().isEnabled();
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.isEnabled(0);
            } else {
                throw e;
            }
        }
        return status;
    }
    
    public boolean isEmpty(int... retries) throws GeneralLeanFtException {
    	boolean status = false;
        try {
           String text  = this.getDesktopListView().getText();
        	 List<ListViewItem> str= this.getDesktopListView().getItems();
        	 if(str.size() == 0 && text.isEmpty()) 
        	 {
        		status = true; 
        	 }else {
        		 status = false;
        	 }
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.isEmpty(0);
            } else {
                throw e;
            }
        }
        return status;
    }
}
