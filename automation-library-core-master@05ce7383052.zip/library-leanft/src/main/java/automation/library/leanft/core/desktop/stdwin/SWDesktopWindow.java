package automation.library.leanft.core.desktop.stdwin;

import automation.library.leanft.core.desktop.DesktopWindow;
import automation.library.leanft.exec.DesktopContext;
import com.hp.lft.sdk.Desktop;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.KeyModifier;
import com.hp.lft.sdk.insight.InsightDescription;
import com.hp.lft.sdk.insight.InsightObject;
import com.hp.lft.sdk.stdwin.Window;
import com.hp.lft.sdk.stdwin.WindowDescription;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.imageio.ImageIO;
import java.awt.image.RenderedImage;
import java.io.File;
import java.io.IOException;
import java.util.EnumSet;

public class SWDesktopWindow extends DesktopWindow {

    private Window window;

    protected final Logger log = LogManager.getLogger(this.getClass().getName());

    public SWDesktopWindow(String windowClassRegExp, String windowTitleRegExp) throws GeneralLeanFtException {
        if (DesktopContext.getInstance().runOnGrid()) {
            this.window = DesktopContext.getInstance()
                    .getEnv()
                    .describe(Window.class, new WindowDescription.Builder()
                            .childWindow(false)
                            .ownedWindow(false)
                            .windowClassRegExp(windowClassRegExp)
                            .windowTitleRegExp(windowTitleRegExp).build());
        } else {
            this.window = Desktop.describe(Window.class, new WindowDescription.Builder()
                    .childWindow(false)
                    .ownedWindow(false)
                    .windowClassRegExp(windowClassRegExp)
                    .windowTitleRegExp(windowTitleRegExp).build());
        }
    }

    public SWDesktopWindow(String windowClassRegExp, String windowTitleRegExp, boolean childWindow, boolean ownedWindow) throws GeneralLeanFtException {
        if (DesktopContext.getInstance().runOnGrid()) {
            this.window = DesktopContext.getInstance()
                                        .getEnv()
                                        .describe(Window.class, new WindowDescription.Builder()
                                                .childWindow(childWindow)
                                                .ownedWindow(ownedWindow)
                                                .windowClassRegExp(windowClassRegExp)
                                                .windowTitleRegExp(windowTitleRegExp).build());
        } else {
            this.window = Desktop.describe(Window.class, new WindowDescription.Builder()
                    .childWindow(childWindow)
                    .ownedWindow(ownedWindow)
                    .windowClassRegExp(windowClassRegExp)
                    .windowTitleRegExp(windowTitleRegExp).build());
        }
    }

    public SWDesktopWindow(String windowClassRegExp, String text,int index) throws GeneralLeanFtException {
        if (DesktopContext.getInstance().runOnGrid()) {
            this.window = DesktopContext.getInstance()
                    .getEnv()
                    .describe(Window.class, new WindowDescription.Builder()
                            .childWindow(false)
                            .ownedWindow(false)
                            .index(index)
                            .windowClassRegExp(windowClassRegExp)
                            .text(text).build());
        } else {
            this.window = Desktop.describe(Window.class, new WindowDescription.Builder()
                    .childWindow(false)
                    .ownedWindow(false)
                    .index(index)
                    .windowClassRegExp(windowClassRegExp)
                    .text(text).build());
        }
    }

    public Window getWindow() {
        return this.window;
    }
    
    @Override
    public SWDesktopWindow sendKeys(String keys, String modifierKey, int... retries) throws GeneralLeanFtException {
        try {
            EnumSet<KeyModifier> modifier = EnumSet.of(KeyModifier.valueOf(modifierKey));
            this.getWindow().sendKeys(keys, modifier);
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.sendKeys(keys, modifierKey, 0);
            } else {
                throw e;
            }
        }
        return this;
    }
    
    
    @Override
    public SWDesktopWindow sendKeys(String keys, int... retries) throws GeneralLeanFtException {
        try {
            this.getWindow().sendKeys(keys);
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.sendKeys(keys,  0);
            } else {
                throw e;
            }
        }
        return this;
    }

    public void clickImage(String imagePath, int... retries) throws GeneralLeanFtException, IOException {
        File imgFile = new File(imagePath);
        RenderedImage imageF = null;
        try {
            imageF = ImageIO.read(imgFile);
            InsightObject imageObject = this.getWindow().describe(InsightObject.class, new InsightDescription(imageF));
            imageObject.click();
        } catch (Exception e){
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.getWindow().describe(InsightObject.class, new InsightDescription(imageF)).click();
            } else {
                throw e;
            }
        }
    }


}
