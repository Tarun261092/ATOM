package automation.library.leanft.core.desktop.stdwin;

import automation.library.leanft.core.desktop.DesktopComboBox;
import com.hp.lft.sdk.GeneralLeanFtException;

import java.util.List;

public class SWDesktopComboBox extends DesktopComboBox {
    @Override
    public DesktopComboBox select(String name, int... retries) throws GeneralLeanFtException {
        return null;
    }

    @Override
    public DesktopComboBox select(int name, int... retries) throws GeneralLeanFtException {
        return null;
    }

    @Override
    public String getSelectedItem(int... retries) throws GeneralLeanFtException {
        return null;
    }


    @Override
    public DesktopComboBox exists(int... retries) throws GeneralLeanFtException {
        return null;
    }

    @Override
    public DesktopComboBox click(int... a) throws GeneralLeanFtException {
        return null;
    }

    @Override
    public boolean isEnabled(int... retries) throws GeneralLeanFtException {
        return false;
    }

    @Override
    public List<String> getComboboxValue(int... retries) throws GeneralLeanFtException {
        return null;
    }
}
