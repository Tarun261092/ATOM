package automation.library.leanft.core.desktop.winforms;

import automation.library.leanft.core.Constants;
import automation.library.leanft.core.desktop.DesktopCheckbox;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.winforms.CheckBox;
import com.hp.lft.sdk.winforms.CheckBoxDescription;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import static com.hp.lft.sdk.WaitUntilTestObjectState.waitUntil;

public class WFDesktopCheckbox extends DesktopCheckbox {

    private WFDesktopWindow parentWindow;
    private CheckBox checkBox;
    private String objectName;

    protected final Logger log = LogManager.getLogger(this.getClass().getName());

    public WFDesktopCheckbox(String windowObjectName, String windowTitleExp, String fullType, String objectName) throws GeneralLeanFtException {
        this.parentWindow = new WFDesktopWindow(windowObjectName, windowTitleExp, fullType);
        this.objectName = objectName;
        this.checkBox = parentWindow.getWindow().describe(CheckBox.class, new CheckBoxDescription.Builder()
                .objectName(objectName).build());
    }

    public WFDesktopCheckbox(WFDesktopWindow wfDesktopWindow, String objectName) throws GeneralLeanFtException {
        this.parentWindow = wfDesktopWindow;
        this.objectName = objectName;
        this.checkBox = parentWindow.getWindow().describe(CheckBox.class, new CheckBoxDescription.Builder()
                .objectName(objectName).build());
    }

    public CheckBox getDesktopCheckbox() {
        return this.checkBox;
    }

    /**
     * @param retries
     * @return
     * @throws GeneralLeanFtException
     */
    public DesktopCheckbox click(int... retries) throws GeneralLeanFtException {
        try {
            this.getDesktopCheckbox().click();
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.click(0);
            } else {
                throw e;
            }
        }
        return this;
    }

    /**
     * searches again for the field using the by
     */
    public WFDesktopCheckbox refind(int... retries) {
        log.info("Attempting to refind the field: {}", objectName);
        int attempts = 0;
        boolean retry = true;
        int maxRetry = retries.length > 0 ? retries[0] : getFindRetries();
        while (attempts < maxRetry && retry) {
            try {
                log.debug("retry number {}", attempts);
                waitUntil(this.getDesktopCheckbox(), testObject -> getDesktopCheckbox().exists());
                this.getDesktopCheckbox().getObjectName();
                retry = false;
            } catch (Exception e) {
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e1) {
                    log.debug(e1.getMessage());
                    Thread.currentThread().interrupt();
                }
            }
            attempts++;
        }
        return this;
    }

    public static int getFindRetries() {
        final int defaultFindRetries = 10;
        int refind;
        try {
            refind = Integer.parseInt(System.getProperty(Constants.DEFAULT_RETRIES));
        } catch (Exception e) {
            refind = defaultFindRetries;
        }
        return refind;
    }

    /**
     * @param retries
     * @return
     * @throws GeneralLeanFtException
     */
    public WFDesktopCheckbox exists(int... retries) throws GeneralLeanFtException {
        try {
            waitUntil(this.checkBox, testObject -> checkBox.exists());
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                return this.exists(0);
            } else {
                throw e;
            }
        }
        return this;
    }

    /**
     * @param retries
     * @return
     * @throws GeneralLeanFtException
     */
    public boolean isEnabled(int... retries) throws GeneralLeanFtException {
        boolean status = false;
        try {
            status = this.getDesktopCheckbox().isEnabled();
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.isEnabled(0);
            } else {
                throw e;
            }
        }
        return status;
    }

    /**
     * @param retries
     * @return
     * @throws GeneralLeanFtException
     */
    public boolean isChecked(int... retries) throws GeneralLeanFtException {
        boolean status = false;
        try {
            status = this.getDesktopCheckbox().isChecked();
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.isChecked(0);
            } else {
                throw e;
            }
        }
        return status;
    }
}
