package automation.library.leanft.core.desktop;

import com.hp.lft.sdk.GeneralLeanFtException;

public abstract class DesktopTable extends DesktopObject {

    public abstract DesktopTable click(int...a) throws GeneralLeanFtException;
    public abstract String getCellText(int row,int col,int...a) throws GeneralLeanFtException;
    public abstract String selectMatchingRow(int secondColumn,int firstColumn,String firstRow, int... retries) throws GeneralLeanFtException;
    public abstract DesktopTable exists(int... retries) throws GeneralLeanFtException;
    public abstract boolean isEnabled(int... retries) throws GeneralLeanFtException;
    public abstract DesktopTable clickCell(int row,int col,int...a) throws GeneralLeanFtException;



}
