package automation.library.leanft.core.desktop.stdwin;

import automation.library.leanft.core.Constants;
import automation.library.leanft.core.desktop.DesktopUiObject;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.stdwin.UiObject;
import com.hp.lft.sdk.stdwin.UiObjectDescription;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import static com.hp.lft.sdk.WaitUntilTestObjectState.waitUntil;

public class SWDesktopUIObject extends DesktopUiObject {


    private UiObject object;
    private SWDesktopWindow parentWindow;
    private String accessibleName;

    protected final Logger log = LogManager.getLogger(this.getClass().getName());

    public SWDesktopUIObject(String windowClassRegExp, String windowTitleRegExp, String windowClassRegExpObj, String accessibleName) throws GeneralLeanFtException {
        this.parentWindow = new SWDesktopWindow(windowClassRegExp,windowTitleRegExp);
        this.accessibleName=accessibleName;
        this.object = parentWindow.getWindow().describe(UiObject.class, new UiObjectDescription.Builder()
                .accessibleName(accessibleName).windowClassRegExp(windowClassRegExpObj).build());

    }

    public SWDesktopUIObject(String windowClassRegExp, String windowTitleRegExp, String windowClassRegExpObj, String windowTitleRegExpObj, String text) throws GeneralLeanFtException {
        this.parentWindow = new SWDesktopWindow(windowClassRegExp,windowTitleRegExp);
        this.object = parentWindow.getWindow().describe(UiObject.class, new UiObjectDescription.Builder()
                .windowClassRegExp(windowClassRegExpObj)
                .windowTitleRegExp(windowTitleRegExpObj)
                .text(text).build());

    }

    public UiObject getUiObject() {
        return this.object;
    }

    public DesktopUiObject sendKeys(String text, int... retries) throws GeneralLeanFtException {
        try {
            this.getUiObject().sendKeys(text);
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.sendKeys(text, 0);
            } else {
                throw e;
            }
        }
        return null;
    }

    public DesktopUiObject click(int... retries) throws GeneralLeanFtException {
        try {
            this.getUiObject().click();
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.click(0);
            } else {
                throw e;
            }
        }
        return this;
    }
    /**
     * searches again for the field using the by
     */
    public SWDesktopUIObject refind(int... retries) {
        log.info("Attempting to refind the field: {}", accessibleName);
        int attempts = 0;
        boolean retry = true;
        int maxRetry = retries.length > 0 ? retries[0] : getFindRetries();
        while (attempts < maxRetry && retry) {
            try {
                log.debug("retry number {}", attempts);
                waitUntil(this.getUiObject(), testObject -> getUiObject().exists());
                this.getUiObject().getAccessibleName();
                retry = false;
            } catch (Exception e) {
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e1) {
                    log.debug(e1.getMessage());
                    Thread.currentThread().interrupt();
                }
            }
            attempts++;
        }
        return this;
    }
    public static int getFindRetries() {
        final int defaultFindRetries = 10;
        int refind;
        try {
            refind = Integer.parseInt(System.getProperty(Constants.DEFAULT_RETRIES));
        } catch (Exception e) {
            refind = defaultFindRetries;
        }
        return refind;
    }

    /**
     * @param retries
     * @return
     * @throws GeneralLeanFtException
     */
    public SWDesktopUIObject exists(int... retries) throws GeneralLeanFtException {
        try {
            waitUntil(this.object, testObject -> object.exists());
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                return this.exists(0);
            } else {
                throw e;
            }
        }
        return this;
    }

    /**
     * @param retries
     * @return
     * @throws GeneralLeanFtException
     */
    public boolean isEnabled(int... retries) throws GeneralLeanFtException {
        boolean status = false;
        try {
            status= this.getUiObject().isEnabled();
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.isEnabled(0);
            } else {
                throw e;
            }
        }
        return status;
    }
}
