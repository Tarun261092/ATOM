package automation.library.leanft.core.desktop.web;

import automation.library.common.Property;
import automation.library.leanft.core.Constants;
import automation.library.leanft.core.desktop.DesktopImage;
import automation.library.leanft.core.desktop.DesktopObject;
import automation.library.leanft.core.desktop.stdwin.SWDesktopWindow;
import automation.library.leanft.core.desktop.winforms.WFDesktopWindow;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.web.*;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import static com.hp.lft.sdk.WaitUntilTestObjectState.waitUntil;

public class DesktopWebImage extends DesktopImage {
    private DesktopWebPageEmbedded desktopWebPage;
    private Image image;
    private String locatorText;
    private WebDesktopBrowserWindow parentWindow;
    private DesktopWebFrame desktopWebFrame;

    protected final Logger log = LogManager.getLogger(this.getClass().getName());
    
    

    public DesktopWebImage() {
	}

	public DesktopWebImage(WFDesktopWindow parentWindow,
                                String locatorText,
                                LocatorType locatorType) throws GeneralLeanFtException {
        this.desktopWebPage = new DesktopWebPageEmbedded(parentWindow);
        this.locatorText = locatorText;
        this.image = desktopWebPage.getEmbeddedPage()
                .describe(Image.class,
                        getLocatorObject(locatorText, locatorType));
    }

    public DesktopWebImage(SWDesktopWindow parentWindow,
                           String locatorText,
                           LocatorType locatorType) throws GeneralLeanFtException {
        this.desktopWebPage = new DesktopWebPageEmbedded(parentWindow);
        this.locatorText = locatorText;
        this.image = desktopWebPage.getEmbeddedPage()
                .describe(Image.class,
                        getLocatorObject(locatorText, locatorType));
    }

    public DesktopWebImage(String title, String browserType, String name,String xpath) throws GeneralLeanFtException {
        this.parentWindow = new WebDesktopBrowserWindow(title, browserType);
        this.image = parentWindow.getWindow().describe(Image.class, new ImageDescription.Builder()
                .name(name).xpath(xpath).build());
    }

    public DesktopWebImage(WebDesktopBrowserWindow window, String locatorText,LocatorType locatorType) throws GeneralLeanFtException {
        this.parentWindow = window;
        this.image = parentWindow.getWindow().
                describe(Image.class,getLocatorObject(locatorText, locatorType));
    }

    public DesktopWebImage(DesktopWebPageEmbedded desktopWebPage, String locatorText, LocatorType locatorType) throws GeneralLeanFtException {
        this.desktopWebPage = desktopWebPage;
        this.image = desktopWebPage.getEmbeddedPage().
                describe(Image.class, getLocatorObject(locatorText, locatorType));
    }

    public DesktopWebImage(DesktopWebFrame desktopWebFrame, String locatorText, LocatorType locatorType) throws GeneralLeanFtException {
        this.desktopWebFrame = desktopWebFrame;
        this.image = desktopWebFrame.getFrame().describe(Image.class, getLocatorObject(locatorText, locatorType));
    }
    
    public WebElement checkVisiblityOfImageInFrame(String title, String browserType, String frameName, String xpath)
			throws GeneralLeanFtException {
		String numberOfRetries = "";
		int count = 1;
		locatorText = xpath;
		boolean visible = false;
		numberOfRetries = Property.getProperty(Constants.LEANFTRUNTIMEPATH, "defaultWait");
		if(numberOfRetries==null || numberOfRetries.equals("0")) {
			numberOfRetries = "40";
		}
		log.info("Trying to find the element with LocaterText: {}", locatorText);
		while(count<Integer.parseInt(numberOfRetries))
		{
			try {
				this.parentWindow = new WebDesktopBrowserWindow(title, browserType);
				 this.image = parentWindow.getWindow().
			                describe(Frame.class, new FrameDescription.Builder()
			               .name(frameName).build()).
			                describe(Image.class,new ImageDescription.Builder().xpath(xpath).build());
				waitUntil(this.getImage(), testObject -> getImage().exists());
	            this.getImage().getId();
				visible = true;
				log.info("Element Located successfully with LocaterText: {}", locatorText);			
			
			} catch (Exception e) {
				try {
					Thread.sleep(1000);
					count = count + 1;
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
				
			}
			if(visible == true) {
				log.info("The element was found in "+count+" attempts");
				break;
			}
		}		
		if(visible==false)
		{
			log.info("Unable to find the element with LocaterText: {}", locatorText);
		}
		return this.image;
		
	}
    
    public WebElement checkVisiblityOfImage(String title, String browserType, String xpath)
			throws GeneralLeanFtException {
		String numberOfRetries = "";
		int count = 1;
		locatorText = xpath;
		boolean visible = false;
		numberOfRetries = Property.getProperty(Constants.LEANFTRUNTIMEPATH, "defaultWait");
		if(numberOfRetries==null || numberOfRetries.equals("0")) {
			numberOfRetries = "40";
		}
		log.info("Trying to find the element with LocaterText: {}", locatorText);
		while(count<Integer.parseInt(numberOfRetries))
		{
			try {
				this.parentWindow = new WebDesktopBrowserWindow(title, browserType);
				this.image = this.parentWindow.getWindow().describe(Image.class,new ImageDescription.Builder().xpath(xpath).build());
				waitUntil(this.getImage(), testObject -> getImage().exists());
                this.getImage().getId();
				visible = true;
				log.info("Element Located successfully with LocaterText: {}", locatorText);			
			
			} catch (Exception e) {
				try {
					Thread.sleep(1000);
					count = count + 1;
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
				
			}
			if(visible == true) {
				log.info("The element was found in "+count+" attempts");
				break;
			}
		}		
		if(visible==false)
		{
			log.info("Unable to find the element with LocaterText: {}", locatorText);
		}
		return this.image;
		
	}
    private ImageDescription getLocatorObject(String locatorText, LocatorType locatorType) {
        switch (locatorType) {
            case CSS:
                return new ImageDescription.Builder()
                        .cssSelector(locatorText)
                        .build();
            case XPATH:
                return new ImageDescription.Builder()
                        .xpath(locatorText)
                        .build();
            case ID:
                return new ImageDescription.Builder()
                        .id(locatorText)
                        .build();
            case TAGNAME:
                return new ImageDescription.Builder()
                        .tagName(locatorText)
                        .build();
            case NAME:
                return new ImageDescription.Builder()
                        .name(locatorText)
                        .build();
            default:
                throw new IllegalArgumentException("Unrecognized locator type: " + locatorType.getLocatorTagName());

        }
    }

    public Image getImage() {
        return image;
    }

    @Override
    public DesktopImage click(int... retries) throws GeneralLeanFtException {
        try {
            this.getImage().click();
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.click(0);
            } else {
                throw e;
            }
        }
        return this;
    }

    @Override
    public DesktopImage doubleClick(int... retries) throws GeneralLeanFtException {
        try {
            this.getImage().doubleClick();
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.doubleClick(0);
            } else {
                throw e;
            }
        }
        return this;
    }

    @Override
    public DesktopObject exists(int... retries) throws GeneralLeanFtException {
        try {
            waitUntil(this.image, testObject -> image.exists());
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                return this.exists(0);
            } else {
                throw e;
            }
        }
        return this;
    }

    @Override
    public boolean isEnabled(int... retries) throws GeneralLeanFtException {
        return false;
    }

    public DesktopWebImage refind(int... retries) {
        log.info("Attempting to refind the field: {}", locatorText);
        int attempts = 0;
        boolean retry = true;
        int maxRetry = retries.length > 0 ? retries[0] : getFindRetries();
        while (attempts < maxRetry && retry) {
            try {
                log.debug("retry number {}", attempts);
                waitUntil(this.getImage(), testObject -> getImage().exists());
                this.getImage().getId();
                retry = false;
            } catch (Exception e) {
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e1) {
                    log.debug(e1.getMessage());
                    Thread.currentThread().interrupt();
                }
            }
            attempts++;
        }
        return this;
    }

    public static int getFindRetries() {
        final int defaultFindRetries = 10;
        int refind;
        try {
            refind = Integer.parseInt(System.getProperty(Constants.DEFAULT_RETRIES));
        } catch (Exception e) {
            refind = defaultFindRetries;
        }
        return refind;
    }
}
