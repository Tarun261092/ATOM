package automation.library.leanft.selenium;

import automation.library.leanft.exec.DesktopContext;
import com.hp.lft.sdk.SDK;
import com.hp.lft.sdk.internal.ServerLauncher;

public class BaseTest extends automation.library.cucumber.selenium.BaseTest {
   protected void clearSDK() {
        SDK.cleanup();
        if (DesktopContext.getInstance().isLeanFTUp()) {
            ServerLauncher.closeServer();
        }
    }
}
