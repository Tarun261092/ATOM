package automation.library.leanft.core.desktop;

import com.hp.lft.sdk.GeneralLeanFtException;

public abstract class DesktopStatic extends DesktopObject {
    public abstract String geText(int... retries) throws GeneralLeanFtException;
}
