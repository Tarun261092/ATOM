package automation.library.leanft.core.desktop.stdwin;

import automation.library.leanft.core.desktop.DesktopRadioButton;
import com.hp.lft.sdk.GeneralLeanFtException;

public class SWDesktopRadioButton extends DesktopRadioButton {
    @Override
    public DesktopRadioButton click(int... a) throws GeneralLeanFtException {
        return null;
    }

    @Override
    public DesktopRadioButton exists(int... retries) throws GeneralLeanFtException {
        return null;
    }

    @Override
    public boolean isEnabled(int... retries) throws GeneralLeanFtException {
        return false;
    }

    @Override
    public DesktopRadioButton select(int index, int... retries) throws GeneralLeanFtException {
        return null;
    }

    @Override
    public DesktopRadioButton select(String value, int... retries) throws GeneralLeanFtException {
        return null;
    }
}
