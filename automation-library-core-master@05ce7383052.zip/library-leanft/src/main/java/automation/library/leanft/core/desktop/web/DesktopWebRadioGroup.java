package automation.library.leanft.core.desktop.web;

import automation.library.common.Property;
import automation.library.leanft.core.Constants;
import automation.library.leanft.core.desktop.DesktopRadioButton;
import automation.library.leanft.core.desktop.winforms.WFDesktopWindow;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.web.*;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import static com.hp.lft.sdk.WaitUntilTestObjectState.waitUntil;

public class DesktopWebRadioGroup extends DesktopRadioButton {

    private DesktopWebPageEmbedded desktopWebPage;
    private WebDesktopBrowserWindow parentWindow;
    private DesktopWebFrame desktopWebFrame;
    private RadioGroup radioGroup;
    private String locatorText;
    protected final Logger log = LogManager.getLogger(this.getClass().getName());

    
    public DesktopWebRadioGroup() {
	}

	public DesktopWebRadioGroup(String windowObjectName,
                          String fullType,
                          String windowTitle,
                          String locatorText,
                          LocatorType locatorType) throws GeneralLeanFtException {
        this.desktopWebPage = new DesktopWebPageEmbedded(windowObjectName, windowTitle, fullType);
        this.locatorText = locatorText;
        this.radioGroup = desktopWebPage.getEmbeddedPage()
                .describe(RadioGroup.class,
                        getLocatorObject(locatorText, locatorType));
    }

    public DesktopWebRadioGroup(WFDesktopWindow parentWindow,
                          String locatorText,
                          LocatorType locatorType) throws GeneralLeanFtException {
        this.desktopWebPage = new DesktopWebPageEmbedded(parentWindow);
        this.locatorText = locatorText;
        this.radioGroup = desktopWebPage.getEmbeddedPage()
                .describe(RadioGroup.class,
                        getLocatorObject(locatorText, locatorType));
    }
    public DesktopWebRadioGroup(String title,
                                String browser,
                                String locatorText,
                                LocatorType locatorType) throws GeneralLeanFtException {
        this.parentWindow = new WebDesktopBrowserWindow(title, browser);
        this.locatorText = locatorText;
        this.radioGroup = parentWindow.getWindow()
                .describe(RadioGroup.class,
                        getLocatorObject(locatorText, locatorType));
    }

    public DesktopWebRadioGroup(WebDesktopBrowserWindow parentWindow, String locatorText, LocatorType locatorType) throws GeneralLeanFtException {
        this.parentWindow = parentWindow;
        this.radioGroup = parentWindow.getWindow().
                describe(RadioGroup.class, getLocatorObject(locatorText, locatorType));
    }

    public DesktopWebRadioGroup(DesktopWebPageEmbedded desktopWebPage, String locatorText, LocatorType locatorType) throws GeneralLeanFtException {
        this.desktopWebPage = desktopWebPage;
        this.radioGroup = desktopWebPage.getEmbeddedPage().describe(RadioGroup.class, getLocatorObject(locatorText, locatorType));
    }

    public DesktopWebRadioGroup(DesktopWebFrame desktopWebFrame, String locatorText, LocatorType locatorType) throws GeneralLeanFtException {
        this.desktopWebFrame = desktopWebFrame;
        this.radioGroup = desktopWebFrame.getFrame().describe(RadioGroup.class, getLocatorObject(locatorText, locatorType));
    }
    
    public WebElement checkVisiblityOfRadioGroupInFrame(String title, String browserType, String frameName, String xpath)
			throws GeneralLeanFtException {
		String numberOfRetries = "";
		int count = 1;
		locatorText = xpath;
		boolean visible = false;
		numberOfRetries = Property.getProperty(Constants.LEANFTRUNTIMEPATH, "defaultWait");
		if(numberOfRetries==null || numberOfRetries.equals("0")) {
			numberOfRetries = "40";
		}
		log.info("Trying to find the element with LocaterText: {}", locatorText);
		while(count<Integer.parseInt(numberOfRetries))
		{
			try {
				this.parentWindow = new WebDesktopBrowserWindow(title, browserType);
				 this.radioGroup = parentWindow.getWindow().
			                describe(Frame.class, new FrameDescription.Builder()
			               .name(frameName).build()).
			                describe(RadioGroup.class,new RadioGroupDescription.Builder().xpath(xpath).build());
				waitUntil(this.getRadioGroup(), testObject -> getRadioGroup().exists());
	            this.getRadioGroup().getId();
				visible = true;
				log.info("Element Located successfully with LocaterText: {}", locatorText);			
			
			} catch (Exception e) {
				try {
					Thread.sleep(1000);
					count = count + 1;
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
				
			}
			if(visible == true) {
				log.info("The element was found in "+count+" attempts");
				break;
			}
		}		
		if(visible==false)
		{
			log.info("Unable to find the element with LocaterText: {}", locatorText);
		}
		return this.radioGroup;
		
	}
    
    public WebElement checkVisiblityOfRadioGroup(String title, String browserType, String xpath)
			throws GeneralLeanFtException {
		String numberOfRetries = "";
		int count = 1;
		locatorText = xpath;
		boolean visible = false;
		numberOfRetries = Property.getProperty(Constants.LEANFTRUNTIMEPATH, "defaultWait");
		if(numberOfRetries==null || numberOfRetries.equals("0")) {
			numberOfRetries = "40";
		}
		log.info("Trying to find the element with LocaterText: {}", locatorText);
		while(count<Integer.parseInt(numberOfRetries))
		{
			try {
				this.parentWindow = new WebDesktopBrowserWindow(title, browserType);
				this.radioGroup = this.parentWindow.getWindow().describe(RadioGroup.class,new RadioGroupDescription.Builder().xpath(xpath).build());
				waitUntil(this.getRadioGroup(), testObject -> getRadioGroup().exists());
                this.getRadioGroup().getId();
				visible = true;
				log.info("Element Located successfully with LocaterText: {}", locatorText);			
			
			} catch (Exception e) {
				try {
					Thread.sleep(1000);
					count = count + 1;
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
				
			}
			if(visible == true) {
				log.info("The element was found in "+count+" attempts");
				break;
			}
		}		
		if(visible==false)
		{
			log.info("Unable to find the element with LocaterText: {}", locatorText);
		}
		return this.radioGroup;
		
	}

    private RadioGroupDescription getLocatorObject(String locatorText, LocatorType locatorType) {
        switch (locatorType) {
            case CSS:
                return new RadioGroupDescription.Builder()
                        .cssSelector(locatorText)
                        .build();
            case XPATH:
                return new RadioGroupDescription.Builder()
                        .xpath(locatorText)
                        .build();
            case ID:
                return new RadioGroupDescription.Builder()
                        .id(locatorText)
                        .build();
            case TAGNAME:
                return new RadioGroupDescription.Builder()
                        .tagName(locatorText)
                        .build();
            case NAME:
                return new RadioGroupDescription.Builder()
                        .name(locatorText)
                        .build();
            default:
                throw new IllegalArgumentException("Unrecognized locator type: " + locatorType.getLocatorTagName());

        }
    }

    public RadioGroup getRadioGroup() {
        return radioGroup;
    }

    @Override
    public DesktopRadioButton exists(int... retries) throws GeneralLeanFtException {
        try {
            waitUntil(this.radioGroup, testObject -> radioGroup.exists());
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                return this.exists(0);
            } else {
                throw e;
            }
        }
        return this;
    }

    @Override
    public boolean isEnabled(int... retries) throws GeneralLeanFtException {
        return false;
    }


    public DesktopRadioButton click(int... retries) throws GeneralLeanFtException {
        try {
            this.getRadioGroup().click();
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.click(0);
            } else {
                throw e;
            }
        }
        return this;
    }

    @Override
    public DesktopRadioButton select(int index, int... retries) throws GeneralLeanFtException {
        try {
            this.getRadioGroup().select(index);
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.select(index,0);
            } else {
                throw e;
            }
        }
        return this;
    }

    @Override
    public DesktopRadioButton select(String value, int... retries) throws GeneralLeanFtException {
        try {
            this.getRadioGroup().select(value);
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.select(value,0);
            } else {
                throw e;
            }
        }
        return this;
    }

    public DesktopWebRadioGroup refind(int... retries) {
        log.info("Attempting to refind the field: {}", locatorText);
        int attempts = 0;
        boolean retry = true;
        int maxRetry = retries.length > 0 ? retries[0] : getFindRetries();
        while (attempts < maxRetry && retry) {
            try {
                log.debug("retry number {}", attempts);
                waitUntil(this.getRadioGroup(), testObject -> getRadioGroup().exists());
                this.getRadioGroup().getId();
                retry = false;
            } catch (Exception e) {
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e1) {
                    log.debug(e1.getMessage());
                    Thread.currentThread().interrupt();
                }
            }
            attempts++;
        }
        return this;
    }

    public static int getFindRetries() {
        final int defaultFindRetries = 10;
        int refind;
        try {
            refind = Integer.parseInt(System.getProperty(Constants.DEFAULT_RETRIES));
        } catch (Exception e) {
            refind = defaultFindRetries;
        }
        return refind;
    }
}

