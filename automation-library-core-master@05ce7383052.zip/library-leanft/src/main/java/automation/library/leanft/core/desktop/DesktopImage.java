package automation.library.leanft.core.desktop;

import com.hp.lft.sdk.GeneralLeanFtException;

public abstract class DesktopImage extends DesktopObject {
    public abstract DesktopImage click(int... retries) throws GeneralLeanFtException;
    public abstract DesktopImage doubleClick(int... retries) throws GeneralLeanFtException;
}
