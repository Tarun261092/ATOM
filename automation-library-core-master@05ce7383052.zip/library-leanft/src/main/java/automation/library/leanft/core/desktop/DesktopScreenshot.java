package automation.library.leanft.core.desktop;

import automation.library.common.Property;
import automation.library.leanft.core.ScreenshotBase;
import automation.library.leanft.core.desktop.stdwin.SWDesktopWindow;
import automation.library.leanft.core.desktop.web.WebDesktopBrowserWindow;
import automation.library.leanft.core.desktop.winforms.WFDesktopWindow;
import automation.library.leanft.exec.DesktopContext;
import com.hp.lft.sdk.GeneralLeanFtException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
import java.util.UUID;

import static automation.library.leanft.core.Constants.LEANFTRUNTIMEPATH;

public class DesktopScreenshot extends ScreenshotBase {

    public static File grabScreenshot() {
        if(DesktopContext.getInstance().getCurrentLeanFTWindow() != null) {
            return grabScreenshot(DesktopContext.getInstance().getCurrentLeanFTWindow());
        } else if(DesktopContext.getInstance().getCurrentLeanFTDialog() != null) {
           return grabDialogScreenshot(DesktopContext.getInstance().getCurrentLeanFTDialog());
        }

        return null;
    }

    /**
     * capture and return a file object.
     *
     * @param window
     */
    public static File grabScreenshot(DesktopWindow window) {
        File file = new File(String.format("%s%s", UUID.randomUUID(), ".png"));

        if (window instanceof SWDesktopWindow) {
            return getSWDesktopWindowScreenshot((SWDesktopWindow) window, file);
        } else if (window instanceof WFDesktopWindow) {
            return getWFDesktopWindowScreenshot((WFDesktopWindow) window, file);
        } else if (window instanceof WebDesktopBrowserWindow) {
            return getWebDesktopWindowScreenshot((WebDesktopBrowserWindow) window, file);
        }

        return file;

    }

    private static File getWFDesktopWindowScreenshot(WFDesktopWindow window, File file) {
        try {
            Thread.sleep(Property.getProperties(LEANFTRUNTIMEPATH).getInt("screenshotDelay", 0));
            if (window.getWindow().exists()) {
                ImageIO.write(window.getWindow().getSnapshot(), "PNG", file);
            } else {
                getLogger().warn("Did not find window specified. Skipping screenshot");
            }
        } catch (IOException | GeneralLeanFtException | InterruptedException e) {
            getLogger().error(e.getMessage());
            Thread.currentThread().interrupt();
        }

        return file;
    }

    private static File getWebDesktopWindowScreenshot(WebDesktopBrowserWindow window, File file) {
        try {
            Thread.sleep(Property.getProperties(LEANFTRUNTIMEPATH).getInt("screenshotDelay", 0));
            if (window.getWindow().exists()) {
                ImageIO.write(window.getWindow().getSnapshot(), "PNG", file);
            } else {
                getLogger().warn("Did not find window specified. Skipping screenshot");
            }
        } catch (IOException | GeneralLeanFtException | InterruptedException e) {
            getLogger().error(e.getMessage());
            Thread.currentThread().interrupt();
        }

        return file;
    }

    private static File getSWDesktopWindowScreenshot(SWDesktopWindow window, File file) {
        try {
            Thread.sleep(Property.getProperties(LEANFTRUNTIMEPATH).getInt("screenshotDelay", 0));
            if (window.getWindow().exists()) {
                ImageIO.write(window.getWindow().getSnapshot(), "PNG", file);
            } else {
                getLogger().warn("Did not find window specified. Skipping screenshot");
            }
        } catch (IOException | GeneralLeanFtException | InterruptedException e) {
            getLogger().error(e.getMessage());
            Thread.currentThread().interrupt();
        }

        return file;
    }


    private static File grabDialogScreenshot(DesktopDialog currentLeanFTDialog) {
        File file = new File(String.format("%s%s", UUID.randomUUID(), ".png"));

        try {
            Thread.sleep(Property.getProperties(LEANFTRUNTIMEPATH).getInt("screenshotDelay", 0));
            if (currentLeanFTDialog.getDialog().exists()) {
                ImageIO.write(currentLeanFTDialog.getDialog().getSnapshot(), "PNG", file);
            } else {
                getLogger().warn("Did not find dialog specified. Skipping screenshot");
            }
        } catch (IOException | GeneralLeanFtException | InterruptedException e) {
            getLogger().error(e.getMessage());
            Thread.currentThread().interrupt();
        }

        return file;
    }

    private static Logger getLogger() {
        return LogManager.getLogger(ScreenshotBase.class);
    }
}
