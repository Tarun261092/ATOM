package automation.library.leanft.core.desktop.web;

import automation.library.common.Property;
import automation.library.leanft.core.Constants;
import automation.library.leanft.core.desktop.DesktopEditField;
import automation.library.leanft.core.desktop.stdwin.SWDesktopWindow;
import automation.library.leanft.core.desktop.winforms.WFDesktopWindow;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.web.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import com.hp.lft.sdk.Keyboard;
import static com.hp.lft.sdk.WaitUntilTestObjectState.waitUntil;

public class DesktopWebEditField extends DesktopEditField {

    private EditField editField;
    private String locatorText;
    private WebDesktopBrowserWindow parentWindow;
    private DesktopWebPageEmbedded desktopWebPage;
    private DesktopWebFrame desktopWebFrame;

    protected final Logger log = LogManager.getLogger(this.getClass().getName());

    
    public DesktopWebEditField() {
	}

	public DesktopWebEditField(String windowObjectName,
                               String fullType,
                               String windowTitle,
                               String locatorText,
                               LocatorType locatorType) throws GeneralLeanFtException {
        this.desktopWebPage = new DesktopWebPageEmbedded(windowObjectName, windowTitle, fullType);
        this.locatorText = locatorText;
        this.editField = desktopWebPage.getEmbeddedPage()
                .describe(EditField.class,
                        getLocatorObject(locatorText, locatorType));
    }

    public DesktopWebEditField(WFDesktopWindow parentWindow,
                               String locatorText,
                               LocatorType locatorType) throws GeneralLeanFtException {
        this.desktopWebPage = new DesktopWebPageEmbedded(parentWindow);
        this.locatorText = locatorText;
        this.editField = desktopWebPage.getEmbeddedPage()
                .describe(EditField.class,
                        getLocatorObject(locatorText, locatorType));
    }

    public DesktopWebEditField(String title, String browserType, String name) throws GeneralLeanFtException {
        this.parentWindow = new WebDesktopBrowserWindow(title, browserType);
        this.editField = parentWindow.getWindow().describe(EditField.class, new EditFieldDescription.Builder()
                .name(name).build());

    }

    public DesktopWebEditField(WFDesktopWindow parentWindow,
                               SWDesktopWindow embeddedwindow,
                               String locatorText,
                               LocatorType locatorType) throws GeneralLeanFtException {
        this.desktopWebPage = new DesktopWebPageEmbedded(parentWindow, embeddedwindow);
        this.locatorText = locatorText;
        this.editField = desktopWebPage.getEmbeddedPage()
                .describe(EditField.class,
                        getLocatorObject(locatorText, locatorType));
    }

    public DesktopWebEditField(WebDesktopBrowserWindow parentWindow, String name) throws GeneralLeanFtException {
        this.parentWindow = parentWindow;
        this.editField = parentWindow.getWindow().describe(EditField.class, new EditFieldDescription.Builder()
                .name(name).build());

    }

    public DesktopWebEditField(String title, String browserType, String name, String xpath) throws GeneralLeanFtException {
        this.parentWindow = new WebDesktopBrowserWindow(title, browserType);
        this.editField = parentWindow.getWindow().describe(EditField.class, new EditFieldDescription.Builder()
                .name(name)
                .xpath(xpath).build());
    }

    public DesktopWebEditField(WebDesktopBrowserWindow parentWindow, String tagName, String name) throws GeneralLeanFtException {
        this.parentWindow = parentWindow;
        this.editField = parentWindow.getWindow().describe(EditField.class, new EditFieldDescription.Builder()
                .tagName(tagName)
                .name(name).build());
    }

    public DesktopWebEditField(WebDesktopBrowserWindow parentWindow, String frameName, String title, String name, String xpath) throws GeneralLeanFtException {
        this.parentWindow = parentWindow;
        this.editField = parentWindow.getWindow().describe(Frame.class, new FrameDescription.Builder()
                .name(frameName)
                .title(title).build())
                .describe(EditField.class, new EditFieldDescription.Builder()
                        .name(name)
                        .xpath(xpath).build());
    }

    public DesktopWebEditField(WebDesktopBrowserWindow parentWindow, String locatorText, LocatorType locatorType) throws GeneralLeanFtException {
        this.parentWindow = parentWindow;
        this.editField = parentWindow.getWindow().describe(EditField.class, getLocatorObject(locatorText, locatorType));
    }

    public DesktopWebEditField(DesktopWebFrame desktopWebFrame, String locatorText, LocatorType locatorType) throws GeneralLeanFtException {
        this.desktopWebFrame = desktopWebFrame;
        this.editField = desktopWebFrame.getFrame().describe(EditField.class, getLocatorObject(locatorText, locatorType));
    }

    public DesktopWebEditField(DesktopWebPageEmbedded desktopWebPage, String locatorText, LocatorType locatorType) throws GeneralLeanFtException {
        this.desktopWebPage = desktopWebPage;
        this.editField = desktopWebPage.getEmbeddedPage().describe(EditField.class, getLocatorObject(locatorText, locatorType));
    }
    
    public WebElement checkVisiblityOfEditFieldInFrame(String title, String browserType, String frameName, String xpath)
			throws GeneralLeanFtException {
		String numberOfRetries = "";
		int count = 1;
		locatorText = xpath;
		boolean visible = false;
		numberOfRetries = Property.getProperty(Constants.LEANFTRUNTIMEPATH, "defaultWait");
		if(numberOfRetries==null || numberOfRetries.equals("0")) {
			numberOfRetries = "40";
		}
		log.info("Trying to find the element with LocaterText: {}", locatorText);
		while(count<Integer.parseInt(numberOfRetries))
		{
			try {
				this.parentWindow = new WebDesktopBrowserWindow(title, browserType);
				this.editField = parentWindow.getWindow().
			                describe(Frame.class, new FrameDescription.Builder()
			               .name(frameName).build()).
			                describe(EditField.class,new EditFieldDescription.Builder().xpath(xpath).build());
	            waitUntil(this.getEditField(), testObject -> getEditField().exists());
                this.getEditField().getName();
				visible = true;
				log.info("Element Located successfully with LocaterText: {}", locatorText);			
			
			} catch (Exception e) {
				try {
					Thread.sleep(1000);
					count = count + 1;
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
				
			}
			if(visible == true) {
				log.info("The element was found in "+count+" attempts");
				break;
			}
		}		
		if(visible==false)
		{
			log.info("Unable to find the element with LocaterText: {}", locatorText);
		}
		return this.editField;
		
	}
    
    public WebElement checkVisiblityOfEditField(String title, String browserType, String xpath)
			throws GeneralLeanFtException {
		String numberOfRetries = "";
		int count = 1;
		locatorText = xpath;
		boolean visible = false;
		numberOfRetries = Property.getProperty(Constants.LEANFTRUNTIMEPATH, "defaultWait");
		if(numberOfRetries==null || numberOfRetries.equals("0")) {
			numberOfRetries = "40";
		}
		log.info("Trying to find the element with LocaterText: {}", locatorText);
		while(count<Integer.parseInt(numberOfRetries))
		{
			try {
				this.parentWindow = new WebDesktopBrowserWindow(title, browserType);
				this.parentWindow.getWindow().highlight();
				this.editField = this.parentWindow.getWindow().describe(EditField.class,new EditFieldDescription.Builder().xpath(xpath).build());
				waitUntil(this.getEditField(), testObject -> getEditField().exists());
                this.getEditField().getId();
				visible = true;
				log.info("Element Located successfully with LocaterText: {}", locatorText);			
			
			} catch (Exception e) {
				try {
					Thread.sleep(1000);
					count = count + 1;
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
				
			}
			if(visible == true) {
				log.info("The element was found in "+count+" attempts");
				break;
			}
		}		
		if(visible==false)
		{
			log.info("Unable to find the element with LocaterText: {}", locatorText);
		}
		return this.editField;
		
	}

    private EditFieldDescription getLocatorObject(String locatorText, LocatorType locatorType) {
        switch (locatorType) {
            case CSS:
                return new EditFieldDescription.Builder()
                        .cssSelector(locatorText)
                        .build();
            case XPATH:
                return new EditFieldDescription.Builder()
                        .xpath(locatorText)
                        .build();
            case ID:
                return new EditFieldDescription.Builder()
                        .id(locatorText)
                        .build();
            case TAGNAME:
                return new EditFieldDescription.Builder()
                        .tagName(locatorText)
                        .build();
            case NAME:
                return new EditFieldDescription.Builder()
                        .name(locatorText)
                        .build();
            default:
                throw new IllegalArgumentException("Unrecognized locator type: " + locatorType.getLocatorTagName());

        }
    }

    public EditField getEditField() {
        return editField;
    }

    @Override
    public DesktopEditField exists(int... retries) throws GeneralLeanFtException {
        try {
            waitUntil(this.editField, testObject -> editField.exists());
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                return this.exists(0);
            } else {
                throw e;
            }
        }
        return this;
    }

    @Override
    public String getText(int... retries) throws GeneralLeanFtException {
        String str = null;
        try {
            str = this.editField.getValue();
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                return this.getText(0);
            } else {
                throw e;
            }
        }
        return str;
    }

    @Override
    public boolean isEnabled(int... retries) throws GeneralLeanFtException {
        boolean status = false;
        try {
            status = !this.getEditField().isReadOnly();
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.isEnabled(0);
            } else {
                throw e;
            }
        }
        return status;
    }

    public DesktopEditField setText(String text, int... retries) throws GeneralLeanFtException {
        try {
            this.getEditField().setValue(text);
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.setText(text, 0);
            } else {
                throw e;
            }
        }
        return this;
    }
    
    public DesktopEditField setString(String text, int... retries) throws GeneralLeanFtException {
    	try {
    	this.getEditField().click();
    	try{Thread.sleep(500);}catch(Exception e) {}
    	Keyboard.sendString(text);
    	try{Thread.sleep(500);}catch(Exception e) {}
    	//Keyboard.pressKey(Keyboard.Keys.TAB);
    }catch(Exception e)
    {
    	if (!(retries.length > 0 && retries[0] == 0)) {
            this.refind(retries);
            this.setString(text, 0);
        }
    	else {
            throw e;
        }
    }
    	
    	return this;
    	
    }
    
    public DesktopWebEditField refind(int... retries) {
        log.info("Attempting to refind the field: {}", locatorText);
        int attempts = 0;
        boolean retry = true;
        int maxRetry = retries.length > 0 ? retries[0] : getFindRetries();
        while (attempts < maxRetry && retry) {
            try {
                log.debug("retry number {}", attempts);
                waitUntil(this.getEditField(), testObject -> getEditField().exists());
                this.getEditField().getId();
                retry = false;
            } catch (Exception e) {
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e1) {
                    log.debug(e1.getMessage());
                    Thread.currentThread().interrupt();
                }
            }
            attempts++;
        }
        return this;
    }

    public static int getFindRetries() {
        final int defaultFindRetries = 10;
        int refind;
        try {
            refind = Integer.parseInt(System.getProperty(Constants.DEFAULT_RETRIES));
        } catch (Exception e) {
            refind = defaultFindRetries;
        }
        return refind;
    }

    @Override
    public DesktopEditField click(int... retries) throws GeneralLeanFtException {
        try {
            this.getEditField().click();
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.click(0);
            } else {
                throw e;
            }
        }
        return this;
    }
}

