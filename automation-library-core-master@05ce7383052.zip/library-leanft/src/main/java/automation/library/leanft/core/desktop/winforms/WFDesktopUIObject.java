package automation.library.leanft.core.desktop.winforms;

import automation.library.leanft.core.Constants;
import automation.library.leanft.core.desktop.DesktopUiObject;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.winforms.UiObject;
import com.hp.lft.sdk.winforms.UiObjectDescription;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import static com.hp.lft.sdk.WaitUntilTestObjectState.waitUntil;

public class WFDesktopUIObject extends DesktopUiObject {

    private UiObject uiObject;
    private WFDesktopWindow parentWindow;
    private String objectName;
    protected final Logger log = LogManager.getLogger(this.getClass().getName());


    public WFDesktopUIObject(String windowObjectName,
                             String fullType,
                             String uiObjectName) throws GeneralLeanFtException {
        this.parentWindow = new WFDesktopWindow(windowObjectName, fullType);
        this.objectName = uiObjectName;
        this.uiObject = this.parentWindow.getWindow()
                                         .describe(UiObject.class,
                                                   new UiObjectDescription.Builder().objectName(uiObjectName).build());

    }

    public WFDesktopUIObject(WFDesktopWindow wfDesktopWindow,
                             String objectName) throws GeneralLeanFtException {
        this.parentWindow = wfDesktopWindow;
        this.objectName = objectName;
        this.uiObject = this.parentWindow.getWindow()
                                         .describe(UiObject.class,
                                                   new UiObjectDescription.Builder().objectName(objectName).build());

    }

    public UiObject getUiObject() {
        return this.uiObject;
    }

    /**
     * @param retries
     * @return
     * @throws GeneralLeanFtException
     */
    public DesktopUiObject click(int... retries) throws GeneralLeanFtException {
        try {
            this.getUiObject().click();
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.click(0);
            } else {
                throw e;
            }
        }
        return this;
    }

    /**
     * @param text
     * @param retries
     * @return
     * @throws GeneralLeanFtException
     */
    public DesktopUiObject sendKeys(String text, int... retries) throws GeneralLeanFtException {
        try {
            this.getUiObject().sendKeys(text);
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.sendKeys(text, 0);
            } else {
                throw e;
            }
        }
        return this;
    }


    /**
     * searches again for the field using the by
     */
    public WFDesktopUIObject refind(int... retries) {
        log.info("Attempting to refind the field: {}", objectName);
        int attempts = 0;
        boolean retry = true;
        int maxRetry = retries.length > 0 ? retries[0] : getFindRetries();
        while (attempts < maxRetry && retry) {
            try {
                log.debug("retry number {}", attempts);
                waitUntil(this.getUiObject(), testObject -> getUiObject().exists());
                this.getUiObject().getObjectName();
                retry = false;
            } catch (Exception e) {
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e1) {
                    log.debug(e1.getMessage());
                    Thread.currentThread().interrupt();
                }
            }
            attempts++;
        }
        return this;
    }

    public static int getFindRetries() {
        final int defaultFindRetries = 10;
        int refind;
        try {
            refind = Integer.parseInt(System.getProperty(Constants.DEFAULT_RETRIES));
        } catch (Exception e) {
            refind = defaultFindRetries;
        }
        return refind;
    }

    /**
     * @param retries
     * @return
     * @throws GeneralLeanFtException
     */
    public WFDesktopUIObject exists(int... retries) throws GeneralLeanFtException {
        try {
            waitUntil(this.uiObject, testObject -> uiObject.exists());
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                return this.exists(0);
            } else {
                throw e;
            }
        }
        return this;
    }

    /**
     * @param retries
     * @return
     * @throws GeneralLeanFtException
     */
    public boolean isEnabled(int... retries) throws GeneralLeanFtException {
        boolean status = false;
        try {
            status = this.getUiObject().isEnabled();
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.isEnabled(0);
            } else {
                throw e;
            }
        }
        return status;
    }
}
