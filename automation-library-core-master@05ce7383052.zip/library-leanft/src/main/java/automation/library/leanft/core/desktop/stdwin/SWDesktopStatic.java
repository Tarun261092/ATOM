package automation.library.leanft.core.desktop.stdwin;

import automation.library.leanft.core.Constants;
import automation.library.leanft.core.desktop.DesktopStatic;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.stdwin.ButtonDescription;
import com.hp.lft.sdk.stdwin.Static;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import static com.hp.lft.sdk.WaitUntilTestObjectState.waitUntil;

public class SWDesktopStatic extends DesktopStatic {
    private SWDesktopDialog parentDialog;
    private Static staticObj;
    private String accessibleName;
    protected final Logger log = LogManager.getLogger(this.getClass().getName());

        public SWDesktopStatic(SWDesktopDialog swDesktopDialog, String windowClassRegExp, String windowTitleRegExp) throws GeneralLeanFtException {
        this.parentDialog = swDesktopDialog;
        this.staticObj = parentDialog.getDialog().describe(Static.class, new ButtonDescription.Builder()
                .windowClassRegExp(windowClassRegExp)
                .windowTitleRegExp(windowTitleRegExp).build());
    }

    public Static getDesktopStaticObj() {
        return this.staticObj;
    }

    /**
     * searches again for the field using the by
     */
    public SWDesktopStatic refind(int... retries) {
        log.info("Attempting to refind the field: {}", accessibleName);
        int attempts = 0;
        boolean retry = true;
        int maxRetry = retries.length > 0 ? retries[0] : getFindRetries();
        while (attempts < maxRetry && retry) {
            try {
                log.debug("retry number {}", attempts);
                waitUntil(this.getDesktopStaticObj(), testObject -> getDesktopStaticObj().exists());
                this.getDesktopStaticObj().getAccessibleName();
                retry = false;
            } catch (Exception e) {
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e1) {
                    log.debug(e1.getMessage());
                    Thread.currentThread().interrupt();
                }
            }
            attempts++;
        }
        return this;
    }

    public static int getFindRetries() {
        final int defaultFindRetries = 10;
        int refind;
        try {
            refind = Integer.parseInt(System.getProperty(Constants.DEFAULT_RETRIES));
        } catch (Exception e) {
            refind = defaultFindRetries;
        }
        return refind;
    }

    public String geText(int... retries) throws GeneralLeanFtException {
        String str = null;
        try {
            str = this.getDesktopStaticObj().getVisibleText();
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                return this.geText(0);
            } else {
                throw e;
            }
        }
        return str;
    }

    /**
     * @param retries
     * @return
     * @throws GeneralLeanFtException
     */
    public SWDesktopStatic exists(int... retries) throws GeneralLeanFtException {
        try {
            waitUntil(this.staticObj, testObject -> staticObj.exists());
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                return this.exists(0);
            } else {
                throw e;
            }
        }
        return this;
    }

    /**
     * @param retries
     * @return
     * @throws GeneralLeanFtException
     */
    public boolean isEnabled(int... retries) throws GeneralLeanFtException {
        boolean status = false;
        try {
            status = this.getDesktopStaticObj().isEnabled();
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.isEnabled(0);
            } else {
                throw e;
            }
        }
        return status;
    }
}
