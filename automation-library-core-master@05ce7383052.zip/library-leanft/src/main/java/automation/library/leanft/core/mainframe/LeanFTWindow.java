package automation.library.leanft.core.mainframe;

import automation.library.leanft.core.Constants;
import automation.library.leanft.exec.DesktopContext;
import com.hp.lft.sdk.Desktop;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.GeneralReplayException;
import com.hp.lft.sdk.te.EmulatorStatus;
import com.hp.lft.sdk.te.Window;
import com.hp.lft.sdk.te.WindowDescription;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import static com.hp.lft.sdk.WaitUntilTestObjectState.waitUntil;

public class LeanFTWindow {
    private Window window;
    private String name;

    protected final Logger log = LogManager.getLogger(this.getClass().getName());


    public LeanFTWindow(String name) throws GeneralLeanFtException {
        this.name = name;
        if (DesktopContext.getInstance().runOnGrid()) {
            this.window = DesktopContext.getInstance()
                                   .getEnv()
                                   .describe(com.hp.lft.sdk.te.Window.class,
                                             new WindowDescription.Builder().emulatorStatus(EmulatorStatus.READY)
                                                                            .shortName(name)
                                                                            .build());
        } else {
            this.window = Desktop.describe(com.hp.lft.sdk.te.Window.class,
                                           new WindowDescription.Builder().emulatorStatus(EmulatorStatus.READY)
                                                                          .shortName(name)
                                                                          .build());
        }
    }

    public Window getWindow() {
        return this.window;
    }

    /**
     *
     * @return
     */
    public static int getFindRetries() {
        final int defaultFindRetries = 10;
        int refind;
        try {
            refind = Integer.parseInt(System.getProperty(Constants.DEFAULT_RETRIES));
        } catch (Exception e) {
            refind = defaultFindRetries;
        }
        return refind;
    }


    /**
     * searches again for the window using the by
     */
    public LeanFTWindow refind(int... retries) {
        log.info("Attempting to refind the field with label: {}", name);
        int attempts = 0;
        Boolean retry = true;
        int maxRetry = retries.length > 0 ? retries[0] : getFindRetries();
        while (attempts < maxRetry && retry) {
            try {
                log.debug("retry number {}", attempts);
                waitUntil(this.window, testObject -> window.exists());
                this.window.getShortName();
                retry = false;
            } catch (Exception e) {
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e1) {
                    log.debug(e1.getMessage());
                    Thread.currentThread().interrupt();
                }
            }
            attempts++;
        }
        return this;
    }

    public LeanFTWindow activate(int... retries) throws GeneralLeanFtException {
        try {
            waitUntil(window, testObject -> window.exists());
            window.activate();
        } catch (GeneralReplayException e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                return this.activate(0);
            } else {
                throw e;
            }
        }
        return this;
    }
}
