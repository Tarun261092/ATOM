package automation.library.leanft.core.desktop;

import com.hp.lft.sdk.GeneralLeanFtException;

public abstract class DesktopToolBar extends DesktopObject {

    public abstract DesktopToolBar select(String name,int... retries) throws GeneralLeanFtException;
    public abstract DesktopToolBar exists(int... retries) throws GeneralLeanFtException;
    public abstract boolean isEnabled(int... retries) throws GeneralLeanFtException;

}
