package automation.library.leanft.core.desktop.stdwin;

import automation.library.leanft.core.desktop.DesktopCheckbox;
import com.hp.lft.sdk.GeneralLeanFtException;

public class SWDesktopCheckbox extends DesktopCheckbox {
    @Override
    public DesktopCheckbox click(int... a) throws GeneralLeanFtException {
        return null;
    }

    @Override
    public DesktopCheckbox exists(int... retries) throws GeneralLeanFtException {
        return null;
    }

    @Override
    public boolean isEnabled(int... retries) throws GeneralLeanFtException {
        return false;
    }

    @Override
    public boolean isChecked(int... retries) throws GeneralLeanFtException {
        return false;
    }
}
