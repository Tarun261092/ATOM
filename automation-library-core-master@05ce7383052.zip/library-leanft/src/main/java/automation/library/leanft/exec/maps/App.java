package automation.library.leanft.exec.maps;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class App {
    @SerializedName("emulatorToUse")
    @Expose
    private String emulatorToUse;
    @SerializedName("startingScreen")
    @Expose
    private String startingScreen;
    @SerializedName("startingField")
    @Expose
    private String startingField;
    @SerializedName("launchTextToEnter")
    @Expose
    private String launchTextToEnter;

    public String getLaunchTextToEnter() {
        return launchTextToEnter;
    }

    public String getStartingScreen() {
        return startingScreen;
    }
    public String getStartingField() {
        return startingField;
    }

    public String getEmulatorToUse() {
        return emulatorToUse;
    }

    public void setEmulatorToUse(String emulatorToUse) {
        this.emulatorToUse = emulatorToUse;
    }

    public void setStartingScreen(String startingScreen) {
        this.startingScreen = startingScreen;
    }

    public void setStartingField(String startingField) {
        this.startingField = startingField;
    }

    public void setLaunchTextToEnter(String launchTextToEnter) {
        this.launchTextToEnter = launchTextToEnter;
    }
}
