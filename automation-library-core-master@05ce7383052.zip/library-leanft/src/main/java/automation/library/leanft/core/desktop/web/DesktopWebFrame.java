package automation.library.leanft.core.desktop.web;

import automation.library.leanft.core.desktop.DesktopWindow;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.web.Frame;
import com.hp.lft.sdk.web.FrameDescription;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;

public class DesktopWebFrame extends DesktopWindow {

    private Frame frame;
    private WebDesktopBrowserWindow window;

    protected final Logger log = LogManager.getLogger(this.getClass().getName());

    public DesktopWebFrame(String browser, String pagetitle, String frameName, String frameId) throws GeneralLeanFtException {
        WebDesktopBrowserWindow window = new WebDesktopBrowserWindow(browser, pagetitle);
        this.frame = window.getWindow().describe(Frame.class, new FrameDescription.Builder()
                .name(frameName)
                .id(frameId).build());
    }

    public DesktopWebFrame(String browser, String pagetitle, String locatorText, LocatorType locatorType) throws GeneralLeanFtException {
        WebDesktopBrowserWindow window = new WebDesktopBrowserWindow(browser, pagetitle);
        this.frame = window.getWindow().describe(Frame.class, getLocatorObject(locatorText, locatorType));
    }

    public DesktopWebFrame(WebDesktopBrowserWindow window, String frameName, String frameId) throws GeneralLeanFtException {
        this.frame = window.getWindow().describe(Frame.class, new FrameDescription.Builder()
                .name(frameName)
                .id(frameId).build());
    }

    public DesktopWebFrame(WebDesktopBrowserWindow window, String locatorText, LocatorType locatorType) throws
            GeneralLeanFtException {
        this.frame = window.getWindow().describe(Frame.class, getLocatorObject(locatorText, locatorType));
    }

    private FrameDescription getLocatorObject(String locatorText, LocatorType locatorType) {
        switch (locatorType) {
            case NAME:
                return new FrameDescription.Builder()
                        .name(locatorText)
                        .build();
            case ID:
                return new FrameDescription.Builder()
                        .id(locatorText)
                        .build();
            default:
                throw new IllegalArgumentException("Unrecognized locator type: " + locatorType.getLocatorTagName());

        }
    }

    public Frame getFrame() {
        return this.frame;
    }

    @Override
    public DesktopWindow sendKeys(String keys, String modifierKey, int... retries) throws GeneralLeanFtException {
        return null;
    }

    @Override
    public DesktopWindow sendKeys(String keys, int... retries) throws GeneralLeanFtException {
        return null;
    }

    @Override
    public void clickImage(String imagePath, int... retries) throws GeneralLeanFtException, IOException {

    }
}