package automation.library.leanft.exec.managers;

import automation.library.common.StringHelper;
import automation.library.leanft.exec.DesktopContext;
import automation.library.leanft.exec.DesktopManager;
import automation.library.leanft.exec.maps.DesktopApplication;
import com.hp.lft.sdk.EnvironmentFactory;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.web.Browser;
import com.hp.lft.sdk.web.BrowserDescription;
import com.hp.lft.sdk.web.BrowserFactory;
import com.hp.lft.sdk.web.BrowserType;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class BrowserManager extends DesktopManager {

    private static final String WEBBROWSER = "WEBBROWSER";
    private Logger log = LogManager.getLogger(this.getClass().getName());

    @Override
    protected void createAut(String appName) {
        try {
            String sessionToLaunch = WEBBROWSER + StringHelper.removeSpecialChars(appName);

            DesktopApplication appInfo = null;
            if(DesktopContext.getInstance().getAppLaunchData().getDesktopApplications() != null) {
                appInfo = DesktopContext.getInstance().getAppLaunchData().getDesktopApplications().get(sessionToLaunch);
                if (appInfo == null) {
                    appInfo = DesktopContext.getInstance().getAppLaunchData().getDesktopApplications().get(WEBBROWSER);
                }
            }

            if (appInfo != null) {
                browser = getExistingBrowser(appInfo.getPageTitle(), appInfo.getBrowser());
                if (browser == null) {
                    browser = openBrowser();
                }
                Thread.sleep(appInfo.getDefaultApplLaunchWait());
            } else {
                log.error("Unable to launch application, App Info does not exist in leanFT launch config file");
            }
        } catch (InterruptedException e) {
            log.error(e.getMessage());
            Thread.currentThread().interrupt();
        }
    }

    @Override
    protected void quitAut() throws GeneralLeanFtException {
        if (browser != null) {
            browser.close();
        }
    }

    public Browser getExistingBrowser(String pageTitle, String browser) {
        if (DesktopContext.getInstance().runOnGrid()) {
            try {
                env = EnvironmentFactory.get(setEnvironmentDescription(listOfTechStacks.get(0)));
                checkForSDKStart();
                return BrowserFactory.attach(new BrowserDescription.Builder().title(pageTitle).type(BrowserType.valueOf(browser)).build());
            } catch(GeneralLeanFtException e) {
                try {
                    log.warn("Unable to set up LeanFT grid as especified. Defaulting to a local run");
                    DesktopContext.getInstance().setRunOnGrid(false);
                    updateLeanFTProperties(LOCAL);
                    checkForSDKStart();
                    return BrowserFactory.attach(new BrowserDescription.Builder().title(pageTitle).type(BrowserType.valueOf(browser)).build());
                } catch (GeneralLeanFtException ex) {
                    log.warn("Unable to find existing {} browser with title {}", browser, pageTitle);
                    return null;
                }
            }
        } else {
            try {
                checkForSDKStart();
                return BrowserFactory.attach(new BrowserDescription.Builder().title(pageTitle).type(BrowserType.valueOf(browser)).build());
            } catch (GeneralLeanFtException e) {
                log.warn("Unable to find existing {} browser with title {}", browser, pageTitle);
                return null;
            }

        }
    }

    public Browser openBrowser() {
        //todo: implement method to create Browser session
        try {
            throw new Exception("Browser session creation not implemented yet. Make sure browser is already opened.");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}