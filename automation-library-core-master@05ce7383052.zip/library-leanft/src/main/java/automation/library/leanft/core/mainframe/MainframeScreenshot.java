package automation.library.leanft.core.mainframe;

import automation.library.common.Property;
import automation.library.leanft.core.ScreenshotBase;
import com.hp.lft.sdk.GeneralLeanFtException;
import org.apache.commons.io.FileUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
import java.util.UUID;

import static automation.library.leanft.core.Constants.LEANFTRUNTIMEPATH;

public class MainframeScreenshot extends ScreenshotBase {
    private MainframeScreenshot() {
        //Utility class
    }

    /**
     * capture and return a file object.
     * @param screen
     */
    public static File grabScreenshot(LeanFTScreen screen) {
        File file = new File(String.format("%s%s", UUID.randomUUID(), ".png"));

        try {
            Thread.sleep(Property.getProperties(LEANFTRUNTIMEPATH).getInt("screenshotDelay", 0));
            if(screen.getScreen().exists()) {
                ImageIO.write(screen.getScreen().getSnapshot(), "PNG", file);
            } else if (screen.getParentWindow().getWindow().exists()){
                screen.getParentWindow().getWindow().activate();
                ImageIO.write(screen.getParentWindow().getWindow().getSnapshot(), "PNG", file);
            } else {
                getLogger().warn("Did not find TE screen specified. Skipping screenshot");
            }
        } catch (IOException | GeneralLeanFtException | InterruptedException e) {
            getLogger().error(e.getMessage());
            Thread.currentThread().interrupt();
        }
        return file;
    }

    private static Logger getLogger() {
        return LogManager.getLogger(ScreenshotBase.class);
    }
}
