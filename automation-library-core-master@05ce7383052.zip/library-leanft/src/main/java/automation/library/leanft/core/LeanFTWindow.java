package automation.library.leanft.core;

import com.hp.lft.sdk.GeneralLeanFtException;

/**
 * @deprecated This class is replaced by automation.library.leanft.core.mainframe.LeanFTWindow
 */
@Deprecated
public class LeanFTWindow extends automation.library.leanft.core.mainframe.LeanFTWindow {

    public LeanFTWindow(String name) throws GeneralLeanFtException {
        super(name);
    }
}
