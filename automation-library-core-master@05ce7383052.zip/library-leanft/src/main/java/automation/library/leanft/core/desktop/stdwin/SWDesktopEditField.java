package automation.library.leanft.core.desktop.stdwin;

import automation.library.leanft.core.Constants;
import automation.library.leanft.core.desktop.DesktopEditField;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.Keyboard;
import com.hp.lft.sdk.stdwin.EditField;
import com.hp.lft.sdk.stdwin.EditFieldDescription;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import static com.hp.lft.sdk.WaitUntilTestObjectState.waitUntil;

public class SWDesktopEditField extends DesktopEditField {
    private EditField object;
    private SWDesktopWindow parentWindow;
    private SWDesktopDialog parentDialog;
    private String accessibleName;

    protected final Logger log = LogManager.getLogger(this.getClass().getName());

    public SWDesktopEditField(String windowClassRegExp, String windowTitleRegExp, String accessibleName) throws GeneralLeanFtException {
        this.parentWindow = new SWDesktopWindow(windowClassRegExp,windowTitleRegExp);
        this.accessibleName =accessibleName;
        this.object = parentWindow.getWindow().describe(EditField.class, new EditFieldDescription.Builder()
                .accessibleName(accessibleName).build());

    }

    public SWDesktopEditField(SWDesktopDialog swDesktopDialog, String windowClassRegExp, int windowId) throws GeneralLeanFtException {
        this.parentDialog = swDesktopDialog;
        this.object = parentDialog.getDialog().describe(EditField.class, new EditFieldDescription.Builder()
                .windowClassRegExp(windowClassRegExp)
                .windowId(windowId).build());
    }

    public SWDesktopEditField(SWDesktopDialog swDesktopDialog, String windowClassRegExp, int windowId, int index) throws GeneralLeanFtException {
        this.parentDialog = swDesktopDialog;
        this.object = parentDialog.getDialog().describe(EditField.class, new EditFieldDescription.Builder()
                .windowClassRegExp(windowClassRegExp)
                .windowId(windowId)
                .index(index).build());
    }

    public EditField getEditField() {
        return this.object;
    }


    public DesktopEditField setText(String text, int... retries) throws GeneralLeanFtException {
        try {
            this.getEditField().setText(text);
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.setText(text, 0);
            } else {
                throw e;
            }
        }
        return this;
    }

    /**
     * searches again for the field using the by
     */
    public SWDesktopEditField refind(int... retries) {
        log.info("Attempting to refind the field: {}", accessibleName);
        int attempts = 0;
        Boolean retry = true;
        int maxRetry = retries.length > 0 ? retries[0] : getFindRetries();
        while (attempts < maxRetry && retry) {
            try {
                log.debug("retry number {}", attempts);
                waitUntil(this.getEditField(), testObject -> getEditField().exists());
                this.getEditField().getAccessibleName();
                retry = false;
            } catch (Exception e) {
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e1) {
                    log.debug(e1.getMessage());
                    Thread.currentThread().interrupt();
                }
            }
            attempts++;
        }
        return this;
    }


    public static int getFindRetries() {
        final int defaultFindRetries = 10;
        int refind;
        try {
            refind = Integer.parseInt(System.getProperty(Constants.DEFAULT_RETRIES));
        } catch (Exception e) {
            refind = defaultFindRetries;
        }
        return refind;
    }

    public SWDesktopEditField exists(int... retries) throws GeneralLeanFtException {
        {
            try {
                waitUntil(this.object, testObject -> object.exists());
            } catch (Exception e) {
                if (!(retries.length > 0 && retries[0] == 0)) {
                    this.refind(retries);
                    return this.exists(0);
                } else {
                    throw e;
                }
            }
            return this;
        }
    }

    /**
     *
     * @param retries
     * @return
     * @throws GeneralLeanFtException
     */
    public String getText(int... retries) throws GeneralLeanFtException {
        String str = null;
        try {
            str = this.object.getText();
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                return this.getText(0);
            } else {
                throw e;
            }
        }
        return str;
    }

    /**
     * @param retries
     * @return
     * @throws GeneralLeanFtException
     */
    public boolean isEnabled(int... retries) throws GeneralLeanFtException {
        boolean status = false;
        try {
            status= this.getEditField().isEnabled();
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.isEnabled(0);
            } else {
                throw e;
            }
        }
        return status;
    }

    @Override
    public DesktopEditField click(int... retries) throws GeneralLeanFtException {
        return null;
    }

    public DesktopEditField setString(String text, int... retries) throws GeneralLeanFtException {
    	try {
    	this.getEditField().click();
    	try{Thread.sleep(500);}catch(Exception e) {}
    	Keyboard.sendString(text);
    	try{Thread.sleep(500);}catch(Exception e) {}
    	Keyboard.pressKey(Keyboard.Keys.TAB);
    }catch(Exception e)
    {
    	if (!(retries.length > 0 && retries[0] == 0)) {
            this.refind(retries);
            this.setString(text, 0);
        }
    	else {
            throw e;
        }
    }
    	
    	return this;
    	
    }
}
