package automation.library.leanft.core.desktop;

import com.hp.lft.sdk.GeneralLeanFtException;

public abstract class DesktopButton extends DesktopObject {

    public abstract DesktopButton click(int...a) throws GeneralLeanFtException;
    public abstract DesktopButton doubleClick(int...a) throws GeneralLeanFtException;
    public abstract DesktopButton exists(int... retries) throws GeneralLeanFtException;
    public abstract boolean isEnabled(int... retries) throws GeneralLeanFtException;


}
