package automation.library.leanft.core.desktop.web;

import automation.library.leanft.core.desktop.DesktopObject;
import automation.library.leanft.core.desktop.DesktopWeb;
import automation.library.leanft.core.desktop.stdwin.SWDesktopWindow;
import automation.library.leanft.core.desktop.winforms.WFDesktopWindow;
import com.hp.lft.sdk.web.Browser;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.stdwin.Window;
import com.hp.lft.sdk.web.Page;
import com.hp.lft.sdk.web.PageDescription;

import static com.hp.lft.sdk.WaitUntilTestObjectState.waitUntil;

public class DesktopWebPageEmbedded extends DesktopWeb {

    private WFDesktopWindow parentWindow;
    private SWDesktopWindow parentSWWindow;
    private WebDesktopBrowserWindow parentBrowserWindow;
    private Page embeddedPage;

    public DesktopWebPageEmbedded(String windowObjectName,
                                  String fullType,
                                  String windowTitle) throws GeneralLeanFtException {
        this.parentWindow = new WFDesktopWindow(windowObjectName, windowTitle, fullType);

        this.embeddedPage = parentWindow.getWindow().describe(Page.class, new PageDescription());
    }

    public DesktopWebPageEmbedded(WFDesktopWindow wfDesktopWindow) throws GeneralLeanFtException {
        this.parentWindow = wfDesktopWindow;

        this.embeddedPage = parentWindow.getWindow().describe(Page.class, new PageDescription());
    }

    public DesktopWebPageEmbedded(WFDesktopWindow wfDesktopWindow, SWDesktopWindow swDesktopWindow) throws GeneralLeanFtException {
        this.parentWindow = wfDesktopWindow;
        this.embeddedPage = parentWindow.getWindow().describe(Window.class, swDesktopWindow.getWindow().getDescription()).describe(Page.class, new PageDescription());
    }

    public DesktopWebPageEmbedded(SWDesktopWindow swDesktopWindow) throws GeneralLeanFtException {
        this.parentSWWindow = swDesktopWindow;

        this.embeddedPage = parentWindow.getWindow().describe(Page.class, new PageDescription());
    }

    public DesktopWebPageEmbedded(WebDesktopBrowserWindow webDesktopBrowserWindow, String pageTitle) throws GeneralLeanFtException {
        this.parentBrowserWindow = webDesktopBrowserWindow;
        this.embeddedPage = parentBrowserWindow.getWindow().describe(Page.class, new PageDescription.Builder()
                                                                                        .title(pageTitle).build());
    }
    public Page getEmbeddedPage() {
        return embeddedPage;
    }

    @Override
    public DesktopObject exists(int... retries) throws GeneralLeanFtException {
        try {
            waitUntil(this.embeddedPage, testObject -> embeddedPage.exists());
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                return this.exists(0);
            } else {
                throw e;
            }
        }
        return this;
    }

    @Override
    public boolean isEnabled(int... retries) throws GeneralLeanFtException {
        return false;
    }

    @Override
    public DesktopWeb doubleClick(int... retries) throws GeneralLeanFtException {
        return null;
    }

    @Override
    public DesktopWeb click(int... retries) throws GeneralLeanFtException {
        return null;
    }

    @Override
    public DesktopWeb hover(int... retries) throws GeneralLeanFtException {
        return null;
    }

    @Override
    public String getText(int... retries) throws GeneralLeanFtException {
        return null;
    }

    @Override
    public DesktopWeb select(String value, int... retries) throws GeneralLeanFtException {
        return null;
    }

    @Override
    public DesktopWeb select(int index, int... retries) throws GeneralLeanFtException {
        return null;
    }

    @Override
    public DesktopWeb setText(String text, int... retries) throws GeneralLeanFtException {
        return null;
    }
}
