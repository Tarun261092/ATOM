package automation.library.leanft.core.desktop;

import com.hp.lft.sdk.GeneralLeanFtException;

public abstract class DesktopTabControl extends DesktopObject {

    public abstract DesktopTabControl select(String name,int... retries) throws GeneralLeanFtException;
    public abstract DesktopTabControl exists(int... retries) throws GeneralLeanFtException;
    public abstract boolean isEnabled(int... retries) throws GeneralLeanFtException;


}
