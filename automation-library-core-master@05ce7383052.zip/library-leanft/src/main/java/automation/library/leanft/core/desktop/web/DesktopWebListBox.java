package automation.library.leanft.core.desktop.web;

import automation.library.common.Property;
import automation.library.leanft.core.Constants;
import automation.library.leanft.core.desktop.DesktopObject;
import automation.library.leanft.core.desktop.DesktopWeb;
import automation.library.leanft.core.desktop.stdwin.SWDesktopWindow;
import automation.library.leanft.core.desktop.winforms.WFDesktopWindow;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.GeneralReplayException;
import com.hp.lft.sdk.web.*;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import static com.hp.lft.sdk.WaitUntilTestObjectState.waitUntil;

public class DesktopWebListBox extends DesktopWeb {

    private DesktopWebPageEmbedded desktopWebPage;
    private ListBox listBox;
    private String locatorText;
    private WebDesktopBrowserWindow parentWindow;
    private DesktopWebFrame desktopWebFrame;

    protected final Logger log = LogManager.getLogger(this.getClass().getName());

    
    public DesktopWebListBox() {
	}

	public DesktopWebListBox(String windowObjectName,
                             String fullType,
                             String windowTitle,
                             String locatorText,
                             LocatorType locatorType) throws GeneralLeanFtException {
        this.desktopWebPage = new DesktopWebPageEmbedded(windowObjectName, windowTitle, fullType);
        this.locatorText = locatorText;
        this.listBox = desktopWebPage.getEmbeddedPage()
                                 .describe(ListBox.class,
                                           getLocatorObject(locatorText, locatorType));
    }

    public DesktopWebListBox(WFDesktopWindow parentWindow,
                             String locatorText,
                             LocatorType locatorType) throws GeneralLeanFtException {
        this.desktopWebPage = new DesktopWebPageEmbedded(parentWindow);
        this.locatorText = locatorText;
        this.listBox = desktopWebPage.getEmbeddedPage()
                                 .describe(ListBox.class,
                                           getLocatorObject(locatorText, locatorType));
    }

    public DesktopWebListBox(WFDesktopWindow parentWindow,
                             SWDesktopWindow swDesktopWindow,
                             String locatorText,
                             LocatorType locatorType) throws GeneralLeanFtException {
        this.desktopWebPage = new DesktopWebPageEmbedded(parentWindow, swDesktopWindow);
        this.locatorText = locatorText;
        this.listBox = desktopWebPage.getEmbeddedPage()
                                 .describe(ListBox.class,
                                           getLocatorObject(locatorText, locatorType));
    }

    public DesktopWebListBox(String title, String browserType, String name,String xpath) throws GeneralLeanFtException {
        this.parentWindow = new WebDesktopBrowserWindow(title, browserType);
        this.listBox = parentWindow.getWindow().describe(ListBox.class, new ListBoxDescription.Builder()
                .name(name).xpath(xpath).build());

    }
    
    public DesktopWebListBox(WebDesktopBrowserWindow parentWindow, String locatorText, LocatorType locatorType) throws GeneralLeanFtException {
        this.parentWindow = parentWindow;
        this.listBox = parentWindow.getWindow().describe(ListBox.class, getLocatorObject(locatorText, locatorType));
    }

    public DesktopWebListBox(DesktopWebPageEmbedded desktopWebPage, String locatorText, LocatorType locatorType) throws GeneralLeanFtException {
        this.desktopWebPage = desktopWebPage;
        this.listBox = desktopWebPage.getEmbeddedPage().describe(ListBox.class, getLocatorObject(locatorText, locatorType));
    }

    public DesktopWebListBox(DesktopWebFrame desktopWebFrame, String locatorText, LocatorType locatorType) throws GeneralLeanFtException {
        this.desktopWebFrame = desktopWebFrame;
        this.listBox = desktopWebFrame.getFrame().describe(ListBox.class, getLocatorObject(locatorText, locatorType));
    }
    
    public WebElement checkVisiblityOfListBoxInFrame(String title, String browserType, String frameName, String xpath)
			throws GeneralLeanFtException {
		String numberOfRetries = "";
		int count = 1;
		locatorText = xpath;
		boolean visible = false;
		numberOfRetries = Property.getProperty(Constants.LEANFTRUNTIMEPATH, "defaultWait");
		if(numberOfRetries==null || numberOfRetries.equals("0")) {
			numberOfRetries = "40";
		}
		log.info("Trying to find the element with LocaterText: {}", locatorText);
		while(count<Integer.parseInt(numberOfRetries))
		{
			try {
				this.parentWindow = new WebDesktopBrowserWindow(title, browserType);
				this.listBox = parentWindow.getWindow().
			                describe(Frame.class, new FrameDescription.Builder()
			               .name(frameName).build()).
			                describe(ListBox.class,new ListBoxDescription.Builder().xpath(xpath).build());
				waitUntil(this.getListBox(), testObject -> getListBox().exists());
	            this.getListBox().getId();
				visible = true;
				log.info("Element Located successfully with LocaterText: {}", locatorText);			
			
			} catch (Exception e) {
				try {
					Thread.sleep(1000);
					count = count + 1;
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
				
			}
			if(visible == true) {
				log.info("The element was found in "+count+" attempts");
				break;
			}
		}		
		if(visible==false)
		{
			log.info("Unable to find the element with LocaterText: {}", locatorText);
		}
		return this.listBox;
		
	}
    
    public WebElement checkVisiblityOfListBox(String title, String browserType, String xpath)
			throws GeneralLeanFtException {
		String numberOfRetries = "";
		int count = 1;
		locatorText = xpath;
		boolean visible = false;
		numberOfRetries = Property.getProperty(Constants.LEANFTRUNTIMEPATH, "defaultWait");
		if(numberOfRetries==null || numberOfRetries.equals("0")) {
			numberOfRetries = "40";
		}
		log.info("Trying to find the element with LocaterText: {}", locatorText);
		while(count<Integer.parseInt(numberOfRetries))
		{
			try {
				this.parentWindow = new WebDesktopBrowserWindow(title, browserType);
				this.listBox = this.parentWindow.getWindow().describe(ListBox.class,new ListBoxDescription.Builder().xpath(xpath).build());
				waitUntil(this.getListBox(), testObject -> getListBox().exists());
                this.getListBox().getId();
				visible = true;
				log.info("Element Located successfully with LocaterText: {}", locatorText);			
			
			} catch (Exception e) {
				try {
					Thread.sleep(1000);
					count = count + 1;
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
				
			}
			if(visible == true) {
				log.info("The element was found in "+count+" attempts");
				break;
			}
		}		
		if(visible==false)
		{
			log.info("Unable to find the element with LocaterText: {}", locatorText);
		}
		return this.listBox;
		
	}
    
    private ListBoxDescription getLocatorObject(String locatorText, LocatorType locatorType) {
        switch (locatorType) {
            case CSS:
                return new ListBoxDescription.Builder()
                        .cssSelector(locatorText)
                        .build();
            case XPATH:
                return new ListBoxDescription.Builder()
                        .xpath(locatorText)
                        .build();
            case ID:
                return new ListBoxDescription.Builder()
                        .id(locatorText)
                        .build();
            case TAGNAME:
                return new ListBoxDescription.Builder()
                        .tagName(locatorText)
                        .build();
            default:
                throw new IllegalArgumentException("Unrecognized locator type: " + locatorType.getLocatorTagName());

        }
    }

    public ListBox getListBox() {
        return listBox;
    }

    @Override
    public DesktopObject exists(int... retries) throws GeneralLeanFtException {
        try {
            waitUntil(this.listBox, testObject -> listBox.exists());
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                return this.exists(0);
            } else {
                throw e;
            }
        }
        return this;
    }

    @Override
    public boolean isEnabled(int... retries) throws GeneralLeanFtException {
        return false;
    }

    @Override
    public DesktopWeb doubleClick(int... retries) throws GeneralLeanFtException {
        return null;
    }

    @Override
    public DesktopWeb click(int... retries) throws GeneralLeanFtException {
        try {
            this.getListBox().click();
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.click(0);
            } else {
                throw e;
            }
        }
        return this;
    }

    @Override
    public DesktopWeb hover(int... retries) throws GeneralLeanFtException {
        return null;
    }

    @Override
    public String getText(int... retries) throws GeneralLeanFtException {
        return null;
    }

    @Override
    public DesktopWeb setText(String text, int... retries) throws GeneralLeanFtException {
        return null;
    }

    public DesktopWebListBox refind(int... retries) {
        log.info("Attempting to refind the field: {}", locatorText);
        int attempts = 0;
        boolean retry = true;
        int maxRetry = retries.length > 0 ? retries[0] : getFindRetries();
        while (attempts < maxRetry && retry) {
            try {
                log.debug("retry number {}", attempts);
                waitUntil(this.getListBox(), testObject -> getListBox().exists());
                this.getListBox().getId();
                retry = false;
            } catch (Exception e) {
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e1) {
                    log.debug(e1.getMessage());
                    Thread.currentThread().interrupt();
                }
            }
            attempts++;
        }
        return this;
    }

    public static int getFindRetries() {
        final int defaultFindRetries = 10;
        int refind;
        try {
            refind = Integer.parseInt(System.getProperty(Constants.DEFAULT_RETRIES));
        } catch (Exception e) {
            refind = defaultFindRetries;
        }
        return refind;
    }

    public DesktopWeb select(String value, int... retries) throws GeneralLeanFtException {
        try {
            this.getListBox().select(value);
        } catch (GeneralReplayException e) {
            this.getListBox().extendSelect(value);
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.select(value, 0);
            } else {
                throw e;
            }
        }
        return this;
    }

    @Override
    public DesktopWeb select(int index, int... retries) throws GeneralLeanFtException {
        return null;
    }

}
