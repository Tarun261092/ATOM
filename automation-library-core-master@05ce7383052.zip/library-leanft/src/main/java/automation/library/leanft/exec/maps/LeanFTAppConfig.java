package automation.library.leanft.exec.maps;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.Map;

public class LeanFTAppConfig {
    @SerializedName("listOfApps")
    @Expose
    private Map<String, App> appList;
    @SerializedName("desktopApplications")
    @Expose
    private Map<String, DesktopApplication> desktopApplications;
    @SerializedName("terminalEmulator")
    @Expose
    private Map<String, DesktopApplication> terminalEmulators;

    public Map<String, App> getAppList() {
        return appList;
    }

    public void setAppList(Map<String, App> appList) {
        this.appList = appList;
    }

    public Map<String, DesktopApplication> getDesktopApplications() {
        return desktopApplications;
    }

    public void setDesktopApplications(Map<String, DesktopApplication> desktopApplications) {
        this.desktopApplications = desktopApplications;
    }
    public Map<String, DesktopApplication> getTerminalEmulators() {
        return terminalEmulators;
    }

    public void setTerminalEmulators(Map<String, DesktopApplication> terminalEmulators) {
        this.terminalEmulators = terminalEmulators;
    }
}
