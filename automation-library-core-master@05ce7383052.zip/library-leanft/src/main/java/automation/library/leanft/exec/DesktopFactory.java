package automation.library.leanft.exec;

import automation.library.leanft.exec.managers.*;
import automation.library.reporting.Reporter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class DesktopFactory {
    private Logger log = LogManager.getLogger(this.getClass().getName());

    private DesktopFactory() {
    }

    public static DesktopManager createDesktopDriver(String appName) {
        return new DesktopFactory().setDesktop(appName);
    }

    private DesktopManager setDesktop(String appName) {
        DesktopType desktopAppName = DesktopType.get(DesktopContext.getInstance().getEmulatorName(appName));

        switch(desktopAppName) {
            case PCOM:
                return new PCOMManager();
            case HOD:
               return new HODManager();
            case AVAYA:
                return new DesktopAppManager();
            case RPLID:
                return new RPLIDManager();
            case WINFORM:
                return new DesktopAppManager();
            case JAVA:
                return new DesktopAppManager();
            case FIRFLY:
                return new DesktopAppManager();
            case CONCIERGE:
                return new DesktopAppManager();
            case SALESFORCEDESKTOP:
                return new DesktopAppManager();
            case TIGRA:
                return new DesktopAppManager();
            case WEBBROWSER:
                return new BrowserManager();
            default:
                String errorMsg = String.format("Unrecognized terminal emulator: %s", desktopAppName);
                log.error(errorMsg);
                Reporter.addStepLog("FAIL",errorMsg);
                throw new IllegalArgumentException(errorMsg);
        }
    }
}
