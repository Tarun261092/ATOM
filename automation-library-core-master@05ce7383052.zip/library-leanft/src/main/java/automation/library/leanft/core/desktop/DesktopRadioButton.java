package automation.library.leanft.core.desktop;

import com.hp.lft.sdk.GeneralLeanFtException;

public abstract class DesktopRadioButton extends DesktopObject {

    public abstract DesktopRadioButton click(int...a) throws GeneralLeanFtException;
    public abstract DesktopRadioButton exists(int... retries) throws GeneralLeanFtException;
    public abstract boolean isEnabled(int... retries) throws GeneralLeanFtException;
    public abstract DesktopRadioButton select(int index, int... retries) throws GeneralLeanFtException;
    public abstract DesktopRadioButton select(String value, int... retries) throws GeneralLeanFtException;
}
