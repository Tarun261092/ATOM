package automation.library.leanft.core.desktop.winforms;

import automation.library.leanft.core.Constants;
import automation.library.leanft.core.desktop.DesktopTable;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.winforms.Table;
import com.hp.lft.sdk.winforms.TableDescription;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import static com.hp.lft.sdk.WaitUntilTestObjectState.waitUntil;

public class WFDesktopTable extends DesktopTable {

    private WFDesktopWindow parentUiObj;
    private Table table;
    private String objectName;

    protected final Logger log = LogManager.getLogger(this.getClass().getName());


    public WFDesktopTable(String windowObjectName, String fullType, String tableObjectName) throws GeneralLeanFtException {
        this.parentUiObj = new WFDesktopWindow(windowObjectName, fullType);
        this.objectName = tableObjectName;
        this.table = parentUiObj.getWindow().describe(Table.class, new TableDescription.Builder()
                .objectName(tableObjectName)
                .build());

    }

    public WFDesktopTable(WFDesktopWindow parentWindow, String fullType, String objectName) throws GeneralLeanFtException {
        this.parentUiObj = parentWindow;
        this.objectName = objectName;
        this.table = parentUiObj.getWindow().describe(Table.class, new TableDescription.Builder()
                .objectName(objectName)
                .fullType(fullType)
                .build());
    }

    public Table getDesktopTable() {
        return this.table;
    }


    public WFDesktopTable click(int... retries) throws GeneralLeanFtException {
        try {
            this.getDesktopTable().click();
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.click(0);
            } else {
                throw e;
            }
        }
        return this;
    }

    public String getCellText(int row, int col, int... retries) throws GeneralLeanFtException {
        String str = null;
        try {
            str = String.valueOf(this.getDesktopTable().getCustomGrid().getDataGrid().getRows().get(row).getCells().get(col).getValue());
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.getCellText(row, col, 0);
            } else {
                throw e;
            }
        }
        return str;
    }

    public DesktopTable clickCell(int row, int col, int... retries) throws GeneralLeanFtException {
        try {
            this.getDesktopTable().activateCell(row, col);
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.clickCell(row, col, 0);
            } else {
                throw e;
            }
        }
        return this;
    }

    /**
     * select row value based on column
     */
    public String selectMatchingRow(int secondColumn, int firstColumn, String firstRow, int... retries) throws GeneralLeanFtException {
        String str = null;
        String str1 = null;
        try {
            for (int i = 0; i < this.getDesktopTable().getCustomGrid().getDataGrid().getRows().size(); i++) {
                str = String.valueOf(this.getDesktopTable().getCustomGrid().getDataGrid().getRows().get(i).getCells().get(firstColumn).getValue());
                if (str.equalsIgnoreCase(firstRow)) {
                    log.info("Matching cell Value is {}", str);
                    //click on next cell with row num
                    str1 = String.valueOf(this.getDesktopTable().getCustomGrid().getDataGrid().getRows().get(i).getCells().get(secondColumn).getValue());
                    this.getDesktopTable().selectCell(i, secondColumn);
                    break;
                }
            }
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.selectMatchingRow(secondColumn, firstColumn, firstRow, 0);
            } else {
                throw e;
            }
        }
        return str1;
    }

    /**
     * searches again for the field using the by
     */
    public WFDesktopTable refind(int... retries) {
        log.info("Attempting to refind the field: {}", objectName);
        int attempts = 0;
        boolean retry = true;
        int maxRetry = retries.length > 0 ? retries[0] : getFindRetries();
        while (attempts < maxRetry && retry) {
            try {
                log.debug("retry number {}", attempts);
                waitUntil(this.getDesktopTable(), testObject -> getDesktopTable().exists());
                this.getDesktopTable().getObjectName();
                retry = false;
            } catch (Exception e) {
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e1) {
                    log.debug(e1.getMessage());
                    Thread.currentThread().interrupt();
                }
            }
            attempts++;
        }
        return this;
    }

    public static int getFindRetries() {
        final int defaultFindRetries = 10;
        int refind;
        try {
            refind = Integer.parseInt(System.getProperty(Constants.DEFAULT_RETRIES));
        } catch (Exception e) {
            refind = defaultFindRetries;
        }
        return refind;
    }

    /**
     * @param retries
     * @return
     * @throws GeneralLeanFtException
     */
    public WFDesktopTable exists(int... retries) throws GeneralLeanFtException {
        try {
            waitUntil(this.table, testObject -> table.exists());
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                return this.exists(0);
            } else {
                throw e;
            }
        }
        return this;
    }

    /**
     * @param retries
     * @return
     * @throws GeneralLeanFtException
     */
    public boolean isEnabled(int... retries) throws GeneralLeanFtException {
        boolean status = false;
        try {
            status = this.getDesktopTable().isEnabled();
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.isEnabled(0);
            } else {
                throw e;
            }
        }
        return status;
    }

}


