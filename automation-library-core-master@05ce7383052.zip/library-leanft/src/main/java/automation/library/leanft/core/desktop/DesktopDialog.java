package automation.library.leanft.core.desktop;

import com.hp.lft.sdk.stdwin.Dialog;

public abstract class DesktopDialog extends DesktopObject {

    public abstract Dialog getDialog();


}
