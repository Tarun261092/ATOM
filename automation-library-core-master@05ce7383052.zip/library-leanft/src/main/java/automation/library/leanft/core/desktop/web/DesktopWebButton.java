package automation.library.leanft.core.desktop.web;

import automation.library.common.Property;
import automation.library.leanft.core.Constants;
import automation.library.leanft.core.desktop.DesktopButton;
import automation.library.leanft.core.desktop.stdwin.SWDesktopWindow;
import automation.library.leanft.core.desktop.winforms.WFDesktopWindow;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.web.BrowserDescription;
import com.hp.lft.sdk.web.BrowserFactory;
import com.hp.lft.sdk.web.BrowserType;
import com.hp.lft.sdk.web.Button;
import com.hp.lft.sdk.web.ButtonDescription;
import com.hp.lft.sdk.web.Frame;
import com.hp.lft.sdk.web.FrameDescription;
import com.hp.lft.sdk.web.WebElement;
import com.hp.lft.sdk.web.WebElementDescription;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import static com.hp.lft.sdk.WaitUntilTestObjectState.waitUntil;

public class DesktopWebButton extends DesktopButton {
	private WebElement webElement;
    private DesktopWebPageEmbedded desktopWebPage;
    private Button button;
    private String locatorText;
    private WebDesktopBrowserWindow parentWindow;
    private DesktopWebFrame desktopWebFrame;


    protected final Logger log = LogManager.getLogger(this.getClass().getName());
    
     public DesktopWebButton() {
		
	}

	public DesktopWebButton(String windowObjectName,
                             String fullType,
                             String windowTitle,
                             String locatorText,
                             LocatorType locatorType) throws GeneralLeanFtException {
        this.desktopWebPage = new DesktopWebPageEmbedded(windowObjectName, windowTitle, fullType);
        this.locatorText = locatorText;
        this.button = desktopWebPage.getEmbeddedPage()
                .describe(Button.class,
                        getLocatorObject(locatorText, locatorType));
    }

    public DesktopWebButton(WFDesktopWindow parentWindow,
                             String locatorText,
                             LocatorType locatorType) throws GeneralLeanFtException {
        this.desktopWebPage = new DesktopWebPageEmbedded(parentWindow);
        this.locatorText = locatorText;
        this.button = desktopWebPage.getEmbeddedPage()
                .describe(Button.class,
                        getLocatorObject(locatorText, locatorType));
    }

    public DesktopWebButton(WFDesktopWindow parentWindow,
                             SWDesktopWindow swDesktopWindow,
                             String locatorText,
                             LocatorType locatorType) throws GeneralLeanFtException {
        this.desktopWebPage = new DesktopWebPageEmbedded(parentWindow, swDesktopWindow);
        this.locatorText = locatorText;
        this.button = desktopWebPage.getEmbeddedPage()
                .describe(Button.class,
                        getLocatorObject(locatorText, locatorType));
    }
    public DesktopWebButton(String title, String browserType, String name,String xpath) throws GeneralLeanFtException {
        this.parentWindow = new WebDesktopBrowserWindow(title, browserType);
        this.button = parentWindow.getWindow().describe(Button.class, new ButtonDescription.Builder()
                .name(name).xpath(xpath).build());

    }

    public WebElement checkVisiblityOfButtonInFrame(String title, String browserType, String frameName, String xpath)
			throws GeneralLeanFtException {
		String numberOfRetries = "";
		int count = 1;
		locatorText = xpath;
		boolean visible = false;
		numberOfRetries = Property.getProperty(Constants.LEANFTRUNTIMEPATH, "defaultWait");
		if(numberOfRetries==null || numberOfRetries.equals("0")) {
			numberOfRetries = "40";
		}
		log.info("Trying to find the element with LocaterText: {}", locatorText);
		while(count<Integer.parseInt(numberOfRetries))
		{
			try {
				this.parentWindow = new WebDesktopBrowserWindow(title, browserType);
				this.button = parentWindow.getWindow().
			                describe(Frame.class, new FrameDescription.Builder()
			               .name(frameName).build()).
			                describe(Button.class,new ButtonDescription.Builder().xpath(xpath).build());
				waitUntil(this.getButton(), testObject -> getButton().exists());
                this.getButton().getId();
				visible = true;
				log.info("Element Located successfully with LocaterText: {}", locatorText);			
			
			} catch (Exception e) {
				try {
					Thread.sleep(1000);
					count = count + 1;
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
				
			}
			if(visible == true) {
				log.info("The element was found in "+count+" attempts");
				break;
			}
		}		
		if(visible==false)
		{
			log.info("Unable to find the element with LocaterText: {}", locatorText);
		}
		return this.button;
		
	}
    
    public WebElement checkVisiblityOfButton(String title, String browserType, String xpath)
			throws GeneralLeanFtException {
		String numberOfRetries = "";
		int count = 1;
		locatorText = xpath;
		boolean visible = false;
		numberOfRetries = Property.getProperty(Constants.LEANFTRUNTIMEPATH, "defaultWait");
		if(numberOfRetries==null || numberOfRetries.equals("0")) {
			numberOfRetries = "40";
		}
		log.info("Trying to find the element with LocaterText: {}", locatorText);
		while(count<Integer.parseInt(numberOfRetries))
		{
			try {				
				this.parentWindow = new WebDesktopBrowserWindow(title, browserType);
				this.button = this.parentWindow.getWindow().describe(Button.class,new ButtonDescription.Builder().xpath(xpath).build());
				waitUntil(this.getButton(), testObject -> getButton().exists());
				this.getButton().getId();
				visible = true;
				log.info("Element Located successfully with LocaterText: {}", locatorText);			
			
			} catch (Exception e) {
				try {
					Thread.sleep(1000);
					count = count + 1;
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
				
			}
			if(visible == true) {
				log.info("The element was found in "+count+" attempts");
				break;
			}
		}		
		if(visible==false)
		{
			log.info("Unable to find the element with LocaterText: {}", locatorText);
		}
		return this.button;
		
	}
    
    public DesktopWebButton(String title, String browserType, String locatorText,LocatorType locatorType) throws GeneralLeanFtException {
        this.parentWindow = new WebDesktopBrowserWindow(title, browserType);
        this.button = parentWindow.getWindow().describe(Button.class,getLocatorObject(locatorText, locatorType));
    }

    public DesktopWebButton(WebDesktopBrowserWindow window, String framename,String locatorText,LocatorType locatorType) throws GeneralLeanFtException {
        this.parentWindow = window;
        this.button = parentWindow.getWindow().
                describe(Frame.class, new FrameDescription.Builder()
               .name(framename).build()).
                describe(Button.class,getLocatorObject(locatorText, locatorType));
    }

    public DesktopWebButton(WebDesktopBrowserWindow parentWindow, String name,String xpath) throws GeneralLeanFtException {
        this.parentWindow = parentWindow;
        this.button = parentWindow.getWindow().describe(Button.class, new ButtonDescription.Builder()
                .name(name).xpath(xpath).build());

    }
    
    
    public DesktopWebButton(WebDesktopBrowserWindow parentWindow, String locatorText, LocatorType locatorType) throws GeneralLeanFtException {
        this.parentWindow = parentWindow;
        this.button = parentWindow.getWindow().describe(Button.class, getLocatorObject(locatorText, locatorType));
    }

    public DesktopWebButton(DesktopWebFrame desktopWebFrame, String locatorText, LocatorType locatorType) throws GeneralLeanFtException {
        this.desktopWebFrame = desktopWebFrame;
        this.button = desktopWebFrame.getFrame().describe(Button.class, getLocatorObject(locatorText, locatorType));
    }

    public DesktopWebButton(DesktopWebPageEmbedded desktopWebPage, String locatorText, LocatorType locatorType) throws GeneralLeanFtException {
        this.desktopWebPage = desktopWebPage;
        this.button = desktopWebPage.getEmbeddedPage().describe(Button.class, getLocatorObject(locatorText, locatorType));
    }
    
    
    
    
    
    private ButtonDescription getLocatorObject(String locatorText, LocatorType locatorType) {
        switch (locatorType) {
            case CSS:
                return new ButtonDescription.Builder()
                        .cssSelector(locatorText)
                        .build();
            case XPATH:
                return new ButtonDescription.Builder()
                        .xpath(locatorText)
                        .build();
            case ID:
                return new ButtonDescription.Builder()
                        .id(locatorText)
                        .build();
            case TAGNAME:
                return new ButtonDescription.Builder()
                        .tagName(locatorText)
                        .build();
            case NAME:
                return new ButtonDescription.Builder()
                        .name(locatorText)
                        .build();
            default:
                throw new IllegalArgumentException("Unrecognized locator type: " + locatorType.getLocatorTagName());

        }
    }

    public Button getButton() {
        return button;
    }

    @Override
    public DesktopButton exists(int... retries) throws GeneralLeanFtException {
        try {
            waitUntil(this.button, testObject -> button.exists());
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                return this.exists(0);
            } else {
                throw e;
            }
        }
        return this;
    }

    @Override
    public boolean isEnabled(int... retries) throws GeneralLeanFtException {
        return false;
    }

    public DesktopWebButton refind(int... retries) {
        log.info("Attempting to refind the field: {}", locatorText);
        int attempts = 0;
        boolean retry = true;
        int maxRetry = retries.length > 0 ? retries[0] : getFindRetries();
        while (attempts < maxRetry && retry) {
            try {
                log.debug("retry number {}", attempts);
                waitUntil(this.getButton(), testObject -> getButton().exists());
                this.getButton().getId();
                retry = false;
            } catch (Exception e) {
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e1) {
                    log.debug(e1.getMessage());
                    Thread.currentThread().interrupt();
                }
            }
            attempts++;
        }
        return this;
    }

    public static int getFindRetries() {
        final int defaultFindRetries = 10;
        int refind;
        try {
            refind = Integer.parseInt(System.getProperty(Constants.DEFAULT_RETRIES));
        } catch (Exception e) {
            refind = defaultFindRetries;
        }
        return refind;
    }

    public DesktopButton click(int... retries) throws GeneralLeanFtException {
        try {
            this.getButton().click();
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.click(0);
            } else {
                throw e;
            }
        }
        return this;
    }

    public DesktopButton doubleClick(int... retries) throws GeneralLeanFtException {
        try {
            this.getButton().doubleClick();
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.doubleClick(0);
            } else {
                throw e;
            }
        }
        return this;
    }
}

