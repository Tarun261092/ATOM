package automation.library.leanft.core.desktop.winforms;

import automation.library.leanft.core.Constants;
import automation.library.leanft.core.desktop.DesktopRadioButton;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.winforms.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import static com.hp.lft.sdk.WaitUntilTestObjectState.waitUntil;

public class WFDesktopRadioButton extends DesktopRadioButton {

    private WFDesktopWindow parentUiObj;
    private RadioButton radioButton;
    private String objectName;

    protected final Logger log = LogManager.getLogger(this.getClass().getName());

    public WFDesktopRadioButton(String windowObjectName,String windowTitleExp, String fullType,String objectName) throws GeneralLeanFtException {
        this.parentUiObj = new WFDesktopWindow(windowObjectName,windowTitleExp,fullType);
        this.objectName = objectName;
        this.radioButton = parentUiObj.getWindow().describe(RadioButton.class, new RadioButtonDescription.Builder()
                .objectName(objectName).build());
    }

    public WFDesktopRadioButton(String windowObjectName, String windowFullType, String text) throws GeneralLeanFtException {
        this.parentUiObj = new WFDesktopWindow(windowObjectName, windowFullType);
        this.radioButton = parentUiObj.getWindow().describe(RadioButton.class, new RadioButtonDescription.Builder()
                .text(text).build());
    }

    public RadioButton getDesktopRadioButton() {
        return this.radioButton;
    }
    /**
     * @param retries
     * @return
     * @throws GeneralLeanFtException
     */
    public DesktopRadioButton click(int... retries) throws GeneralLeanFtException {
        try {
            this.getDesktopRadioButton().click();
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.click(0);
            } else {
                throw e;
            }
        }
        return this;
    }
    /**
     * searches again for the field using the by
     */
    public WFDesktopRadioButton refind(int... retries) {
        log.info("Attempting to refind the field: {}", objectName);
        int attempts = 0;
        boolean retry = true;
        int maxRetry = retries.length > 0 ? retries[0] : getFindRetries();
        while (attempts < maxRetry && retry) {
            try {
                log.debug("retry number {}", attempts);
                waitUntil(this.getDesktopRadioButton(), testObject -> getDesktopRadioButton().exists());
                this.getDesktopRadioButton().getObjectName();
                retry = false;
            } catch (Exception e) {
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e1) {
                    log.debug(e1.getMessage());
                    Thread.currentThread().interrupt();
                }
            }
            attempts++;
        }
        return this;
    }
    public static int getFindRetries() {
        final int defaultFindRetries = 10;
        int refind;
        try {
            refind = Integer.parseInt(System.getProperty(Constants.DEFAULT_RETRIES));
        } catch (Exception e) {
            refind = defaultFindRetries;
        }
        return refind;
    }

    /**
     * @param retries
     * @return
     * @throws GeneralLeanFtException
     */
    public WFDesktopRadioButton exists(int... retries) throws GeneralLeanFtException {
        try {
            waitUntil(this.radioButton, testObject -> radioButton.exists());
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                return this.exists(0);
            } else {
                throw e;
            }
        }
        return this;
    }

    /**
     * @param retries
     * @return
     * @throws GeneralLeanFtException
     */
    public boolean isEnabled(int... retries) throws GeneralLeanFtException {
        boolean status = false;
        try {
            status= this.getDesktopRadioButton().isEnabled();
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.isEnabled(0);
            } else {
                throw e;
            }
        }
        return status;
    }

    @Override
    public DesktopRadioButton select(int index, int... retries) throws GeneralLeanFtException {
        return null;
    }

    @Override
    public DesktopRadioButton select(String value, int... retries) throws GeneralLeanFtException {
        return null;
    }
}
