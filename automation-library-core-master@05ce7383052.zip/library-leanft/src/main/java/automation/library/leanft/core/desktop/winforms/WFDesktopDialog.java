package automation.library.leanft.core.desktop.winforms;

import automation.library.leanft.core.desktop.DesktopDialog;
import automation.library.leanft.core.desktop.DesktopObject;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.stdwin.Dialog;

public class WFDesktopDialog extends DesktopDialog {
    public Dialog getDialog() {
        return null;
    }

    @Override
    public DesktopObject exists(int... retries) throws GeneralLeanFtException {
        return null;
    }

    @Override
    public boolean isEnabled(int... retries) throws GeneralLeanFtException {
        return false;
    }
}
