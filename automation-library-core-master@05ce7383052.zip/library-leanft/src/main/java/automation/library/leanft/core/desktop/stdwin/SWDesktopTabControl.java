package automation.library.leanft.core.desktop.stdwin;

import automation.library.leanft.core.desktop.DesktopTabControl;
import com.hp.lft.sdk.GeneralLeanFtException;

public class SWDesktopTabControl extends DesktopTabControl {
    @Override
    public DesktopTabControl select(String name, int... retries) throws GeneralLeanFtException {
        return null;
    }

    @Override
    public DesktopTabControl exists(int... retries) throws GeneralLeanFtException {
        return null;
    }

    @Override
    public boolean isEnabled(int... retries) throws GeneralLeanFtException {
        return false;
    }
}
