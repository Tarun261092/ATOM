package automation.library.leanft.core.desktop.stdwin;

import automation.library.leanft.core.Constants;
import automation.library.leanft.core.desktop.DesktopButton;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.stdwin.Button;
import com.hp.lft.sdk.stdwin.ButtonDescription;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import static com.hp.lft.sdk.WaitUntilTestObjectState.waitUntil;

public class SWDesktopButton extends DesktopButton {

    private SWDesktopWindow parentUiObj;
    private SWDesktopDialog parentDialog;
    private Button button;
    private String accessibleName;
    protected final Logger log = LogManager.getLogger(this.getClass().getName());

    public SWDesktopButton(String windowClassRegExp, String text, int index, String accessibleName) throws GeneralLeanFtException {
        this.parentUiObj = new SWDesktopWindow(windowClassRegExp, text, index);
        this.accessibleName = accessibleName;
        this.button = parentUiObj.getWindow().describe(Button.class, new ButtonDescription.Builder()
                .accessibleName(accessibleName).build());
    }

    public SWDesktopButton(SWDesktopDialog swDesktopDialog, String text, int index) throws GeneralLeanFtException {
        this.parentDialog = swDesktopDialog;
        this.button = parentDialog.getDialog().describe(Button.class, new ButtonDescription.Builder()
                .index(index)
                .text(text).build());
    }

    public SWDesktopButton(SWDesktopDialog swDesktopDialog, String windowClassRegExp, String windowTitleRegExp) throws GeneralLeanFtException {
        this.parentDialog = swDesktopDialog;
        this.button = parentDialog.getDialog().describe(Button.class, new ButtonDescription.Builder()
                .windowClassRegExp(windowClassRegExp)
                .windowTitleRegExp(windowTitleRegExp).build());
    }

    public SWDesktopButton(SWDesktopDialog swDesktopDialog, int windowId) throws GeneralLeanFtException {
        this.parentDialog = swDesktopDialog;
        this.button = parentDialog.getDialog().describe(Button.class, new ButtonDescription.Builder()
                .windowId(windowId).build());
    }

    public Button getDesktopButton() {
        return this.button;
    }


    public DesktopButton click(int... retries) throws GeneralLeanFtException {
        try {
            this.getDesktopButton().click();
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.click(0);
            } else {
                throw e;
            }
        }
        return this;
    }

    /**
     * searches again for the field using the by
     */
    public SWDesktopButton refind(int... retries) {
        log.info("Attempting to refind the field: {}", accessibleName);
        int attempts = 0;
        boolean retry = true;
        int maxRetry = retries.length > 0 ? retries[0] : getFindRetries();
        while (attempts < maxRetry && retry) {
            try {
                log.debug("retry number {}", attempts);
                waitUntil(this.getDesktopButton(), testObject -> getDesktopButton().exists());
                this.getDesktopButton().getAccessibleName();
                retry = false;
            } catch (Exception e) {
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e1) {
                    log.debug(e1.getMessage());
                    Thread.currentThread().interrupt();
                }
            }
            attempts++;
        }
        return this;
    }

    public static int getFindRetries() {
        final int defaultFindRetries = 10;
        int refind;
        try {
            refind = Integer.parseInt(System.getProperty(Constants.DEFAULT_RETRIES));
        } catch (Exception e) {
            refind = defaultFindRetries;
        }
        return refind;
    }

    /**
     * @param retries
     * @return
     * @throws GeneralLeanFtException
     */
    public SWDesktopButton exists(int... retries) throws GeneralLeanFtException {
        try {
            waitUntil(this.button, testObject -> button.exists());
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                return this.exists(0);
            } else {
                throw e;
            }
        }
        return this;
    }

    /**
     * @param retries
     * @return
     * @throws GeneralLeanFtException
     */
    public boolean isEnabled(int... retries) throws GeneralLeanFtException {
        boolean status = false;
        try {
            status = this.getDesktopButton().isEnabled();
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.isEnabled(0);
            } else {
                throw e;
            }
        }
        return status;
    }

    public DesktopButton doubleClick(int... retries) throws GeneralLeanFtException {
        try {
            this.getDesktopButton().doubleClick();
        } catch (Exception e) {
            if (!(retries.length > 0 && retries[0] == 0)) {
                this.refind(retries);
                this.doubleClick(0);
            } else {
                throw e;
            }
        }
        return this;
    }
}


