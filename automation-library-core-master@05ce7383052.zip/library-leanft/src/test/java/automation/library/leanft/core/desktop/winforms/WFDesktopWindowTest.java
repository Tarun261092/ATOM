package automation.library.leanft.core.desktop.winforms;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.hp.lft.sdk.GeneralLeanFtException;

public class WFDesktopWindowTest {
	
	private static String windowTitleExp="SSA Gatekeeper";
    private static String fullType="rplAuthorizationDotNet.rplAutorizationUI";
    private static String objectName = "rplAutorizationUI";
    
    static WFDesktopWindow WfDesktopWindow = null;
    
    @BeforeAll
    public static void setUp()
    {
    	System.setProperty("fw.defaultFindRetries","1");
    	
    	try {
    			WfDesktopWindow = new WFDesktopWindow(objectName,windowTitleExp,fullType);
			} catch (GeneralLeanFtException e) {
				
			}
    }
    
    @Test
    public void WFDesktopWindowTest1() {
			assertThat(WfDesktopWindow).isNotNull();
    }
    
    @Test
    public void WFDesktopWindowTest2() {
    	
    	try {
    		WFDesktopWindow wfDesktopWindow = new WFDesktopWindow(objectName,fullType);
			assertThat(wfDesktopWindow).isNotNull();
		} catch (GeneralLeanFtException e) {
			
		}
    	
    }
    
    @Test
    public void sendKeysModifierTest()
    {
    	assertThrows(GeneralLeanFtException.class, () -> {
    		WfDesktopWindow.sendKeys("keys", "CTRL", 1);
    	});   
    }
    
    @Test
    public void sendKeysTest()
    {
    	assertThrows(GeneralLeanFtException.class, () -> {
    		WfDesktopWindow.sendKeys("keys", 1);
    	});
    }
    
    @Test
    public void getWindowTest()
    {
    	assertThat(WfDesktopWindow.getWindow()).isNotNull();
    }
    
}
