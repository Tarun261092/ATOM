package automation.library.leanft.core.desktop.winforms;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.hp.lft.sdk.GeneralLeanFtException;

public class WFDesktopUIObjectTest {
	
	private static String windowObjectName="frmLogon";
    private static String fullType="SSAGate.frmLogon";
    private static String objectName = "UiObject";
    
    static WFDesktopUIObject WfDesktopUIObject = null;
    
    @BeforeAll
    public static void setUp()
    {
    	System.setProperty("fw.defaultFindRetries","1");
    	
    	try {
    			WfDesktopUIObject = new WFDesktopUIObject(windowObjectName,fullType,objectName);
			} catch (GeneralLeanFtException e) {
				
			}
    }
    
    @Test
    public void WFDesktopUIObjectTest1() {
			assertThat(WfDesktopUIObject).isNotNull();
    }
    
    @Test
    public void WFDesktopUIObjectTest2() {
    	
    	try {
    		WFDesktopWindow parentWindow = new WFDesktopWindow(objectName, fullType);
    		WFDesktopUIObject wfDesktopUIObject = new WFDesktopUIObject(parentWindow,objectName);
			assertThat(wfDesktopUIObject).isNotNull();
		} catch (GeneralLeanFtException e) {
			
		}
    	
    }
    
    @Test
    public void sendKeysTest()
    {
    		assertThrows(GeneralLeanFtException.class, () -> {
    		WfDesktopUIObject.sendKeys(objectName,1);
    	});
    }
    
    @Test
    public void getFindRetriesTest() {
    	assertThat(WFDesktopUIObject.getFindRetries()).isGreaterThan(0);
    }
    
    @Test
    public void existsTest() {
    		assertThrows(GeneralLeanFtException.class, () -> {
    		WfDesktopUIObject.exists(1);
    	});    
    }

    @Test
    public void isEnabledTest() {
    	assertThrows(GeneralLeanFtException.class, () -> {
    		WfDesktopUIObject.isEnabled(1);
    	});
    }
    
    @Test
    public void clickTest() {
    	assertThrows(GeneralLeanFtException.class, () -> {
    		WfDesktopUIObject.click(1);
    	});
    }

}
