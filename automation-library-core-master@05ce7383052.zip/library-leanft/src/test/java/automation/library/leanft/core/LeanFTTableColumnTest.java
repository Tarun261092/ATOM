package automation.library.leanft.core;

import org.junit.jupiter.api.Test;
import static org.assertj.core.api.Assertions.assertThat;

import com.hp.lft.sdk.GeneralLeanFtException;

import automation.library.leanft.core.mainframe.LeanFTField;
import automation.library.leanft.core.mainframe.LeanFTTable.MultiRow;
import automation.library.leanft.core.mainframe.LeanFTTableCompareType;

public class LeanFTTableColumnTest {

	@Test
    public void leanFTTableColumnTest() {
		LeanFTField columnField = null;
		
		try {
				columnField = new LeanFTField("name", 1, 1);
				} catch (GeneralLeanFtException e) {
					}

		assertThat(new LeanFTTableColumn(1, 2, columnField, 1, LeanFTTableCompareType.FULL_ROW)).isNotNull();
		assertThat(new LeanFTTableColumn(1, 1, 2, columnField, 1, MultiRow.ROW1 , LeanFTTableCompareType.FULL_ROW)).isNotNull();
		
	}
}