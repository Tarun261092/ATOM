package automation.library.leanft.core.mainframe;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.hp.lft.sdk.GeneralLeanFtException;

public class LeanFTWindowTest {

    static String name = "name";
    static LeanFTWindow leanFTWindow = null;
    
    @BeforeAll
    public static void setUp()
    {
    	System.setProperty("fw.defaultFindRetries","1");
    	
    	try {
	    		leanFTWindow = new LeanFTWindow(name);
				} catch (GeneralLeanFtException e) {
					
				}
    }

    @Test
    public void LeanFTWindowTest1() {
    	try {
    			LeanFTWindow leanFTWindow = new LeanFTWindow(name);
				assertThat(leanFTWindow).isNotNull();
			} catch (GeneralLeanFtException e) {
			}
    }

    @Test
    public void getWindowTest() {
    	assertThat(leanFTWindow.getWindow()).isNotNull();
    }

    @Test
    public void getFindRetries() {
    	assertThat(LeanFTWindow.getFindRetries()).isGreaterThan(0);
    }


}
