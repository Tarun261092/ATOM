package automation.library.leanft.core.desktop.winforms;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.hp.lft.sdk.GeneralLeanFtException;

public class WFDesktopTableTest {
	
 	private static String windowObjectName="RPLBillingUI";
    private static String fullType="rBillingPrDotNet.RPLBillingUI";
    private static String objectName = "TableView";
    
    static WFDesktopTable WfDesktopTable = null;
    
    @BeforeAll
    public static void setUp()
    {
    	System.setProperty("fw.defaultFindRetries","1");
    	
    	try {
	    		WfDesktopTable = new WFDesktopTable(windowObjectName, fullType, objectName);
			} catch (GeneralLeanFtException e) {
					
			}
    }
    
    @Test
    public void WFDesktopTableTest1() {
    		assertThat(WfDesktopTable).isNotNull();	
    }
    
    @Test
    public void WFDesktopTableTest2() {
    	
    	try {
    			WFDesktopWindow parentWindow = new WFDesktopWindow(objectName, fullType);
	    		WFDesktopTable wfDesktopTablelocal = new WFDesktopTable(parentWindow,fullType,windowObjectName);
				assertThat(wfDesktopTablelocal).isNotNull();
			} catch (GeneralLeanFtException e) {
				
			}   	
    }
    
    @Test
    public void getDesktopTable()
    {
    	assertThat(WfDesktopTable.getDesktopTable()).isNotNull();
    }
    
    @Test
    public void getFindRetriesTest() {
    	assertThat(WFDesktopTable.getFindRetries()).isGreaterThan(0);
    }
    
    @Test
    public void existsTest() {
    	assertThrows(GeneralLeanFtException.class, () -> {
    		WfDesktopTable.exists(1);
    	});
    }

    @Test
    public void isEnabledTest() {
    	assertThrows(GeneralLeanFtException.class, () -> {
    		WfDesktopTable.isEnabled(1);
    	});
    }
    
    @Test
    public void clickTest() {
    	assertThrows(GeneralLeanFtException.class, () -> {
    		WfDesktopTable.click(1);
    	});
    }
    
}
