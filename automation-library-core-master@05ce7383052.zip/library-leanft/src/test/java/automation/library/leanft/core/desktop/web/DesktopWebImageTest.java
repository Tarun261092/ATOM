package automation.library.leanft.core.desktop.web;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.hp.lft.sdk.GeneralLeanFtException;

import automation.library.leanft.core.desktop.winforms.WFDesktopWindow;

public class DesktopWebImageTest {
	
	  	private static String locatorText = "locatorText";
	    private static String objectName = "objectName";
	    private static String fullType="fullType";
	    
	    @BeforeAll
	    public static void setUp()
	    {
	    	System.setProperty("fw.defaultFindRetries", "1");
	    }
	    
	    @Test
	    public void DesktopWebImageTest1() {
	    	
	    	try {
	    		WFDesktopWindow parentWindow = new WFDesktopWindow(objectName, fullType);
	    		DesktopWebImage desktopWebImage = new DesktopWebImage(parentWindow,locatorText,LocatorType.TAGNAME);
				assertThat(desktopWebImage).isNotNull();
			} catch (GeneralLeanFtException e) {
				
			}
	    	
	    }
	    
	    @Test
	    public void DesktopWebImageTest2() {
	    	
	    	try {
	    		WFDesktopWindow parentWindow = new WFDesktopWindow(objectName, fullType);
	    		DesktopWebImage desktopWebImage = new DesktopWebImage(parentWindow,locatorText,LocatorType.CSS);
				assertThat(desktopWebImage).isNotNull();
			} catch (GeneralLeanFtException e) {
				
			}
	    	
	    }
	    
	    @Test
	    public void DesktopWebImageTest3() {
	    	
	    	try {
	    		WFDesktopWindow parentWindow = new WFDesktopWindow(objectName, fullType);
	    		DesktopWebImage desktopWebImage = new DesktopWebImage(parentWindow,locatorText,LocatorType.XPATH);
				assertThat(desktopWebImage).isNotNull();
			} catch (GeneralLeanFtException e) {
				
			}
	    	
	    }
	    
	    @Test
	    public void DesktopWebImageTest4() {
	    	
	    	try {
	    		WFDesktopWindow parentWindow = new WFDesktopWindow(objectName, fullType);
	    		DesktopWebImage desktopWebImage = new DesktopWebImage(parentWindow,locatorText,LocatorType.ID);
				assertThat(desktopWebImage).isNotNull();
			} catch (GeneralLeanFtException e) {
				
			}
	    	
	    }
	    
	    @Test
	    public void getImageTest()
	    {
			try {
				WFDesktopWindow parentWindow = new WFDesktopWindow(objectName, fullType);
				DesktopWebImage desktopWebImage = new DesktopWebImage(parentWindow,locatorText,LocatorType.NAME);
		    	assertThat(desktopWebImage.getImage()).isNotNull();
			} catch (GeneralLeanFtException e) {
			}
    		
	    }
	    
	    @Test
	    public void existsTest()  {
	    	 try {
	    		 	WFDesktopWindow parentWindow = new WFDesktopWindow(objectName, fullType);
					DesktopWebImage desktopWebImage = new DesktopWebImage(parentWindow,locatorText,LocatorType.NAME);
					assertThat(desktopWebImage.exists(1)).isNull();
				 } catch (GeneralLeanFtException e) {
				}
	    }

	    @Test
	    public void getFindRetriesTest() {
	    	assertThat(DesktopWebImage.getFindRetries()).isGreaterThan(0);
	    }

	    @Test
	    public void isEnabledTest() {
	    	try {
	    			WFDesktopWindow parentWindow = new WFDesktopWindow(objectName, fullType);
	    			DesktopWebImage desktopWebImage = new DesktopWebImage(parentWindow,locatorText,LocatorType.NAME);
					assertThat(desktopWebImage.isEnabled(1)).isFalse();
				} catch (GeneralLeanFtException e) {
				}
	  
	    }

}
