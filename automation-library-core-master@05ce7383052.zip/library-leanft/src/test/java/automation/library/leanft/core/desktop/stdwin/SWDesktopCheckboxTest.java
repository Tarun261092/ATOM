package automation.library.leanft.core.desktop.stdwin;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

import com.hp.lft.sdk.GeneralLeanFtException;

public class SWDesktopCheckboxTest {
	
	@Test
	public void SWDesktopCheckboxTest1() {
	    	
	    	try {
	    		SWDesktopCheckbox swDesktopCheckbox = new SWDesktopCheckbox();
				assertThat(swDesktopCheckbox.exists(1)).isNull();
			} catch (GeneralLeanFtException e) {
			}
	 }
	
	@Test
	public void SWDesktopCheckboxTest2() {
	    	
	    	try {
	    		SWDesktopCheckbox swDesktopCheckbox = new SWDesktopCheckbox();
				assertThat(swDesktopCheckbox.click(1)).isNull();
			} catch (GeneralLeanFtException e) {
			}
	 }
	
	@Test
	public void SWDesktopCheckboxTest3() {
	    	
	    	try {
	    		SWDesktopCheckbox swDesktopCheckbox = new SWDesktopCheckbox();
	    		assertThat(swDesktopCheckbox.isEnabled(1)).isEqualTo(false);
			} catch (GeneralLeanFtException e) {
			}
	 }
	
	@Test
	public void SWDesktopCheckboxTest4() {
	    	
	    	try {
	    		SWDesktopCheckbox swDesktopCheckbox = new SWDesktopCheckbox();
				assertThat(swDesktopCheckbox.isChecked(1)).isEqualTo(false);
			} catch (GeneralLeanFtException e) {
			}
	}

}
