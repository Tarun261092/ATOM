package automation.library.leanft.core.desktop.winforms;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.hp.lft.sdk.GeneralLeanFtException;

public class WFDesktopEditorTest {
	
		private static String windowObjectName="RPLBillingUI";
	    private static String fullType="rBillingPrDotNet.RPLBillingUI";
	    private static String objectName = "Description";
		private static String windowFullType = "windowFullType";
		private static int index = 1;
		
		static WFDesktopEditor WfDesktopEditor = null;
	    
	    @BeforeAll
	    public static void setUp()
	    {
	    	System.setProperty("fw.defaultFindRetries","1");
	    	
	    	try {
	    			WfDesktopEditor = new WFDesktopEditor(windowObjectName,fullType,objectName);
				} catch (GeneralLeanFtException e) {
					
				}
	    }
			
		@Test
		public void WFDesktopEditorTest1() {
				assertThat(WfDesktopEditor).isNotNull();	
	    }
		
		@Test
		public void WFDesktopEditorTest2() {
	    	
	    	try {
	    		WFDesktopEditor wfDesktopEditor = new WFDesktopEditor(windowObjectName,windowFullType,fullType,index);
				assertThat(wfDesktopEditor).isNotNull();
			} catch (GeneralLeanFtException e) {
				
			}
	    	
	    }
		
		@Test
		public void WFDesktopEditorTest3() {
	    	
	    	try {
	    		WFDesktopWindow window = new WFDesktopWindow(windowObjectName, windowFullType);
	    		WFDesktopEditor wfDesktopEditor = new WFDesktopEditor(window,fullType,objectName);
				assertThat(wfDesktopEditor).isNotNull();
			} catch (GeneralLeanFtException e) {
				
			}
	    	
	    }
	
		@Test
		public void WFDesktopEditorTest4() {
	    	
	    	try {
	    		WFDesktopWindow window = new WFDesktopWindow(windowObjectName, windowFullType);
	    		WFDesktopEditor wfDesktopEditor = new WFDesktopEditor(window,fullType,index);
				assertThat(wfDesktopEditor).isNotNull();
			} catch (GeneralLeanFtException e) {
				
			}
	    	
	    }
		@Test
		public void WFDesktopEditorTest5() {
	    	
	    	try {
		    		WFDesktopWindow window = new WFDesktopWindow(windowObjectName, windowFullType);
		    		WFDesktopEditor wfDesktopEditor = new WFDesktopEditor(window, objectName);
					assertThat(wfDesktopEditor).isNotNull();
				} catch (GeneralLeanFtException e) {
					
				}
	    	
	    }
	
	 	@Test
	    public void getTextTest()
	    {
		 		assertThrows(GeneralLeanFtException.class, () -> {
		 		WfDesktopEditor.getText(1);
	    	});    	
	    }
	    
	    @Test
	    public void getFindRetriesTest() {
	    	assertThat(WFDesktopEditor.getFindRetries()).isGreaterThan(0);
	    }
	    
	    @Test
	    public void existsTest() {
	    	assertThrows(GeneralLeanFtException.class, () -> {
		 		WfDesktopEditor.exists(1);
	    	});   
	    }

	    @Test
	    public void isEnabledTest() {
	    	assertThrows(GeneralLeanFtException.class, () -> {
		 		WfDesktopEditor.isEnabled(1);
	    	});   
	    }
	    
	    @Test
	    public void sendkeysTest() {
	    	assertThrows(GeneralLeanFtException.class, () -> {
		 		WfDesktopEditor.sendKeys(objectName,1);
	    	});   
	    }
	    
	
}
