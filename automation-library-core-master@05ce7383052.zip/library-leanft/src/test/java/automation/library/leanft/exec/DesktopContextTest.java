package automation.library.leanft.exec;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

public class DesktopContextTest {
 
	static public DesktopContext desktopContext = DesktopContext.getInstance();
	
	 @BeforeAll
	 public static void beforeAllTestMethods() {
		 desktopContext.setDesktopContextWithLaunchInfo("FDR");
		 desktopContext.setEmulatorName("FDR","PCOM");
		 desktopContext.setLeanFTUp(true);
		 desktopContext.setKeepTEOpen(true);
		 desktopContext.setRunOnGrid(true);
	 }
	 
	 @Test
	  public void getAppLaunchDataTest() {
		assertThat(desktopContext.getAppLaunchData()).isNotNull();
	  }	 
	 
	@Test
    public void getEmulatorNameTest() {
		assertThat(desktopContext.getEmulatorName("FDR")).isNotNull();
    }

	@Test
    public void keepTEOpenTest() {
		assertThat(desktopContext.keepTEOpen()).isTrue();
    }

	@Test
    public void isLeanftUpTest() {
		assertThat(desktopContext.isLeanFTUp()).isTrue();
	}

	@Test
    public void getCurrentLeanFTScreenTest() {
		assertThat(desktopContext.getCurrentLeanFTScreen()).isNull();;
    }

	@Test
    public void getCurrentLeanFTWindowTest() {
		assertThat(desktopContext.getCurrentLeanFTWindow()).isNull();
    }

	@Test
    public void runOnGridTest() {
		assertThat(desktopContext.runOnGrid()).isTrue();
    }

	@Test
    public void getCurrentLeanFTDialogTest() {
		assertThat(desktopContext.getCurrentLeanFTDialog()).isNull();
    }
}