package automation.library.leanft.exec.maps;

import static org.assertj.core.api.Assertions.assertThat;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

public class DesktopApplicationTest {
   
	static DesktopApplication desktopApplication = new DesktopApplication();
	
	 @BeforeAll
	 public static void beforeAllTestMethods() {
		 desktopApplication.setArgs(new String[1]);
		 desktopApplication.setFileName("fileName");
		 desktopApplication.setCommandWindowTitle("commandWindowTitl");
		 desktopApplication.setDefaultApplLaunchWait(10);
		 desktopApplication.setRplidWindowTitle("rplidWindowTitle");
		 desktopApplication.setWindowTitle("windowTitleRegExp");
		 desktopApplication.setWorkingDirectory("workingDirectory");
	 }
	
	@Test
    public void getFileNameTest() {
		assertThat(desktopApplication.getFileName()).isNotNull();
    }

	@Test
    public void getArgs() {
		assertThat(desktopApplication.getArgs()).isNotNull();
    }

	@Test
    public void getWorkingDirectory() {
		assertThat(desktopApplication.getWorkingDirectory()).isNotNull();
    }

	@Test
    public void getDefaultApplLaunchWait() {
		assertThat(desktopApplication.getDefaultApplLaunchWait()).isGreaterThanOrEqualTo(0);
    }

	@Test
    public void getWindowTitle() {
		assertThat(desktopApplication.getWindowTitle()).isNotNull();
    }

	@Test
    public void getRplidWindowTitle() {
		assertThat(desktopApplication.getRplidWindowTitle()).isNotNull();
    }
	
	@Test
    public void getCommandWindowTitle() {
		assertThat(desktopApplication.getCommandWindowTitle()).isNotNull();
    }

	
}
