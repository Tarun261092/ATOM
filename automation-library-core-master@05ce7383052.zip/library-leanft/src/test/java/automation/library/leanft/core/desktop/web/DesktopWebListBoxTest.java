package automation.library.leanft.core.desktop.web;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.hp.lft.sdk.GeneralLeanFtException;

import automation.library.leanft.core.desktop.stdwin.SWDesktopWindow;
import automation.library.leanft.core.desktop.winforms.WFDesktopWindow;

public class DesktopWebListBoxTest {
	
	private static String windowObjectName="windowObjectName";
    private static String windowTitle="windowTitle"; 
    private static String fullType="fullType";
    private static String locatorText = "locatorText";
    private static String objectName = "objectName";
    private static String windowClassRegExp = "windowClassRegExp";
	private static String text = "text";
	private static int index = 1;
    
    static DesktopWebListBox desktopWebListBox = null;
	
    @BeforeAll
    public static void setUp()
    {
    	System.setProperty("fw.defaultFindRetries", "1");
    	
    	try {
    			desktopWebListBox = new DesktopWebListBox(windowObjectName,fullType,windowTitle,locatorText,LocatorType.TAGNAME);
			} catch (GeneralLeanFtException e) {
				
			}
    }
    
    @Test
    public void DesktopWebListBoxTest1() {
    	
    	try {
    		DesktopWebListBox dtWebListBox = new DesktopWebListBox(windowObjectName,fullType,windowTitle,locatorText,LocatorType.TAGNAME);
			assertThat(dtWebListBox).isNotNull();
		} catch (GeneralLeanFtException e) {
			
		}
    	
    }
    
    @Test
    public void DesktopWebListBoxTest2() {
    	
    	try {
    		WFDesktopWindow parentWindow = new WFDesktopWindow(objectName, fullType);
    		DesktopWebListBox dtWebListBox = new DesktopWebListBox(parentWindow,locatorText,LocatorType.get("id"));
			assertThat(dtWebListBox).isNotNull();
		} catch (GeneralLeanFtException e) {
			
		}
    	
    }
    
    @Test
    public void DesktopWebListBoxTest3() {
    	
    	try {
    		WFDesktopWindow parentWindow = new WFDesktopWindow(objectName, fullType);
    		DesktopWebListBox dtWebListBox = new DesktopWebListBox(parentWindow,locatorText,LocatorType.get("css"));
			assertThat(dtWebListBox).isNotNull();
		} catch (GeneralLeanFtException e) {
			
		}
    	
    }
    
    @Test
    public void DesktopWebListBoxTest4() {
    	
    	try {
    		WFDesktopWindow parentWindow = new WFDesktopWindow(objectName, fullType);
    		DesktopWebListBox dtWebListBox = new DesktopWebListBox(parentWindow,locatorText,LocatorType.XPATH);
			assertThat(dtWebListBox).isNotNull();
		} catch (GeneralLeanFtException e) {
			
		}
    	
    }
    
    @Test
    public void DesktopWebListBoxTest5() {
    	
    	try {
    		WFDesktopWindow parentWindow = new WFDesktopWindow(objectName, fullType);
			SWDesktopWindow swDesktopWindow = new SWDesktopWindow(windowClassRegExp, text, index);
    		DesktopWebListBox dtWebListBox = new DesktopWebListBox(parentWindow,swDesktopWindow,locatorText,LocatorType.XPATH);
			assertThat(dtWebListBox).isNotNull();
		} catch (GeneralLeanFtException e) {
			
		}
    	
    }
    
    @Test
    public void getEditFieldTest()
    {
    	assertThat(desktopWebListBox.getListBox()).isNotNull();
    }

    @Test
    public void selectTest1()
    {
    	try {
				assertThat(desktopWebListBox.select(1, 1)).isNull();
			} catch (GeneralLeanFtException e) {
			}
    }
    
    @Test
    public void selectTest2()
    {
    	try {
				assertThat(desktopWebListBox.select("1", 1)).isNotNull();
			} catch (GeneralLeanFtException e) {
			}
    }
    
    @Test
    public void getSetTextTest()
    {
    	try {
    			desktopWebListBox.setText("locatorText", 1);
    			assertThat(desktopWebListBox.getText(1)).isNull();
			} catch (GeneralLeanFtException e) {
			}
    }
    
 
    @Test
    public void existsTest()  {
    	 try {
				assertThat(desktopWebListBox.exists(1)).isNotNull();
			 } catch (GeneralLeanFtException e) {
			}
    }

    @Test
    public void getFindRetriesTest() {
    	assertThat(DesktopWebListBox.getFindRetries()).isGreaterThan(0);
    }

    @Test
    public void isEnabledTest() {
    	try {
				assertThat(desktopWebListBox.isEnabled(1)).isFalse();
			} catch (GeneralLeanFtException e) {
			}
 
    }
    
    @Test
    public void hoverTest()
    {
    	try {
				assertThat(desktopWebListBox.hover(1)).isNull();
			} catch (GeneralLeanFtException e) {
			}
    }
    
    @Test
    public void clickTest()
    {
    	try {
				assertThat(desktopWebListBox.click(1)).isNull();
			} catch (GeneralLeanFtException e) {
			}
    }
    
    @Test
    public void doubleClickTest()
    {
    	try {
				assertThat(desktopWebListBox.doubleClick(1)).isNull();
			} catch (GeneralLeanFtException e) {
			}
    }

}