package automation.library.leanft.core.desktop.winforms;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.hp.lft.sdk.GeneralLeanFtException;

public class WFDesktopToolBarTest {
	
	private static String windowObjectName="frmLogon";
    private static String windowTitleExp="SSA Gatekeeper"; 
    private static String fullType="SSAGate.frmLogon";
    private static String objectName = "toolBar";
    
    static WFDesktopToolBar WfDesktopToolBar = null;
    
    @BeforeAll
    public static void setUp()
    {
    	System.setProperty("fw.defaultFindRetries","1");
    	
    	try {
    			WfDesktopToolBar = new WFDesktopToolBar(windowObjectName,windowTitleExp,fullType,objectName);
			} catch (GeneralLeanFtException e) {
				
			}
    }
    
    @Test
    public void WFDesktopToolBarTest1() {
   			assertThat(WfDesktopToolBar).isNotNull();
    }
    
    @Test
    public void WFDesktopToolBarTest2() {
    	
    	try {
    		WFDesktopWindow window = new WFDesktopWindow(windowObjectName,windowTitleExp,fullType);
    		WFDesktopToolBar wfDesktopToolBar = new WFDesktopToolBar(window,objectName);
			assertThat(wfDesktopToolBar).isNotNull();
		} catch (GeneralLeanFtException e) {
			
		}
    	
    }
    
   
    @Test
    public void getDesktopToolBarTest() {
    	assertThat(WfDesktopToolBar.getDesktopToolBar()).isNotNull();
    }
    
    @Test
    public void getFindRetriesTest() {
    	assertThat(WFDesktopToolBar.getFindRetries()).isGreaterThan(0);
    }
    
    @Test
    public void existsTest() {
    		assertThrows(GeneralLeanFtException.class, () -> {
    		WfDesktopToolBar.exists(1);
    	});
    }

    @Test
    public void isEnabledTest() {
    		assertThrows(GeneralLeanFtException.class, () -> {
    		WfDesktopToolBar.isEnabled(1);
    	});
    }
    
    @Test
    public void selectTest() {
    		assertThrows(GeneralLeanFtException.class, () -> {
    		WfDesktopToolBar.select(objectName,1);
    	});
    }

}
