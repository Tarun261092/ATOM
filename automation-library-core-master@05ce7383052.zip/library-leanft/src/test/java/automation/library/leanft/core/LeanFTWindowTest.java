package automation.library.leanft.core;

import org.junit.jupiter.api.Test;
import static org.assertj.core.api.Assertions.assertThat;

import com.hp.lft.sdk.GeneralLeanFtException;

import automation.library.leanft.core.mainframe.LeanFTWindow;

public class LeanFTWindowTest {

	@Test
    public void leanFTWindowTest() {
        try {
        		assertThat(new LeanFTWindow("name")).isNotNull();
			} catch (GeneralLeanFtException e) {
			}
    }
}
