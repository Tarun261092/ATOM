package automation.library.leanft.core.desktop.winforms;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.hp.lft.sdk.GeneralLeanFtException;

public class WFDesktopTabControlTest {
	
 	private static String windowObjectName="frmLogon";
    private static String windowTitleExp="SSA Gatekeeper"; 
    private static String fullType="SSAGate.frmLogon";
    private static String objectName = "tabSystem";
    
    static WFDesktopTabControl WfDesktopTabControl = null;
    
    @BeforeAll
    public static void setUp()
    {
    	System.setProperty("fw.defaultFindRetries","1");
    	
    	try {
    			WfDesktopTabControl = new WFDesktopTabControl(windowObjectName,windowTitleExp,fullType,objectName);
			} catch (GeneralLeanFtException e) {
				
			}
    }
    
    @Test
    public void WFDesktopTabControlTest1() {
    		assertThat(WfDesktopTabControl).isNotNull();
    }
    
    @Test
    public void WFDesktopTabControlTest2() {
    	
    	try {
    		WFDesktopWindow window = new WFDesktopWindow(windowObjectName,windowTitleExp,fullType);
    		WFDesktopTabControl wfDesktopTabControl = new WFDesktopTabControl(window,objectName);
			assertThat(wfDesktopTabControl).isNotNull();
		} catch (GeneralLeanFtException e) {
			
		}
    	
    }
    
    @Test
    public void getDesktopTabControlTest()
    {
    	assertThat(WfDesktopTabControl.getDesktopTabControl()).isNotNull();
    }
    
    @Test
    public void getFindRetriesTest() {
    	assertThat(WFDesktopTabControl.getFindRetries()).isGreaterThan(0);
    }
    
    @Test
    public void existsTest() {
    		assertThrows(GeneralLeanFtException.class, () -> {
    		WfDesktopTabControl.exists(1);
    	});
    }

    @Test
    public void isEnabledTest() {
    		assertThrows(GeneralLeanFtException.class, () -> {
    		WfDesktopTabControl.isEnabled(1);
    	});
    }
    
    @Test
    public void selectTest() {
    		assertThrows(GeneralLeanFtException.class, () -> {
    		WfDesktopTabControl.select(objectName,1);
    	});
    }
    
}
