package automation.library.leanft.core.desktop.stdwin;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

import com.hp.lft.sdk.GeneralLeanFtException;

public class SWDesktopDialogTest {
	
	private static String windowClassRegExp = "windowClassRegExp";
	private static String windowTitleRegExp = "windowTitleRegExp";
	private static boolean childWindow = true;
	private static boolean ownedWindow = true;
	
	@Test
	public void SWDesktopDialogTest1() {
	    	
	    	try {
	    		SWDesktopDialog swDesktopDialog = new SWDesktopDialog(windowClassRegExp,windowTitleRegExp);
				assertThat(swDesktopDialog).isNotNull();
			} catch (GeneralLeanFtException e) {
			}
	    	
	}
	
	@Test
	public void SWDesktopDialogTest2() {
	    	
	    	try {
	    		SWDesktopDialog swDesktopDialog = new SWDesktopDialog(windowClassRegExp,windowTitleRegExp,childWindow,ownedWindow);
				assertThat(swDesktopDialog).isNotNull();
			} catch (GeneralLeanFtException e) {
			}
	    	
	 }
	
	@Test
    public void existsTest() {
    	try {
    			SWDesktopDialog swDesktopDialog = new SWDesktopDialog(windowClassRegExp,windowTitleRegExp,childWindow,ownedWindow);
				assertThat(swDesktopDialog.exists(1)).isNull();
			} catch (GeneralLeanFtException e) {
			}
    }

    @Test
    public void isEnabledTest() {
    	try {
    			SWDesktopDialog swDesktopDialog = new SWDesktopDialog(windowClassRegExp,windowTitleRegExp,childWindow,ownedWindow);	
    			assertThat(swDesktopDialog.isEnabled(1)).isTrue();
			} catch (GeneralLeanFtException e) {
			}
    }
    
    @Test
    public void getTextTest() {
    	try {
    			SWDesktopDialog swDesktopDialog = new SWDesktopDialog(windowClassRegExp,windowTitleRegExp,childWindow,ownedWindow);	
    			assertThat(swDesktopDialog.getDialog()).isNotNull();
			} catch (GeneralLeanFtException e) {
			}
    }
	
}
