package automation.library.leanft.core.desktop.stdwin;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

import com.hp.lft.sdk.GeneralLeanFtException;

public class SWDesktopTabControlTest {
	
	private static String name = "name";
	
	@Test
	public void SWDesktopTabControlTest1() {
	    	
	    	try {
	    		SWDesktopTabControl swDesktopTabControl = new SWDesktopTabControl();
				assertThat(swDesktopTabControl.exists(1)).isNull();
			} catch (GeneralLeanFtException e) {
			}
	 }
	
	@Test
	public void SWDesktopTabControlTest2() {
	    	
	    	try {
	    		SWDesktopTabControl swDesktopTabControl = new SWDesktopTabControl();
				assertThat(swDesktopTabControl.select(name,1)).isNull();
			} catch (GeneralLeanFtException e) {
			}
	 }
	
	@Test
	public void SWDesktopTabControlTest3() {
	    	
	    	try {
	    		SWDesktopTabControl swDesktopTabControl = new SWDesktopTabControl();
				assertThat(swDesktopTabControl.isEnabled(1)).isEqualTo(false);
			} catch (GeneralLeanFtException e) {
			}
	 }

}
