package automation.library.leanft.core.desktop.winforms;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.hp.lft.sdk.GeneralLeanFtException;

public class WFDesktopRadioButtonTest {
	
	 	private static String windowObjectName="frmLogon";
	    private static String windowTitleExp="SSA Gatekeeper"; 
	    private static String fullType="SSAGate.frmLogon";
	    private static String objectName = "cmdRadio";
	    
	    static WFDesktopRadioButton WfDesktopRadioButton = null;
	    
	    @BeforeAll
	    public static void setUp()
	    {
	    	System.setProperty("fw.defaultFindRetries","1");
	    	
	    	try {
	    			WfDesktopRadioButton = new WFDesktopRadioButton(windowObjectName,windowTitleExp,fullType,objectName);
				} catch (GeneralLeanFtException e) {
					
				}
	    }
	    
	    
	    @Test
	    public void WFDesktopRadioButtonTest1() {
	    	assertThat(WfDesktopRadioButton).isNotNull();
	    }
	    
	    @Test
	    public void WFDesktopRadioButtonTest2() {
	    	
	    	try {
		    		WFDesktopRadioButton wfRadioButton = new WFDesktopRadioButton(windowObjectName, fullType, "text");
					assertThat(wfRadioButton).isNotNull();
				} catch (GeneralLeanFtException e) {
					
				}
	    }
	  
	    @Test
	    public void getFindRetriesTest() {
	    	assertThat(WFDesktopRadioButton.getFindRetries()).isGreaterThan(0);
	    }
	    
	    @Test
	    public void existsTest() {
	    	assertThrows(GeneralLeanFtException.class, () -> {
	    		WfDesktopRadioButton.exists(1);
	    	});
	    }

	    @Test
	    public void isEnabledTest() {
	    		assertThrows(GeneralLeanFtException.class, () -> {
	    		WfDesktopRadioButton.isEnabled(1);
	    	});
	    }
	    
	    @Test
	    public void selectIntTest() {
	    	try {
					assertThat(WfDesktopRadioButton.select(1, 1)).isNull();
				} catch (GeneralLeanFtException e) {
				}
	    }
	    
	    @Test
	    public void selectStringTest() {
	    	try {
					assertThat(WfDesktopRadioButton.select("1", 1)).isNull();
				} catch (GeneralLeanFtException e) {
				}
	    }
	    
	    @Test
	    public void clickTest() {
	    		assertThrows(GeneralLeanFtException.class, () -> {
	    		WfDesktopRadioButton.click(1);
	    	});
	    }
	        
}
