package automation.library.leanft.core.desktop.winforms;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.hp.lft.sdk.GeneralLeanFtException;

public class WFDesktopListViewTest {
	
	private static String windowObjectName="rplAutorizationUI";
    private static String fullType="rplAuthorizationDotNet.rplAutorizationUI";
    private static String objectName = "lvwfpList";
    
    static WFDesktopListView wfDesktopListView = null;
    
    @BeforeAll
    public static void setUp()
    {
    	System.setProperty("fw.defaultFindRetries","1");
    	
    	try {
				wfDesktopListView = new WFDesktopListView(windowObjectName,fullType,objectName);
			} catch (GeneralLeanFtException e) {
				
			}
    }
    
    @Test
	public void WFDesktopListViewTest1() {
    		assertThat(wfDesktopListView).isNotNull();	
    }
    
    @Test
   	public void WFDesktopListViewTest2() {
       	
       	try {
       		WFDesktopWindow window = new WFDesktopWindow(windowObjectName, fullType);
       		WFDesktopListView wfDesktopListViewlocal = new WFDesktopListView(window,objectName);
   			assertThat(wfDesktopListViewlocal).isNotNull();
   		} catch (GeneralLeanFtException e) {
   			
   		}
       	
    }
    
    @Test
    public void getDesktopListViewTest()
    {
    	assertThat(wfDesktopListView.getDesktopListView()).isNotNull();
    }
    
    @Test
    public void getTextTest()
    {
    	assertThrows(GeneralLeanFtException.class, () -> {
    	wfDesktopListView.getText(1);
	}); 	
    }
    
    @Test
    public void getFindRetriesTest() {
    	assertThat(WFDesktopListView.getFindRetries()).isGreaterThan(0);
    }
    
    @Test
    public void existsTest() 
    {
        	assertThrows(GeneralLeanFtException.class, () -> {
        	wfDesktopListView.exists(1);
    	}); 	
    }

    @Test
    public void isEnabledTest() 
    {
    	assertThrows(GeneralLeanFtException.class, () -> {
    	wfDesktopListView.isEnabled(1);
	}); 	
    }
    
    @Test
    public void doubleClickTest() 
    {
    	assertThrows(GeneralLeanFtException.class, () -> {
    	wfDesktopListView.doubleClick(objectName,1);
	}); 	
    }
    
    @Test
    public void selectTest() 
    {
    	assertThrows(GeneralLeanFtException.class, () -> {
    	wfDesktopListView.select(objectName,1);
	}); 	
    }

}
