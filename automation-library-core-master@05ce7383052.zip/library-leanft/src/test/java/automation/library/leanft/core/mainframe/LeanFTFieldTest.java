package automation.library.leanft.core.mainframe;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.hp.lft.sdk.GeneralLeanFtException;

public class LeanFTFieldTest {
	
    static String name = "name";
    static String label = "label";
    static int id = 1;
    static String screenId = "screenId";
    String text = "text";

    static LeanFTField leanFTField = null;
    
    @BeforeAll
    public static void setUp()
    {
    	System.setProperty("fw.defaultFindRetries","1");
    	
    	try {
    			leanFTField = new LeanFTField(name, label, id);
			} catch (GeneralLeanFtException e) {
				
			}
    }

    @Test
    public void LeanFTFieldTest1() {
        assertThat(leanFTField).isNotNull();
    }

    @Test
    public void LeanFTFieldTest2() {    	
		try {
			LeanFTScreen leanFTScreen = new LeanFTScreen(name, label);
			leanFTField = new LeanFTField(leanFTScreen, id);
			assertThat(leanFTField).isNotNull();
		} catch (GeneralLeanFtException e) {
		}     
    }
  
    @Test
    public void LeanFTFieldTest3() {    	
		try {
				LeanFTScreen leanFTScreen = new LeanFTScreen(name, label);
				leanFTField = new LeanFTField(leanFTScreen, 1, 1);
		        assertThat(leanFTField).isNull();
			} catch (GeneralLeanFtException e) {
			}
    }
    
    @Test
    public void LeanFTFieldTest4() {    	
		try {
				leanFTField = new LeanFTField(name, 1, 1);
		        assertThat(leanFTField).isNotNull();
			} catch (GeneralLeanFtException e) {
			}
    }
  
    @Test
    public void getFieldTest() {
    	assertThat(leanFTField.getField()).isNotNull();
    }

    @Test
    public void getParentScreenTest() {
    	assertThat(leanFTField.getParentScreen()).isNotNull();
    }

    @Test
    public void getWaitDurationTest() {
    	assertThat(LeanFTField.getWaitDuration()).isGreaterThan(0);
    }

    @Test
    public void getFindRetries() {
    	assertThat(LeanFTField.getFindRetries()).isGreaterThan(0);
    }

    @Test
    public void setTextTest() {
    		assertThrows(GeneralLeanFtException.class, () -> {
    		leanFTField.setText(text,1);
    	});
    }

    @Test
    public void setSecureTest() {
    	assertThrows(GeneralLeanFtException.class, () -> {
    		leanFTField.setSecure(text,1);
    	});
    }

    @Test
    public void setCursorTest() {
    	assertThrows(GeneralLeanFtException.class, () -> {
    		leanFTField.setCursor(1);
    	});
    }

    @Test
    public void getTextTest() {
    	assertThrows(GeneralLeanFtException.class, () -> {
    		leanFTField.getText(1);
    	});
    }

    @Test
    public void visibleTest() {
    	assertThrows(GeneralLeanFtException.class, () -> {
    		leanFTField.visible(1);
    	});
    }
    
    
    @Test
    public void existsTest() {
    	assertThrows(GeneralLeanFtException.class, () -> {
    		leanFTField.exists(1);
    	});
    }

    @Test
    public void findFieldTest() {
    	try {
				assertThat(leanFTField.findField(name,label,id)).isNotNull();
			} catch (GeneralLeanFtException e) {
			}
    }
}
