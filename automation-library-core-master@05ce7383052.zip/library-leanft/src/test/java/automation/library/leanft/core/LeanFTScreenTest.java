package automation.library.leanft.core;

import java.util.ArrayList;

import org.junit.jupiter.api.Test;
import static org.assertj.core.api.Assertions.assertThat;

import com.hp.lft.sdk.GeneralLeanFtException;

public class LeanFTScreenTest {
	
	@Test
    public void LeanFTScreenTest1() {
        try {
        		assertThat(new LeanFTScreen("name", "label")).isNotNull();
        		assertThat(new LeanFTScreen("name", 1)).isNotNull();

				ArrayList<Integer> list = new ArrayList<Integer>();
				list.add(1);
				assertThat(new LeanFTScreen("name", list)).isNotNull();
				assertThat(new LeanFTScreen("name", "label", false)).isNotNull();
				
			} catch (GeneralLeanFtException e) {
			}
    }
	

}
