package automation.library.leanft.core.desktop.stdwin;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

import com.hp.lft.sdk.GeneralLeanFtException;

public class SWDesktopEditorTest {
	
	private static String text = "text";
	
	@Test
	public void SWDesktopEditorTest1() {
	    	
	    	try {
	    		SWDesktopEditor swDesktopEditor = new SWDesktopEditor();
				assertThat(swDesktopEditor.exists(1)).isNull();
			} catch (GeneralLeanFtException e) {
			}
	 }
	
	@Test
	public void SWDesktopEditorTest2() {
	    	
	    	try {
	    		SWDesktopEditor swDesktopEditor = new SWDesktopEditor();
				assertThat(swDesktopEditor.getText(1)).isNull();
			} catch (GeneralLeanFtException e) {
			}
	 }
	
	@Test
	public void SWDesktopEditorTest3() {
	    	
	    	try {
	    		SWDesktopEditor swDesktopEditor = new SWDesktopEditor();
	    		assertThat(swDesktopEditor.isEnabled(1)).isEqualTo(false);
			} catch (GeneralLeanFtException e) {
			}
	 }
	
	@Test
	public void SWDesktopEditorTest4() {
	    	
	    	try {
	    		SWDesktopEditor swDesktopEditor = new SWDesktopEditor();
				assertThat(swDesktopEditor.sendKeys(text,1)).isNull();
			} catch (GeneralLeanFtException e) {
			}
	}

}
