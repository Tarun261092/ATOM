package automation.library.leanft.exec;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class DesktopFactoryTest {
	
	static public DesktopContext desktopContext = DesktopContext.getInstance();
	
	 @BeforeAll
	 public static void beforeAllTestMethods() {
		 desktopContext.setEmulatorName("appName1","pcom");
		 desktopContext.setEmulatorName("appName2","hod");
		 desktopContext.setEmulatorName("appName3","avaya");
		 desktopContext.setEmulatorName("appName4","rplid");
		 desktopContext.setEmulatorName("appName5","winform");
		 desktopContext.setEmulatorName("appName6","firefly");
		 desktopContext.setEmulatorName("appName7","java");
	 }
    
	@Test
    public void createDesktopDriverTest() {
		assertThat(DesktopFactory.createDesktopDriver("appName1")).isNotNull();
		assertThat(DesktopFactory.createDesktopDriver("appName2")).isNotNull();;
		assertThat(DesktopFactory.createDesktopDriver("appName3")).isNotNull();;
		assertThat(DesktopFactory.createDesktopDriver("appName4")).isNotNull();;
		assertThat(DesktopFactory.createDesktopDriver("appName5")).isNotNull();;
		assertThat(DesktopFactory.createDesktopDriver("appName6")).isNotNull();;
		assertThat(DesktopFactory.createDesktopDriver("appName7")).isNotNull();;
    }

}
