package automation.library.leanft.core.desktop.web;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.hp.lft.sdk.GeneralLeanFtException;

import automation.library.leanft.core.desktop.winforms.WFDesktopWindow;

public class DesktopWebLinkTest {
	
	private static String windowObjectName="windowObjectName";
    private static String windowTitle="windowTitle"; 
    private static String fullType="fullType";
    private static String locatorText = "locatorText";
    private static String objectName = "objectName";
    
    static DesktopWebLink desktopWebLink = null;
	
    @BeforeAll
    public static void setUp()
    {
    	System.setProperty("fw.defaultFindRetries", "1");
    	
    	try {
    			desktopWebLink = new DesktopWebLink(windowObjectName,fullType,windowTitle,locatorText,LocatorType.TAGNAME);
			} catch (GeneralLeanFtException e) {
				
			}
    }
    
    @Test
    public void DesktopWebLinkTest1() {
    	
    	try {
    		DesktopWebLink dtWebLink = new DesktopWebLink(windowObjectName,fullType,windowTitle,locatorText,LocatorType.TAGNAME);
			assertThat(dtWebLink).isNotNull();
		} catch (GeneralLeanFtException e) {
			
		}
    	
    }
    
    @Test
    public void DesktopWebLinkTest2() {
    	
    	try {
    		WFDesktopWindow parentWindow = new WFDesktopWindow(objectName, fullType);
    		DesktopWebLink dtWebLink = new DesktopWebLink(parentWindow,locatorText,LocatorType.get("id"));
			assertThat(dtWebLink).isNotNull();
		} catch (GeneralLeanFtException e) {
			
		}
    	
    }
    
    @Test
    public void DesktopWebLinkTest3() {
    	
    	try {
    		WFDesktopWindow parentWindow = new WFDesktopWindow(objectName, fullType);
    		DesktopWebLink dtWebLink = new DesktopWebLink(parentWindow,locatorText,LocatorType.get("css"));
			assertThat(dtWebLink).isNotNull();
		} catch (GeneralLeanFtException e) {
			
		}
    	
    }
    
    @Test
    public void DesktopWebLinkTest4() {
    	
    	try {
    		WFDesktopWindow parentWindow = new WFDesktopWindow(objectName, fullType);
    		DesktopWebLink dtWebLink = new DesktopWebLink(parentWindow,locatorText,LocatorType.XPATH);
			assertThat(dtWebLink).isNotNull();
		} catch (GeneralLeanFtException e) {
			
		}
    	
    }

    
    @Test
    public void getWebElementTest()
    {
    	assertThat(desktopWebLink.getLink()).isNotNull();
    }
    
    
    @Test
    public void getSelectTest1()
    {
    	try {
			assertThat(desktopWebLink.select("1", 1)).isNull();
		} catch (GeneralLeanFtException e) {
		}
    }
  
    @Test
    public void getSelectTest2()
    {
    	try {
			assertThat(desktopWebLink.select(1, 1)).isNull();
		} catch (GeneralLeanFtException e) {
		}
    }
    
    @Test
    public void setTextTest()
    {
    	try {
			assertThat(desktopWebLink.setText("text", 1)).isNull();
		} catch (GeneralLeanFtException e) {
		}
    }
    
   
    @Test
    public void existsTest()  {
    	 try {
				assertThat(desktopWebLink.exists(1)).isNull();
			 } catch (GeneralLeanFtException e) {
			}
    }

    @Test
    public void getFindRetriesTest() {
    	assertThat(DesktopWebLink.getFindRetries()).isGreaterThan(0);
    }

    @Test
    public void isEnabledTest() {
    	try {
				assertThat(desktopWebLink.isEnabled(1)).isFalse();
			} catch (GeneralLeanFtException e) {
			}
  
    }
    
    @Test
    public void getTextTest()  {
    	 try {
				assertThat(desktopWebLink.getText(1)).isNull();
			 } catch (GeneralLeanFtException e) {
			}
    }
    
    @Test
    public void hoverTest()  {
    	 try {
				assertThat(desktopWebLink.hover(1)).isNull();
			 } catch (GeneralLeanFtException e) {
			}
    }
    
    @Test
    public void doubleClickTest()  {
    	 try {
				assertThat(desktopWebLink.doubleClick(1)).isNull();
			 } catch (GeneralLeanFtException e) {
			}
    }

}
