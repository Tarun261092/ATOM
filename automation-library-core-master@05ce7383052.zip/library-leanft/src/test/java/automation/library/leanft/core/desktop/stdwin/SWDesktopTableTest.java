package automation.library.leanft.core.desktop.stdwin;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

import com.hp.lft.sdk.GeneralLeanFtException;

public class SWDesktopTableTest {
	
	private static String firstRow = "firstRow";
	
	@Test
	public void SWDesktopTableTest1() {
	    	
	    	try {
	    		SWDesktopTable swDesktopTable = new SWDesktopTable();
				assertThat(swDesktopTable.click(1)).isNull();
			} catch (GeneralLeanFtException e) {
			}
	 }
	
	@Test
	public void SWDesktopTableTest2() {
	    	
	    	try {
	    		SWDesktopTable swDesktopTable = new SWDesktopTable();
				assertThat(swDesktopTable.getCellText(1,1,1)).isNull();
			} catch (GeneralLeanFtException e) {
			}
	 }
	
	@Test
	public void SWDesktopTableTest3() {
	    	
	    	try {
	    		SWDesktopTable swDesktopTable = new SWDesktopTable();
				assertThat(swDesktopTable.selectMatchingRow(1,1,firstRow,1)).isNull();
			} catch (GeneralLeanFtException e) {
			}
	 }
	
	@Test
	public void SWDesktopTableTest4() {
	    	
	    	try {
	    		SWDesktopTable swDesktopTable = new SWDesktopTable();
				assertThat(swDesktopTable.exists(1)).isNull();
			} catch (GeneralLeanFtException e) {
			}
	 }
	
	@Test
	public void SWDesktopTableTest5() {
	    	
	    	try {
	    		SWDesktopTable swDesktopTable = new SWDesktopTable();
				assertThat(swDesktopTable.isEnabled(1)).isEqualTo(false);
			} catch (GeneralLeanFtException e) {
			}
	 }

}
