package automation.library.leanft.core.desktop.winforms;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import com.hp.lft.sdk.GeneralLeanFtException;

public class WFDesktopButtonTest {
	
	private static String windowObjectName="frmLogon";
    private static String windowTitleExp="SSA Gatekeeper"; 
    private static String fullType="SSAGate.frmLogon";
    private static String objectName = "cmdConnect";
    private static String windowFullType="windowFullType";
    private static int index=1;
    private static String text = "text";
    
    static WFDesktopButton wfDesktopButton = null;
    
    @BeforeAll
    public static void setUp()
    {
    	System.setProperty("fw.defaultFindRetries","1");
    	
    	try {
    			wfDesktopButton = new WFDesktopButton(windowObjectName,windowTitleExp,fullType,objectName);
			} catch (GeneralLeanFtException e) {
				
			}
    }
       
    @Test
    public void WFDesktopButtonTest1() {
    	assertThat(wfDesktopButton).isNotNull();
    }
    
    @Test
    public void WFDesktopButtonTest2() {
    	
    	try {
    		wfDesktopButton = new WFDesktopButton(windowObjectName, windowFullType, fullType,index,text);
			assertThat(wfDesktopButton).isNotNull();
		} catch (GeneralLeanFtException e) {
			
		}
    	
    }
    
    @Test
    public void WFDesktopButtonTest3() {
    	
    	try {
    		WFDesktopWindow parentWindow = new WFDesktopWindow(objectName, fullType);
    		wfDesktopButton = new WFDesktopButton(parentWindow, fullType,index,text);
			assertThat(wfDesktopButton).isNotNull();
		} catch (GeneralLeanFtException e) {
			
		}
    	
    }
    
    @Test
    public void WFDesktopButtonTest4() {
    	
    	try {
    		WFDesktopWindow parentUiObj = new WFDesktopWindow(objectName, fullType);
    		wfDesktopButton = new WFDesktopButton(parentUiObj,objectName);
			assertThat(wfDesktopButton).isNotNull();
		} catch (GeneralLeanFtException e) {
			
		}
    	
    }
    
    @Test
    public void WFDesktopButtonTest5() {
    	
    	try {
    			wfDesktopButton = new WFDesktopButton( windowObjectName, windowFullType, "fullNamePath");
				assertThat(wfDesktopButton).isNotNull();
			} catch (GeneralLeanFtException e) {
				
			}
    	
    }
    
    @Test
    public void WFDesktopButtonTest6() {
    	
    	try {
    		    WFDesktopWindow parentWindow = new WFDesktopWindow(objectName, fullType);
    		    wfDesktopButton = new WFDesktopButton(parentWindow, fullType, objectName);
				assertThat(wfDesktopButton).isNotNull();
			} catch (GeneralLeanFtException e) {
				
			}
    	
    }
    
    @Test
    public void getDesktopButtonTest()
    {
    	assertThat(wfDesktopButton.getDesktopButton()).isNotNull();
    }
    
    @Test
    public void getFindRetriesTest() {
    	assertThat(WFDesktopButton.getFindRetries()).isGreaterThan(0);
    }
    
    @Test
    public void existsTest() {
    		assertThrows(GeneralLeanFtException.class, () -> {
    		wfDesktopButton.exists(1);
    	});
    }

    @Test
    public void isEnabledTest() {
    		assertThrows(GeneralLeanFtException.class, () -> {
    		wfDesktopButton.isEnabled(1);
    	});
    }
    
    @Test
    public void clickTest() {
    		assertThrows(GeneralLeanFtException.class, () -> {
    		wfDesktopButton.click(1);
    	});
    }
    
    @Test
    public void doubleClickTest() {
    		assertThrows(GeneralLeanFtException.class, () -> {
    		wfDesktopButton.doubleClick(1);
    	});
    }
    
}
