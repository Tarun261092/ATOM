package automation.library.leanft.core.desktop.winforms;

import org.junit.jupiter.api.Test;

import com.hp.lft.sdk.GeneralLeanFtException;

import static org.assertj.core.api.Assertions.assertThat;

public class WFDesktopDialogTest {
	
	WFDesktopDialog WfDesktopDialog = new WFDesktopDialog();
	
	@Test
    public void getDialogTest() {
		assertThat(WfDesktopDialog.getDialog()).isNull();
    }

    @Test
    public void existsTest() {
    	try {
				assertThat(WfDesktopDialog.exists(1)).isNull();
			} catch (GeneralLeanFtException e) {
			}
    }

    @Test
    public void isEnabledTest() {
    	try {
			assertThat(WfDesktopDialog.isEnabled(1)).isFalse();
			} catch (GeneralLeanFtException e) {
			}
    }
}
