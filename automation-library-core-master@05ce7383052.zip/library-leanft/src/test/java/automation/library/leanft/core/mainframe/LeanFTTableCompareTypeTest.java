package automation.library.leanft.core.mainframe;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class LeanFTTableCompareTypeTest {
    
	@Test
    public void leanFTTableCompareTypeTest() {
		assertThat(LeanFTTableCompareType.valueOfLabel("Full_Row")).isNotNull();
	}
}