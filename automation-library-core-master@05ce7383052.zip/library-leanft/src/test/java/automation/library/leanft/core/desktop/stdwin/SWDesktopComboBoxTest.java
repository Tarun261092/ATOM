package automation.library.leanft.core.desktop.stdwin;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

import com.hp.lft.sdk.GeneralLeanFtException;

public class SWDesktopComboBoxTest {
	
	private static String name = "name";
	
	@Test
	public void SWDesktopComboBoxTest1() {
	    	
	    	try {
	    		SWDesktopComboBox swDesktopComboBox = new SWDesktopComboBox();
				assertThat(swDesktopComboBox.select(name, 1)).isNull();
			} catch (GeneralLeanFtException e) {
			}
	 }
	
	@Test
	public void SWDesktopComboBoxTest2() {
	    	
	    	try {
	    		SWDesktopComboBox swDesktopComboBox = new SWDesktopComboBox();
				assertThat(swDesktopComboBox.select(1, 1)).isNull();
			} catch (GeneralLeanFtException e) {
			}
	 }
	
	@Test
	public void SWDesktopComboBoxTest3() {
	    	
	    	try {
	    		SWDesktopComboBox swDesktopComboBox = new SWDesktopComboBox();
				assertThat(swDesktopComboBox.exists(1)).isNull();
			} catch (GeneralLeanFtException e) {
			}
	 }
	
	@Test
	public void SWDesktopComboBoxTest4() {
	    	
	    	try {
	    		SWDesktopComboBox swDesktopComboBox = new SWDesktopComboBox();
				assertThat(swDesktopComboBox.click(1)).isNull();
			} catch (GeneralLeanFtException e) {
			}
	 }
	
	@Test
	public void SWDesktopComboBoxTest5() {
	    	
	    	try {
	    		SWDesktopComboBox swDesktopComboBox = new SWDesktopComboBox();
				assertThat(swDesktopComboBox.getComboboxValue(1)).isNull();
			} catch (GeneralLeanFtException e) {
			}
	 }
	
	@Test
	public void SWDesktopComboBoxTest6() {
	    	
	    	try {
	    		SWDesktopComboBox swDesktopComboBox = new SWDesktopComboBox();
				assertThat(swDesktopComboBox.isEnabled(1)).isEqualTo(false);
			} catch (GeneralLeanFtException e) {
			}
	 }
}
