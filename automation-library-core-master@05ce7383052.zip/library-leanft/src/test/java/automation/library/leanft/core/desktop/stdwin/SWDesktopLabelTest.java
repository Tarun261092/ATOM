package automation.library.leanft.core.desktop.stdwin;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

import com.hp.lft.sdk.GeneralLeanFtException;

public class SWDesktopLabelTest {
	
	@Test
	public void SWDesktopLabelTest1() {
	    	
	    	try {
	    		SWDesktopLabel swDesktopLabel = new SWDesktopLabel();
				assertThat(swDesktopLabel.exists(1)).isNull();
			} catch (GeneralLeanFtException e) {
			}
	 }
	
	@Test
	public void SWDesktopLabelTest2() {
	    	
	    	try {
	    		SWDesktopLabel swDesktopLabel = new SWDesktopLabel();
				assertThat(swDesktopLabel.click(1)).isNull();
			} catch (GeneralLeanFtException e) {
			}
	 }
	
	@Test
	public void SWDesktopLabelTest3() {
	    	
	    	try {
	    		SWDesktopLabel swDesktopLabel = new SWDesktopLabel();
	    		assertThat(swDesktopLabel.isEnabled(1)).isEqualTo(false);
			} catch (GeneralLeanFtException e) {
			}
	 }
	
	@Test
	public void SWDesktopLabelTest4() {
	    	
	    	try {
	    		SWDesktopLabel swDesktopLabel = new SWDesktopLabel();
				assertThat(swDesktopLabel.getText(1)).isNull();
			} catch (GeneralLeanFtException e) {
			}
	}

}
