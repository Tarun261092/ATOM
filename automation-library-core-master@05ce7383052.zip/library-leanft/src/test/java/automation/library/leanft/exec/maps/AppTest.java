package automation.library.leanft.exec.maps;

import static org.assertj.core.api.Assertions.assertThat;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

public class AppTest {
   
	static App app = new App();
	
	 @BeforeAll
	 public static void beforeAllTestMethods() {
		 app.setEmulatorToUse("emulatorToUse");
		 app.setStartingScreen("startingScreen");
		 app.setStartingField("startingField");
		 app.setLaunchTextToEnter("launchTextToEnter");
	 }

	@Test
    public void getLaunchTextToEnterTest() {
        assertThat(app.getLaunchTextToEnter()).isNotNull();
    }

	@Test
    public void getStartingScreenTest() {
		assertThat(app.getStartingScreen()).isNotNull();
    }
	
	@Test
    public void getStartingFieldTest() {
		assertThat(app.getStartingField()).isNotNull();
    }

	@Test
    public void getEmulatorToUseTest() {
		assertThat(app.getEmulatorToUse()).isNotNull();
    }
   
}
