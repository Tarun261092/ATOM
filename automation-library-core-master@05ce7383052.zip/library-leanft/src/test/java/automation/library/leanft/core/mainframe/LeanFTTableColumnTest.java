package automation.library.leanft.core.mainframe;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.hp.lft.sdk.GeneralLeanFtException;

public class LeanFTTableColumnTest {
    static LeanFTField columnField = null;
    static int valOffset = 1;
    static LeanFTTableCompareType tableCompareType = LeanFTTableCompareType.FIELD_ONLY;
    private LeanFTTable.MultiRow rowNum;
    
    static LeanFTTableColumn leanFTTableColumn = null;
    
    @BeforeAll
    public static void setUp()
    {
    	System.setProperty("fw.defaultFindRetries","1");
    	
    	try {
    			columnField = new LeanFTField("name", 1, 1);
    			leanFTTableColumn = new LeanFTTableColumn(1, 5, columnField, valOffset, tableCompareType);
			} catch (GeneralLeanFtException e) {
				
			}
    }

    @Test
    public void LeanFTTableColumnTest2() {
    	LeanFTTableColumn leanFTTableColumn = new LeanFTTableColumn(1, 5, columnField, valOffset, tableCompareType);
		assertThat(leanFTTableColumn).isNotNull();
    }

    @Test
    public void LeanFTTableColumnTest3() {
        LeanFTTableColumn leanFTTableColumn = new LeanFTTableColumn(1, 1, 5, columnField, valOffset, rowNum, tableCompareType);
    	assertThat(leanFTTableColumn).isNotNull();
    }

    @Test
    public void getColumnFieldTest() {
    	assertThat(leanFTTableColumn.getColumnField()).isNotNull();
    }

    @Test
    public void getRowNumOfMultiRowTest() {
    	assertThat(leanFTTableColumn.getRowNumOfMultiRow()).isGreaterThanOrEqualTo(0);
    }

    @Test
    public void getColLength()  {
    	try {
				assertThat(leanFTTableColumn.getColLength()).isGreaterThanOrEqualTo(0);
			} catch (GeneralLeanFtException e) {
			}
    }
    
    @Test
    public void getColStartNumTest() {
    	assertThat(leanFTTableColumn.getColStartNum()).isGreaterThanOrEqualTo(0);
    }
    
}