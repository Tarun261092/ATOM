package automation.library.leanft.core.desktop.web;

import static org.assertj.core.api.Assertions.assertThat;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.hp.lft.sdk.GeneralLeanFtException;

import automation.library.leanft.core.desktop.stdwin.SWDesktopWindow;
import automation.library.leanft.core.desktop.winforms.WFDesktopWindow;

public class DesktopWebElementTest {
	
	private static String windowObjectName="windowObjectName";
    private static String windowTitle="windowTitle"; 
    private static String fullType="fullType";
    private static String locatorText = "locatorText";
    private static String objectName = "objectName";
    private static String windowClassRegExp = "windowClassRegExp";
    private static String windowTitleRegExp = "windowTitleRegExp";
    static DesktopWebElement desktopWebElement = null;
	
    @BeforeAll
    public static void setUp()
    {
    	System.setProperty("fw.defaultFindRetries", "1");
    	
    	try {
    			desktopWebElement = new DesktopWebElement(windowObjectName,fullType,windowTitle,locatorText,LocatorType.TAGNAME);
			} catch (GeneralLeanFtException e) {
			}
    }
    
    
    @Test
    public void DesktopWebElementTest1() {
    	
    	try {
    		DesktopWebElement dtWebElement = new DesktopWebElement(windowObjectName,fullType,windowTitle,locatorText,LocatorType.TAGNAME);
			assertThat(dtWebElement).isNotNull();
		} catch (GeneralLeanFtException e) {
			
		}
    	
    }
    
    @Test
    public void DesktopWebElementTest2() {
    	
    	try {
    		WFDesktopWindow parentWindow = new WFDesktopWindow(objectName, fullType);
    		DesktopWebElement dtWebElement = new DesktopWebElement(parentWindow,locatorText,LocatorType.get("id"));
			assertThat(dtWebElement).isNotNull();
		} catch (GeneralLeanFtException e) {
			
		}
    	
    }
    
    @Test
    public void DesktopWebElementTest3() {
    	
    	try {
    		WFDesktopWindow parentWindow = new WFDesktopWindow(objectName, fullType);
    		DesktopWebElement dtWebElement = new DesktopWebElement(parentWindow,locatorText,LocatorType.get("css"));
			assertThat(dtWebElement).isNotNull();
		} catch (GeneralLeanFtException e) {
			
		}
    	
    }
    
    @Test
    public void DesktopWebElementTest4() {
    	
    	try {
    		WFDesktopWindow parentWindow = new WFDesktopWindow(objectName, fullType);
    		DesktopWebElement dtWebElement = new DesktopWebElement(parentWindow,locatorText,LocatorType.XPATH);
			assertThat(dtWebElement).isNotNull();
		} catch (GeneralLeanFtException e) {
			
		}
    	
    }
    
    @Test
    public void DesktopWebElementTest5() {
    	
    	try {
    		WFDesktopWindow parentWindow = new WFDesktopWindow(objectName, fullType);
    		SWDesktopWindow swDesktopWindow =  new SWDesktopWindow(windowClassRegExp, windowTitleRegExp);
    		DesktopWebElement dtWebElement = new DesktopWebElement(parentWindow,swDesktopWindow,locatorText,LocatorType.NAME);
			assertThat(dtWebElement).isNotNull();
		} catch (GeneralLeanFtException e) {
			
		}
    	
    }
       
    @Test
    public void DesktopWebElemenTest6() {
    	
    	try {
	    		DesktopWebElement dtWebElement = new DesktopWebElement(windowTitle, "CHROME", objectName, "xpath");
				assertThat(dtWebElement).isNotNull();
			} catch (GeneralLeanFtException e) {
				
			}
		}
		
    @Test
    public void DesktopWebElementTest7() {
		
    	try {
    			WebDesktopBrowserWindow parentWindow = new WebDesktopBrowserWindow(objectName, "CHROME");
	    		DesktopWebElement dtWebElement = new DesktopWebElement(parentWindow, objectName, "xpath");
				assertThat(dtWebElement).isNotNull();
			} catch (GeneralLeanFtException e) {
				
			}
    }

    @Test
    public void getWebElementTest()
    {
    	assertThat(desktopWebElement.getWebElement()).isNotNull();
    }
    
    
    @Test
    public void getSelectTest1()
    {
    	try {
			assertThat(desktopWebElement.select("1", 1)).isNull();
		} catch (GeneralLeanFtException e) {
		}
    }
  
    @Test
    public void getSelectTest2()
    {
    	try {
			assertThat(desktopWebElement.select(1, 1)).isNull();
		} catch (GeneralLeanFtException e) {
		}
    }
    
    @Test
    public void setTextTest()
    {
    	try {
			assertThat(desktopWebElement.setText("text", 1)).isNull();
		} catch (GeneralLeanFtException e) {
		}
    }
    
   
    @Test
    public void existsTest()  {
    	 try {
				assertThat(desktopWebElement.exists(1)).isNull();
			 } catch (GeneralLeanFtException e) {
			}
    }

    @Test
    public void getFindRetriesTest() {
    	assertThat(DesktopWebElement.getFindRetries()).isGreaterThan(0);
    }

    @Test
    public void isEnabledTest() {
    	try {
				assertThat(desktopWebElement.isEnabled(1)).isFalse();
			} catch (GeneralLeanFtException e) {
			}
  
    }
    
    @Test
    public void getTextTest()  {
    	 try {
				assertThat(desktopWebElement.getText(1)).isNotNull();
			 } catch (GeneralLeanFtException e) {
			}
    }

}
