package automation.library.leanft.core.desktop.stdwin;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

import com.hp.lft.sdk.GeneralLeanFtException;

public class SWDesktopWindowTest {
	
	private static String windowClassRegExp = "windowClassRegExp";
	private static String windowTitleRegExp = "windowTitleRegExp";
	private static boolean childWindow = true;
	private static boolean ownedWindow = true;
	private static String text = "text";
	private static int index =1;
	
	@Test
	public void SWDesktopWindowTest1() {
	    	
	    	try {
	    		SWDesktopWindow swDesktopWindow = new SWDesktopWindow(windowClassRegExp,windowTitleRegExp);
				assertThat(swDesktopWindow).isNotNull();
			} catch (GeneralLeanFtException e) {
			}
	    	
	}
	
	@Test
	public void SWDesktopWindowTest2() {
	    	
	    	try {
	    		SWDesktopWindow swDesktopWindow = new SWDesktopWindow(windowClassRegExp,windowTitleRegExp,childWindow,ownedWindow);
				assertThat(swDesktopWindow).isNotNull();
			} catch (GeneralLeanFtException e) {
			}
	    	
	}
	
	@Test
	public void SWDesktopWindowTest3() {
	    	
	    	try {
	    		SWDesktopWindow swDesktopWindow = new SWDesktopWindow(windowClassRegExp,text,index);
				assertThat(swDesktopWindow).isNotNull();
			} catch (GeneralLeanFtException e) {
			}
	    	
	 }
	
	@Test
	public void SWDesktopWindowTest4() {
	    	
	    	try {
	    		SWDesktopWindow swDesktopWindow = new SWDesktopWindow(windowClassRegExp,text,index);
				assertThat(swDesktopWindow.getWindow()).isNotNull();
			} catch (GeneralLeanFtException e) {
			}
	    	
	 }

}
