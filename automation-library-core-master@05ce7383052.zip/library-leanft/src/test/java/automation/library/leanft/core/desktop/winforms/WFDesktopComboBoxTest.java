package automation.library.leanft.core.desktop.winforms;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import com.hp.lft.sdk.GeneralLeanFtException;

public class WFDesktopComboBoxTest {
	
	private static String windowObjectName="RPLBillingUI";
    private static String windowTitleRegExp="Billing Profile"; 
    private static String fullType="rBillingPrDotNet.RPLBillingUI";
    private static String objectName = "cboMediaReq";
    
    static WFDesktopComboBox WfDesktopComboBox = null;
    
    @BeforeAll
    public static void setUp()
    {
    	System.setProperty("fw.defaultFindRetries","1");
    	
    	try {
    			WfDesktopComboBox = new WFDesktopComboBox(windowObjectName,windowTitleRegExp,fullType,objectName);
			} catch (GeneralLeanFtException e) {
				
			}
    }
    
    @Test
	public void WFDesktopComboBoxTest1() {    	
				assertThat(WfDesktopComboBox).isNotNull();
    }
    
    @Test
	public void WFDesktopComboBoxTest2() {
	    	
	    	try {
	    		WFDesktopWindow window = new WFDesktopWindow(windowObjectName, windowTitleRegExp,fullType);
	    		WFDesktopComboBox wfDesktopComboBoxlocal = new WFDesktopComboBox(window,objectName);
				assertThat(wfDesktopComboBoxlocal).isNotNull();
			} catch (GeneralLeanFtException e) {
				
			}    	
	}
    
    @Test
	public void getDesktopComboBoxTest()
	{
    	assertThat(WfDesktopComboBox.getDesktopComboBox()).isNotNull();
	}
    
    @Test
    public void getFindRetriesTest() {
    	assertThat(WFDesktopComboBox.getFindRetries()).isGreaterThan(0);
    }
    
    @Test
    public void existsTest() {
    	assertThrows(GeneralLeanFtException.class, () -> {
    		WfDesktopComboBox.exists(1);
    	});
    }

    @Test
    public void isEnabledTest() {
    	assertThrows(GeneralLeanFtException.class, () -> {
    		WfDesktopComboBox.isEnabled(1);
    	});
    }
    
    @Test
    public void getComboboxValueTest() {
    	assertThrows(GeneralLeanFtException.class, () -> {
    		WfDesktopComboBox.getComboboxValue(1);
    	});
    }
    
    @Test
    public void selectTest() {
    	assertThrows(GeneralLeanFtException.class, () -> {
    		WfDesktopComboBox.select(1,1);
    	});
    }
    
    @Test
    public void selectTest1() {
    	assertThrows(GeneralLeanFtException.class, () -> {
    		WfDesktopComboBox.select(objectName,1);
    	});
    }
    
    @Test
    public void clickTest() {
    	assertThrows(GeneralLeanFtException.class, () -> {
    		WfDesktopComboBox.click(1);
    	});
    }
    
    
}