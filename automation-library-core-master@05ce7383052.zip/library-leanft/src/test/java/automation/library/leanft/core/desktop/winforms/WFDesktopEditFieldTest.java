package automation.library.leanft.core.desktop.winforms;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.hp.lft.sdk.GeneralLeanFtException;

public class WFDesktopEditFieldTest {
	
		private static String windowObjectName="RPLBillingUI";
	    private static String fullNamePath="fullNamePath"; 
	    private static String fullType="rBillingPrDotNet.RPLBillingUI";
	    private static String objectName = "dtfrom";
		private static String windowFullType = "windowFullType";
		private static int index = 1;
		
		static WFDesktopEditField WfDesktopEditField = null;
		    
		@BeforeAll
		public static void setUp()
		{
		   System.setProperty("fw.defaultFindRetries","1");
		    	
		   try {
			   	WfDesktopEditField = new WFDesktopEditField(windowObjectName,fullType,objectName);
			   } catch (GeneralLeanFtException e) {
						
					}
		}
		
		@Test
		public void WFDesktopEditFieldTest1() {
				assertThat(WfDesktopEditField).isNotNull();   	
	    }
	
		@Test
		public void WFDesktopEditFieldTest2() {
	    	
	    	try {
	    		WFDesktopEditField wfDesktopEditField = new WFDesktopEditField(windowObjectName,windowFullType,fullType,index);
				assertThat(wfDesktopEditField).isNotNull();
			} catch (GeneralLeanFtException e) {
				
			}
	    	
	    }
	
		@Test
		public void WFDesktopEditFieldTest3() {
	    	
	    	try {
	    		
	    		WFDesktopEditField wfDesktopEditField = new WFDesktopEditField(windowObjectName,windowFullType,objectName,fullNamePath);
				assertThat(wfDesktopEditField).isNotNull();
			} catch (GeneralLeanFtException e) {
				
			}
	    	
	    }
	
		@Test
		public void WFDesktopEditFieldTest4() {
	    	
	    	try {
	    		WFDesktopWindow parentWindow = new WFDesktopWindow(windowObjectName, fullType);
	    		WFDesktopEditField wfDesktopEditField = new WFDesktopEditField(parentWindow, objectName);
				assertThat(wfDesktopEditField).isNotNull();
			} catch (GeneralLeanFtException e) {
				
			}
	    	
	    }
	
		@Test
		public void WFDesktopEditFieldTest5() {
	    	
	    	try {
	    		WFDesktopWindow parentWindow = new WFDesktopWindow(objectName, fullType);
	    		WFDesktopEditField wfDesktopEditField = new WFDesktopEditField(parentWindow, fullType, objectName);
				assertThat(wfDesktopEditField).isNotNull();
			} catch (GeneralLeanFtException e) {
				
			}
	    	
	    }
	
		@Test
		public void WFDesktopEditFieldTest6() {
	    	
	    	try {
	    		WFDesktopWindow parentWindow = new WFDesktopWindow(objectName, fullType);
	    		WFDesktopEditField wfDesktopEditField = new WFDesktopEditField(parentWindow, fullType, index);
				assertThat(wfDesktopEditField).isNotNull();
			} catch (GeneralLeanFtException e) {
				
			}
	    	
	    }
	
		@Test
	    public void setTextTest()
	    {
			assertThrows(GeneralLeanFtException.class, () -> {
	    		WfDesktopEditField.setText(objectName,1);
	    	});
	    }
	
	
		@Test
	    public void getEditFieldTest()
		{
			assertThat(WfDesktopEditField.getEditField()).isNotNull();
		}
	
	 	@Test
	    public void getTextTest()
	    {
	 		assertThrows(GeneralLeanFtException.class, () -> {
	    		WfDesktopEditField.getText(1);
	    	});
	    }
	    
	    @Test
	    public void getFindRetriesTest() {
	    	assertThat(WFDesktopEditField.getFindRetries()).isGreaterThan(0);
	    }
	    
	    @Test
	    public void existsTest() {
	    	assertThrows(GeneralLeanFtException.class, () -> {
	    		WfDesktopEditField.exists(1);
	    	});
	    }

	    @Test
	    public void isEnabledTest() {
	    	assertThrows(GeneralLeanFtException.class, () -> {
	    		WfDesktopEditField.isEnabled(1);
	    	});
	    }
	
}
