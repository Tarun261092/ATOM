package automation.library.leanft.core;

import org.junit.jupiter.api.Test;
import static org.assertj.core.api.Assertions.assertThat;

import com.hp.lft.sdk.GeneralLeanFtException;

import automation.library.leanft.core.mainframe.LeanFTScreen;

public class LeanFTFieldTest {

	@Test
    public void LeanFTFieldTest1() {
        try {
			assertThat(new LeanFTField("name", "label", 1)).isNotNull();
		} catch (GeneralLeanFtException e) {
		}
    }

	@Test
    public void LeanFTFieldTest2() {
    	try {
    		assertThat(new LeanFTField("name", "label", 1)).isNotNull();
		} catch (GeneralLeanFtException e) {
		}
    }

	@Test
    public void LeanFTFieldTest3() {
    	try {
    		assertThat(new LeanFTField("name", 1, 1)).isNotNull();
		} catch (GeneralLeanFtException e) {
		}
    }

    @Test
    public void LeanFTFieldTest4()  {
    	try {
    		assertThat(new LeanFTField(new LeanFTScreen("name", 1), 1, 1)).isNotNull();
		} catch (GeneralLeanFtException e) {
		}
    }
}
