package automation.library.leanft.core.mainframe;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.core.config.Configurator;

import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.Keyboard;

import automation.library.leanft.core.mainframe.LeanFTTable.MultiRow;

public class LeanFTTableTest {

    static LeanFTScreen parentScreen;
    static int maxRowsPerScreen = 1;
    static Keyboard.Keys keyToPriorScreen;
    static LeanFTTableCompareType tableCompareType = LeanFTTableCompareType.FULL_TABLE;
    static LeanFTField leanFTField;
    private boolean searchCurrentScreenOnly = false;
    
    static LeanFTTable leanFTTable = null;
    
    @BeforeAll
    public static void setUp()
    {
    	System.setProperty("fw.defaultFindRetries","1");
    	
    	try {
    		    parentScreen = new LeanFTScreen("name", "id");
    		    leanFTField = new LeanFTField("name", "screenId", 1);
    			leanFTTable = new LeanFTTable("name", "label", maxRowsPerScreen, tableCompareType);
                leanFTTable.setBeginningOfTableIndicator(leanFTField, "begOfTableText", keyToPriorScreen);
                leanFTTable.setEndOfTableIndicator(leanFTField, "begOfTableText", keyToPriorScreen);
			} catch (GeneralLeanFtException e) {
				
			}
    	Configurator.setLevel("automation.library.leanft.core.mainframe", Level.OFF);
    }

    @Test
    public void LeanFTTableTest1() {
    	LeanFTTable leanFTTable = new LeanFTTable(parentScreen, maxRowsPerScreen, tableCompareType, searchCurrentScreenOnly);
		assertThat(leanFTTable).isNotNull();	
    }

    @Test
    public void LeanFTTableTest2() {
    	LeanFTTable leanFTTable = new LeanFTTable(parentScreen, maxRowsPerScreen, tableCompareType);
		assertThat(leanFTTable).isNotNull();
    }

    @Test
    public void LeanFTTableTest3() {
    	LeanFTTable leanFTTable = null;
    	
		try {
				leanFTTable = new LeanFTTable("name", "label", maxRowsPerScreen, tableCompareType);
			} catch (GeneralLeanFtException e) {
			}
		assertThat(leanFTTable).isNotNull();
    }

    @Test
    public void LeanFTTableTest4() {
    	LeanFTTable leanFTTable = null;
    	
		try {
				leanFTTable = new LeanFTTable("name", "label", maxRowsPerScreen, tableCompareType, searchCurrentScreenOnly);
			} catch (GeneralLeanFtException e) {
			}
		assertThat(leanFTTable).isNotNull();
    }
    
    @Test
    public void addColumnTest1() {
		assertThat(leanFTTable.addColumn("columnName", leanFTField, 1)).isNotNull();		
    }
    
    @Test
    public void addColumnTest2() {
    	assertThat(leanFTTable.addColumn("columnName", leanFTField)).isNotNull();
    }

    @Test
    public void addColumnTest3() {
    	assertThat(leanFTTable.addColumn("columnName", 1 , 2, leanFTField)).isNotNull();
    }

    @Test
    public void addColumnTest4() {
    	assertThat(leanFTTable.addColumn("columnName", 1 , 2, leanFTField,1)).isNotNull();
    }

    @Test
    public void addColumnTest5() {
    	assertThat(leanFTTable.addColumn("columnName", 0, 1 , 2, leanFTField, 1, MultiRow.ROW1)).isNotNull();
    }

    @Test
    public void addColumnTest6() {
    	assertThat(leanFTTable.addColumn("columnName", 0, 1 , 2, leanFTField, MultiRow.ROW1)).isNotNull();
    }

    @Test
    public void addColumnTest7() {
    	assertThat(leanFTTable.addColumn("columnName", 1 , 2, leanFTField, MultiRow.ROW1)).isNotNull();
    }

    @Test
    public void addColumnTest8() {
    	assertThat(leanFTTable.addColumn("columnName", 0, 1 , 2, leanFTField)).isNotNull();
    }
    
    @Test
    public void checkForMatchInTableTest1() {
    	try {
				leanFTTable.addColumn("columnName1", 1 , 2, leanFTField);
				assertThat(leanFTTable.checkForMatchInTable("columnName1", "firstValToMatch")).isNotNull();
			} catch (GeneralLeanFtException e) {
			}
    }
    
    @Test
    public void checkForMatchInTableTest2() {
    	try {
				leanFTTable.addColumn("columnName1", 1 , 2, leanFTField);
				leanFTTable.addColumn("columnName2", 1 , 2, leanFTField);
				assertThat(leanFTTable.checkForMatchInTable("columnName1", "firstValToMatch","columnName2", "secondValToMatch")).isNotNull();
			} catch (GeneralLeanFtException e) {
			}
    }

    @Test
    public void checkForMatchInTableTest3() {
    	try {
				leanFTTable.addColumn("columnName1", 1 , 2, leanFTField);
				leanFTTable.addColumn("columnName2", 1 , 2, leanFTField);
				leanFTTable.addColumn("columnName3", 1 , 2, leanFTField);
				assertThat(leanFTTable.checkForMatchInTable("columnName1", "firstValToMatch","columnName2", "secondValToMatch","columnName3", "thirdValToMatch")).isNotNull();
			} catch (GeneralLeanFtException e) {
			}
    }

    @Test
    public void checkForMatchInTableTest4() {
    	try {
				leanFTTable.addColumn("columnName1", 1 , 2, leanFTField);
				leanFTTable.addColumn("columnName2", 1 , 2, leanFTField);
				leanFTTable.addColumn("columnName3", 1 , 2, leanFTField);
				leanFTTable.addColumn("columnName4", 1 , 2, leanFTField);
				assertThat(leanFTTable.checkForMatchInTable("columnName1", "firstValToMatch","columnName2", "secondValToMatch","columnName3", "thirdValToMatch","columnName4", "fourthValToMatch")).isNotNull();
			} catch (GeneralLeanFtException e) {
			}
    }
    
    @Test
    public void retrieveColumnValTest1() {
    	try {
    			leanFTTable.addColumn("columnName", 1 , 2, leanFTField);
				assertThat(leanFTTable.retrieveColumnVal("colNameToRetrieve", "columnName", "colValToMatch")).isNotNull();
			} catch (GeneralLeanFtException e) {
			}
    }
    
    @Test
    public void retrieveColumnValTest2() {
    	 try {
				leanFTTable.addColumn("columnName1", 1 , 2, leanFTField);
				leanFTTable.addColumn("columnName2", 1 , 2, leanFTField);
				assertThat(leanFTTable.retrieveColumnVal("colNameToRetrieve", "columnName1", "colValToMatch1", "columnName2", "colValToMatch2")).isNotNull();
			} catch (GeneralLeanFtException e) {
			}
    }

    @Test
    public void retrieveColumnValTest3() {
    	 try {
				leanFTTable.addColumn("columnName1", 1 , 2, leanFTField);
				leanFTTable.addColumn("columnName2", 1 , 2, leanFTField);
				leanFTTable.addColumn("columnName3", 1 , 2, leanFTField);
				assertThat(leanFTTable.retrieveColumnVal("colNameToRetrieve", "columnName1", "colValToMatch1", "columnName2", "colValToMatch2", "columnName3", "colValToMatch3")).isNotNull();
			} catch (GeneralLeanFtException e) {
			}
    }

    @Test
    public void retrieveColumnValTest4() {
    	try {
				leanFTTable.addColumn("columnName1", 1 , 2, leanFTField);
				leanFTTable.addColumn("columnName2", 1 , 2, leanFTField);
				leanFTTable.addColumn("columnName3", 1 , 2, leanFTField);
				leanFTTable.addColumn("columnName4", 1 , 2, leanFTField);
				assertThat(leanFTTable.retrieveColumnVal("colNameToRetrieve", "columnName1", "colValToMatch1", "columnName2", "colValToMatch2", "columnName3", "colValToMatch3","columnName4", "colValToMatch4")).isNotNull();
			} catch (GeneralLeanFtException e) {
			}
    }


}