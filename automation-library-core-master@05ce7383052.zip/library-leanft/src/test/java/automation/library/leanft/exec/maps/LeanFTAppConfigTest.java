package automation.library.leanft.exec.maps;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.HashMap;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

public class LeanFTAppConfigTest {
   
	static LeanFTAppConfig leanFTAppConfig = new LeanFTAppConfig();
	static HashMap<String, App> appList = new HashMap<String, App>();
	static HashMap<String, DesktopApplication> desktopApplicationList = new HashMap<String, DesktopApplication>();
	static HashMap<String, DesktopApplication> terminalEmulatorsList = new HashMap<String, DesktopApplication>();
	static DesktopApplication desktopApplication = new DesktopApplication();
	
	 @BeforeAll
	 public static void beforeAllTestMethods() {
		 appList.put("app1", new App());
		 desktopApplicationList.put("desktopApp1", desktopApplication);
		 
		 leanFTAppConfig.setAppList(appList);
		 leanFTAppConfig.setDesktopApplications(desktopApplicationList);
		 leanFTAppConfig.setTerminalEmulators(terminalEmulatorsList);		 
	 }
	
	@Test
    public void getAppListTest() {
		assertThat(leanFTAppConfig.getAppList()).isNotNull();
	}

	@Test
    public void getDesktopApplicationsTest() {
		assertThat(leanFTAppConfig.getDesktopApplications()).isNotNull();
    }
	
	@Test
    public void getTerminalEmulatorsTest() {
		assertThat(leanFTAppConfig.getTerminalEmulators()).isNotNull();
    }

}