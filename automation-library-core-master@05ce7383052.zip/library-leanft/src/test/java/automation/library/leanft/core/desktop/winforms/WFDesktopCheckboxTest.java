package automation.library.leanft.core.desktop.winforms;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.hp.lft.sdk.GeneralLeanFtException;

public class WFDesktopCheckboxTest {
	
    private static String windowObjectName="RPLBillingUI";
    private static String windowTitleExp="Billing Profile"; 
    private static String fullType="rBillingPrDotNet.RPLBillingUI";
    private static String objectName = "chkWithin10";
    
    static WFDesktopCheckbox WfDesktopCheckbox = null;
    
	@BeforeAll
	public static void setUp()
	{
	   System.setProperty("fw.defaultFindRetries","1");
	    	
	   try {
		   		WfDesktopCheckbox = new WFDesktopCheckbox(windowObjectName,windowTitleExp,fullType,objectName);
		   } catch (GeneralLeanFtException e) {
					
				}
	}

    @Test
	public void WFDesktopCheckboxTest1() {
	    	
	    	try {
	    		WFDesktopCheckbox wfDesktopCheckBox = new WFDesktopCheckbox(windowObjectName,windowTitleExp,fullType,objectName);
				assertThat(wfDesktopCheckBox).isNotNull();
			} catch (GeneralLeanFtException e) {
				
			}
	    	
	}
    
    @Test
	public void WFDesktopCheckboxTest2() {
	    	
	    	try {
	    		WFDesktopWindow parentWindow = new WFDesktopWindow(objectName, fullType);
	    		WFDesktopCheckbox wfDesktopCheckBox = new WFDesktopCheckbox(parentWindow,objectName);
				assertThat(wfDesktopCheckBox).isNotNull();
			} catch (GeneralLeanFtException e) {	
			}    	
	}
  
    @Test
    public void getDesktopCheckboxTest()
    {
    	assertThat(WfDesktopCheckbox.getDesktopCheckbox()).isNotNull();
    }
    
    @Test
    public void getFindRetriesTest() {
    	assertThat(WFDesktopCheckbox.getFindRetries()).isGreaterThan(0);
    }
    
    @Test
    public void existsTest() {
    	try {
				assertThat(WfDesktopCheckbox.exists(1)).isNull();
			} catch (GeneralLeanFtException e) {
			}
    }

    @Test
    public void isEnabledTest() {
    		assertThrows(GeneralLeanFtException.class, () -> {
    		WfDesktopCheckbox.isEnabled(1);
    	});
    }
    
    @Test
    public void isCheckedTest() {
    		assertThrows(GeneralLeanFtException.class, () -> {
    		WfDesktopCheckbox.isChecked(1);
    	});
    }
    
    @Test
    public void clickTest() {
    		assertThrows(GeneralLeanFtException.class, () -> {
    		WfDesktopCheckbox.click(1);
    	});
    }
}