package automation.library.leanft.core.mainframe;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.hp.lft.sdk.GeneralLeanFtException;

public class LeanFTScreenTest {
	
    static String name = "name";
    static String label = "label";
    static int id = 1;

    static LeanFTScreen leanFTScreen = null;
    
    @BeforeAll
    public static void setUp()
    {
    	System.setProperty("fw.defaultFindRetries","1");
    	
    	try {
    			leanFTScreen = new LeanFTScreen(name, id);
			} catch (GeneralLeanFtException e) {
				
			}
    }

    @Test
    public void LeanFTScreenTest1(){
    	
    	try {
    			LeanFTScreen leanFTScreen = new LeanFTScreen(name, label);
				assertThat(leanFTScreen).isNotNull();
			} catch (GeneralLeanFtException e) {
			}
    }

    @Test
    public void LeanFTScreenTest2(){
    	
    	try {
    			LeanFTScreen leanFTScreen = new LeanFTScreen(name, id);
				assertThat(leanFTScreen).isNotNull();
			} catch (GeneralLeanFtException e) {
			}
    }

    @Test
    public void LeanFTScreenTest3(){
    	
    	try {
    			LeanFTScreen leanFTScreen = new LeanFTScreen(name, label, true);
				assertThat(leanFTScreen).isNotNull();
			} catch (GeneralLeanFtException e) {
			}
    }

    @Test
    public void LeanFTScreenTest4(){
    	
    	try {
    		  	List<Integer> list = new ArrayList<Integer>();
    		  	list.add(1);
    		  
    			LeanFTScreen leanFTScreen = new LeanFTScreen(name, list);
				assertThat(leanFTScreen).isNotNull();
			} catch (GeneralLeanFtException e) {
			}
    }

 
    @Test
    public void getScreenTest() {
    	assertThat(leanFTScreen.getScreen()).isNotNull();
    }

    @Test
    public void getParentWindowTest() {
    	assertThat(leanFTScreen.getParentWindow()).isNotNull();
    }

    @Test
    public void getIdTest() {
    	assertThat(leanFTScreen.getId()).isGreaterThan(0);
    }

    @Test
    public void getFindRetriesTest() {
    	assertThat(LeanFTScreen.getFindRetries()).isGreaterThan(0);
    }
    
    @Test
    public void sendKeysTest(){
    	assertThrows(GeneralLeanFtException.class, () -> {
    		leanFTScreen.sendKeys("keys",1);
    	});
    }

}
