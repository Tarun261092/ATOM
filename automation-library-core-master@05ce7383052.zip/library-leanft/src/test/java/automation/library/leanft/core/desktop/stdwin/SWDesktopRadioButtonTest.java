package automation.library.leanft.core.desktop.stdwin;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

import com.hp.lft.sdk.GeneralLeanFtException;

public class SWDesktopRadioButtonTest {
	
private static String value = "value";
	
	@Test
	public void SWDesktopRadioButtonTest1() {
	    	
	    	try {
	    		SWDesktopRadioButton swDesktopRadioButton = new SWDesktopRadioButton();
				assertThat(swDesktopRadioButton.click(1)).isNull();
			} catch (GeneralLeanFtException e) {
			}
	 }
	
	@Test
	public void SWDesktopRadioButtonTest2() {
	    	
	    	try {
	    		SWDesktopRadioButton swDesktopRadioButton = new SWDesktopRadioButton();
				assertThat(swDesktopRadioButton.exists(1)).isNull();
			} catch (GeneralLeanFtException e) {
			}
	 }
	
	@Test
	public void SWDesktopRadioButtonTest3() {
	    	
	    	try {
	    		SWDesktopRadioButton swDesktopRadioButton = new SWDesktopRadioButton();
				assertThat(swDesktopRadioButton.select(1,1)).isNull();
			} catch (GeneralLeanFtException e) {
			}
	 }
	
	@Test
	public void SWDesktopRadioButtonTest4() {
	    	
	    	try {
	    		SWDesktopRadioButton swDesktopRadioButton = new SWDesktopRadioButton();
				assertThat(swDesktopRadioButton.select(value,1)).isNull();
			} catch (GeneralLeanFtException e) {
			}
	 }
	
	@Test
	public void SWDesktopRadioButtonTest5() {
	    	
	    	try {
	    		SWDesktopRadioButton swDesktopRadioButton = new SWDesktopRadioButton();
				assertThat(swDesktopRadioButton.isEnabled(1)).isEqualTo(false);
			} catch (GeneralLeanFtException e) {
			}
	}

}
