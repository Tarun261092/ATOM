package automation.library.leanft.core;

import org.junit.jupiter.api.Test;
import static org.assertj.core.api.Assertions.assertThat;

import com.hp.lft.sdk.GeneralLeanFtException;

public class LeanFTTableTest  {

	@Test
	public void leanFTTableTest() {
		
		LeanFTScreen leanFTScreen = null;
		
		try {
				 leanFTScreen = new LeanFTScreen("name", 1);
				
				 assertThat(new LeanFTTable(leanFTScreen, 1, LeanFTTableCompareType.FULL_ROW)).isNotNull();
				 assertThat(new LeanFTTable(leanFTScreen, 1, LeanFTTableCompareType.FULL_ROW, false)).isNotNull();
				 assertThat(new LeanFTTable("name", "label", 1, LeanFTTableCompareType.FULL_ROW, false)).isNotNull();
				 assertThat(new LeanFTTable("name", "label", 1 , LeanFTTableCompareType.FULL_ROW)).isNotNull();
			} catch (GeneralLeanFtException e) {
			}	
	}
	
	
	 

}