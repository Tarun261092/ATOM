package automation.library.leanft.core.desktop.web;

import static org.assertj.core.api.Assertions.assertThat;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.hp.lft.sdk.GeneralLeanFtException;

import automation.library.leanft.core.desktop.stdwin.SWDesktopWindow;
import automation.library.leanft.core.desktop.winforms.WFDesktopWindow;

public class DesktopWebPageEmbeddedTest {
	
	private static String windowClassRegExp = "windowClassRegExp";
	private static String windowTitleRegExp = "windowTitleRegExp";
	private static String windowObjectName="windowObjectName";
    private static String windowTitle="windowTitle"; 
    private static String fullType="fullType";
	static DesktopWebPageEmbedded desktopWebPageEmbedded = null;
	
    @BeforeAll
    public static void setUp()
    {
    	System.setProperty("fw.defaultFindRetries", "1");
    	
    	try {
    			desktopWebPageEmbedded = new DesktopWebPageEmbedded(windowObjectName,fullType,windowTitle);
			} catch (GeneralLeanFtException e) {
			}
    }
    
    @Test
    public void DesktopWebPageEmbeddedTest1() {
    	
    	try {
    		DesktopWebPageEmbedded dtWebPageEmbedded = new DesktopWebPageEmbedded(windowObjectName,fullType,windowTitle);
			assertThat(dtWebPageEmbedded).isNotNull();
		} catch (GeneralLeanFtException e) {
			
		}
    	
    }
    
    @Test
    public void DesktopWebPageEmbeddedTest2() {
    	
    	try {
    		WFDesktopWindow wfDesktopWindow = new WFDesktopWindow(windowObjectName, windowTitle, fullType);
    		DesktopWebPageEmbedded dtWebPageEmbedded = new DesktopWebPageEmbedded(wfDesktopWindow);
			assertThat(dtWebPageEmbedded).isNotNull();
		} catch (GeneralLeanFtException e) {
			
		}
    	
    }
    
    @Test
    public void DesktopWebPageEmbeddedTest3() {
    	
    	try {
    		WFDesktopWindow wfDesktopWindow = new WFDesktopWindow(windowObjectName, windowTitle, fullType);
    		SWDesktopWindow swDesktopWindow = new SWDesktopWindow(windowClassRegExp,windowTitleRegExp);
    		DesktopWebPageEmbedded dtWebPageEmbedded = new DesktopWebPageEmbedded(wfDesktopWindow,swDesktopWindow);
			assertThat(dtWebPageEmbedded).isNotNull();
		} catch (GeneralLeanFtException e) {
			
		}
    	
    }
    
    @Test
    public void getButtonTest()
    {
    	assertThat(desktopWebPageEmbedded.getEmbeddedPage()).isNotNull();
    }
    
    @Test
    public void existsTest()  {
    	 try {
				assertThat(desktopWebPageEmbedded.exists(1)).isNull();
			 } catch (GeneralLeanFtException e) {
			}
    }
  
    @Test
    public void selectTest1() {
    	try {
    			assertThat(desktopWebPageEmbedded.select(1, 1)).isNull();
			} catch (GeneralLeanFtException e) {
			}
  
    }
    
    @Test
    public void selectTest2() {
    	try {
    			assertThat(desktopWebPageEmbedded.select("1", 1)).isNull();
			} catch (GeneralLeanFtException e) {
			}
  
    }
    
    @Test
    public void isEnabledTest() {
    	try {
				assertThat(desktopWebPageEmbedded.isEnabled(1)).isFalse();
			} catch (GeneralLeanFtException e) {
			}
  
    } 
    
    @Test
    public void getSetTextTest() {
    	try {
			desktopWebPageEmbedded.setText("text", 1);
			assertThat(desktopWebPageEmbedded.getText(1)).isNull();
		} catch (GeneralLeanFtException e) {
		}
    }
    
    @Test
    public void hoverTest()
    {
    	try {
				assertThat(desktopWebPageEmbedded.hover(1)).isNull();
			} catch (GeneralLeanFtException e) {
			}
    }
    
    @Test
    public void clickTest()
    {
    	try {
				assertThat(desktopWebPageEmbedded.click(1)).isNull();
			} catch (GeneralLeanFtException e) {
			}
    }
    
    @Test
    public void doubleClickTest()
    {
    	try {
				assertThat(desktopWebPageEmbedded.doubleClick(1)).isNull();
			} catch (GeneralLeanFtException e) {
			}
    }
 
}
