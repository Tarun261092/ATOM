package automation.library.leanft.core.desktop.winforms;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.hp.lft.sdk.GeneralLeanFtException;

public class WFDesktopLabelTest {
	
		private static String windowObjectName="MsgUI";
	    private static String fullType="DesktopDialogSvr.MsgUI";
	    private static String labelObjectName = "lblMsg";
	    private static String uiObjectName = "uiMsg";
	    private static String text = "text";
	    
	    static WFDesktopLabel WfDesktopLabel = null;
	    
	    @BeforeAll
	    public static void setUp()
	    {
	    	System.setProperty("fw.defaultFindRetries","1");
	    	
	    	try {
	    			WfDesktopLabel = new WFDesktopLabel(windowObjectName,fullType,labelObjectName);
				} catch (GeneralLeanFtException e) {
					
				}
	    }
	    
		@Test
		public void WFDesktopLabelTest1() {
				assertThat(WfDesktopLabel).isNotNull();
	    }
		
		@Test
		public void WFDesktopLabelTest2() {
	    	
	    	try {
	    		WFDesktopLabel wfDesktopLabel = new WFDesktopLabel(windowObjectName,fullType,uiObjectName,labelObjectName,text);
	    		assertThat(wfDesktopLabel).isNotNull();
			} catch (GeneralLeanFtException e) {
				
			}
	    	
	    }
		
		@Test
		public void getDesktopLabelTest()
		{
			 assertThat(WfDesktopLabel.getDesktopLabel()).isNotNull();
		}
	
	
	 	@Test
	    public void getTextTest()
	    {
	 		assertThrows(GeneralLeanFtException.class, () -> {
	 		WfDesktopLabel.getText(1);
	    	});
	    }
	    
	    @Test
	    public void getFindRetriesTest() {
	    	assertThat(WFDesktopLabel.getFindRetries()).isGreaterThan(0);
	    }
	    
	    @Test
	    public void existsTest() {
	    	assertThrows(GeneralLeanFtException.class, () -> {
		 	WfDesktopLabel.exists(1);
		    });
	    }

	    @Test
	    public void isEnabledTest() {
	    	assertThrows(GeneralLeanFtException.class, () -> {
		 	WfDesktopLabel.isEnabled(1);
		    });
	    }
	    
	    @Test
	    public void clickTest() {
	    	assertThrows(GeneralLeanFtException.class, () -> {
		 	WfDesktopLabel.click(1);
		    });
	    }
	
}
