package automation.library.leanft.core.desktop.web;

import static org.assertj.core.api.Assertions.assertThat;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.hp.lft.sdk.GeneralLeanFtException;

import automation.library.leanft.core.desktop.stdwin.SWDesktopWindow;
import automation.library.leanft.core.desktop.winforms.WFDesktopWindow;

public class DesktopWebEditFieldTest {
	
	private static String windowObjectName="windowObjectName";
    private static String windowTitle="windowTitle"; 
    private static String fullType="fullType";
    private static String locatorText = "locatorText";
    private static String objectName = "objectName";
    private static String windowClassRegExp = "windowClassRegExp";
    private static String windowTitleRegExp = "windowTitleRegExp";
    static DesktopWebEditField desktopWebEditField = null;
	
    @BeforeAll
    public static void setUp()
    {
    	System.setProperty("fw.defaultFindRetries", "1");
    	
    	try {
    			desktopWebEditField = new DesktopWebEditField(windowObjectName,fullType,windowTitle,locatorText,LocatorType.TAGNAME);
			} catch (GeneralLeanFtException e) {
			}
    }
    
    @Test
    public void DesktopWebEditFieldTest1() {
    	
    	try {
    		DesktopWebEditField dtWebEditField = new DesktopWebEditField(windowObjectName,fullType,windowTitle,locatorText,LocatorType.XPATH);
			assertThat(dtWebEditField).isNotNull();
		} catch (GeneralLeanFtException e) {
		}
    	
    }
    
    @Test
    public void DesktopWebEditFieldTest2() {
    	
    	try {
    		WFDesktopWindow parentWindow = new WFDesktopWindow(objectName, fullType);
    		DesktopWebEditField dtWebEditField = new DesktopWebEditField(parentWindow,locatorText,LocatorType.get("id"));
			assertThat(dtWebEditField).isNotNull();
		} catch (GeneralLeanFtException e) {
		}
    	
    }
    
    @Test
    public void DesktopWebEditFieldTest3() {
    	
    	try {
    		WFDesktopWindow parentWindow = new WFDesktopWindow(objectName, fullType);
    		DesktopWebEditField dtWebEditField = new DesktopWebEditField(parentWindow,locatorText,LocatorType.get("css"));
			assertThat(dtWebEditField).isNotNull();
		} catch (GeneralLeanFtException e) {
		}
    	
    }
    
    @Test
    public void DesktopWebEditFieldTest4() {
    	
    	try {
    		WFDesktopWindow parentWindow = new WFDesktopWindow(objectName, fullType);
    		SWDesktopWindow swDesktopWindow =  new SWDesktopWindow(windowClassRegExp, windowTitleRegExp);
    		DesktopWebEditField dtWebEditField = new DesktopWebEditField(parentWindow,swDesktopWindow,locatorText,LocatorType.NAME);
			assertThat(dtWebEditField).isNotNull();
		} catch (GeneralLeanFtException e) {
		}
    	
    }
    
   
    @Test
    public void getEditFieldTest()
    {
    	assertThat(desktopWebEditField.getEditField()).isNotNull();
    }
        
    @Test
    public void setTextTest()
    {
    	try {
				assertThat(desktopWebEditField.setText("locatorText", 1)).isNotNull();
			} catch (GeneralLeanFtException e) {
			}
    }
    
    @Test
    public void existsTest()  {
    	 try {
				assertThat(desktopWebEditField.exists(1)).isNull();
			 } catch (GeneralLeanFtException e) {
			}
    }

    @Test
    public void getFindRetriesTest() {
    	assertThat(DesktopWebEditField.getFindRetries()).isGreaterThan(0);
    }

    @Test
    public void isEnabledTest() {
    	try {
				assertThat(desktopWebEditField.isEnabled(1)).isFalse();
			} catch (GeneralLeanFtException e) {
			} 
    }
    
    @Test
    public void getTextTest()  {
    	 try {
				assertThat(desktopWebEditField.getText(1)).isNotNull();
			 } catch (GeneralLeanFtException e) {
			}
    }
    
}