package automation.library.leanft.core.desktop.web;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.hp.lft.sdk.GeneralLeanFtException;

import automation.library.leanft.core.desktop.winforms.WFDesktopButton;
import automation.library.leanft.core.desktop.winforms.WFDesktopWindow;

public class DesktopWebRadioGroupTest {
	
	private static String windowObjectName="windowObjectName";
    private static String windowTitle="windowTitle"; 
    private static String fullType="fullType";
    private static String locatorText = "locatorText";
    private static String objectName = "objectName";
    
    static DesktopWebRadioGroup desktopWebRadioGroup = null;
    
    @BeforeAll
    public static void setUp()
    {
    	System.setProperty("fw.defaultFindRetries","1");
    	
    	try {
    			desktopWebRadioGroup = new DesktopWebRadioGroup(windowObjectName,fullType,windowTitle,locatorText,LocatorType.TAGNAME);
			} catch (GeneralLeanFtException e) {
				
			}
    }
    @Test
    public void DesktopWebRadioGroupTest1() {
    	
    	try {
    		DesktopWebRadioGroup dtWebRadio = new DesktopWebRadioGroup(windowObjectName,fullType,windowTitle,locatorText,LocatorType.NAME);
			assertThat(dtWebRadio).isNotNull();
		} catch (GeneralLeanFtException e) {
			
		}
    	
    }
    
    @Test
    public void DesktopWebRadioGroupTest2() {
    	
    	try {
    		WFDesktopWindow parentWindow = new WFDesktopWindow(objectName, fullType);
    		DesktopWebRadioGroup dtWebRadio = new DesktopWebRadioGroup(parentWindow,locatorText,LocatorType.get("id"));
			assertThat(dtWebRadio).isNotNull();
		} catch (GeneralLeanFtException e) {
			
		}
    	
    }
    
    @Test
    public void DesktopWebRadioGroupTest3() {
    	
    	try {
    		WFDesktopWindow parentWindow = new WFDesktopWindow(objectName, fullType);
    		DesktopWebRadioGroup dtWebRadio = new DesktopWebRadioGroup(parentWindow,locatorText,LocatorType.get("css"));
			assertThat(dtWebRadio).isNotNull();
		} catch (GeneralLeanFtException e) {
			
		}
    	
    }
    
    @Test
    public void DesktopWebRadioGroupTest4() {
    	
    	try {
    		WFDesktopWindow parentWindow = new WFDesktopWindow(objectName, fullType);
    		DesktopWebRadioGroup dtWebRadio = new DesktopWebRadioGroup(parentWindow,locatorText,LocatorType.XPATH);
			assertThat(dtWebRadio).isNotNull();
		} catch (GeneralLeanFtException e) {
			
		}
    	
    }
    
    @Test
    public void getRadioGroupTest()
    {
    	assertThat(desktopWebRadioGroup.getRadioGroup()).isNotNull();
    }
    
    @Test
    public void getFindRetriesTest() {
    	assertThat(DesktopWebRadioGroup.getFindRetries()).isGreaterThan(0);
    }
    
    @Test
    public void existsTest() {
    	try {
				assertThat(desktopWebRadioGroup.exists(1)).isNull();
			} catch (GeneralLeanFtException e) {
			}
    }

    @Test
    public void isEnabledTest() {
    	try {
				assertThat(desktopWebRadioGroup.isEnabled(1)).isFalse();
			} catch (GeneralLeanFtException e) {
			}
    }
    
    @Test
    public void selectTest1() {
    	try {
    			assertThat(desktopWebRadioGroup.select(1, 1)).isNull();
			} catch (GeneralLeanFtException e) {
			}
    }
    
    @Test
    public void selectTest2() {
    	try {
    			assertThat(desktopWebRadioGroup.select("1", 1)).isNull();
			} catch (GeneralLeanFtException e) {
			}
    }

}
