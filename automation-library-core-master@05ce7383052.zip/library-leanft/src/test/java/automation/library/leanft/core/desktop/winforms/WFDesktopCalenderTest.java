package automation.library.leanft.core.desktop.winforms;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.hp.lft.sdk.GeneralLeanFtException;

public class WFDesktopCalenderTest {

    static WFDesktopCalender WfDesktopCalender = null;
    		
    @BeforeAll
    public static void setUp()
    {
    	System.setProperty("fw.defaultFindRetries", "1");
    	
    	try {
				WfDesktopCalender = new WFDesktopCalender("windowObjectName", "windowTitleRegExp", "fullType", "objectName");
			} catch (GeneralLeanFtException e) {
			}
    }

    @Test
    public void getDesktopCalenderTest() {
        assertThat(WfDesktopCalender.getDesktopCalender()).isNotNull();
    }


    @Test
    public void existsTest()  {
    	 try {
				assertThat(WfDesktopCalender.exists(1)).isNull();
			 } catch (GeneralLeanFtException e) {
			 }
    }

    @Test
    public void getFindRetriesTest() {
    	assertThat(WFDesktopCalender.getFindRetries()).isGreaterThan(0);
    }

    @Test
    public void isEnabledTest() {
    		assertThrows(GeneralLeanFtException.class, () -> {
    		WfDesktopCalender.isEnabled(1);
    	});
    }
    
    @Test
    public void clickTest() {
    		assertThrows(GeneralLeanFtException.class, () -> {
    		WfDesktopCalender.click(1);
    	});
    }
    
}
