package automation.library.leanft.core.desktop.stdwin;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

import com.hp.lft.sdk.GeneralLeanFtException;

public class SWDesktopEditFieldTest {
	
	private static String windowClassRegExp = "windowClassRegExp";
	private static String accessibleName = "accessibleName";
	private static String windowTitleRegExp = "windowTitleRegExp";
	private static int windowId = 1;
	
	@Test
	public void SWEditFieldTest1() {
	    	
	    	try {
	    		SWDesktopEditField swDesktopEditField = new SWDesktopEditField(windowClassRegExp,windowTitleRegExp,accessibleName);
				assertThat(swDesktopEditField).isNotNull();
			} catch (GeneralLeanFtException e) {
			}
	    	
	 }
	
	@Test
	public void SWEditFieldTest2() {
	    	
	    	try {
	    		SWDesktopDialog swDesktopDialog = new SWDesktopDialog(windowClassRegExp, windowTitleRegExp);
	    		SWDesktopEditField swDesktopEditField = new SWDesktopEditField(swDesktopDialog,windowClassRegExp,windowId);
				assertThat(swDesktopEditField).isNotNull();
			} catch (GeneralLeanFtException e) {
			}
	    	
	 }
	
	  @Test
	    public void getFindRetriesTest() {
	    	assertThat(SWDesktopEditField.getFindRetries()).isGreaterThan(0);
	    }
	    
	    @Test
	    public void existsTest() {
	    	try {
	    			SWDesktopEditField swDesktopEditField = new SWDesktopEditField(windowClassRegExp,windowTitleRegExp,accessibleName);
					assertThat(swDesktopEditField.exists(1)).isNull();
				} catch (GeneralLeanFtException e) {
				}
	    }

	    @Test
	    public void isEnabledTest() {
	    	try {
	    			SWDesktopEditField swDesktopEditField = new SWDesktopEditField(windowClassRegExp,windowTitleRegExp,accessibleName);	
	    			assertThat(swDesktopEditField.isEnabled(1)).isFalse();
				} catch (GeneralLeanFtException e) {
				}
	    }
	    
	    @Test
	    public void getTextTest() {
	    	try {
	    			SWDesktopEditField swDesktopEditField = new SWDesktopEditField(windowClassRegExp,windowTitleRegExp,accessibleName);	
	    			assertThat(swDesktopEditField.getText(1)).isNull();
				} catch (GeneralLeanFtException e) {
				}
	    }
	    
	    @Test
	    public void setTextTest() {
	    	try {
	    			SWDesktopEditField swDesktopEditField = new SWDesktopEditField(windowClassRegExp,windowTitleRegExp,accessibleName);	
	    			assertThat(swDesktopEditField.setText("text",1)).isNull();
				} catch (GeneralLeanFtException e) {
				}
	    }

}
