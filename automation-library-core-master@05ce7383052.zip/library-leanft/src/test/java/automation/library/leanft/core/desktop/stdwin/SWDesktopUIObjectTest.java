package automation.library.leanft.core.desktop.stdwin;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

import com.hp.lft.sdk.GeneralLeanFtException;

public class SWDesktopUIObjectTest {
	
	private static String windowClassRegExp = "windowClassRegExp";
	private static String accessibleName = "accessibleName";
	private static String windowTitleRegExp = "windowTitleRegExp";
	private static String text = "text";
	private static String windowClassRegExpObj = "windowClassRegExpObj";
	private static String windowTitleRegExpObj = "windowTitleRegExpObj";
	
	@Test
	public void SWDesktopUIObjectTest1() {
	    	
	    	try {
	    		SWDesktopUIObject swDesktopUiObject = new SWDesktopUIObject(windowClassRegExp,windowTitleRegExp,windowClassRegExpObj,accessibleName);
				assertThat(swDesktopUiObject).isNotNull();
			} catch (GeneralLeanFtException e) {
			}
	    	
	 }
	
	@Test
	public void SWDesktopUIObjectTest2() {
	    	
	    	try {
	    		SWDesktopUIObject swDesktopUiObject = new SWDesktopUIObject(windowClassRegExp,windowTitleRegExp,windowClassRegExpObj,windowTitleRegExpObj,text);
				assertThat(swDesktopUiObject).isNotNull();
			} catch (GeneralLeanFtException e) {
			}
	    	
	 }
	
	@Test
    public void getFindRetriesTest() {
    	assertThat(SWDesktopUIObject.getFindRetries()).isGreaterThan(0);
    }
	
	@Test
    public void getUiObjectTest() {
		try {
			SWDesktopUIObject swDesktopUiObject = new SWDesktopUIObject(windowClassRegExp,windowTitleRegExp,windowClassRegExpObj,accessibleName);
			assertThat(swDesktopUiObject.getUiObject()).isNotNull();
		} catch (GeneralLeanFtException e) {
		}
    }
    
    @Test
    public void existsTest() {
    	try {
    			SWDesktopUIObject swDesktopUiObject = new SWDesktopUIObject(windowClassRegExp,windowTitleRegExp,windowClassRegExpObj,accessibleName);
				assertThat(swDesktopUiObject.exists(1)).isNull();
			} catch (GeneralLeanFtException e) {
			}
    }

    @Test
    public void isEnabledTest() {
    	try {
    			SWDesktopUIObject swDesktopUiObject = new SWDesktopUIObject(windowClassRegExp,windowTitleRegExp,windowClassRegExpObj,accessibleName);
    			assertThat(swDesktopUiObject.isEnabled(1)).isFalse();
			} catch (GeneralLeanFtException e) {
			}
    }

}
