package automation.library.leanft.core.desktop.web;

import static org.assertj.core.api.Assertions.assertThat;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.hp.lft.sdk.GeneralLeanFtException;

import automation.library.leanft.core.desktop.stdwin.SWDesktopWindow;
import automation.library.leanft.core.desktop.winforms.WFDesktopWindow;

public class DesktopWebButtonTest {
	
	private static String windowObjectName="windowObjectName";
    private static String windowTitle="windowTitle"; 
    private static String fullType="fullType";
    private static String locatorText = "locatorText";
    private static String objectName = "objectName";
    private static int index=1;
    private static String text = "text";
    private static String windowClassRegExp="windowClassRegExp";
    
    static DesktopWebButton desktopWebButton = null;
	
    @BeforeAll
    public static void setUp()
    {
    	System.setProperty("fw.defaultFindRetries", "1");
    	
    	try {
    			desktopWebButton = new DesktopWebButton(windowObjectName,fullType,windowTitle,locatorText,LocatorType.TAGNAME);
			} catch (GeneralLeanFtException e) {
			}
    }
    
    
    @Test
    public void DesktopWebButtonTest1() {
    	
    	try {
    		DesktopWebButton dfButton = new DesktopWebButton(windowObjectName,fullType,windowTitle,locatorText,LocatorType.TAGNAME);
			assertThat(dfButton).isNotNull();
		} catch (GeneralLeanFtException e) {
			
		}
    	
    }
    
    @Test
    public void DesktopWebButtonTest2() {
    	
    	try {
    		WFDesktopWindow parentWindow = new WFDesktopWindow(objectName, fullType);
    		DesktopWebButton dfButton = new DesktopWebButton(parentWindow,locatorText,LocatorType.get("id"));
			assertThat(dfButton).isNotNull();
		} catch (GeneralLeanFtException e) {
			
		}
    	
    }
    
    @Test
    public void DesktopWebButtonTest3() {
    	
    	try {
    		WFDesktopWindow parentWindow = new WFDesktopWindow(objectName, fullType);
    		SWDesktopWindow swDesktopWindow = new SWDesktopWindow(windowClassRegExp, text, index);
    		DesktopWebButton dfButton = new DesktopWebButton(parentWindow,swDesktopWindow,locatorText,LocatorType.get("css"));
			assertThat(dfButton).isNotNull();
		} catch (GeneralLeanFtException e) {
			
		}
    	
    }
    
    @Test
    public void DesktopWebButtonTest4() {
    	
    	try {
	    		WFDesktopWindow parentWindow = new WFDesktopWindow(objectName, fullType);
	    		DesktopWebButton dfButton = new DesktopWebButton(parentWindow,locatorText,LocatorType.get("xpath"));
				assertThat(dfButton).isNotNull();
			} catch (GeneralLeanFtException e) {
				
			}
    	
    }
    
    @Test
    public void DesktopWebButtonTest5() {
    	try {
	    		DesktopWebButton dfButton = new DesktopWebButton(windowTitle, "CHROME", objectName, "xpath");
				assertThat(dfButton).isNotNull();
			} catch (GeneralLeanFtException e) {
				
			}
    }

    @Test
    public void DesktopWebButtonTest6() {
    	try {
    			WebDesktopBrowserWindow parentWindow = new WebDesktopBrowserWindow(objectName, "CHROME");
	    		DesktopWebButton dfButton = new DesktopWebButton(parentWindow, "name", "xpath");
				assertThat(dfButton).isNotNull();
			} catch (GeneralLeanFtException e) {
				
			}
    }
    
    @Test
    public void DesktopWebButtonTest7() {
    	
    	try {
    		DesktopWebButton dfButton = new DesktopWebButton(windowObjectName,fullType,windowTitle,locatorText,LocatorType.NAME);
			assertThat(dfButton).isNotNull();
		} catch (GeneralLeanFtException e) {
			
		}
    	
    }
    
    
    @Test
    public void getButtonTest()
    {
    	assertThat(desktopWebButton.getButton()).isNotNull();
    }
    
    @Test
    public void existsTest()  {
    	 try {
				assertThat(desktopWebButton.exists(1)).isNull();
			 } catch (GeneralLeanFtException e) {
			}
    }

    @Test
    public void getFindRetriesTest() {
    	assertThat(DesktopWebButton.getFindRetries()).isGreaterThan(0);
    }

    @Test
    public void isEnabledTest() {
    	try {
				assertThat(desktopWebButton.isEnabled(1)).isFalse();
			} catch (GeneralLeanFtException e) {
			}
  
    }
    
}
