package automation.library.leanft.core.desktop.stdwin;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import com.hp.lft.sdk.GeneralLeanFtException;

public class SWDesktopButtonTest {
	
	private static String windowClassRegExp = "windowClassRegExp";
	private static String text = "text";
	private static int index = 1;
	private static String accessibleName = "accessibleName";
	private static String windowTitleRegExp = "windowTitleRegExp";
	private static int windowId = 1;
	
	@Test
	 public void SWDesktopButtonTest1() {
	    	
	    	try {
	    		SWDesktopButton swButtton = new SWDesktopButton(windowClassRegExp,text,index,accessibleName);
				assertThat(swButtton).isNotNull();
			} catch (GeneralLeanFtException e) {
			}
	    	
	 }
	 
	 @Test
	 public void SWDesktopButtonTest2() {
	    	
	    	try {
	    		SWDesktopDialog swDesktopDialog = new SWDesktopDialog(windowClassRegExp, windowTitleRegExp);
	    		SWDesktopButton swButtton = new SWDesktopButton(swDesktopDialog,text,index);
				assertThat(swButtton).isNotNull();
			} catch (GeneralLeanFtException e) {
			}
	    	
	 }
	 
		 @Test
		 public void SWDesktopButtonTest3() {
		    	
		    	try {
		    		 SWDesktopDialog swDesktopDialog = new SWDesktopDialog(windowClassRegExp, windowTitleRegExp);
			    	 SWDesktopButton swButtton = new SWDesktopButton(swDesktopDialog,windowId);
			    	 assertThat(swButtton).isNotNull();
				} catch (GeneralLeanFtException e) {
				}
		    	
		} 
	 
	 	@Test
	    public void getSWDesktopButtonTest()
	    {
			try {
				SWDesktopButton swButtton = new SWDesktopButton(windowClassRegExp,text,index,accessibleName);
				assertThat(swButtton.getDesktopButton()).isNotNull();
			} catch (GeneralLeanFtException e) {
			}    	
	    }
	    
	    @Test
	    public void getFindRetriesTest() {
	    	assertThat(SWDesktopButton.getFindRetries()).isGreaterThan(0);
	    }
	    
	    @Test
	    public void existsTest() {
	    	try {
	    			SWDesktopButton swButtton = new SWDesktopButton(windowClassRegExp,text,index,accessibleName);
					assertThat(swButtton.exists(1)).isNull();
				} catch (GeneralLeanFtException e) {
				}
	    }

	    @Test
	    public void isEnabledTest() {
	    	try {
	    			SWDesktopButton swButtton = new SWDesktopButton(windowClassRegExp,text,index,accessibleName);	
	    			assertThat(swButtton.isEnabled(1)).isFalse();
				} catch (GeneralLeanFtException e) {
				}
	    }


}
