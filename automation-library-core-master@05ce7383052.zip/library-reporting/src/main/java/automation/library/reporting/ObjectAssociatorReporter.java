package automation.library.reporting;

import io.qameta.allure.Allure;
import io.qameta.allure.AllureLifecycle;
import io.qameta.allure.model.Label;
import io.qameta.allure.model.Status;
import io.qameta.allure.model.StepResult;
import io.qameta.allure.model.TestResult;
import org.apache.commons.io.IOUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static io.qameta.allure.model.Status.*;
import static io.qameta.allure.util.ResultsUtils.*;

public class ObjectAssociatorReporter {
    private String featureName;
    private String stepUUID;
    private String scenarioUUID;
    private Status scenarioStatus = PASSED;
    private Status stepStatus = PASSED;
    private AllureLifecycle lifecycle;
    private static final double EXACT_THRESHOLD = 1;
    private static final double ABOVE_THRESHOLD = 0.85;
    protected final Logger log = LogManager.getLogger(ObjectAssociatorReporter.class);

    public ObjectAssociatorReporter() {
        //Utility class
    }

    public void setFeatureName(String featureNameFromFile) {
        featureName = featureNameFromFile;
    }

    public void addScenario(String scenarioName, String scenarioDescription, List<String> scenarioTags) {
        lifecycle = Allure.getLifecycle();
        scenarioUUID = UUID.randomUUID().toString();

        final TestResult result = new TestResult()
                .setUuid(scenarioUUID)
                .setHistoryId(getHistoryId(scenarioName))
                .setFullName(String.format("%s: %s", featureName, scenarioName))
                .setName(scenarioName)
                .setLabels(getScenarioTags(scenarioName, scenarioTags));

        if (scenarioDescription != null) {
            result.setDescription(scenarioDescription);
        }

        lifecycle.scheduleTestCase(result);
        lifecycle.startTestCase(scenarioUUID);
    }

    public void beginStep(String keyword, String stepDescription) {
        stepUUID = UUID.randomUUID().toString();
        lifecycle.startStep(stepUUID, new StepResult().setName(String.format("%s %s", keyword, stepDescription)));
    }

    public void updateStepToPassed() {
        lifecycle.updateStep(stepUUID, stepResult -> stepResult.setStatus(PASSED));
    }

    public void addSubStepResult(Double similarityScore, String searchResultMsg, String listOfObjs) {
        Status statusCd = getStepStatus(similarityScore);
        setScenarioStatus(statusCd);
        setStepStatus(statusCd);

        if (!searchResultMsg.isEmpty()) {
            String subStepUUID = UUID.randomUUID().toString();

            lifecycle.startStep(stepUUID, subStepUUID, new StepResult().setName(searchResultMsg).setStatus(statusCd));

            if(listOfObjs != null) {
                try (InputStream is = IOUtils.toInputStream(listOfObjs, StandardCharsets.UTF_8)) {
                    lifecycle.addAttachment(getSubStepType(searchResultMsg), (String)null, (String)null, is);
                } catch (IOException ex) {
                    log.error("{} failed: {}", "List", ex.getMessage());
                }
            }

            lifecycle.stopStep(subStepUUID);
        }
    }

    private String getSubStepType(String searchResultMsg) {
        String[] subSetType = searchResultMsg.split(":");

        if (subSetType.length > 0) {
            return subSetType[0] + " List:";
        }
        else
            return null;
    }

    public void resetFeature() {
        featureName = null;
    }

    public void resetScenario() {
        lifecycle.stopTestCase(scenarioUUID);
        lifecycle.writeTestCase(scenarioUUID);
        scenarioUUID = null;
        scenarioStatus = PASSED;
    }

    public void resetStep() {
        lifecycle.stopStep(stepUUID);
        stepUUID = null;
        stepStatus = PASSED;
    }

    private Status getStepStatus(Double similarityScore) {
        if (similarityScore == EXACT_THRESHOLD) {
            return PASSED;
        } else if (similarityScore >= ABOVE_THRESHOLD) {
            return BROKEN;
        } else {
            return FAILED;
        }
    }

    private void setScenarioStatus(Status statusCd) {
        if(statusCd != SKIPPED) {
            if ((scenarioStatus == PASSED && statusCd != PASSED) || (scenarioStatus == BROKEN && statusCd == FAILED)) {
                scenarioStatus = statusCd;
            }

            lifecycle.updateTestCase(scenarioUUID, scenarioResult -> scenarioResult.setStatus(scenarioStatus));
        }
    }

    private void setStepStatus(Status statusCd) {
        if((stepStatus == PASSED && statusCd != PASSED) || (stepStatus == BROKEN && statusCd == FAILED)) {
            stepStatus = statusCd;
        }

        lifecycle.updateStep(stepUUID, stepResult -> stepResult.setStatus(stepStatus));
    }

    private List<Label> getScenarioTags(String scenarioName, List<String> scenarioTags) {
        List<Label> scenarioLabels = new ArrayList<>();

        scenarioLabels.add(createPackageLabel(featureName));
        scenarioLabels.add(createSuiteLabel(featureName));
        scenarioLabels.add(createTestClassLabel(scenarioName));

        scenarioTags.forEach(curTag -> scenarioLabels.add(createTagLabel(curTag.replace("@", ""))));
        scenarioTags.forEach(curTag -> scenarioLabels.add(createStoryLabel(curTag.replace("@", ""))));

        return scenarioLabels;
    }

    private String getHistoryId(final String id) {
        return md5(id);
    }

    public void addSubStepResult(Status statusCd, String searchResultMsg) {
        setScenarioStatus(statusCd);
        setStepStatus(statusCd);

        if (!searchResultMsg.isEmpty()) {
            String subStepUUID = UUID.randomUUID().toString();
            lifecycle.startStep(stepUUID, subStepUUID, new StepResult().setName(searchResultMsg).setStatus(statusCd));
            lifecycle.stopStep(subStepUUID);
        }
    }
}