package automation.library.selenium.exec.driver.factory;

import automation.library.common.Property;
import automation.library.common.TestContext;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileDriver;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.Set;

import static automation.library.selenium.core.Constants.SELENIUMRUNTIMEPATH;

public abstract class DriverManager {

    protected WebDriver driver;
    protected WebDriverWait wait;
    private Logger log = LogManager.getLogger(DriverManager.class);

    public WebDriver getDriver() {
        if (driver == null) {
            createDriver();
        }

        if (driver instanceof MobileDriver && ((AppiumDriver) driver).getContext().equals("NATIVE_APP")) {
            ((AppiumDriver) driver).hideKeyboard();
        }

        return driver;
    }

    public void quitDriver() {
        if (driver != null) {
            driver.quit();
            driver = null;
        }
    }
    
    public boolean isDriverRunning() {
    	if (driver == null)
    		return false;
    	else
    		return true;
    }

    public WebDriverWait getWait() {
        if (wait == null) {
            wait = new WebDriverWait(driver, getWaitDuration());
        }
        return wait;
    }

    public String getDriverPath(String drivername) {
        String driverName = drivername + (System.getProperty("os.name").split(" ")[0].equalsIgnoreCase("Windows") ? ".exe" : "");
        String path = Property.getVariable("cukes.driverPath");
        return (path == null ? "lib/drivers/" + System.getProperty("os.name").split(" ")[0].toLowerCase() + "/" + driverName : path);
    }

    /**
     * Returns duration for specified waits
     */
    public int getWaitDuration() {
        final int defaultWait = 10;
        int duration;
        try {
            duration = Property.getProperties(SELENIUMRUNTIMEPATH).getInt("defaultWait");
        } catch (Exception e) {
            duration = defaultWait;
        }
        return duration;
    }

    public boolean switchContext(String contextToFind) {
        if (driver instanceof MobileDriver) {
            int waitBetween = Integer.parseInt(System.getProperty("fw.waitBetweenConnectionRequest"));
            int retry = 0;

            while (retry < 2) {
                try {
                    Set<String> contextNames = ((AppiumDriver) driver).getContextHandles();
                    for (String currentContext : contextNames) {
						if (checkAndSwitchToContext(contextToFind, waitBetween, currentContext))
							return true;
					}
                } catch (WebDriverException | InterruptedException e) {
                    log.error(e);
                    Thread.currentThread().interrupt();
                }
                retry++;
            }
        }

        return false;
    }

	private boolean checkAndSwitchToContext(String contextToFind,
											int waitBetween,
											String currentContext) throws InterruptedException {
		if (currentContext.contains(contextToFind)) {
			((AppiumDriver) driver).context(contextToFind);
			if ( ((AppiumDriver) driver).getContext().equals(contextToFind)) {
				log.debug("Driver switched to context: {} ", contextToFind);
				return true;
			}
		} else {
			log.debug("Retrying switching to context: {}", contextToFind);
			Thread.sleep(waitBetween);
		}
		return false;
	}

	protected abstract void createDriver();

    public abstract void updateResults(String result);
}