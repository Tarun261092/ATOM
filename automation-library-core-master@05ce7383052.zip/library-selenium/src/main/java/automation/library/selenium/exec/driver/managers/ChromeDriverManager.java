package automation.library.selenium.exec.driver.managers;

import automation.library.common.Property;
import automation.library.selenium.core.Constants;
import automation.library.selenium.exec.driver.factory.DriverContext;
import automation.library.selenium.exec.driver.factory.DriverManager;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.apache.commons.configuration2.PropertiesConfiguration;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import java.io.File;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.io.FileUtils;

import static automation.library.selenium.core.Constants.SELENIUMRUNTIMEPATH;

public class ChromeDriverManager extends DriverManager {

    protected Logger log = LogManager.getLogger(this.getClass().getName());


    @Override
    public void createDriver() {
        PropertiesConfiguration props = Property.getProperties(SELENIUMRUNTIMEPATH);
        if (Property.getVariable("cukes.webdrivermanager") != null && Property.getVariable("cukes.webdrivermanager").equalsIgnoreCase("true")) {
            if (Property.getVariable("cukes.chromeDriver") != null) {
                WebDriverManager.chromedriver().browserVersion(Property.getVariable("cukes.chromeDriver")).setup();
            } else {
                WebDriverManager.chromedriver().setup();
            }
        } else {
            System.setProperty("webdriver.chrome.driver", getDriverPath("chromedriver"));
        }
        System.setProperty("webdriver.chrome.silentOutput", "true");
        ChromeOptions options = new ChromeOptions();

        for (String variable : props.getStringArray("options." + DriverContext.getInstance().getBrowserName().replaceAll("\\s", ""))) {
            options.addArguments(variable);
        }

        if(props.getString("options.chrome.useAutomationExtension") != null &&
           props.getString("options.chrome.useAutomationExtension").equalsIgnoreCase("false")) {
            options.setExperimentalOption("useAutomationExtension", false);
        }

        if(Boolean.parseBoolean(props.getString("prefs.chrome.overrideDownloadSettings"))) {
            String downloadDir = Paths.get(Constants.DOWNLOADPATH).toAbsolutePath().toString();
            Map<String, Object> userPrefs = new HashMap<>();
            userPrefs.put("download.default_directory", downloadDir);
            userPrefs.put("download.prompt_for_download", false);
            userPrefs.put("plugins.always_open_pdf_externally", true);
            options.setExperimentalOption("prefs", userPrefs);
        }
        
        if(Boolean.parseBoolean(props.getString("prefs.chrome.browsernotifications")))
        {
        	String folder="";
        	String[] Options=props.getStringArray("options.chrome");
        	for (String Option : Options) 
        	{ 
        	    if(Option.contains("--user-data-dir"))
        	    {
        	    	String[] userdir=Option.split("=");
        	    	folder=userdir[1];
        	    	break;
        	    }
        	}
        	try
        	{
        		File f = new File(folder);
        		FileUtils.cleanDirectory(f); //clean out directory (this is optional -- but good know)
                FileUtils.forceDelete(f); //delete directory
        	}
        	catch(Exception e)
        	{
        		 log.info("UserDiretory is not present");
        	}
        	String notification_allow_deny=props.getString("notification.allow.deny");
        	if(notification_allow_deny!=null)
        	{
        		
	        	Map<String, Object> userPrefs = new HashMap<>();
	        	if(notification_allow_deny.equals("1"))
	        		userPrefs.put("profile.default_content_setting_values.notifications", 1);
	        	else if(notification_allow_deny.equals("2"))
	        		userPrefs.put("profile.default_content_setting_values.notifications", 2);
	        	options.setExperimentalOption("prefs", userPrefs);
        	}
        	else
        	{
        		log.info("No preferences added");
        	}
        }

        if (DriverContext.getInstance().getBrowserName().contains("kiosk")) {
            options.addArguments("--kiosk");
        }

        driver = new ChromeDriver(options);
    }

    @Override
    public void updateResults(String result) {
        //do nothing
    }
} 