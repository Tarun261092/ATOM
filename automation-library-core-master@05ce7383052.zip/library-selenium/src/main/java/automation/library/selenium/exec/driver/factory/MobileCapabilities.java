package automation.library.selenium.exec.driver.factory;

import automation.library.common.Property;
import automation.library.selenium.core.Constants;
import automation.library.selenium.exec.driver.enums.PlatformType;
import org.apache.commons.configuration2.PropertiesConfiguration;
import org.openqa.selenium.Proxy;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

import java.util.Map;

import static automation.library.selenium.core.Constants.ENVIRONMENTPATH;

public class MobileCapabilities {

    private DesiredCapabilities dc;
    private static final String PLATFORM_NAME = "platformName";
    private static final String FW_MOBILE_APP_NAME = "fw.mobileAppName";

    public MobileCapabilities() {
        Map<String, String> map = DriverContext.getInstance().getMobileTechStack();
        PropertiesConfiguration props = Property.getProperties(Constants.SELENIUMRUNTIMEPATH);
        PropertiesConfiguration propsEnv = Property.getProperties(ENVIRONMENTPATH + Property.getVariable("cukes.env") + ".properties");
        dc = new DesiredCapabilities();

        for (Map.Entry<String, String> pair : map.entrySet()) {
            if (!pair.getKey().equalsIgnoreCase("seleniumServer") && !pair.getKey().equalsIgnoreCase("description"))
                dc.setCapability(pair.getKey(), pair.getValue());
        }

        //when launching an app, set appropriate capability for iOS or Android
        if (propsEnv != null && dc.getCapability(PLATFORM_NAME) != null) {
            final PlatformType platform = PlatformType.get(String.valueOf(dc.getCapability(PLATFORM_NAME)));
            final String appNameWithPlatform = propsEnv.getString(String.format("%s_%s", System.getProperty(FW_MOBILE_APP_NAME)
                                                                                               .replaceAll("\\s+", ""),
                                                                                platform.getPlatformName()));

            if (platform.equals(PlatformType.ANDROID)) {
                System.setProperty("fw.platformName", platform.getPlatformName());
                dc.setCapability("appPackage", appNameWithPlatform);
            } else if (platform.equals(PlatformType.IOS)) {
                System.setProperty("fw.platformName", platform.getPlatformName());
                dc.setCapability("bundleId", appNameWithPlatform);
            }
        }

        if (Boolean.parseBoolean(props.getString("usePerfectoProxy"))) {
            Proxy proxy = new Proxy();
            if (props.getString("httpPefectoProxyURL") != null && props.getString("sslPerfectoProxyURL") != null) {
                proxy.setHttpProxy(props.getString("httpPefectoProxyURL"))
                     .setSslProxy(props.getString("sslPerfectoProxyURL"));

                dc.setCapability(CapabilityType.PROXY, proxy);
            } else {
                throw new IllegalArgumentException("usePerfectoProxy set to true, but value not provided for httpPefectoProxyURL or sslPerfectoProxyURL in runtime.properties.");
            }
        }
    }

    public DesiredCapabilities getCap() {
        return dc;
    }

}
