package automation.library.selenium.exec;

import automation.library.common.TestContext;
import automation.library.selenium.core.MobilePageObject;
import automation.library.selenium.exec.driver.factory.DriverContext;

import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

public class BaseMobilePO extends MobilePageObject {
    protected WebDriverWait mobileWait;

    public BaseMobilePO() {
        super((RemoteWebDriver) DriverContext.getInstance().getMobileDriver());
        getPlatformName();
    }

    @Override
    public RemoteWebDriver getDriver() {
        log.debug("obtaining the driver for current thread");
        return (RemoteWebDriver) DriverContext.getInstance().getMobileDriver();
    }

    @Override
    public WebDriverWait getMobileWait() {
        log.debug("obtaining the wait for current thread");
        return DriverContext.getInstance().getMobileWait();
    }

    public void quitDriver() {
        log.debug("quitting the driver and removing from current thread of driver factory");
        DriverContext.getInstance().quit();
    }

    @Override
    public SoftAssertions sa() {
        return TestContext.getInstance().sa();
    }

    public void getPlatformName() {
    	if(System.getProperty("fw.platformName") != null) {
    		if (System.getProperty("fw.platformName").equalsIgnoreCase("android"))
                AndroidElements();
            if (System.getProperty("fw.platformName").equalsIgnoreCase("ios"))
                iOSElements();
    	}        
    }

    protected void AndroidElements() {};

    protected void iOSElements() {};
}
