package automation.library.selenium.exec;

import automation.library.common.Property;

public class ExecConstants extends automation.library.selenium.core.Constants {
    public static final String SELENIUMSTACKSPATH = BASEPATH + "config/selenium/stacks/" + Property.getVariable("cukes.techstack") + ".json";
    public static final String SELENIUMMOBILESTACKSPATH = BASEPATH + "config/selenium/stacks/" + Property.getVariable("cukes.mobiletechstack") + ".json";
    public static final String TESTCASEPATH = BASEPATH + "scripts/testcases.xlsx";
}
