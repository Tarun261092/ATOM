package automation.library.selenium.exec.driver.factory;

import automation.library.selenium.exec.driver.util.DriverContextUtil;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.Map;

/**
 * Used to hold the execution context including scenario, properties and platform/browser combo
 * for each execution thread
 */
public class DriverContext {

    private static ThreadLocal<DriverContext> instance = ThreadLocal.withInitial(DriverContext::new);
    private Map<String, String> techStack = null;
    private Map<String, String> mobileTechStack = null;
    private boolean keepBrowserOpen = false;
    private DriverManager browserDriverManager;
    private DriverManager mobileDriverManager;  

    private DriverContext() {
    }

    public static synchronized DriverContext getInstance() {
        return instance.get();
    }

    public static void removeInstance() {
        instance.remove();
    }

    public void setDriverContext(Map<String, String> techStack) {
        setTechStack(techStack);
    }

    public void updateDriverContext(String browserName) {
        DriverContextUtil.updateDriverContext(browserName);
    }

    public void updateDriverPath(String browserName) {
        DriverContextUtil.updateDriverPath(browserName);
    }


    public Map<String, String> getTechStack() {
        return this.techStack;
    }

    public String getBrowserName() {
        if (techStack == null) {
            return null;
        } else {
            return this.techStack.get("browserName") == null ? this.techStack.get("browser") : this.techStack.get("browserName");
        }
    }

    public String getBrowserVersion() {
        if (techStack == null) {
            return null;
        } else {
            return this.techStack.get("version") == null ? this.techStack.get("browser_version") : this.techStack.get("version");
        }
    }

    public String getPlatform() {
        if (techStack == null) {
            return null;
        } else {
            return this.techStack.get("platform") == null ? this.techStack.get("os") + "_" + this.techStack.get("os_version") : this.techStack.get("platform");
        }
    }

    public void setTechStack(Map<String, String> techStack) {
        this.techStack = techStack;
    }

    public Boolean getKeepBrowserOpen() {
        return this.keepBrowserOpen;
    }

    public void setKeepBrowserOpen(Boolean val) {
        this.keepBrowserOpen = val;
    }

    public WebDriver getDriver() {
        if (browserDriverManager == null) {
            browserDriverManager = DriverFactory.createDriver();
        }

        return browserDriverManager.getDriver();
    }

    public WebDriverWait getWait() {
        return browserDriverManager.getWait();
    }

    public void quit() {
        if (browserDriverManager != null) {
            browserDriverManager.quitDriver();
        }
    }

    public WebDriver getMobileDriver() {
        if (mobileDriverManager == null) {
            mobileDriverManager = MobileDriverFactory.createDriver();
        }

        return mobileDriverManager.getDriver();
    }

    public WebDriverWait getMobileWait() {
        return mobileDriverManager.getWait();
    }

    public void switchContext(String context) {
        if (mobileDriverManager != null) {
            mobileDriverManager.switchContext(context);
        }
    }

    public void quitMobile() {
        if (mobileDriverManager != null) {
            mobileDriverManager.quitDriver();
        }
    }

    public DriverManager driverManager() {
        return browserDriverManager;
    }

    public DriverManager mobileDriverManager() {
        return mobileDriverManager;
    }

    public Map<String, String> getMobileTechStack() {
        return this.mobileTechStack;
    }

    public void setMobileTechStack(Map<String, String> mobileTechStack) {
        this.mobileTechStack = mobileTechStack;
    }
    
    public boolean isMobileDriverRunning() {
    	if (mobileDriverManager != null)
    		return mobileDriverManager.isDriverRunning();
    	else
    		return false;
    }
    
    public boolean isDriverRunning() {
    	if (browserDriverManager != null)
    		return browserDriverManager.isDriverRunning();
    	else
    		return false;
    }   
}
