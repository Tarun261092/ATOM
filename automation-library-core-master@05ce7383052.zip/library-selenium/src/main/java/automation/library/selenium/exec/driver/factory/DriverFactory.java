package automation.library.selenium.exec.driver.factory;

import automation.library.selenium.exec.driver.enums.BrowserType;
import automation.library.selenium.exec.driver.enums.ServerType;
import automation.library.selenium.exec.driver.managers.*;

/**
 * Create WebDriver using Factory pattern
 * Supports remote execution via Saucelabs / BrowserStack / Selenium Grid or local execution.
 * <p>
 * The use of either saucelabs/grid/local is set in the Context instance for
 * the execution thread (via the TestNG DataProvider). For saucelabs or grid then the address
 * of the target host and any credentials are specified in the project properties file.
 * <p>
 * For local execution the broswers currently supported are Firefox, Chrome, IE, Edge,
 * Safari, HTML Unit and Phantom JS but this can be extended as needed by adding further
 * DriverManager classes.
 * <p>
 * The locations of the required drivers/binaries are specified in the project properties file.
 */

public class DriverFactory {

    protected DriverFactory() {
    }

    public static DriverManager createDriver() {
        return new DriverFactory().setDM();
    }

    public DriverManager setDM() {
        ServerType serverType = ServerType.get(DriverContext.getInstance().getTechStack().get("seleniumServer"));
        BrowserType browserType = BrowserType.get(DriverContext.getInstance().getBrowserName());

        switch (serverType) {
            case GRID:
                return new GridDriverManager();
            case SAUCELABS:
                return new SauceLabsDriverManager();
            case BROWSERSTACK:
                return new BrowserStackDriverManager();
            case APPIUM:
                return new AppiumDriverManager();
            default:
                switch (browserType) {
                    case CHROME:
                        return new ChromeDriverManager();
                    case FIREFOX:
                        return new FirefoxDriverManager();
                    case IE:
                        return new IEDriverManager();
                    case MICROSOFTEDGE:
                        return new EdgeDriverManager();
                    case SAFARI:
                        return new SafariDriverManager();
                    case PHANTOMJS:
                        return new PhantomJSDriverManager();
                    case HTMLUNIT:
                        return new HTMLUnitDriverManager();
                    default:
                        throw new UnsupportedOperationException("Invalid driver type provided: " + browserType);
                }
        }

    }
} 