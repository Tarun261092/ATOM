package automation.library.selenium.exec.driver.managers;

import automation.library.common.Property;
import automation.library.selenium.core.Constants;
import automation.library.selenium.exec.driver.factory.DriverManager;
import automation.library.selenium.exec.driver.factory.MobileCapabilities;
import automation.library.selenium.exec.driver.factory.PerfectoHttpClientFactory;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileCommand;
import io.appium.java_client.MobileDriver;
import io.appium.java_client.remote.AppiumCommandExecutor;
import org.apache.commons.configuration2.PropertiesConfiguration;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.http.HttpClient;
import org.openqa.selenium.remote.internal.OkHttpClient;

import java.net.InetSocketAddress;
import java.net.MalformedURLException;
import java.net.Proxy;
import java.net.URL;
import java.util.concurrent.TimeUnit;

public class PerfectoDriverManager extends DriverManager {
    protected Logger log = LogManager.getLogger(this.getClass().getName());

    @Override
    public void createDriver() {
        MobileCapabilities cap = new MobileCapabilities();
        cap.getCap().setCapability("securityToken", Property.getVariable("cukes.perfectoSecurityToken"));
        driver = waitForConnection(cap.getCap());
    }

    private WebDriver waitForConnection(DesiredCapabilities cap) {
        try {
            driver = sleepAndRetryConnect(cap);
        } catch (InterruptedException e) {
            log.error(e);
            Thread.currentThread().interrupt();
        }
        return driver;
    }

    private WebDriver sleepAndRetryConnect(DesiredCapabilities cap) throws InterruptedException {
        int maxWaitTime = Integer.parseInt(System.getProperty("fw.maxWaitTime"));
        int waitBetweenConnectionRequest = Integer.parseInt(System.getProperty("fw.waitBetweenConnectionRequest"));

        log.debug("Waiting for mobile connection...");
        for (int totalTimeWaited = 0; totalTimeWaited <= maxWaitTime; totalTimeWaited += waitBetweenConnectionRequest) {
            try {
                driver = connectViaProxy(cap);
                if (driver != null) {
                    return driver;
                }
            }catch (WebDriverException e){
                Thread.sleep(waitBetweenConnectionRequest);
                if(totalTimeWaited<maxWaitTime) {
                    log.debug("Connection not established. Waiting {} ms and will re-check", waitBetweenConnectionRequest);
                }
                else {
                    log.error("Maximum time limit of {} ms reached and connection has not established. Aborting test", maxWaitTime);
                    throw e;
                }
            }
        }
        return driver;
    }

    @Override
    public void updateResults(String result) {
        //not used
    }

    public MobileDriver connectViaProxy(DesiredCapabilities caps) {
        PropertiesConfiguration mobileProps = Property.getProperties(Constants.MOBILERUNTIMEPATH);
        String httpProtocol = Boolean.parseBoolean(mobileProps.getString("perfecto.useHTTPS")) ? "https://" : "http://";
        String perfectoHost = Property.getVariable("cukes.perfectoHost");
        String perfectoServerAddress = httpProtocol + perfectoHost + "/nexperience/perfectomobile/wd/hub";
        String proxyHost = String.valueOf(mobileProps.getString("perfecto.proxyHost"));
        int proxyPort = Integer.parseInt(mobileProps.getString("perfecto.proxyPort"));

        URL url;
        try {
            url = new URL(perfectoServerAddress);
        } catch (MalformedURLException e) {
            log.error(e.getMessage());
            throw new IllegalStateException(e.getMessage(), e);
        }

        okhttp3.OkHttpClient.Builder client = new okhttp3.OkHttpClient.Builder()
                .connectTimeout(60, TimeUnit.SECONDS)
                .writeTimeout(60, TimeUnit.SECONDS)
                .readTimeout(60, TimeUnit.SECONDS)
                .proxy(new Proxy(Proxy.Type.HTTP, new InetSocketAddress(proxyHost, proxyPort)));

        HttpClient.Factory factory = new PerfectoHttpClientFactory(new OkHttpClient(client.build(), url));
        AppiumCommandExecutor executor = new AppiumCommandExecutor(MobileCommand.commandRepository, url, factory);
        return new AppiumDriver(executor, caps);
    }

}