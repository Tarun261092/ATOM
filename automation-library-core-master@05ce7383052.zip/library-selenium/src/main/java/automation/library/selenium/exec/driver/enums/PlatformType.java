package automation.library.selenium.exec.driver.enums;

import java.util.Arrays;
import java.util.Optional;

public enum PlatformType {
    IOS("ios"),
    ANDROID("android");

    private String platformName;

    PlatformType(String platformName) {
        this.platformName = platformName;
    }

    public String getPlatformName() {
        return platformName;
    }

    public static PlatformType get(String platformName) {
        Optional<PlatformType> first = Arrays.stream(PlatformType.values())
                                             .filter(platform -> platform.getPlatformName()
                                                                         .equalsIgnoreCase(platformName))
                                             .findFirst();
        return first.orElse(null);
    }
}
