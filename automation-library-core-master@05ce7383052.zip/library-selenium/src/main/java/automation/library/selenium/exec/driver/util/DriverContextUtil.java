package automation.library.selenium.exec.driver.util;

import automation.library.common.JSONHelper;
import automation.library.selenium.exec.driver.factory.DriverContext;

import java.util.List;
import java.util.Map;

import static automation.library.selenium.exec.ExecConstants.SELENIUMSTACKSPATH;

public class DriverContextUtil {
    private static final String CUKESDRIVERPATH = "cukes.driverPath";
    private static final String IEDRIVERSERVER = "IEDriverServer";
    private static final String CHROMEDRIVER = "chromedriver";
    private static final String MSEDGEDRIVER ="msedgedriver";

    private DriverContextUtil() {
        //Utility class
    }

    public static void updateDriverContext(String browserName) {
        Map<String, String> currentTeckStackMap = DriverContext.getInstance().getTechStack();
        String currentTechStack = System.getProperty("cukes.techstack");
        String newTechStack = "";
        switch (browserName) {
            case "internet explorer":
                newTechStack = currentTeckStackMap.get("seleniumServer").equalsIgnoreCase("grid") ? "GRID_WINDOWS_IE" : "LOCAL_IE";
                break;
            case "chrome":
                newTechStack = currentTeckStackMap.get("seleniumServer").equalsIgnoreCase("grid") ? "GRID_LINUX_CHROME" : "LOCAL_CHROME";
                break;
            case "microsoftedge":
                newTechStack = currentTeckStackMap.get("seleniumServer").equalsIgnoreCase("grid") ? "GRID_WINDOWS_MSEDGE" : "LOCAL_MSEDGE";
                break;

            default:
                break;
        }
        System.setProperty("cukes.techstack", newTechStack);
        List<Map<String, String>> listOfTechStacks = JSONHelper.getJSONAsListOfMaps(SELENIUMSTACKSPATH.replace(currentTechStack,
                                                                                                               newTechStack));
        DriverContext.getInstance().setDriverContext(listOfTechStacks.get(0));
    }

    public static void updateDriverPath(String browserName) {
        String driverPath = System.getProperty(CUKESDRIVERPATH);
        if (driverPath != null) {
            switch (browserName) {
                case "chrome":
                    driverPath = getChromePath(driverPath);
                    break;
                case "internet explorer":
                    driverPath = getIEDriverPath(driverPath);
                    break;
                case "microsoftedge":
                    driverPath = getMsEdgePath(driverPath);
                    break;
                default:
                    break;
            }
            System.setProperty(CUKESDRIVERPATH, driverPath);

        }
    }

    private static String getIEDriverPath(String driverPath) {
        if (driverPath.contains(CHROMEDRIVER)) {
            if (driverPath.contains("Program Files")) {
                driverPath = System.getProperty(CUKESDRIVERPATH).replace(CHROMEDRIVER, "IE drivers\\IEDriverServer");
            } else {
                driverPath = System.getProperty(CUKESDRIVERPATH).replace(CHROMEDRIVER, IEDRIVERSERVER);
            }
        }
        return driverPath;
    }

    private static String getChromePath(String driverPath) {
        if (driverPath.contains(IEDRIVERSERVER)) {
            if (driverPath.contains("Program Files")) {
                driverPath = System.getProperty(CUKESDRIVERPATH).replace("IE drivers\\IEDriverServer", CHROMEDRIVER);
            } else {
                driverPath = System.getProperty(CUKESDRIVERPATH).replace(IEDRIVERSERVER, CHROMEDRIVER);
            }
        }
        return driverPath;
    }
    
    private static String getMsEdgePath(String driverPath) {
        if (driverPath.contains(IEDRIVERSERVER)) {
            if (driverPath.contains("Program Files")) {
                driverPath = System.getProperty(CUKESDRIVERPATH).replace("Selenium drivers\\IE drivers\\IEDriverServer","Edge drivers\\msedgedriver");
            } else {
                driverPath = System.getProperty(CUKESDRIVERPATH).replace(IEDRIVERSERVER, MSEDGEDRIVER);
            }
        }
        return driverPath;
        
    }
}
