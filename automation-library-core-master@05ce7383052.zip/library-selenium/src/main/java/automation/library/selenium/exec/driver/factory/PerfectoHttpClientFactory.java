package automation.library.selenium.exec.driver.factory;

import org.openqa.selenium.remote.http.HttpClient.Builder;
import org.openqa.selenium.remote.internal.OkHttpClient;

import java.net.URL;

public class PerfectoHttpClientFactory
        implements org.openqa.selenium.remote.http.HttpClient.Factory {
    final OkHttpClient okHttpClient;

    public PerfectoHttpClientFactory(OkHttpClient okHttpClient) {
        this.okHttpClient = okHttpClient;
    }

    @Override
    public org.openqa.selenium.remote.http.HttpClient createClient(URL url) {
        return okHttpClient;
    }

    @Override
    public void cleanupIdleClients() {
        //left empty intentionally
    }

    @Override
    public Builder builder() {
        return null;
    }
}