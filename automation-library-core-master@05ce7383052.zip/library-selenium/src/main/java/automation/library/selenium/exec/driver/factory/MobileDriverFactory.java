package automation.library.selenium.exec.driver.factory;

import automation.library.common.JSONHelper;
import automation.library.selenium.exec.ExecConstants;
import automation.library.selenium.exec.driver.enums.ServerType;
import automation.library.selenium.exec.driver.managers.PerfectoDriverManager;

import java.util.List;
import java.util.Map;

/**
 * Create mobile web driver using Factory pattern
 * The locations of the required drivers/binaries are specified in the project properties file.
 */

public class MobileDriverFactory {

    public static DriverManager createDriver() {
        return new MobileDriverFactory().setDM();
    }

    protected MobileDriverFactory() {
    }


    public DriverManager setDM() {
        List<Map<String, String>> listOfMobileTechStacks = JSONHelper.getJSONAsListOfMaps(ExecConstants.SELENIUMMOBILESTACKSPATH);
        DriverContext.getInstance().setMobileTechStack(listOfMobileTechStacks.get(0));
        ServerType serverType = ServerType.get(DriverContext.getInstance().getMobileTechStack().get("seleniumServer"));
        switch (serverType) {
            case PERFECTO:
                return new PerfectoDriverManager();
            default:
                throw new UnsupportedOperationException("Invalid mobile driver type provided: " + serverType);
        }

    }
}