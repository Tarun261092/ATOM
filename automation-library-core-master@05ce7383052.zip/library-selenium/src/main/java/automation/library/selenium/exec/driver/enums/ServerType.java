package automation.library.selenium.exec.driver.enums;

import java.util.Arrays;
import java.util.Optional;

public enum ServerType {
    LOCAL("local"),
    GRID("grid"),
    SAUCELABS("saucelabs"),
    BROWSERSTACK("browserstack"),
    APPIUM("appium"),
    PERFECTO("perfecto");

    private String serverName;

    ServerType(String serverName) {
        this.serverName = serverName;
    }

    public String getServerName() {
        return serverName;
    }

    public static ServerType get(String serverName) {
        Optional<ServerType> first = Arrays.stream(ServerType.values())
                                           .filter(server -> server.getServerName()
                                                                   .equalsIgnoreCase(serverName))
                                           .findFirst();
        return first.orElse(LOCAL);
    }
}
