package automation.library.selenium.exec.driver.managers;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Map;

import org.apache.commons.io.FileDeleteStrategy;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;

import automation.library.common.FileHelper;
import automation.library.common.Property;
import automation.library.selenium.exec.driver.factory.Capabilities;
import automation.library.selenium.exec.driver.factory.DriverManager;
import io.github.bonigarcia.wdm.WebDriverManager;

public class EdgeDriverManager extends DriverManager {

	protected Logger log = LogManager.getLogger(this.getClass().getName());


	@Override
	public void createDriver(){
		Capabilities cap = new Capabilities();
		if (Property.getVariable("cukes.webdrivermanager") != null && Property.getVariable("cukes.webdrivermanager").equalsIgnoreCase("true")) {
    		if (Property.getVariable("cukes.edgeDriver")!=null) {
				WebDriverManager.edgedriver().browserVersion(Property.getVariable("cukes.edgeDriver")).setup();
			}else {
				WebDriverManager.edgedriver().setup();
			}
    	}else {
		System.setProperty("webdriver.edge.driver", getDriverPath("MicrosoftWebDriver"));
    	}
		
		Map<String, Object> edgePrefs = cap.getCap().asMap();
		EdgeOptions options = new EdgeOptions();
		options.setCapability("prefs", edgePrefs);
		
		if (Boolean.parseBoolean(System.getProperty("fw.browserHistoryAndCacheClearForEdge"))) {
			FileOutputStream outputStream = null;
			try {
				Process process;
				process = Runtime.getRuntime().exec("taskkill /IM msedge.exe /T /F");
				Thread.sleep(5000);
				File bookmarksFile = new File(
						String.format("C:\\Users\\%s\\AppData\\Local\\Microsoft\\Edge\\User Data\\Default\\Bookmarks",
								System.getenv("username")));
				String bookmarksContent = FileHelper.getFileAsString(bookmarksFile.getAbsolutePath(), " ");
				File fin = new File(String.format("C:\\Users\\%s\\AppData\\Local\\Microsoft\\Edge\\User Data",
						System.getenv("username")));
				File[] finlist = fin.listFiles();       
			    for (int n = 0; n < finlist.length; n++) {
					System.gc();
			        Thread.sleep(2000);
					FileDeleteStrategy.FORCE.delete(finlist[n]);
				}
				new File(String.format("C:\\Users\\%s\\AppData\\Local\\Microsoft\\Edge\\User Data\\Default",
						System.getenv("username"))).mkdirs();
				new File(String.format("C:\\Users\\%s\\AppData\\Local\\Microsoft\\Edge\\User Data\\Default\\Bookmarks",
						System.getenv("username"))).createNewFile();

				outputStream = new FileOutputStream(
						String.format("C:\\Users\\%s\\AppData\\Local\\Microsoft\\Edge\\User Data\\Default\\Bookmarks",
								System.getenv("username")));
				byte[] strToBytes = bookmarksContent.getBytes();
				outputStream.write(strToBytes);
				

			} catch (Exception e) {
				e.printStackTrace();
			}
			finally {
				if (outputStream != null) {
					try {
						outputStream.close();
					} catch (IOException e1) {
						e1.printStackTrace();
					}
				}
			}
		}
		
		driver = new EdgeDriver(options);		
	}

	@Override
	public void updateResults(String result){
		//do nothing
	}
} 