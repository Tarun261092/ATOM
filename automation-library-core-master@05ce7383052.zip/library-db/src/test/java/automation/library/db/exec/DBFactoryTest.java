package automation.library.db.exec;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class DBFactoryTest {
	
	private static DBContext DbContext = DBContext.getInstance();
	
	@Test
    public void createDBTestForOracle() {
		DbContext.setDatabaseType("oracle");
		assertThat(DBFactory.createDB()).isNotNull();
    }
	
	@Test
    public void createDBTestForTeradata() {
		DbContext.setDatabaseType("teradata");
		assertThat(DBFactory.createDB()).isNotNull();
    }
	
	@Test
    public void createDBTestForDB2() {
		DbContext.setDatabaseType("db2");
		assertThat(DBFactory.createDB()).isNotNull();
    }
	
	@Test
    public void createDBTestForMongo() {
		System.setProperty("cukes.env", "UAT");
		DbContext.setDatabaseType("mongo");
		DbContext.setAppName("sawgrass");
		assertThat(DBFactory.createDB()).isNotNull();
    }
	
	@Test
    public void createDBTestForSQLServer() {
		DbContext.setDatabaseType("sqlserver");
		assertThat(DBFactory.createDB()).isNotNull();
    }

}