package automation.library.db.exec;

import static org.assertj.core.api.Assertions.assertThat;

import java.sql.Connection;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

public class DBContextTest {
    private static String appName = "appName";
    private static String databaseType = "Oracle";
    private static String databaseURL = "URL";
    private static Connection conn = Mockito.mock(Connection.class);
    private static boolean isConnActive = true;
    private static String databaseName = "OracleDB";
    private static DBContext DbContext = DBContext.getInstance();
    
    @BeforeAll
	 public static void beforeAllTestMethods() {
    	DbContext.setDatabaseType(databaseType);
    	DbContext.setDatabaseName(databaseName);
    	DbContext.setDatabaseURL(databaseURL);
    	DbContext.setSQLConnection(conn);
    	DbContext.setAppName(appName);
    	DbContext.setConnActive(isConnActive);
    }
    
    @Test
    public void getDatabaseTypeTest()
    {
        assertThat(DbContext.getDatabaseType()).isNotNull();
    }

    @Test
    public void getDatabaseURLTest()
    {
        assertThat(DbContext.getDatabaseURL()).isNotNull();
    }

    @Test
    public void getAppNameTest() {
    	assertThat(DbContext.getAppName()).isNotNull();
    }

    @Test
    public void isConnActiveTest() {
    	assertThat(DbContext.isConnActive()).isNotNull();
    }
    
    @Test
	public void getMongoClientTest() {
    	assertThat(DbContext.getMongoClient()).isNull();
	}
    
    @Test
   	public void getSQLConnTest() {
       	assertThat(DbContext.getSQLConnection()).isNotNull();
   	}
    
    @Test
   	public void executeQueryTest() {
       	assertThat(DbContext.executeQuery("query")).isNotNull();
   	}

}