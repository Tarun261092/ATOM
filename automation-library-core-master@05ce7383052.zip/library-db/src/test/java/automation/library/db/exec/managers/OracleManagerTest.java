package automation.library.db.exec.managers;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.File;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.ResultSet;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import automation.library.db.exec.DBContext;
import automation.library.db.exec.DBManager;

public class OracleManagerTest {
	
	private static DBContext DbContext = DBContext.getInstance();
	private static String path;
	private static Connection conn = Mockito.mock(Connection.class);
	OracleManager manager = new OracleManager();
	
	@BeforeAll
	 public static void beforeAllTestMethods() {
		 path = new File("src/test/resources/securetext-UAT.properties").getAbsolutePath();
		 DbContext.setAppName("sawgrass");
		 DbContext.setDatabaseName("oracle");
		 DbContext.setDatabaseType("SQL");
		 DbContext.setDatabaseURL("URL");
		 DbContext.setSQLConnection(conn);
	 }
    
    @Test
    public void getDBUserNameTest() {
    	
    	Class clazz = DBManager.class;
        Method method;
        
		try {
				Object object = clazz.newInstance();
				method = clazz.getDeclaredMethod("getDBUserName", new Class[]{String.class});
			    method.setAccessible(true);
			    assertThat(method.invoke(object, "obj")).isNotNull();
			    
			} catch (InstantiationException | NoSuchMethodException | SecurityException  | IllegalAccessException | InvocationTargetException e) {
				}	
    }
    
    @Test
    public void getDBPasswordTest() {
    	
    	Class clazz = DBManager.class;
        Method method;
        
		try {
				Object object = clazz.newInstance();
				method = clazz.getDeclaredMethod("getDBPassword", new Class[]{String.class});
			    method.setAccessible(true);
			    assertThat(method.invoke(object, "obj")).isNotNull();
			    
			} catch (InstantiationException | NoSuchMethodException | SecurityException  | IllegalAccessException | InvocationTargetException e) {
				}	
    }
    
    @Test
    public void getDatabaseNameTest() {
    	
    	Class clazz = DBManager.class;
        Method method;
        
		try {
				Object object = clazz.newInstance();
				method = clazz.getDeclaredMethod("getDatabaseName");
			    method.setAccessible(true);
			    assertThat(method.invoke(object, "obj")).isNotNull();
			    
			} catch (InstantiationException | NoSuchMethodException | SecurityException  | IllegalAccessException | InvocationTargetException e) {
				}	
    }
    
    @Test
    public void getPathToEnvPropsTest() {
    	
    	Class clazz = DBManager.class;
        Method method;
        
		try {
				Object object = clazz.newInstance();
				method = clazz.getDeclaredMethod("getPathToEnvProps");
			    method.setAccessible(true);
			    assertThat(method.invoke(object, "obj")).isNotNull();
			    
			} catch (InstantiationException | NoSuchMethodException | SecurityException  | IllegalAccessException | InvocationTargetException e) {
				}	
    }
    
    @Test
    public void executeSQLDBQueryTest() {
    	
    	Class clazz = DBManager.class;
        Method method;
        
		try {
				Object object = clazz.newInstance();
				method = clazz.getDeclaredMethod("executeSQLDBQuery", new Class[]{String.class});
			    method.setAccessible(true);
			    assertThat(method.invoke(object, "select 1 from dual")).isNotNull();
			    
			} catch (InstantiationException | NoSuchMethodException | SecurityException  | IllegalAccessException | InvocationTargetException e) {
				}	
    }
    
    @Test
    public void readDatabaseRowsTest() {
    	
    	Class clazz = DBManager.class;
        Method method;
        ResultSet rs = Mockito.mock(ResultSet.class);
        
		try {
				Object object = clazz.newInstance();
				method = clazz.getDeclaredMethod("readDatabaseRows", new Class[]{ResultSet.class});
			    method.setAccessible(true);
			    assertThat(method.invoke(object, rs)).isNotNull();
			    
			} catch (InstantiationException | NoSuchMethodException | SecurityException  | IllegalAccessException | InvocationTargetException e) {
				}	
    }
 
 
    

}