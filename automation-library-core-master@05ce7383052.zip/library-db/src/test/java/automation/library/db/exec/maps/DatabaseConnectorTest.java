package automation.library.db.exec.maps;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

public class DatabaseConnectorTest {
	
	DatabaseConnector connector = new DatabaseConnector();
   
	@Test
	public void getSetDbDriverTest() {
		connector.setDbDriver("dbDriver");
		assertThat(connector.getDbDriver()).isNotNull();;
	}
	
	@Test
	public void getSetDbURLTest() {
		connector.setDbURL("dbURL");
		assertThat(connector.getDbURL()).isNotNull();
	}

}