package automation.library.db.exec.maps;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

public class AppTest {
	App app = new App();
 
	@Test
	public void getSetDatabaseToUseTest()
	{
		app.setDatabaseToUse("Oracle");
		assertThat(app.getDatabaseToUse()).isNotNull();
	}

}