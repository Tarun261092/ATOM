package automation.library.db.exec.managers;

import automation.library.common.Property;
import automation.library.common.TestContext;
import automation.library.db.exec.DBContext;
import automation.library.db.exec.DBManager;
import com.google.gson.Gson;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.ReadContext;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions;
import com.mongodb.MongoClientURI;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;
import org.bson.conversions.Bson;
import org.bson.json.JsonParseException;

import java.util.*;
import java.util.stream.Collectors;

import static automation.library.db.core.Constants.ENVIRONMENTPATH;

public class MongoManager extends DBManager {

    private static final String ENV_PROP = "cukes.env";
    private final String dbURL = DBContext.getInstance().getDatabaseURL();
    private final String dbUserName = getDBUserName(getPathToEnvProps());
    private final String dbPassword = getDBPassword(getPathToEnvProps());
    private final String databaseName = getDatabaseName();
    private static final String JAVAX_NET_SSL_TRUST_STORE = "javax.net.ssl.trustStore";
    private String currentCertFile = "";

    @Override
    protected void createConnection() {
        final String uri = String.format("mongodb://%s:%s@%s%s?authSource=admin&ssl=true", dbUserName, dbPassword, dbURL, databaseName);
        final String propsFilePath = ENVIRONMENTPATH + Property.getVariable(ENV_PROP) + PROPERTIES_EXT;
        final String certificateKey = String.join("_",
                                                  DBContext.getInstance().getAppName(),
                                                  DBContext.getInstance().getDatabaseType(),
                                                  "certs");

        currentCertFile = Property.getVariable(JAVAX_NET_SSL_TRUST_STORE);
        final String certificatePath = ENVIRONMENTPATH + Property.getProperty(propsFilePath, certificateKey);
        System.setProperty(JAVAX_NET_SSL_TRUST_STORE, certificatePath);

        MongoClientOptions.builder().sslEnabled(true).build();

        try {
            MongoClientURI mongoClientUri = new MongoClientURI(uri);
            mongoClient = new MongoClient(mongoClientUri);
            MongoDatabase database = mongoClient.getDatabase(databaseName);
            if (database != null) {
                DBContext.getInstance().setDatabaseName(databaseName);
            }
            DBContext.getInstance().setConnActive(true);
        } catch (Exception e) {
            log.error("Unable to connect to DB");
            throw e;
        }
    }

    @Override
    public void closeConnection() {
        if (mongoClient != null) {
            mongoClient.close();
            DBContext.getInstance().setConnActive(false);
            log.debug("database connection closed successfully:");
            System.setProperty(JAVAX_NET_SSL_TRUST_STORE, currentCertFile);
        } else {
            log.warn("Mongo DB connection is not open.");
        }
    }

    @Override
    protected List<Map<String, Object>> runQuery(String query) {
        Map<String, Object> map = new Gson().fromJson(query, Map.class);
        final String collectionName = (String) getQueryAttribute("mongoCollection", map);
        final String jsonPathForResultBody = getJsonPath((String) getQueryAttribute("resultParam", map));
        final Document queryBson = getBson(map.get("query"));
        final Document sortBson = getBson(map.get("sort"));
        final Document matchBson = getBson(map.get("match"));
        final Document groupBson = getBson(map.get("group"));
        final Document projectBson = getBson(map.get("project"));
        final String totalCountRequired = (String) map.get("totalCollectionCount");
        final MongoCollection<Document> collection = mongoClient.getDatabase(databaseName)
                                                                .getCollection(collectionName);
        List<Map<String, Object>> resultList;

        if (!matchBson.isEmpty() && !groupBson.isEmpty() && !projectBson.isEmpty()) {
            resultList = getAggregateQueryResultList(collection, matchBson, groupBson, projectBson);
        } else {
            resultList = getQueryResultList(collection, queryBson, sortBson, totalCountRequired, jsonPathForResultBody);
        }

        return resultList;
    }

    private String getJsonPath(String paramName) {
        if (paramName != null && !paramName.isEmpty()) {
            StringJoiner jsonPath = new StringJoiner(".");
            jsonPath.add("$");
            jsonPath.add(paramName);
            return jsonPath.toString();
        } else {
            return "$";
        }
    }

    private Object getQueryAttribute(String attributeName, Map<String, Object> queryMap) {
        Object attributeVal = queryMap.get(attributeName);

        if (attributeVal == null) {
            throw new IllegalArgumentException(String.format("No value provided for %s. Please update the query.", attributeName));
        } else {
            return attributeVal;
        }
    }

    private Document getBson(Object jsonString) {
        try {
            if (jsonString != null) {
                return Document.parse(new Gson().toJson(jsonString));
            }
        } catch (JsonParseException e) {
            log.error("Unable to parse query string: {}. Querying with empty JSON body.", e.getMessage());
        }

        return Document.parse("{}");
    }

    private List<Map<String, Object>> getAggregateQueryResultList(MongoCollection<Document> collection, Document matchBson, Document groupBson, Document projectBson) {

        List<Map<String, Object>> resultList = new ArrayList<>();
        Map<String, Object> resultSet;

        List<Bson> aggregationList = Arrays.asList(matchBson, groupBson, projectBson);

        try (MongoCursor<Document> cursor = collection.aggregate(aggregationList).iterator()) {
            while (cursor.hasNext()) {

                if (System.getProperty("fw.dbNullFlag").equals("false")) {

                    String resultString = String.valueOf(cursor.next().toJson());
                    resultSet = new Gson().fromJson(resultString, Map.class);
                    resultList.add(resultSet.entrySet().stream().filter(entry -> entry.getKey() != null)
                                            .filter(entry -> entry.getValue() != null)
                                            .collect((Collectors.toMap(entry -> entry.getKey().toUpperCase(), Map.Entry::getValue))));
                } else {
                    String resultString = String.valueOf(cursor.next().toJson());
                    resultSet = new Gson().fromJson(resultString, Map.class);
                    resultList.add(resultSet.entrySet().stream().filter(entry -> entry.getKey() != null)
                                            .collect(Collectors.toMap(entry -> entry.getKey().toUpperCase(),
                                                                      entry -> Optional.ofNullable(entry.getValue()).orElse("null"))));
                }
            }
        }

        return resultList;
    }

    private List<Map<String, Object>> getQueryResultList(MongoCollection<Document> collection, Document queryBson, Document sortBson, String totalCountRequired, String jsonPathForResultBody) {

        List<Map<String, Object>> resultList = new ArrayList<>();
        Map<String, Object> resultSet;

        try (MongoCursor<Document> cursor = collection.find(queryBson).sort(sortBson)
                                                      .limit(Integer.parseInt(System.getProperty("fw.DBMaxRowCount"))).iterator()) {
            while (cursor.hasNext()) {
                if (System.getProperty("fw.dbNullFlag").equals("false")) {

                    ReadContext ctx = JsonPath.parse(String.valueOf(cursor.next().toJson()));
                    resultSet = ctx.read(jsonPathForResultBody, Map.class);
                    resultList.add(resultSet.entrySet().stream().filter(entry -> entry.getKey() != null)
                                            .filter(entry -> entry.getValue() != null)
                                            .collect((Collectors.toMap(entry -> entry.getKey().toUpperCase(), Map.Entry::getValue))));
                } else {
                    ReadContext ctx = JsonPath.parse(String.valueOf(cursor.next().toJson()));
                    resultSet = ctx.read(jsonPathForResultBody, Map.class);
                    resultList.add(resultSet.entrySet().stream().filter(entry -> entry.getKey() != null)
                                            .collect(Collectors.toMap(entry -> entry.getKey().toUpperCase(),
                                                                      entry -> Optional.ofNullable(entry.getValue()).orElse("null"))));
                }
            }
        }

        log.info("Total Collection Count Required: "+totalCountRequired);
        if(totalCountRequired!=null&&totalCountRequired.equalsIgnoreCase("yes")) {
	        String collectionRecordsCount = String.valueOf(collection.countDocuments());
	        TestContext.getInstance().testdataPut("MongoDBCollectionRecordsCount", collectionRecordsCount);
        }

        String queryResultsCount = String.valueOf(collection.countDocuments(queryBson));
        TestContext.getInstance().testdataPut("MongoDBQueryResultsCount", queryResultsCount);

        return resultList;
    }

}
