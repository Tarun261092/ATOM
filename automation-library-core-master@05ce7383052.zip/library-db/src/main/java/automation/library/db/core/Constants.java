package automation.library.db.core;

import java.io.File;

public class Constants {
    private static final String USER_DIR = System.getProperty("user.dir");
    private static final String BASEPATH = USER_DIR + "/src/test/resources/";
    private static final String CONFIG_DB = "config/db/";
    public static final String ENVIRONMENTPATH = BASEPATH + "config/environments/";
    public static final String DBAPPPATH = BASEPATH + CONFIG_DB;
    public static final String DBRUNTIMEPATH = BASEPATH + CONFIG_DB + "runtime.properties";
    public static final String DBQUERYPATH = BASEPATH + CONFIG_DB + "query.properties";
    public static final String DBQUERYFILEPATH = USER_DIR + "/lib/sqlfiles/";

    public static final String GENERATEDCLASSPATH = USER_DIR + "/target/test-classes/";
    public static final String DBOBJECTSFOLDER = "dbobjects";
    public static final String DBOBJECTSPATH = GENERATEDCLASSPATH + DBOBJECTSFOLDER + File.separator;
    public static final String DBOBJECTSJAR = USER_DIR + "/target/lib/";
    
    public static final String CERTPATH = BASEPATH + "config/certificates/";

    private Constants() {
        //Utility class
    }
}
