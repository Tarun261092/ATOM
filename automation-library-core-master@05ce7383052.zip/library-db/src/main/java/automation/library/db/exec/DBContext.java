package automation.library.db.exec;

import com.mongodb.MongoClient;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.sql.Connection;
import java.util.Collections;
import java.util.List;
import java.util.Map;

public class DBContext {
    private static ThreadLocal<DBContext> instance = ThreadLocal.withInitial(DBContext::new);
    private Logger log = LogManager.getLogger(this.getClass().getName());
    private String appName = null;
    private String databaseType = null;
    private String databaseURL = null;
    private Connection conn = null;
    private boolean isConnActive = false;
    private String databaseName = null;
    private MongoClient mongoClient = null;
    private DBManager dbManager;

    private DBContext() {
    }

    public static synchronized DBContext getInstance() {
        return instance.get();
    }

    public static void removeInstance() {
        instance.remove();
    }

    public String getDatabaseType() {
        return databaseType;
    }

    public void setDatabaseType(String databaseType) {
        this.databaseType = databaseType;
    }

    public Connection getSQLConnection() {
        return conn;
    }

    public String getDatabaseURL() {
        return databaseURL;
    }

    public void setDatabaseURL(String databaseURL) {
        this.databaseURL = databaseURL;
    }

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public boolean isConnActive() {
        return isConnActive;
    }

    public void setConnActive(boolean isConnActive) {
        this.isConnActive = isConnActive;
    }

	public void setDatabaseName(String databaseName) {
		this.databaseName = databaseName;
	}

	public MongoClient getMongoClient() {
		return mongoClient;
	}

	public void setSQLConnection(Connection conn) {
        this.conn = conn;
    }

    public void closeConnection() {
        try {
            dbManager.closeConnection();
        } catch (Exception e) {
            log.error(e.getMessage());
        }
    }

    public void createConnection() {
        if (dbManager != null && isConnActive()) {
            closeConnection();
        } else {
            dbManager = DBFactory.createDB();
        }

        dbManager.createConnection();
    }

    public List<Map<String, Object>> executeQuery(String query) {
        if(dbManager != null) {
            return dbManager.runQuery(query);
        } else {
            return Collections.emptyList();
        }
    }

}
