package automation.library.db.exec;

import java.util.Arrays;
import java.util.Optional;

public enum DatabaseType {
    ORACLE("oracle"),
    TERADATA("teradata"),
    DB2("db2"),
    MONGO("mongo"),
    SQLSERVER("sqlserver");

    private String databaseName;

    DatabaseType(String databaseName) {
        this.databaseName = databaseName;
    }

    public String getDatabaseName() {
        return databaseName;
    }

    public static DatabaseType get(String desktopAppName) {
        Optional<DatabaseType> first = Arrays.stream(DatabaseType.values())
                                             .filter(db -> db.getDatabaseName()
                                                             .equalsIgnoreCase(desktopAppName))
                                             .findFirst();

        return first.orElse(null);
    }
}
