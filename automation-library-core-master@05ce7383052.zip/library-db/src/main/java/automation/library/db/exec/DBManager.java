package automation.library.db.exec;

import automation.library.common.EncryptionHelper;
import automation.library.common.Property;
import com.mongodb.MongoClient;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.sql.*;
import java.util.*;

import static automation.library.db.core.Constants.ENVIRONMENTPATH;

public abstract class DBManager {
    public static final String UNABLE_TO_FIND_KEY = "Unable to find '%s' key in the '%s' file.";
    protected Connection conn;
    protected MongoClient mongoClient;
    protected Logger log = LogManager.getLogger(this.getClass().getName());
    private static final String ENV_PROP = "cukes.env";
    protected static final String PROPERTIES_EXT = ".properties";

    protected abstract void createConnection();

    protected abstract void closeConnection();

    protected abstract List<Map<String, Object>> runQuery(String query);

    protected Connection createSQLDBConnection() throws SQLException {
        String propsFilePath = getPathToEnvProps();
        return createSQLDBConnection(getDBUserName(propsFilePath), getDBPassword(propsFilePath));
    }

    protected Connection createSQLDBConnection(String dbUserName, String dbPassword) throws SQLException {
        String dbURL = DBContext.getInstance().getDatabaseURL();

        conn = DriverManager.getConnection(dbURL, dbUserName, dbPassword);
        log.debug("database connection established successfully:");

        DBContext.getInstance().setConnActive(true);
        DBContext.getInstance().setSQLConnection(conn);
        return conn;
    }

    protected void closeSQLDBConnection() throws SQLException {
        if (conn != null) {
            conn.close();
            DBContext.getInstance().setConnActive(false);
            DBContext.getInstance().setSQLConnection(null);
            log.debug("database connection closed successfully:");
        }
    }

    protected String getDBUserName(String propsFilePath) {
        String userNameKey = String.join("_", DBContext.getInstance().getAppName(),
                                         DBContext.getInstance().getDatabaseType(),
                                         "dbUserName");

        String userName = Property.getProperty(propsFilePath, userNameKey);

        if (userName != null) {
            return userName;
        } else {
            throw new IllegalArgumentException(String.format(UNABLE_TO_FIND_KEY, userNameKey, propsFilePath));
        }
    }

    protected String getDBPassword(String propsFilePath) {
        String passwordKey = String.join("_", DBContext.getInstance().getAppName(),
                                         DBContext.getInstance().getDatabaseType(),
                                         "dbPassword");

        String password = EncryptionHelper.parseSecureText(propsFilePath, passwordKey);

        if (password != null) {
            return password;
        } else {
            throw new IllegalArgumentException(String.format(UNABLE_TO_FIND_KEY, passwordKey, propsFilePath));
        }
    }

    protected String getDatabaseName() {
        String propsFilePath = ENVIRONMENTPATH + Property.getVariable(ENV_PROP) + PROPERTIES_EXT;
        String databaseNameKey = String.join("_", DBContext.getInstance().getAppName(),
                                             DBContext.getInstance().getDatabaseType(),
                                             "databaseName");

        String databaseName = Property.getProperty(propsFilePath, databaseNameKey);

        if (databaseName != null) {
            return databaseName;
        } else {
            throw new IllegalArgumentException(String.format(UNABLE_TO_FIND_KEY, databaseNameKey, propsFilePath));
        }
    }

    protected String getPathToEnvProps() {
        return ENVIRONMENTPATH + "securetext-" + Property.getVariable(ENV_PROP) + PROPERTIES_EXT;
    }

    protected List<Map<String, Object>> executeSQLDBQuery(String query) {
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            int dbMaxRowCount = System.getProperty("fw.DBMaxRowCount") != null ? Integer.parseInt(System.getProperty("fw.DBMaxRowCount")) : 100;
            stmt.setMaxRows(dbMaxRowCount);

            return readDatabaseRows(rs);
        } catch (SQLException e) {
        	 List<Map<String, Object>> list = new ArrayList<>();
        	 Map<String, Object> map = new HashMap<>();
        	 map.put("Exception",e.getMessage());
        	 list.add(map);
        	 return list;
            //return Collections.emptyList();
        }
    }

    private static List<Map<String, Object>> readDatabaseRows(ResultSet rs) throws SQLException {
        List<Map<String, Object>> list = new ArrayList<>();
        ResultSetMetaData meta = rs.getMetaData();
        Clob clob = null;

        while (rs.next()) {
            Map<String, Object> map = new HashMap<>();

            for (int i = 1; i <= meta.getColumnCount(); i++) {
                String key = meta.getColumnName(i).toUpperCase();

                if (meta.getColumnType(i) == Types.CLOB) {
                    clob = rs.getClob(key);
                    String clobValue = clob.getSubString(1, (int) clob.length());
                    map.put(key, clobValue);
                } else {
                    map.put(key, rs.getObject(key));
                }
            }
            list.add(map);
        }
        return list;
    }
}
