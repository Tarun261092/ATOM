package automation.library.db.exec.managers;

import automation.library.common.EncryptionHelper;
import automation.library.db.exec.DBContext;
import automation.library.db.exec.DBManager;
import com.microsoft.sqlserver.jdbc.SQLServerDriver;

import java.io.IOException;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.Properties;

public class SQLServerManager extends DBManager {
    @Override
    public void createConnection() {
        try {
            DriverManager.registerDriver(new SQLServerDriver());

            //handle special case of analytics engine query
            if(DBContext.getInstance().getAppName().equalsIgnoreCase("NAQE") || DBContext.getInstance().getAppName().equalsIgnoreCase("BANAMEX")) {
                String dbUserName = getAEUserName();
                String dbPassword = getAEPassword();
                conn = super.createSQLDBConnection(dbUserName, dbPassword);
            } else {
                conn = super.createSQLDBConnection();
            }
        } catch (SQLException e) {
            log.error("Unable to connect to DB. {}", e.getMessage(), e);
        }
    }

    @Override
    protected void closeConnection() {
        try {
            super.closeSQLDBConnection();
        } catch (SQLException e) {
            log.error("Unable to close connection to DB. {}", e.getMessage(), e);
        }
    }

    @Override
    protected List<Map<String, Object>> runQuery(String query) {
        return super.executeSQLDBQuery(query);
    }

    private String getPropertyFromAEResources(String property) {
        final String fullPathToFile = String.format("%s/%s", "ff-lookup", "AE.properties");
        try {
            Properties propFile = new Properties();
            propFile.load(SQLServerManager.class.getClassLoader().getResourceAsStream(fullPathToFile));
            return propFile.getProperty(property);
        } catch (IOException e) {
            log.error(e);
            return null;
        }
    }


    private String getAEUserName() {
        String userNameKey = String.join("_", DBContext.getInstance().getAppName(),
                                         DBContext.getInstance().getDatabaseType(),
                                         "dbUserName");

        String userName = EncryptionHelper.parseSecureText(getPropertyFromAEResources(userNameKey));

        if (userName != null) {
            return userName;
        } else {
            throw new IllegalArgumentException(String.format(UNABLE_TO_FIND_KEY, userNameKey));
        }
    }

    private String getAEPassword() {
        String passwordKey = String.join("_", DBContext.getInstance().getAppName(),
                                         DBContext.getInstance().getDatabaseType(),
                                         "dbPassword");

        String password = EncryptionHelper.parseSecureText(getPropertyFromAEResources(passwordKey));

        if (password != null) {
            return password;
        } else {
            throw new IllegalArgumentException(String.format(UNABLE_TO_FIND_KEY, passwordKey));
        }
    }

}
