package automation.library.db.exec.managers;

import automation.library.db.exec.DBManager;
import oracle.jdbc.driver.OracleDriver;

import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

public class OracleManager extends DBManager {
    @Override
    public void createConnection() {
        try {
            DriverManager.registerDriver(new OracleDriver());
            conn = super.createSQLDBConnection();
        } catch (SQLException e) {
            log.error("Unable to connect to DB. {}", e.getMessage(), e);
        }
    }

    @Override
    protected void closeConnection() {
        try {
            super.closeSQLDBConnection();
        } catch (SQLException e) {
            log.error("Unable to close connection to DB. {}", e.getMessage(), e);
        }
    }

    @Override
    protected List<Map<String, Object>> runQuery(String query) {
        return super.executeSQLDBQuery(query);
    }

}
