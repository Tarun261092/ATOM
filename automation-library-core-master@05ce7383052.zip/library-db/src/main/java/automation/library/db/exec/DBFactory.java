package automation.library.db.exec;

import automation.library.db.exec.managers.*;
import org.apache.logging.log4j.LogManager;

public class DBFactory {
    protected DBFactory() {
    }

    public static DBManager createDB() {
    	DatabaseType databaseType = DatabaseType.get(DBContext.getInstance().getDatabaseType());

        switch(databaseType) {
            case ORACLE:
                return new OracleManager();
            case TERADATA:
            	return new TeradataManager();
            case DB2:
            	return new DB2Manager();
            case MONGO:
            	return new MongoManager();
            case SQLSERVER:
                return new SQLServerManager();
            default:
                String errorMsg = String.format("Unrecognized database type: %s", databaseType);
                LogManager.getLogger().error(errorMsg);
                throw new IllegalArgumentException(errorMsg);
        }
    }
	    
}
